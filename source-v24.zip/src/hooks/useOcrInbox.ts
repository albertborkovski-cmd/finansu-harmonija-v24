import { useEffect, useMemo, useState } from 'react';
import { canViewMenu, type AppSession } from '../lib/accessControl';
import { loadOcrDocumentSource } from '../lib/ocrDocumentSource';
import { canAccessUnassignedDocuments, canViewCompanyDocuments, canEditCompanyDocumentIssues } from '../lib/documentEditAccess';
import { canReviewDocumentIssues, canUseIssueConversation } from '../lib/documentIssueAccess';
import { canViewTeamLeadOrganization } from '../lib/ocrTeamLeadAccess';
import { loadSavedReviewDocumentTasks } from '../lib/ocrReviewDocuments';
import { buildOcrNotifications, issueViewerSide } from '../lib/ocrNotifications';
import { unreadIssueMessages } from '../lib/documentIssueConversation';
import type { Company, DbDocument } from '../lib/supabase';
import { useOrganizationAccessRevision } from '../components/useOrganizationAccessRevision';

export function useOcrInbox(session: AppSession | null, enabled = true) {
  const revision = useOrganizationAccessRevision();
  const [source, setSource] = useState<{ documents: DbDocument[]; organizations: Company[] }>({ documents: [], organizations: [] });
  const [taskRevision, setTaskRevision] = useState(0);
  const allowed = Boolean(enabled && session && (canViewMenu(session, 'uploaded-documents-documents') || canViewMenu(session, 'ocr-workspace') || canViewMenu(session, 'ocr-ml') || canViewMenu(session, 'messages')));
  useEffect(() => {
    if (!allowed) { setSource({ documents: [], organizations: [] }); return; }
    let disposed = false, request = 0;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const load = async () => {
      const id = ++request;
      try {
        const next = await loadOcrDocumentSource();
        if (!disposed && id === request) { setSource(next); setTaskRevision(current => current + 1); }
      } catch { if (!disposed && id === request) setSource({ documents: [], organizations: [] }); }
    };
    const changed = (event: Event) => {
      const table = (event as CustomEvent<{ table?: string }>).detail?.table;
      if (table && !['documents', 'companies'].includes(table)) return;
      clearTimeout(timer); timer = setTimeout(() => void load(), 80);
    };
    void load();
    const events = ['finansu-harmonija:data-changed', 'document-issues-changed', 'finansu-harmonija:persistent-state-changed', 'storage', 'focus'];
    events.forEach(name => window.addEventListener(name, changed));
    return () => { disposed = true; clearTimeout(timer); events.forEach(name => window.removeEventListener(name, changed)); };
  }, [allowed, session?.email, revision]);
  return useMemo(() => {
    const companies = new Map(source.organizations.map(company => [company.id, company]));
    const worker = canReviewDocumentIssues();
    const issueAccess = (document: DbDocument) => worker && canEditCompanyDocumentIssues(companies.get(document.company_id || ''));
    const teamLeadAccess = (document: DbDocument) => Boolean(document.company_id && companies.has(document.company_id) && canViewTeamLeadOrganization(companies.get(document.company_id)!));
    const documents = allowed ? source.documents.filter(document => document.company_id
      ? canViewCompanyDocuments(companies.get(document.company_id)) || issueAccess(document) || teamLeadAccess(document)
      : canAccessUnassignedDocuments()) : [];
    const records = session && allowed ? buildOcrNotifications(documents, loadSavedReviewDocumentTasks(documents, localStorage), {
      email: session.email, canView: () => true, canReviewIssue: issueAccess, canReviewTeamLead: teamLeadAccess,
      companyName: id => companies.get(id)?.name || '',
    }) : [];
    const conversations = session && allowed ? documents.flatMap(document => {
      const company = companies.get(document.company_id || '');
      if (!company || document.document_deletion) return [];
      return (document.digitization_issues || []).flatMap(issue => {
        const side = issueViewerSide(issue, session.email, issueAccess(document));
        if (!canUseIssueConversation(company, side) || side === 'worker' && issue.assignedToEmail && issue.assignedToEmail.toLowerCase() !== session.email.toLowerCase()) return [];
        return [{ document, company, issue, side, unread: unreadIssueMessages(issue, session.email, side).length }];
      });
    }) : [];
    return { records, documents, companies, conversations };
  }, [source, allowed, session?.email, revision, taskRevision]);
}
