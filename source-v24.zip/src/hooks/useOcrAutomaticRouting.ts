import { useEffect } from 'react';
import { canEditMenu, type AppSession } from '../lib/accessControl';
import { OCR_FIELD_VALIDATION_CHANGED_EVENT } from '../lib/ocrFieldValidation';

export function useOcrAutomaticRouting(session: AppSession) {
  useEffect(() => {
    if (!canEditMenu(session, 'ocr-workspace')) return;
    let stopped = false, running = false, queued = false;
    const refresh = async () => {
      if (running) { queued = true; return; }
      running = true;
      do {
        queued = false;
        try { if (!stopped) await (await import('../lib/supabase')).routeCompletedOcrResults(); }
        catch (error) { console.error('OCR routing could not be completed. Documents have been retained.', error); }
      } while (queued && !stopped);
      running = false;
    };
    const changed = (event: Event) => {
      const table = (event as CustomEvent<{ table?: string }>).detail?.table;
      if (!table || table === 'documents' || table === 'companies') void refresh();
    };
    const events = ['finansu-harmonija:data-changed', 'finansu-harmonija:settings-data-changed', 'finansu-harmonija:persistent-state-changed', OCR_FIELD_VALIDATION_CHANGED_EVENT, 'storage'];
    events.forEach(name => window.addEventListener(name, changed));
    void refresh();
    return () => { stopped = true; events.forEach(name => window.removeEventListener(name, changed)); };
  }, [session]);
}
