import { useEffect, useState } from 'react';
import { loadOcrStatusSettings, OCR_STATUS_DESCRIPTIONS, OCR_STATUS_SETTINGS_CHANGED, OCR_STATUS_SETTINGS_KEY } from '../lib/ocrStatuses';

function readDescriptions() {
  try {
    const custom = loadOcrStatusSettings(window.localStorage).descriptions;
    return { ...OCR_STATUS_DESCRIPTIONS, ...Object.fromEntries(Object.entries(custom).filter(([, value]) => typeof value === 'string' && value.trim())) };
  } catch {
    return OCR_STATUS_DESCRIPTIONS;
  }
}

/** One subscription per list, rather than one storage read and listener per row. */
export default function useOcrStatusDescriptions() {
  const [descriptions, setDescriptions] = useState(readDescriptions);
  useEffect(() => {
    const refresh = (event: Event) => {
      if (event.type === 'storage' && (event as StorageEvent).key && (event as StorageEvent).key !== OCR_STATUS_SETTINGS_KEY) return;
      setDescriptions(readDescriptions());
    };
    window.addEventListener(OCR_STATUS_SETTINGS_CHANGED, refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener(OCR_STATUS_SETTINGS_CHANGED, refresh);
      window.removeEventListener('storage', refresh);
    };
  }, []);
  return descriptions;
}
