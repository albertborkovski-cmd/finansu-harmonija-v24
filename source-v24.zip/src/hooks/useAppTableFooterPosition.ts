import { useCallback, useLayoutEffect, useState, type CSSProperties, type RefObject } from 'react';

interface FixedFooterPosition {
  left: number;
  width: number;
  backdropLeft: number;
  backdropWidth: number;
}

/**
 * Keeps the shared table controls in one viewport position.
 *
 * All Documents is the system reference: a 44px scrollbar immediately above
 * the 28px summary at the viewport bottom. Align to the actual table, including
 * split panes, without covering the organization selector or status panel.
 * Embedded dialog tables remain local; expanded workspaces use the same slot.
 */
export default function useAppTableFooterPosition(
  elementRef: RefObject<HTMLElement>,
  bottom: number,
  maxWidth = 1384,
  enabled = true,
  viewportRef?: RefObject<HTMLElement>,
): CSSProperties | undefined {
  const [position, setPosition] = useState<FixedFooterPosition>();

  const updatePosition = useCallback(() => {
    const element = elementRef.current;
    const expanded = element?.closest<HTMLElement>('[data-table-workspace-expanded]');
    const overlay = element?.parentElement?.closest('[role="dialog"], [aria-modal="true"], .fixed');
    if (!element || (overlay && overlay !== expanded)) {
      setPosition(undefined);
      return;
    }

    const appMain = element.closest<HTMLElement>('[data-app-main]');
    if (!appMain) {
      setPosition(undefined);
      return;
    }

    let viewport = viewportRef?.current;
    // Pagination may be wrapped in an extra summary row. Find only its own
    // list, never a neighbouring table or a table in an open dialog.
    for (let parent = element.parentElement; !viewport && parent && parent !== appMain; parent = parent.parentElement) {
      const candidates = [...parent.querySelectorAll<HTMLElement>('[data-system-table-viewport]')]
        .filter(candidate => !candidate.closest('[role="dialog"], [aria-modal="true"]'));
      if (candidates.length === 1) viewport = candidates[0];
      if (candidates.length > 1) break;
    }
    const mainRect = (expanded || appMain).getBoundingClientRect();
    const referencePadding = expanded ? 16 : window.innerWidth >= 1024 ? 72 : window.innerWidth >= 640 ? 32 : 16;
    const tableRect = viewport?.getBoundingClientRect();
    const insetLeft = tableRect?.width ? tableRect.left : mainRect.left + referencePadding;
    const availableWidth = Math.max(0, tableRect?.width || mainRect.width - referencePadding * 2);
    const width = Math.min(maxWidth, availableWidth);
    const left = insetLeft + Math.max(0, (availableWidth - width) / 2);

    setPosition(current => (
      current &&
      Math.abs(current.left - left) < 0.5 &&
      Math.abs(current.width - width) < 0.5 &&
      Math.abs(current.backdropLeft - insetLeft) < 0.5 &&
      Math.abs(current.backdropWidth - availableWidth) < 0.5
        ? current
        : {
            left,
            width,
            backdropLeft: insetLeft,
            backdropWidth: availableWidth,
          }
    ));
  }, [elementRef, maxWidth, viewportRef]);

  useLayoutEffect(() => {
    if (!enabled) return;
    updatePosition();
    const element = elementRef.current;
    const appMain = element?.closest<HTMLElement>('[data-app-main]');
    if (!element || !appMain) return;

    const observer = new ResizeObserver(updatePosition);
    observer.observe(appMain);
    if (appMain.firstElementChild) observer.observe(appMain.firstElementChild);
    if (element.parentElement) observer.observe(element.parentElement);
    if (viewportRef?.current) observer.observe(viewportRef.current);
    window.addEventListener('resize', updatePosition);

    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updatePosition);
    };
  }, [elementRef, updatePosition, enabled, viewportRef]);

  return enabled && position
    ? ({
        position: 'fixed',
        left: position.left,
        width: position.width,
        bottom,
        '--table-footer-backdrop-left': `${position.backdropLeft}px`,
        '--table-footer-backdrop-width': `${position.backdropWidth}px`,
      } as CSSProperties)
    : undefined;
}
