import { useEffect, type RefObject } from 'react';

/** Shared scrolling contract for system tables using the horizontal scrollbar. */
export default function useFrozenTableHeaders(scrollRef: RefObject<HTMLElement> | undefined, fallbackRef: RefObject<HTMLElement>) {
  useEffect(() => {
    const viewport = scrollRef?.current ?? fallbackRef.current?.previousElementSibling as HTMLElement | null;
    if (!viewport) return;
    const headers = new Set<HTMLElement>();
    let frame: number | undefined;
    const markHeaders = () => {
      for (const header of headers) if (!viewport.contains(header)) headers.delete(header);
      viewport.querySelectorAll<HTMLElement>('thead, .system-table-header-row, [role="row"]:has(> [role="columnheader"])').forEach(header => headers.add(header));
      viewport.querySelectorAll<HTMLElement>('[data-column-resize-handle="true"]').forEach(handle => {
        let row = handle.parentElement;
        while (row && row !== viewport) {
          if (row.querySelectorAll('[data-column-resize-handle="true"]').length > 1) {
            if (!row.matches('table, thead, tr') && !row.querySelector('tbody')) headers.add(row);
            break;
          }
          row = row.parentElement;
        }
      });
      headers.forEach(header => {
        if (header.getAttribute('data-frozen-table-header') !== 'true') header.setAttribute('data-frozen-table-header', 'true');
      });
    };
    const previousHeight = viewport.style.maxHeight;
    const previousFillHeight = viewport.style.height;
    const resize = () => {
      const top = viewport.getBoundingClientRect().top;
      if (viewport.getClientRects().length && top < window.innerHeight) {
        // Use the real footer position instead of reserving a legacy gap for every
        // table. Local/bounded workspaces place their scrollbar at the bottom
        // and must be able to fill that space with rows.
        const footer = fallbackRef.current;
        const footerRect = footer?.getBoundingClientRect();
        const gap = Number.parseFloat(getComputedStyle(viewport.parentElement || viewport).rowGap) || 0;
        const bottom = footerRect && footerRect.top > top
          ? Math.min(footerRect.top, window.innerHeight - footerRect.height)
          : window.innerHeight - 72;
        const available = Math.max(0, bottom - Math.max(0, top) - gap);
        if (viewport.style.maxHeight !== `${available}px`) viewport.style.maxHeight = `${available}px`;
        if ((viewport.hasAttribute('data-fill-table-viewport') || footer?.getAttribute('data-table-scrollbar') === 'fixed') && viewport.style.height !== `${available}px`) viewport.style.height = `${available}px`;
      }
    };
    viewport.setAttribute('data-system-table-viewport', 'true');
    markHeaders();
    resize();
    const sizeObserver = new ResizeObserver(resize);
    if (viewport.parentElement) sizeObserver.observe(viewport.parentElement);
    if (fallbackRef.current) sizeObserver.observe(fallbackRef.current);
    // Text changes inside a cell cannot introduce a new header. Batch structural
    // changes so a table update scans its headers only once per frame.
    const mutations = new MutationObserver(records => {
      if (frame !== undefined || !records.some(record => [...record.addedNodes, ...record.removedNodes].some(node => node.nodeType === 1))) return;
      frame = requestAnimationFrame(() => { frame = undefined; markHeaders(); });
    });
    mutations.observe(viewport, { childList: true, subtree: true });
    window.addEventListener('resize', resize);
    return () => {
      mutations.disconnect();
      sizeObserver.disconnect();
      if (frame !== undefined) cancelAnimationFrame(frame);
      window.removeEventListener('resize', resize);
      viewport.removeAttribute('data-system-table-viewport');
      viewport.style.maxHeight = previousHeight;
      viewport.style.height = previousFillHeight;
      headers.forEach(header => header.removeAttribute('data-frozen-table-header'));
    };
  }, [scrollRef, fallbackRef]);
}
