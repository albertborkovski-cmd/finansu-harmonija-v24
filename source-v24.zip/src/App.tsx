import { translateUi as uiText } from './i18n/language';
import { lazy, Suspense, useEffect, useState, type ReactNode } from 'react';
import { ADMIN_CONTROLS_EVENT, adminSessionWorkspace, loadAdminControls, loginRestriction, sessionRevoked, upcomingAdminMaintenance } from './lib/adminControls';
import LoginPage from './components/LoginPage';
import { supabase } from './lib/supabase';
import { parseSession, resolveSessionForEmail, serializeSession, isSystemAdministratorRole, type AppSession } from './lib/accessControl';
import { AUTH_SESSION_KEY } from './lib/currentUser';
import { isExternalUserInactive } from './lib/externalRoleUserStatus';
import { SETTINGS_DATA_CHANGED_EVENT } from './lib/linkedSettingsData';
import { recordFailedLogin, recordSuccessfulLogin } from './lib/loginHistory';
import LanguageSwitcher from './components/LanguageSwitcher';
import { useLanguage } from './i18n/language';
import SystemTooltip from './components/SystemTooltip';

const Dashboard = lazy(() => import('./components/Dashboard'));
const DebtReconciliationPortalView = lazy(() => import('./components/DebtReconciliationPortalView'));
const ExportSettingsHelpPage = lazy(() => import('./components/ExportSettingsHelpPage'));
const OrganizationSettingsHelpPage = lazy(() => import('./components/OrganizationSettingsHelpPage'));
const IntegrationsHelpPage = lazy(() => import('./components/IntegrationsHelpPage'));
const HelpCenterPage = lazy(() => import('./components/HelpCenterPage'));
const HelpContentRoot = lazy(() => import('./components/HelpContentRoot'));

function AppContent({ children }: { children?: ReactNode }) {
  const [notice, setNotice] = useState('');
  const [reminder, setReminder] = useState<{ id: string; message: string } | null>(null);
  const [dismissedReminder, setDismissedReminder] = useState('');
  const [sessionStarted, setSessionStarted] = useState(() => Number(window.localStorage.getItem(`${AUTH_SESSION_KEY}:started`)) || 1);
  const [session, setSession] = useState<AppSession | null>(() => {
    try {
      return parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    } catch {
      return null;
    }
  });

  const handleLogin = (email: string) => {
    const nextSession = resolveSessionForEmail(email);
    if (nextSession.roleNames.includes('Inactive')) { setNotice('This user account is inactive. Please contact your administrator.'); return; }
    const restriction = loginRestriction(loadAdminControls(), nextSession, Date.now(), adminSessionWorkspace(nextSession.email));
    if (restriction) { setNotice(restriction); return; }
    const started = Date.now();
    setSessionStarted(started);
    window.localStorage.setItem(`${AUTH_SESSION_KEY}:started`, String(started));
    setNotice('');
    recordSuccessfulLogin(nextSession.email);
    try {
      window.localStorage.setItem(AUTH_SESSION_KEY, serializeSession(nextSession));
    } catch {
      // The in-memory session still works when browser storage is unavailable.
    }
    setSession(nextSession);
  };

  const seedRequestedExamples = Boolean(session?.roleNames.some(isSystemAdministratorRole));
  useEffect(() => {
    // Help may be open in another tab when the user signs out of the workspace.
    const syncSession = (event: StorageEvent) => {
      if (event.key !== null && event.key !== AUTH_SESSION_KEY) return;
      try { setSession(parseSession(window.localStorage.getItem(AUTH_SESSION_KEY))); }
      catch { setSession(null); }
    };
    window.addEventListener('storage', syncSession);
    return () => window.removeEventListener('storage', syncSession);
  }, []);
  useEffect(() => {
    if (!seedRequestedExamples) return;
    void import('./lib/advanceEmployeeExamples').then(module => module.initializeAdvanceEmployeeExamples()).catch(error => console.error('Could not initialize requested V23 examples.', error));
  }, [seedRequestedExamples, session?.email]);

  useEffect(() => {
    const check = () => {
      if (!session) { setReminder(null); return; }
      if (isExternalUserInactive(session.email, window.localStorage)) {
        window.localStorage.removeItem(AUTH_SESSION_KEY);
        setNotice('This user account is inactive. Please contact your administrator.');
        setSession(null);
        setReminder(null);
        return;
      }
      const policy = loadAdminControls();
      const now = Date.now();
      const scope = adminSessionWorkspace(session.email);
      const restriction = loginRestriction(policy, session, now, scope);
      if (restriction || sessionRevoked(policy, session, sessionStarted, now, scope)) {
        window.localStorage.removeItem(AUTH_SESSION_KEY);
        setNotice(restriction || 'Your administrator has ended this session. You can sign in again.');
        setSession(null);
        setReminder(null);
        return;
      }
      const plan = upcomingAdminMaintenance(policy, now, scope);
      setReminder(plan && now >= plan.start - plan.reminderMinutes * 60_000 && now < plan.start
        ? { id: plan.id, message: `${plan.message} Sign-out: ${new Date(plan.start).toLocaleString()}. Access resumes: ${new Date(plan.end).toLocaleString()}.` } : null);
    };
    check();
    const timer = window.setInterval(check, 1000);
    window.addEventListener(ADMIN_CONTROLS_EVENT, check);
    window.addEventListener('finansu-harmonija:persistent-state-changed', check);
    window.addEventListener(SETTINGS_DATA_CHANGED_EVENT, check);
    window.addEventListener('storage', check);
    window.addEventListener('focus', check);
    return () => { window.clearInterval(timer); window.removeEventListener(ADMIN_CONTROLS_EVENT, check); window.removeEventListener('finansu-harmonija:persistent-state-changed', check); window.removeEventListener(SETTINGS_DATA_CHANGED_EVENT, check); window.removeEventListener('storage', check); window.removeEventListener('focus', check); };
  }, [session, sessionStarted]);

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } finally {
      try {
        window.localStorage.removeItem(AUTH_SESSION_KEY);
      } catch {
        // The in-memory session is still cleared when browser storage is unavailable.
      }
      setSession(null);
    }
  };

  if (window.location.pathname.startsWith('/debt-reconciliation/')) {
    return <DebtReconciliationPortalView />;
  }

  if (session) {
    return <>{reminder && dismissedReminder !== reminder.id && <div role="alert" className="fixed right-6 top-5 z-[200] max-w-xl rounded-lg border border-amber-300 bg-amber-50 p-4 font-montserrat text-sm text-[#10233A] shadow-lg"><strong>{uiText("Scheduled maintenance")}</strong><p className="my-2">{reminder.message}</p><button className="rounded border border-[#D3E1EC] bg-white px-3 py-1" onClick={() => setDismissedReminder(reminder.id)}>{uiText("Dismiss")}</button></div>}{children ?? <Dashboard session={session} onLogout={handleLogout} />}</>;
  }

  return <>{notice && <div role="alert" className="border-b border-amber-300 bg-amber-50 p-4 text-center font-montserrat text-sm">{notice}<button aria-label={uiText("Dismiss notice")} className="ml-4" onClick={() => setNotice('')}>×</button></div>}<LoginPage onLogin={handleLogin} onLoginFailed={recordFailedLogin} /></>;
}

export default function App() {
  // No language-based key: switching keeps the current page and unsaved form data.
  useLanguage();
  const [helpRoute, setHelpRoute] = useState(() => window.location.hash);
  useEffect(() => {
    const updateHelpRoute = () => setHelpRoute(window.location.hash);
    window.addEventListener('hashchange', updateHelpRoute);
    return () => window.removeEventListener('hashchange', updateHelpRoute);
  }, []);
  return <><SystemTooltip /><LanguageSwitcher /><Suspense fallback={<div role="status" className="p-6 font-montserrat text-sm text-[#7288A3]">{uiText('Loading…')}</div>}><AppContent>{helpRoute.startsWith('#help') ? <HelpContentRoot route={helpRoute}>{helpRoute.startsWith('#help/integrations') ? <IntegrationsHelpPage key={helpRoute} /> : helpRoute.startsWith('#help/export') ? <ExportSettingsHelpPage key={helpRoute} /> : helpRoute.startsWith('#help/organization') ? <OrganizationSettingsHelpPage key={helpRoute} /> : helpRoute === '#help' || helpRoute.startsWith('#help?') ? <HelpCenterPage key={helpRoute} /> : null}</HelpContentRoot> : undefined}</AppContent></Suspense></>;
}
