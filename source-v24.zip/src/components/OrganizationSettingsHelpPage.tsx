import { BookOpen, ArrowUpRight } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLanguage, translateUi as t } from '../i18n/language';
import { ORGANIZATION_HELP_SECTIONS, organizationHelpContent, organizationHelpSteps } from '../lib/organizationSettingsHelp';
import { exportHelpHref } from '../lib/exportSettingsHelp';
import { HelpScreenshot } from './HelpMedia';
import { integrationHelpHref } from './IntegrationHelpLink';

export default function OrganizationSettingsHelpPage() {
  const lt = useLanguage() === 'lt';
  const [selection, setSelection] = useState(() => {
    const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
    return { section: params.get('section') || 'overview', topic: params.get('topic') || 'overview' };
  });
  const content = organizationHelpContent(selection.section, selection.topic);
  useEffect(() => { document.title = `Finansų harmonija · ${lt ? 'Pagalba' : 'Help'}`; }, [lt]);
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'auto' }); }, [selection]);
  return <main className="min-h-screen bg-[#F5F8FB] p-4 font-montserrat text-[#10233A] sm:p-8">
    <div className="mx-auto max-w-6xl">
      <header className="mb-5 flex items-center gap-3"><BookOpen size={24} className="text-[#007EA7]" /><div><p className="text-[12px] font-medium text-[#7288A3]">Finansų harmonija</p><h1 className="text-[22px] font-semibold">{t('Help')}</h1></div></header>
      <div className="grid items-start gap-5 md:grid-cols-[230px_minmax(0,1fr)]">
        <nav aria-label={t('Organization settings sections')} className="space-y-1 rounded-xl border border-[#D3E1EC] bg-white p-3 md:sticky md:top-5">
          <a href={integrationHelpHref()} className="mb-2 flex items-center justify-between gap-2 rounded-md border border-[#D3E1EC] px-3 py-2.5 text-[13px] font-semibold text-[#007EA7] hover:bg-[#E5EDF9]">{lt ? 'Integracijos' : 'Integrations'}<ArrowUpRight size={15} /></a>
          {ORGANIZATION_HELP_SECTIONS.map(item => <button key={item.id} type="button" aria-current={content.id === item.id ? 'page' : undefined} onClick={() => setSelection({ section: item.id, topic: 'overview' })}
            className={`w-full rounded-md px-3 py-2.5 text-left text-[13px] font-medium leading-5 ${content.id === item.id ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#526B86] hover:bg-[#F2F6FA]'} focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]`}>{t(item.label)}</button>)}
        </nav>
        <section className="min-w-0 rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7">
          <h2 className="text-[18px] font-semibold">{t(content.label)}</h2>
          <p className="mt-3 text-[13px] leading-6 text-[#526B86]">{content.intro[lt ? 1 : 0]}</p>
          {selection.topic === 'overview' && <><h3 className="mt-6 text-[14px] font-semibold">{lt ? 'Veiksmų seka' : 'Step by step'}</h3><ol className="mt-3 list-decimal space-y-3 pl-5 text-[13px] leading-6 text-[#526B86]">{organizationHelpSteps(content.id).map((step, index) => <li key={index}>{step[lt ? 1 : 0]}</li>)}</ol><HelpScreenshot lt={lt} file={content.id === 'overview' || content.id === 'digitization' ? 'export-settings.jpg' : content.id === 'counterparties' ? 'counterparties.jpg' : 'expense-import.jpg'} caption={lt ? (content.id === 'counterparties' ? 'FH: kontrahentų sąrašas ir jo veiksmai.' : content.id === 'overview' || content.id === 'digitization' ? 'FH: pasirinktos organizacijos nustatymai.' : 'FH: kodų įkėlimo pavyzdys iš Išlaidų skilties. Kitose kodų skiltyse tokia pati A/B stulpelių tvarka, be išlaidos tipo.') : (content.id === 'counterparties' ? 'FH: counterparties and record actions.' : content.id === 'overview' || content.id === 'digitization' ? 'FH: selected organization settings.' : 'FH: code import example in Expenses. Other code lists use the same A/B columns without an expense type.')} /></>}
          {selection.topic !== 'overview' && <button type="button" onClick={() => setSelection({ section: content.id, topic: 'overview' })} className="mt-3 text-[12px] font-semibold text-[#007EA7] underline underline-offset-2">{lt ? 'Visa skilties pagalba' : 'All help for this section'}</button>}
          <div className="mt-5 divide-y divide-[#E5EDF9]">{content.articles.map(article => <article key={article.id} className="py-4"><h3 className="text-[14px] font-semibold">{t(article.label)}</h3><p className="mt-2 text-[13px] leading-6 text-[#526B86]">{article.body[lt ? 1 : 0]}</p></article>)}</div>
          {['overview', 'digitization'].includes(content.id) && <a href={exportHelpHref('Rivilė')} className="mt-4 inline-flex items-center gap-2 rounded-md border border-[#D3E1EC] px-3 py-2 text-[13px] font-semibold text-[#007EA7] hover:bg-[#F2F6FA]">{lt ? 'Eksporto formatų laukų pagalba' : 'Export format field help'}<ArrowUpRight size={15} /></a>}
          {content.id === 'overview' && <a href={exportHelpHref('Site.pro', 'date-conflict')} className="mt-4 flex items-center gap-2 text-[13px] font-semibold text-[#007EA7] underline underline-offset-2">{lt ? 'Site.pro: Datos konfliktas prekei' : 'Site.pro: Item date conflict'}<ArrowUpRight size={15} /></a>}
        </section>
      </div>
    </div>
  </main>;
}
