import { translateUi as uiText } from '../i18n/language';
import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ChevronDown, Plus, X } from 'lucide-react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { companyBankAccounts } from '../lib/bankTransaction';
import { canCreateCompanyBankTransaction } from '../lib/bankTransactionCreation';
import { newPaymentDraft, paymentRelatedDocuments, saveCompanyPaymentDraft, type CompanyPayment, type PaymentDraft } from '../lib/companyPayments';
import { beneficiaryBankAccounts, normalizedIban, paymentAmountCents, preferredBeneficiaryAccount, validatePaymentAllocations } from '../lib/paymentAllocation';
import { loadOrganizationCounterparties } from '../lib/organizationReferenceLists';
import { isInactiveRecord } from '../lib/recordLifecycle';
import { DEBT_ROWS } from '../lib/companyRelatedObjectData';
import { debtAmountInCents, debtDirection } from '../lib/debtActions';
import BackNavigationButton from './BackNavigationButton';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import { PageActionButton, PageHeader } from './PageHeader';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import SearchableSelect from './SearchableSelect';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import { loadOrganizationReferenceValues } from './OrganizationReferenceValuesView';

const control = 'h-[42px] w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3 text-[14px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10 disabled:bg-[#F2F5F9]';
function PaymentField({ label, optional = false, children }: { label: string; optional?: boolean; children: ReactNode }) {
  return <div className="min-w-0 space-y-2"><div className="text-[12px] font-medium text-[#7288A3]">{uiText(label)}{optional ? <span className="ml-1">{uiText('(optional)')}</span> : <span className="ml-1 text-[#DC2626]">*</span>}</div>{children}</div>;
}
function PaymentSection({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return <section className="min-w-0 rounded-lg border border-[#D3E1EC]"><div className="flex min-h-11 items-center justify-between gap-3 rounded-t-lg bg-[#F2F5F9] px-4 py-2"><h2 className="text-[14px] font-semibold">{title}</h2>{action}</div>{children}</section>;
}

export default function NewPaymentForm({ company, onCancel, onSaved, initialDraft, fromDebts = false, canSave }: {
  company: Company; onCancel: () => void; onSaved: (record: CompanyPayment) => void;
  initialDraft?: PaymentDraft; fromDebts?: boolean; canSave?: () => boolean;
}) {
  const accounts = useMemo(() => companyBankAccounts(company), [company]);
  const contactsResult = useMemo(() => {
    try { return { rows: loadOrganizationCounterparties(company.id).filter(row => !isInactiveRecord(row)), error: '' }; }
    catch { return { rows: [] as Company[], error: 'Could not load organization counterparties.' }; }
  }, [company.id]);
  const contacts = contactsResult.rows;
  const [draft, setDraft] = useState<PaymentDraft>(() => {
    const original = initialDraft ? { ...initialDraft } : newPaymentDraft(company.base_currency || 'EUR');
    const matches = contacts.filter(contact => original.beneficiaryCode ? [contact.company_code, contact.accounting_system_code].includes(original.beneficiaryCode) : contact.name === original.counterparty);
    const contact = matches.length === 1 ? matches[0] : undefined;
    const payer = accounts.find(account => account.iban === original.debtorAccount) || accounts.find(account => account.primary) || (accounts.length === 1 ? accounts[0] : undefined);
    const preferred = preferredBeneficiaryAccount(beneficiaryBankAccounts(contact), payer);
    return { ...original, debtorAccount: payer?.iban || '', beneficiaryId: contact?.id || '', beneficiaryCode: original.beneficiaryCode || contact?.company_code || '',
      creditorAccount: preferred?.iban || original.creditorAccount, beneficiaryBank: preferred?.bank || '', beneficiaryBic: preferred?.bic || '',
      paymentInformationMode: 'purpose', allocations: original.allocations?.map(line => ({ ...line })) || [] };
  });
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState(contactsResult.error);
  const [discard, setDiscard] = useState(false), [additionalOpen, setAdditionalOpen] = useState(false), [addingDocument, setAddingDocument] = useState(false);
  const [manualIban, setManualIban] = useState(false), [manualBeneficiary, setManualBeneficiary] = useState(!contacts.length && !initialDraft?.counterparty);
  const [includedIds, setIncludedIds] = useState(() => new Set(initialDraft?.allocations?.map(line => line.debtId) || []));
  const [requestId] = useState(() => crypto.randomUUID());
  const baseline = useRef(JSON.stringify(draft)), pending = useRef(false), errorRef = useRef<HTMLParagraphElement>(null), tableRef = useRef<HTMLDivElement>(null);
  const purposeEdited = useRef(false);
  const contact = contacts.find(row => row.id === draft.beneficiaryId);
  const beneficiaryAccounts = useMemo(() => beneficiaryBankAccounts(contact), [contact]);
  const allocations = draft.allocations || [];
  const included = allocations.filter(line => includedIds.has(line.debtId));
  const totalCents = included.reduce((sum, line) => sum + (paymentAmountCents(line.paymentAmount) || 0), 0);
  const paymentTotal = allocations.length ? (totalCents / 100).toFixed(2) : draft.amount;
  const currencies = useMemo(() => [...new Set([company.base_currency || 'EUR', draft.currency, ...loadOrganizationReferenceValues('Base currency')])].filter(Boolean), [company.base_currency, draft.currency]);
  const relatedOptions = useMemo(() => [{ value: '', label: uiText('None') }, ...paymentRelatedDocuments(documents, company.id).map(row => ({ value: row.id,
    label: `${row.number || row.file_case || row.id} · ${row.client_counterparty || row.document_type}`, description: `${row.document_date || ''} · ${row.total_amount || ''} ${row.currency || ''}` }))], [documents, company.id]);
  const availableDebts = DEBT_ROWS.filter(row => debtDirection(row) === 'payable' && row.currency === draft.currency && debtAmountInCents(row.outstandingAmount) !== null
    && (draft.beneficiaryCode ? row.counterpartyCode === draft.beneficiaryCode : row.counterpartyName === draft.counterparty) && !allocations.some(line => line.debtId === row.id));
  const beneficiaryOptions = contacts.map(row => ({ value: row.id, label: row.name, description: row.company_code }));
  if (!contact && initialDraft?.counterparty) beneficiaryOptions.unshift({ value: '__initial__', label: initialDraft.counterparty, description: initialDraft.beneficiaryCode || '' });
  const disabled = busy || !canCreateCompanyBankTransaction(company) || (canSave ? !canSave() : false);

  useEffect(() => {
    let active = true;
    void supabase.from('documents').select('*').eq('company_id', company.id).then(result => {
      if (!active) return;
      if (result.error) setError('Related documents could not be loaded. You can still save a draft without a related document.');
      else setDocuments(result.data as unknown as DbDocument[]);
      setLoading(false);
    }).catch(() => { if (active) { setLoading(false); setError('Related documents could not be loaded. You can still save a draft without a related document.'); } });
    return () => { active = false; };
  }, [company.id]);
  useEffect(() => { if (error) errorRef.current?.focus(); }, [error]);

  const update = <K extends keyof PaymentDraft>(key: K, value: PaymentDraft[K]) => setDraft(previous => ({ ...previous, [key]: value }));
  const selectPayer = (iban: string) => setDraft(previous => {
    const preferred = !manualIban && preferredBeneficiaryAccount(beneficiaryAccounts, accounts.find(row => row.iban === iban));
    return { ...previous, debtorAccount: iban, ...(preferred ? { creditorAccount: preferred.iban, beneficiaryBank: preferred.bank, beneficiaryBic: preferred.bic } : {}) };
  });
  const selectBeneficiary = (id: string) => {
    if (allocations.length || fromDebts) return;
    if (id === '__manual__') { setManualBeneficiary(true); setManualIban(true); setDraft(previous => ({ ...previous, beneficiaryId: '', counterparty: '', beneficiaryCode: '', creditorAccount: '', beneficiaryBank: '', beneficiaryBic: '' })); return; }
    const next = contacts.find(row => row.id === id);
    if (!next) return;
    const preferred = preferredBeneficiaryAccount(beneficiaryBankAccounts(next), accounts.find(row => row.iban === draft.debtorAccount));
    setManualBeneficiary(false); setManualIban(false);
    setDraft(previous => ({ ...previous, beneficiaryId: id, counterparty: next.name, beneficiaryCode: next.company_code || '',
      creditorAccount: preferred?.iban || '', beneficiaryBank: preferred?.bank || '', beneficiaryBic: preferred?.bic || '', relatedDocumentId: '' }));
  };
  const selectBeneficiaryAccount = (iban: string) => {
    setManualIban(iban === '__another__');
    const account = beneficiaryAccounts.find(row => row.iban === iban);
    setDraft(previous => ({ ...previous, creditorAccount: account?.iban || '', beneficiaryBank: account?.bank || '', beneficiaryBic: account?.bic || '' }));
  };
  const updateSelection = (next: Set<string>, nextAllocations = allocations) => {
    setIncludedIds(next);
    const refs = nextAllocations.filter(line => next.has(line.debtId)).map(line => DEBT_ROWS.find(row => row.id === line.debtId)?.documentReference).filter(Boolean);
    setDraft(previous => ({ ...previous, allocations: nextAllocations, relatedDocumentId: '',
      amount: (nextAllocations.filter(line => next.has(line.debtId)).reduce((sum, line) => sum + (paymentAmountCents(line.paymentAmount) || 0), 0) / 100).toFixed(2),
      ...(!purposeEdited.current ? { purpose: refs.length ? `${uiText('Payment for invoices')} ${refs.join(', ')}` : '' } : {}) }));
  };
  const close = () => { if (!pending.current) { if (baseline.current !== JSON.stringify(draft) || included.length !== allocations.length) setDiscard(true); else onCancel(); } };
  const save = async (event: FormEvent) => {
    event.preventDefault();
    if (pending.current || disabled) return;
    pending.current = true; setBusy(true); setError('');
    try {
      if ((allocations.length || fromDebts) && !included.length) throw new Error('Select at least one related document.');
      if (included.length) validatePaymentAllocations(included, DEBT_ROWS, draft.counterparty, draft.beneficiaryCode || '', draft.currency);
      onSaved(await saveCompanyPaymentDraft(company.id, requestId, { ...draft, amount: paymentTotal, allocations: included }));
    } catch (cause) {
      if (draft.onBehalfOfAnother && (!draft.originalPayerName?.trim() || !draft.originalPayerCode?.trim())) setAdditionalOpen(true);
      setError(cause instanceof Error ? cause.message : 'Payment draft could not be saved.');
    }
    finally { pending.current = false; setBusy(false); }
  };

  return <div data-new-payment-screen className="flex min-w-0 flex-col gap-5 bg-white px-4 py-14 font-montserrat text-[#10233A] sm:px-8 lg:px-[72px]">
    <PageHeader title={uiText('New payment')} leading={<BackNavigationButton iconOnly label={uiText(fromDebts ? 'Back to debts' : 'Back to Payments')} onClick={close} disabled={busy} />}
      afterTitle={<span className="rounded-full bg-[#E5EDF9] px-3 py-1 text-[11px] font-semibold text-[#007EA7]">{uiText('Draft')}</span>} />
    <CompanyBreadcrumb companyName={company.name} items={['Bank', 'Payments', 'New payment']} />
    <form onSubmit={save} className="min-w-0 space-y-4">
      {error && <p ref={errorRef} tabIndex={-1} role="alert" className="rounded-lg border border-[#F0CAC7] bg-[#FFF5F4] px-4 py-3 text-[12px] text-[#B42318]">{uiText(error)}</p>}
      <PaymentSection title={uiText('Payment details')}>
        <fieldset disabled={disabled} className="m-0 grid min-w-0 grid-cols-1 gap-x-8 gap-y-4 border-0 p-4 sm:grid-cols-2">
          <PaymentField label="Pay from (bank account)"><SearchableSelect ariaLabel={uiText('Pay from (bank account)')} value={draft.debtorAccount} options={accounts.map(account => ({ value: account.iban, label: `${account.bank || uiText('Bank')} · ${account.iban}` }))}
            placeholder={uiText('Select bank account')} disabled={disabled} onChange={selectPayer} portalMenu className={`${control} pr-9`} />
            {!accounts.length && <p className="text-[11px] text-[#926317]">{uiText('Add a company bank account in Bank → Bank accounts.')}</p>}</PaymentField>
          <PaymentField label="Execution date"><input aria-label={uiText('Execution date')} type="date" required value={draft.executionDate} onChange={event => update('executionDate', event.target.value)} className={control} /></PaymentField>
          <PaymentField label="Beneficiary">{manualBeneficiary ? <div className="space-y-1"><input aria-label={uiText('Beneficiary')} required maxLength={300} value={draft.counterparty} onChange={event => update('counterparty', event.target.value)} className={control} />
            {!!contacts.length && <button type="button" className="text-[11px] text-[#007EA7] hover:underline" onClick={() => setManualBeneficiary(false)}>{uiText('Select from counterparties')}</button>}</div>
            : <SearchableSelect ariaLabel={uiText('Beneficiary')} value={draft.beneficiaryId || (initialDraft?.counterparty ? '__initial__' : '')} options={[...beneficiaryOptions, { value: '__manual__', label: uiText('Enter another beneficiary'), description: '' }]}
              disabled={disabled || !!allocations.length || fromDebts} onChange={selectBeneficiary} portalMenu className={`${control} pr-9`} />}</PaymentField>
          <PaymentField label="Total payment amount"><div className="flex min-w-0 gap-2"><input aria-label={uiText('Total payment amount')} inputMode="decimal" required maxLength={20} placeholder="0.00" value={paymentTotal} readOnly={!!allocations.length} onChange={event => update('amount', event.target.value)} className={`${control} flex-1 text-right font-semibold tabular-nums`} />
            <div className="w-28 shrink-0"><SearchableSelect ariaLabel={uiText('Payment currency')} value={draft.currency} options={currencies} onChange={value => update('currency', value)} disabled={disabled || !!allocations.length || fromDebts} portalMenu className={`${control} pr-8`} /></div></div></PaymentField>
          <PaymentField label="Beneficiary bank account"><SearchableSelect ariaLabel={uiText('Beneficiary bank account')} value={manualIban || !beneficiaryAccounts.length ? '__another__' : normalizedIban(draft.creditorAccount)}
            options={[...beneficiaryAccounts.map(account => ({ value: account.iban, label: `${account.bank || uiText('Bank')} · ${account.iban}` })), { value: '__another__', label: uiText('Use another IBAN') }]}
            disabled={disabled} onChange={selectBeneficiaryAccount} portalMenu className={`${control} pr-9`} />
            {(manualIban || !beneficiaryAccounts.length) && <input aria-label={uiText('Beneficiary IBAN')} placeholder={uiText('Beneficiary IBAN')} required maxLength={42} autoCapitalize="characters" value={draft.creditorAccount} onChange={event => update('creditorAccount', event.target.value)} className={control} />}
            <p className="text-[11px] text-[#7288A3]">{uiText('Selection applies to this payment only.')}</p></PaymentField>
        </fieldset>
      </PaymentSection>
      <PaymentSection title={`${uiText('Related documents')} (${included.length})`} action={<PageActionButton icon={<Plus size={14} />} disabled={disabled || !availableDebts.length} onClick={() => setAddingDocument(value => !value)}>{uiText('Add document')}</PageActionButton>}>
        {addingDocument && <div className="border-b border-[#D3E1EC] p-4"><SearchableSelect ariaLabel={uiText('Add document')} value="" options={availableDebts.map(row => ({ value: row.id, label: row.documentReference, description: `${row.outstandingAmount} ${row.currency} · ${row.counterpartyName}` }))} portalMenu disabled={disabled}
          onChange={id => { const row = availableDebts.find(item => item.id === id); if (row) updateSelection(new Set([...includedIds, id]), [...allocations, { debtId: id, paymentAmount: (debtAmountInCents(row.outstandingAmount)! / 100).toFixed(2) }]); setAddingDocument(false); }} /></div>}
        {allocations.length || fromDebts ? <>
          <div ref={tableRef} className="max-h-[320px] overflow-auto"><table className="w-full min-w-[850px] border-collapse text-[12px]">
            <thead className="sticky top-0 z-10 bg-[#F8FBFD]"><tr>{['', 'Document type', 'Document No.', 'Issue date', 'Due date', 'Outstanding amount', 'Payment amount', ''].map((label, index) => <th key={`${label}-${index}`} className={`border-b border-[#D3E1EC] px-3 py-3 font-medium text-[#7288A3] ${index > 4 ? 'text-right' : 'text-left'}`}>
              {index === 0 ? <input type="checkbox" aria-label={uiText('Select all related documents')} checked={!!allocations.length && included.length === allocations.length} disabled={disabled || !allocations.length} onChange={event => updateSelection(new Set(event.target.checked ? allocations.map(line => line.debtId) : []))} /> : uiText(label)}</th>)}</tr></thead>
            <tbody>{allocations.map(line => { const row = DEBT_ROWS.find(item => item.id === line.debtId); if (!row) return null;
              const selected = includedIds.has(line.debtId), cents = paymentAmountCents(line.paymentAmount), outstanding = debtAmountInCents(row.outstandingAmount)!;
              const invalid = selected && (cents === null || cents > outstanding);
              return <tr key={line.debtId} className={`border-b border-[#E5EDF9] ${selected ? 'bg-[#F8FDFF]' : 'bg-white'}`}>
                <td className="px-3 py-2"><input type="checkbox" aria-label={`${uiText('Include document')} ${row.documentReference}`} checked={selected} disabled={disabled} onChange={event => { const next = new Set(includedIds); if (event.target.checked) next.add(line.debtId); else next.delete(line.debtId); updateSelection(next); }} /></td>
                <td className="px-3 py-2">{uiText(row.documentType)}</td><td className="px-3 py-2 font-medium">{row.documentReference}</td><td className="px-3 py-2 whitespace-nowrap">{row.issueDate}</td><td className="px-3 py-2 whitespace-nowrap">{row.dueDate}</td>
                <td className="px-3 py-2 text-right tabular-nums whitespace-nowrap">{row.outstandingAmount} {row.currency}</td>
                <td className="px-3 py-2"><div className="flex items-center justify-end gap-2"><input aria-label={`${uiText('Payment amount')} ${row.documentReference}`} aria-invalid={invalid} inputMode="decimal" disabled={disabled || !selected} value={line.paymentAmount}
                  onChange={event => update('allocations', allocations.map(item => item.debtId === line.debtId ? { ...item, paymentAmount: event.target.value } : item))} className={`${control} !h-9 !w-32 text-right tabular-nums ${invalid ? '!border-[#DC2626]' : ''}`} /><span>{row.currency}</span></div></td>
                <td className="px-3 py-2 text-right"><button type="button" aria-label={`${uiText('Remove document')} ${row.documentReference}`} disabled={disabled} onClick={() => { const next = new Set(includedIds); next.delete(line.debtId); updateSelection(next, allocations.filter(item => item.debtId !== line.debtId)); }} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-[#D3E1EC] text-[#7288A3] hover:text-[#007EA7]"><X size={14} /></button></td>
              </tr>; })}{!allocations.length && <tr><td colSpan={8} className="px-4 py-6 text-center text-[#7288A3]">{uiText('Select at least one related document.')}</td></tr>}</tbody>
          </table></div>
          <HorizontalTableScrollbar scrollRef={tableRef} fixed={false} expandable={false} className="px-3 !pb-2" />
          <div className="flex items-center justify-between gap-4 rounded-b-lg border-t border-[#D3E1EC] bg-[#F2F5F9] px-4 py-3 text-[13px] font-semibold"><span>{uiText('Total payment amount')}</span><span className="tabular-nums">{paymentTotal} {draft.currency}</span></div>
        </> : <div className="p-4"><PaymentField label="Related document" optional><SearchableSelect ariaLabel={uiText('Related document')} value={draft.relatedDocumentId} options={relatedOptions} placeholder={loading ? uiText('Loading documents…') : uiText('Select document')}
          onChange={value => update('relatedDocumentId', value)} disabled={disabled || loading} portalMenu className={`${control} pr-9`} /></PaymentField></div>}
      </PaymentSection>
      <PaymentSection title={uiText('Payment information')}><fieldset disabled={disabled} className="m-0 space-y-4 border-0 p-4">
        <div className="flex flex-wrap gap-6 text-[12px]">{(['purpose', 'contribution'] as const).map(mode => <label key={mode} className="flex items-center gap-2"><input type="radio" name={`payment-information-${requestId}`} checked={(draft.paymentInformationMode || 'purpose') === mode} onChange={() => update('paymentInformationMode', mode)} />{uiText(mode === 'purpose' ? 'Payment purpose' : 'Contribution code')}</label>)}</div>
        {draft.paymentInformationMode === 'contribution' ? <PaymentField label="Contribution code"><input aria-label={uiText('Contribution code')} required maxLength={35} value={draft.contributionCode || ''} onChange={event => update('contributionCode', event.target.value)} className={`${control} max-w-sm`} /></PaymentField>
          : <PaymentField label="Purpose of payment"><textarea aria-label={uiText('Purpose of payment')} required rows={2} maxLength={2000} value={draft.purpose} onChange={event => { purposeEdited.current = true; update('purpose', event.target.value); }} className={`${control} h-auto min-h-20 resize-y py-3`} /></PaymentField>}
      </fieldset></PaymentSection>
      <section className="rounded-lg border border-[#D3E1EC]"><button type="button" aria-expanded={additionalOpen} aria-controls={`additional-${requestId}`} onClick={() => setAdditionalOpen(value => !value)} className={`flex w-full items-center justify-between bg-[#F2F5F9] px-4 py-3 text-left text-[14px] font-semibold ${additionalOpen ? 'rounded-t-lg' : 'rounded-lg'}`}>
        {uiText('Additional details')}<ChevronDown size={16} className={additionalOpen ? 'rotate-180' : ''} /></button>
        {additionalOpen && <fieldset id={`additional-${requestId}`} disabled={disabled} className="m-0 grid grid-cols-1 gap-4 border-0 p-4 sm:grid-cols-2">
          <PaymentField label="Beneficiary code" optional><input aria-label={uiText('Beneficiary code')} maxLength={300} readOnly={!!allocations.length} value={draft.beneficiaryCode || ''} onChange={event => update('beneficiaryCode', event.target.value)} className={control} /></PaymentField>
          <PaymentField label="Beneficiary bank / BIC" optional><input aria-label={uiText('Beneficiary bank / BIC')} readOnly value={[draft.beneficiaryBank, draft.beneficiaryBic].filter(Boolean).join(' · ')} className={`${control} bg-[#F8FBFD]`} /></PaymentField>
          <label className="flex items-center gap-2 text-[12px] sm:col-span-2"><input type="checkbox" checked={!!draft.onBehalfOfAnother} onChange={event => update('onBehalfOfAnother', event.target.checked)} />{uiText('Payment on behalf of another person / company')}</label>
          {draft.onBehalfOfAnother && <><PaymentField label="Original payer name"><input aria-label={uiText('Original payer name')} required maxLength={300} value={draft.originalPayerName || ''} onChange={event => update('originalPayerName', event.target.value)} className={control} /></PaymentField>
            <PaymentField label="Original payer code"><input aria-label={uiText('Original payer code')} required maxLength={300} value={draft.originalPayerCode || ''} onChange={event => update('originalPayerCode', event.target.value)} className={control} /></PaymentField></>}
        </fieldset>}
      </section>
      <footer className="flex flex-wrap items-center justify-end gap-3 border-t border-[#D3E1EC] pt-4">
        {discard ? <><p className="mr-auto text-[12px]">{uiText('Discard unsaved payment?')}</p><CancelButton onClick={() => setDiscard(false)}>{uiText('Keep editing')}</CancelButton><SaveButton onClick={onCancel}>{uiText('Discard changes')}</SaveButton></>
          : <><CancelButton onClick={close}>{uiText('Cancel')}</CancelButton><SaveButton type="submit" disabled={disabled}>{busy ? uiText('Saving…') : uiText('Save draft')}</SaveButton></>}
      </footer>
    </form>
  </div>;
}
