import { useEffect, useId, useRef, useState } from 'react';
import { Check, Loader2 } from 'lucide-react';
import { assignDocumentFields, loadDocumentAssignmentContext } from '../lib/supabase';
import { ASSIGN_DOCUMENT_DATE, ASSIGN_EMPTY, ASSIGN_RESTORE_PARTY, DOCUMENT_ASSIGNMENT_FIELDS, DOCUMENT_EXPORT_ACTIONS, documentAssignmentError, type DocumentAssignmentField, type DocumentAssignmentValues } from '../lib/documentBulkAssignment';
import { documentWasApproved, type InlineDocumentSource } from '../lib/documentInlineEditing';
import { translateUi as t } from '../i18n/language';
import GlJournalDialog from './GlJournalDialog';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import { ApprovedDocumentEditWarning } from './ApprovedDocumentEditWarning';
import ScheduleDatePicker from './ScheduleDatePicker';

export default function DocumentBulkAssignmentDialog({ ids, onClose, onSaved }: {
  ids: string[]; onClose: () => void; onSaved: (count: number) => void;
}) {
  const [context, setContext] = useState<Awaited<ReturnType<typeof loadDocumentAssignmentContext>> | null>(null);
  const [field, setField] = useState<DocumentAssignmentField>('departmentCode');
  const [values, setValues] = useState<DocumentAssignmentValues>({});
  const [customDate, setCustomDate] = useState(true);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const pending = useRef(false), panelId = useId();
  useEffect(() => {
    let alive = true;
    loadDocumentAssignmentContext(ids).then(result => { if (alive) setContext(result); })
      .catch(cause => { if (alive) setError(cause instanceof Error ? cause.message : 'Could not load the selected documents.'); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [ids]);
  const close = () => { if (!pending.current) onClose(); };
  const definition = DOCUMENT_ASSIGNMENT_FIELDS.find(item => item.key === field)!;
  const fieldError = context?.documents.map(document => documentAssignmentError(document as unknown as InlineDocumentSource, field, true)).find(Boolean);
  const setValue = (key: DocumentAssignmentField, value?: string) => {
    setValues(previous => { const next = { ...previous }; if (value === undefined) delete next[key]; else next[key] = value; return next; }); setError('');
  };
  const partyField = field === 'seller' || field === 'buyer';
  const selectField = !['operationDate', 'other', 'note', 'vatRate'].includes(field);
  const disabled = loading || busy || !context || Boolean(fieldError);
  const inputClass = 'w-full rounded-lg border border-[#D3E1EC] bg-white px-3 py-2 text-[13px] text-[#10233A] outline-none placeholder:text-[#A1B6C6] focus:border-[#007EA7] focus:ring-1 focus:ring-[#007EA7]/20';
  const radioClass = 'h-4 w-4 shrink-0 accent-[#007EA7]';
  const save = async () => {
    if (!context || pending.current || !Object.keys(values).length) return;
    pending.current = true; setBusy(true); setError('');
    try { const result = await assignDocumentFields(ids, values, context.snapshots); onSaved(result.updatedCount); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not assign document fields.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return <GlJournalDialog title={`${t('Assign to documents')} (${ids.length})`} onClose={close} overlayZIndex={5400}
    footer={<><PageActionButton disabled={busy} onClick={close}>{t('Cancel')}</PageActionButton>
      <PageActionButton disabled={loading || busy || !context || !Object.keys(values).length} onClick={() => void save()}
        icon={busy ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}>{t(busy ? 'Saving…' : 'Assign')}</PageActionButton></>}>
    <div className="space-y-4">
      {context?.documents.some(document => documentWasApproved(document as unknown as Record<string, unknown>)) && <ApprovedDocumentEditWarning />}
      <div className="grid grid-cols-1 overflow-hidden rounded-lg border border-[#D3E1EC] sm:h-[min(465px,calc(100dvh-250px))] sm:min-h-[290px] sm:grid-cols-[180px_minmax(0,1fr)]">
        <div role="tablist" aria-label={t('Fields to assign')} aria-orientation="vertical" className="max-h-[180px] overflow-y-auto border-b border-[#D3E1EC] bg-[#F8FBFD] p-1.5 sm:max-h-none sm:border-b-0 sm:border-r">
          {DOCUMENT_ASSIGNMENT_FIELDS.map((item, index) => <button key={item.key} type="button" role="tab" id={`${panelId}-${item.key}`}
            aria-label={t(item.label)} aria-selected={field === item.key} aria-controls={panelId} tabIndex={field === item.key ? 0 : -1} disabled={busy}
            onKeyDown={event => {
              if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
              event.preventDefault();
              const next = event.key === 'Home' ? 0 : event.key === 'End' ? DOCUMENT_ASSIGNMENT_FIELDS.length - 1
                : (index + (event.key === 'ArrowDown' ? 1 : -1) + DOCUMENT_ASSIGNMENT_FIELDS.length) % DOCUMENT_ASSIGNMENT_FIELDS.length;
              setField(DOCUMENT_ASSIGNMENT_FIELDS[next].key);
              document.getElementById(`${panelId}-${DOCUMENT_ASSIGNMENT_FIELDS[next].key}`)?.focus();
            }} onClick={() => setField(item.key)}
            className={`flex min-h-8 w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-[12px] font-medium ${field === item.key ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#10233A] hover:bg-[#EDF3F8]'}`}>
            <span className="min-w-0 flex-1">{t(item.label)}</span>
            <span className="flex h-4 w-4 shrink-0 items-center justify-center">{Object.hasOwn(values, item.key) && <Check size={14} aria-label={t('Value selected')} />}</span>
          </button>)}
        </div>
        <div id={panelId} role="tabpanel" aria-labelledby={`${panelId}-${field}`} className="min-w-0 space-y-4 overflow-y-auto p-4">
          <div className="flex min-h-7 items-start justify-between gap-2"><h3 className="text-[13px] font-semibold">{t(definition.label)}</h3>
            {Object.hasOwn(values, field) && <button type="button" disabled={busy} className="shrink-0 text-[11px] font-medium text-[#007EA7] hover:underline" onClick={() => setValue(field)}>{t('Do not change')}</button>}
          </div>
          <fieldset disabled={disabled} className="min-w-0 space-y-3 disabled:opacity-60">
          {partyField && <div className="space-y-3 text-[12px]">
            <label className="flex items-center gap-2"><input type="radio" name={`${panelId}-party-${field}`} className={radioClass} checked={values[field] === ASSIGN_RESTORE_PARTY} onChange={() => setValue(field, ASSIGN_RESTORE_PARTY)} />{t('Restore original value')}</label>
            <label className="flex items-center gap-2"><input type="radio" name={`${panelId}-party-${field}`} className={radioClass} checked={values[field] !== ASSIGN_RESTORE_PARTY} onChange={() => setValue(field)} />{t('Select company')}</label>
          </div>}
          {selectField && (!partyField || values[field] !== ASSIGN_RESTORE_PARTY) && <div className="space-y-2">
            {!partyField && <p className="text-[12px] text-[#7288A3]">{t('Assign manually')}</p>}
            <SearchableSelect key={field} ariaLabel={t(definition.label)} value={values[field] || ''}
              options={[{ value: '', label: t('Do not change') }, ...(field === 'accountableResponsible' ? [{ value: ASSIGN_EMPTY, label: t('Leave empty') }] : []), ...(context?.options[field] || [])]}
              placeholder={t(partyField ? 'Search companies' : 'Select')}
              onChange={value => setValue(field, value || undefined)}
              disabled={disabled} portalMenu menuClassName="!z-[5500]" />
          </div>}
          {field === 'operationDate' && <div className="space-y-3 text-[12px]">
            <label className="flex items-center gap-2"><input type="radio" name={`${panelId}-date`} className={radioClass} checked={values.operationDate === ASSIGN_DOCUMENT_DATE} onChange={() => { setCustomDate(false); setValue('operationDate', ASSIGN_DOCUMENT_DATE); }} />{t('Use each document’s invoice date')}</label>
            <label className="flex items-center gap-2"><input type="radio" name={`${panelId}-date`} className={radioClass} checked={customDate && values.operationDate !== ASSIGN_DOCUMENT_DATE} onChange={() => { setCustomDate(true); if (values.operationDate === ASSIGN_DOCUMENT_DATE) setValue('operationDate'); }} />{t('Assign another date')}</label>
            {customDate && values.operationDate !== ASSIGN_DOCUMENT_DATE && <ScheduleDatePicker inline value={values.operationDate || ''} onChange={value => setValue('operationDate', value || undefined)} placeholder="YYYY-MM-DD" ariaLabel={t('Operation date')} />}
          </div>}
          {field === 'note' && <div className="space-y-3">
            <label className="flex items-center gap-2 text-[12px]"><input type="checkbox" className={radioClass} checked={Object.hasOwn(values, 'note')} onChange={event => setValue('note', event.target.checked ? '' : undefined)} />{t('Assign manually')}</label>
            <textarea aria-label={t('Note')} rows={4} maxLength={5000} placeholder={t('Leave empty')} className={`${inputClass} resize-y`} value={values.note || ''} onChange={event => setValue('note', event.target.value)} />
            <p className="text-[11px] leading-5 text-[#7288A3]">{t('Assigning an empty note clears the notes on the selected documents.')}</p>
          </div>}
          {field === 'vatRate' && <div className="space-y-2">
            <div className="relative"><input type="text" inputMode="decimal" aria-label={t('VAT %')} placeholder={t('Enter VAT rate')} value={values.vatRate ?? ''} onChange={event => setValue('vatRate', event.target.value || undefined)} className={`${inputClass} pr-9`} /><span aria-hidden="true" className="absolute right-3 top-2 text-[13px] text-[#7288A3]">%</span></div>
            <p className="text-[12px] leading-5 text-[#7288A3]">{t('The VAT rate will apply to all lines of the selected documents. VAT and totals will be recalculated.')}</p>
          </div>}
          {field === 'other' && <div className="space-y-3 text-[12px]">
            {DOCUMENT_EXPORT_ACTIONS.map((action, index) => <label key={action.value} className={`flex items-start gap-2 ${index === 2 ? 'border-t border-[#D3E1EC] pt-4' : ''}`}><input type="radio" name={`${panelId}-export`} className={`${radioClass} mt-0.5`} checked={values.other === action.value} onChange={() => setValue('other', action.value)} /><span>{t(action.label)}</span></label>)}
            <p className="pt-2 text-[11px] leading-5 text-[#7288A3]">{t('These actions change export marks only; they do not send documents or undo a completed transfer.')}</p>
          </div>}
          </fieldset>
          {loading ? <p role="status" className="text-[12px] text-[#7288A3]">{t('Loading…')}</p>
            : fieldError ? <p className="text-[12px] leading-5 text-[#926317]">{t(fieldError)}</p>
            : selectField && context && !context.options[field].length ? <p className="text-[12px] leading-5 text-[#7288A3]">{t('No shared values are configured for the selected organizations.')}</p> : null}
        </div>
      </div>
      <p className="text-[11px] leading-5 text-[#7288A3]">{t('Only chosen fields will change. All other document data stays unchanged.')}
        {context && context.companyCount > 1 ? ` ${t('Only values available in every selected organization are shown.')}` : ''}</p>
      {error && <p role="alert" className="rounded-lg border border-[#E8D3AC] bg-[#FFF9EE] px-3 py-2 text-[12px] text-[#926317]">{t(error)}</p>}
    </div>
  </GlJournalDialog>;
}
