import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { canManageHelp, emptyHelpContent, HELP_CONTENT_EVENT, readHelpContent, saveHelpContent, type HelpContentState } from '../lib/helpContent';

type HelpContext = { state: HelpContentState; admin: boolean; error: string; save: (revision: number, change: Parameters<typeof saveHelpContent>[2]) => void; reload: () => void };
const Context = createContext<HelpContext | null>(null);
export function HelpContentProvider({ children }: { children: ReactNode }) {
  const load = () => { try { return { state: readHelpContent(localStorage), error: '' }; } catch (error) { return { state: emptyHelpContent(), error: String((error as Error).message) }; } };
  const [data, setData] = useState(load);
  const [admin, setAdmin] = useState(() => canManageHelp(localStorage));
  const reload = useCallback(() => { setData(load()); setAdmin(canManageHelp(localStorage)); }, []);
  useEffect(() => {
    const events = ['storage', 'focus', HELP_CONTENT_EVENT, 'finansu-harmonija:persistent-state-changed', 'finansu-harmonija:settings-data-changed'];
    events.forEach(event => window.addEventListener(event, reload));
    return () => events.forEach(event => window.removeEventListener(event, reload));
  }, [reload]);
  const save = (revision: number, change: Parameters<typeof saveHelpContent>[2]) => {
    if (data.error) throw new Error(data.error);
    const next = saveHelpContent(localStorage, revision, change);
    setData({ state: next, error: '' });
    window.dispatchEvent(new Event(HELP_CONTENT_EVENT));
  };
  return <Context.Provider value={{ ...data, admin, save, reload }}>{children}</Context.Provider>;
}
export function useHelpContent() {
  const value = useContext(Context);
  if (!value) throw new Error('HelpContentProvider is required.');
  return value;
}
