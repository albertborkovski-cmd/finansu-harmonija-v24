import { translateUi as uiText } from '../i18n/language';
import { lazy, Suspense, useEffect, useState, type ReactNode } from 'react';
import { ArrowLeft, User, Menu, LogOut, ChevronDown, LayoutDashboard, Files, HandCoins, Scale, BarChart3, Headphones, HelpCircle, BookOpenText, Landmark, ListTodo, Package, Banknote } from 'lucide-react';
import type { Company, DbDocument } from '../lib/supabase';
import Documents from './Documents';
import DashboardView from './DashboardView';
import OcrAdditionalInformation from './OcrAdditionalInformation';
import InvoicesView from './invoices';
import CompanyClientInformation from './CompanyClientInformation';
import CompanyClientsView from './CompanyClientsView';
import CompanyDebtsView from './CompanyDebtsView';
import CompanyReconciliationView from './CompanyReconciliationView';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import Companies from './Companies';
import OrganizationEmailSettingsView from './OrganizationEmailSettingsView';
import { Settings } from 'lucide-react';
import GeneralLedgerView from './GeneralLedgerView';
import CompanyReportsView from './CompanyReportsView';
import CompanyGlJournalView, { type GlJournalSection } from './CompanyGlJournalView';
import CompanyBankView from './CompanyBankView';
import CompanyBankAccountsView from './CompanyBankAccountsView';
import CompanySepaPaymentsView from './CompanySepaPaymentsView';
import type { InvoiceChatContext } from './invoices/invoiceChat';
import type { RelatedObject } from '../lib/notifications';
import { WAREHOUSE_MENU_SECTIONS, type WarehouseSection } from '../lib/warehouse';
import { warehousePermissions } from '../lib/warehouseStore';
import { CASH_SECTIONS, type CashSection } from '../lib/cash';
import { cashPermissions } from '../lib/cashStore';
import { ASSET_SECTIONS, type AssetSection } from '../lib/fixedAssets';
import { assetPermissions } from '../lib/fixedAssetStore';
import { companyMenuVisible, type WorkspaceMode } from '../lib/workspaceMode';

const CompanyWarehouseView = lazy(() => import('./CompanyWarehouseView'));
const FinancialStatementItemsView = lazy(() => import('./FinancialStatementItemsView'));
const CompanyCashView = lazy(() => import('./CompanyCashView'));
const CompanyFixedAssetsView = lazy(() => import('./CompanyFixedAssetsView'));

interface CompanyDetailProps {
  company: Company;
  onBack: () => void;
  onLogout: () => void;
  onOpenProfile: () => void;
  initialMenu?: string;
  initialDocumentId?: string | null;
  initialDocumentMode?: 'view' | 'edit' | 'original-view';
  initialRelatedObject?: RelatedObject | null;
  onInitialRelatedObjectBack?: () => void;
  onOpenChat?: (context: InvoiceChatContext) => void;
  notificationsContent?: ReactNode;
  canEditReconciliation?: boolean;
  workspaceMode?: WorkspaceMode;
  onOpenOcrDocument?: (document: DbDocument) => void;
}

const mainMenuItems = [
  { id: 'overview',      label: 'Dashboard', icon: LayoutDashboard },
  { id: 'notifications', label: 'Tasks', icon: ListTodo },
  { id: 'documents',     label: 'All documents', icon: Files },
  { id: 'warehouse',     label: 'Warehouse', icon: Package },
  { id: 'fixed-assets',  label: 'Fixed assets', icon: Landmark },
  { id: 'gl-journal',    label: 'GL journal', icon: BookOpenText },
  { id: 'bank',          label: 'Bank', icon: Landmark },
  { id: 'cash',          label: 'Cash', icon: Banknote },
  { id: 'reports',       label: 'Debts', icon: HandCoins },
  { id: 'services',      label: 'Reconciliation', icon: Scale },
  { id: 'settings',      label: 'Reports', icon: BarChart3 },
  { id: 'counterparties', label: 'Counterparties', icon: User },
  { id: 'company-settings', label: 'Settings', icon: Settings },
];

const contactMenuItems = [
  { id: 'contacts', label: 'Support', icon: Headphones },
  { id: 'partners', label: 'Help', icon: HelpCircle },
  { id: 'team',     label: 'FAQ', icon: HelpCircle },
];

const COMPANY_SUBMENU_IDS = ['documents', 'warehouse', 'fixed-assets', 'gl-journal', 'bank', 'cash', 'activity'];

const glJournalMenuItems = [
  { id: 'journal', label: 'Journal entries' },
  { id: 'revaluation', label: 'Exchange rate revaluation' },
  { id: 'chart-of-accounts', label: 'Chart of accounts' },
  { id: 'financial-statement-items', label: 'Financial statement items' },
] as const;

const bankMenuItems = [
  { id: 'transactions', label: 'Bank transaction' },
  { id: 'accounts', label: 'Bank accounts' },
  { id: 'sepa', label: 'Payments' },
] as const;

const companyInformationMenuItems = [
  'Client information',
  'Stats',
  'Contacts',
  'Address',
  'Taxes',
  'Banking',
  'Accounting settings',
  'Representatives',
  'Clients',
  'Files',
  'GL account',
] as const;

function getCompanyInitials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map((part) => part.charAt(0))
    .join('')
    .toUpperCase();
}

function SubmenuStepperDot({ isActive, isFirst, isLast }: { isActive: boolean; isFirst: boolean; isLast: boolean }) {
  return (
    <div className="flex w-1 self-stretch flex-col items-center">
      <div className="w-0 flex-1 border-l border-[#007EA7]" style={{ opacity: isFirst ? 0 : 0.2 }} />
      <div className="h-1 w-1 flex-shrink-0 rounded-full bg-[#007EA7]" style={{ opacity: isActive ? 1 : 0.2 }} />
      <div className="w-0 flex-1 border-l border-[#007EA7]" style={{ opacity: isLast ? 0 : 0.2 }} />
    </div>
  );
}

function CompanySubmenu<T extends string>({ id, items, activeId, onSelect }: {
  id: string;
  items: readonly { id: T; label: string }[];
  activeId: T;
  onSelect: (id: T) => void;
}) {
  return (
    <div id={id} className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
      {items.map((item, index) => (
        <div key={item.id} className="flex h-8 flex-row items-center gap-[14px]">
          <SubmenuStepperDot isActive={activeId === item.id} isFirst={index === 0} isLast={index === items.length - 1} />
          <button
            type="button"
            aria-current={activeId === item.id ? 'page' : undefined}
            title={uiText(item.label)}
            onClick={() => onSelect(item.id)}
            className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 transition-colors ${activeId === item.id ? 'bg-[#007EA7]' : 'hover:bg-[#F0F7FA]'}`}
          >
            <span className={`truncate font-montserrat text-[14px] font-medium leading-5 ${activeId === item.id ? 'text-white' : 'text-[#10233A]'}`}>{uiText(item.label)}</span>
          </button>
        </div>
      ))}
    </div>
  );
}

export default function CompanyDetail({ company, onBack, onLogout, onOpenProfile, initialMenu = 'overview', initialDocumentId = null, initialDocumentMode = 'view', initialRelatedObject = null, onInitialRelatedObjectBack, onOpenChat, notificationsContent, canEditReconciliation = false, workspaceMode = 'combined', onOpenOcrDocument }: CompanyDetailProps) {
  const relatedObject = initialRelatedObject?.organizationId === company.id ? initialRelatedObject : null;
  const relatedRecordId = relatedObject?.recordId || relatedObject?.id;
  const relatedMenu = relatedObject?.type === 'Bank operation' ? 'bank'
    : relatedObject?.type === 'Debt' ? 'reports'
      : relatedObject?.type === 'Reconciliation' ? 'services'
        : relatedObject?.type === 'Counterparty' ? 'activity' : null;
  const backFromRelatedObject = onInitialRelatedObjectBack ?? onBack;
  const [currentCompany, setCurrentCompany] = useState(company);
  const [isExpanded, setIsExpanded] = useState(true);
  const [activeMenu, setActiveMenu] = useState(relatedMenu ?? (initialMenu === 'invoices' ? 'documents' : initialMenu));
  const [expandedMenu, setExpandedMenu] = useState<string | null>(activeMenu);
  const [activeDocumentsMenu, setActiveDocumentsMenu] = useState<'documents' | 'invoices'>(initialMenu === 'invoices' ? 'invoices' : 'documents');
  const [dashboardDocumentId, setDashboardDocumentId] = useState<string | null>(initialDocumentId);
  const [activeBankMenu, setActiveBankMenu] = useState<'transactions' | 'accounts' | 'sepa'>('transactions');
  const [activeCashMenu, setActiveCashMenu] = useState<CashSection>('transactions');
  const [activeAssetMenu, setActiveAssetMenu] = useState<AssetSection>('register');
  const [activeWarehouseMenu, setActiveWarehouseMenu] = useState<WarehouseSection>('stock');
  const [activeGlJournalMenu, setActiveGlJournalMenu] = useState<GlJournalSection | 'chart-of-accounts' | 'financial-statement-items'>('journal');
  const [linkedReconciliationBatch, setLinkedReconciliationBatch] = useState<string>();
  const [linkedJournalBatch, setLinkedJournalBatch] = useState<string>();
  const [activeCompanyInformationMenu, setActiveCompanyInformationMenu] = useState<(typeof companyInformationMenuItems)[number]>(relatedObject?.type === 'Counterparty' ? 'Clients' : 'Client information');
  const fallbackMenuLabel = [...mainMenuItems, ...contactMenuItems].find(
    (item) => item.id === activeMenu,
  )?.label ?? "Company overview";
  useEffect(() => {
    if (!companyMenuVisible(workspaceMode, activeMenu)) { setActiveMenu('overview'); setExpandedMenu(null); }
  }, [workspaceMode, activeMenu]);
  const selectCompanyMenu = (menuId: string) => {
    setExpandedMenu(current => COMPANY_SUBMENU_IDS.includes(menuId)
      ? (activeMenu === menuId && current === menuId ? null : menuId)
      : null);
    setActiveMenu(menuId);
    if (menuId === 'activity' && activeMenu !== menuId) {
      setActiveCompanyInformationMenu('Client information');
    }
  };
  const openGeneralLedger = () => {
    setActiveMenu('gl-journal');
    setExpandedMenu('gl-journal');
    setActiveGlJournalMenu('chart-of-accounts');
  };

  useEffect(() => {
    setCurrentCompany(company);
  }, [company]);

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Blue strip */}
      <div className="w-12 min-h-screen bg-[#E6F2F6] flex flex-col justify-between items-center py-4 z-10 flex-shrink-0">
        <div className="group relative flex h-8 w-12 items-center justify-center">
          <button
            type="button"
            onClick={onOpenProfile}
            aria-label={uiText("Profile settings")}
            data-tooltip-side="right"
            className="peer w-8 h-8 flex items-center justify-center rounded hover:bg-[#D0E8EF] transition-colors"
          >
            <User size={16} className="text-[#7288A3]" />
          </button>
        </div>
        <div className="flex flex-col items-center gap-1">
          <div className="group relative flex h-8 w-12 items-center justify-center">
            <button
              onClick={() => setIsExpanded(v => !v)}
              aria-label={uiText("Collapse sidebar")}
              data-tooltip-side="right"
              className="peer w-12 h-8 flex items-center justify-center hover:bg-[#D0E8EF] rounded transition-colors"
            >
              <Menu size={16} className="text-[#006080]" />
            </button>
          </div>
          <button onClick={onLogout} className="w-12 h-8 flex items-center justify-center hover:bg-[#D0E8EF] rounded transition-colors" title={uiText("Logout")}>
            <LogOut size={16} className="text-[#006080] rotate-90" />
          </button>
        </div>
      </div>

      {/* White panel */}
      <div
        className="min-h-screen bg-white border-r-2 border-[#E6F2F6] flex flex-col transition-all duration-300 overflow-hidden flex-shrink-0"
        style={{ width: isExpanded ? '288px' : '68px' }}
      >
        <div className="p-4 flex flex-col h-full">
          {/* Back button */}
          <div className="flex items-center px-2 py-[6px] h-8 flex-shrink-0 overflow-hidden mb-2">
            <button
              onClick={onBack}
              className="flex flex-row items-center gap-2 hover:opacity-70 transition-opacity"
              title={uiText("Back")}
            >
              <ArrowLeft size={11} className="text-[#007EA7] flex-shrink-0" style={{ strokeWidth: 2.5 }} />
              {isExpanded && (
                <span className="font-montserrat font-semibold text-[14px] leading-5 text-[#007EA7] whitespace-nowrap">{uiText("Back")}</span>
              )}
            </button>
          </div>

          {/* Company name */}
          <div className={`mb-2 flex h-5 flex-shrink-0 items-center overflow-hidden ${isExpanded ? 'px-2' : 'justify-center px-0'}`}>
            {isExpanded ? (
              <span className="font-montserrat font-medium text-[14px] leading-5 text-[#161616] whitespace-nowrap truncate block">{uiText("Client: ")}{currentCompany.name}
              </span>
            ) : (
              <span
                className="font-montserrat text-[13px] font-semibold leading-5 text-[#10233A]"
                title={currentCompany.name}
                aria-label={currentCompany.name}
              >
                {getCompanyInitials(currentCompany.name)}
              </span>
            )}
          </div>

          {/* Main menu — grows to fill space */}
          <nav className="flex flex-col gap-0 flex-1 overflow-y-auto">
            {[...mainMenuItems, ...(workspaceMode === 'ocr' ? [{ id: 'manage-company', label: 'Manage company', icon: Settings }] : [])].filter(item => companyMenuVisible(workspaceMode, item.id) && (item.id !== 'notifications' || notificationsContent) && (item.id !== 'warehouse' || warehousePermissions(currentCompany).view) && (item.id !== 'cash' || cashPermissions(currentCompany).view) && (item.id !== 'fixed-assets' || assetPermissions(currentCompany).view)).map((item) => {
              const isActive = activeMenu === item.id;
              const hasSubmenu = COMPANY_SUBMENU_IDS.includes(item.id);
              const isSubmenuOpen = isExpanded && isActive && expandedMenu === item.id;
              const Icon = item.icon;
              return (
                <div key={item.id} className="flex flex-col">
                  <button
                    type="button"
                    aria-expanded={hasSubmenu ? isSubmenuOpen : undefined}
                    aria-controls={hasSubmenu && isSubmenuOpen ? `company-${item.id}-submenu` : undefined}
                    onClick={() => selectCompanyMenu(item.id)}
                    title={!isExpanded ? item.label : undefined}
                    className={`h-9 flex flex-row items-center justify-between rounded transition-colors overflow-hidden ${
                      isExpanded ? 'w-full px-3' : 'w-9 justify-center px-[10px]'
                    } ${isActive ? 'bg-[#007EA7]' : 'hover:bg-[#F0F7FA]'}`}
                  >
                    {!isExpanded && <Icon size={16} className={isActive ? 'text-white' : 'text-[#7288A3]'} />}
                    {isExpanded && (
                      <>
                        <div className="flex min-w-0 items-center gap-2">
                          <Icon size={16} className={`flex-shrink-0 ${isActive ? 'text-white' : 'text-[#7288A3]'}`} />
                          <span className={`truncate whitespace-nowrap font-montserrat text-[14px] font-medium leading-5 ${isActive ? 'text-white' : 'text-[#10233A]'}`}>
                            {uiText(item.label)}
                          </span>
                        </div>
                        {hasSubmenu && <ChevronDown size={16} className={`flex-shrink-0 transition-transform ${isSubmenuOpen ? 'rotate-180' : ''} ${isActive ? 'text-white' : 'text-[#10233A]'}`} />}
                      </>
                    )}
                  </button>
                  {isSubmenuOpen && item.id === 'gl-journal' && (
                    <CompanySubmenu id="company-gl-journal-submenu" items={glJournalMenuItems} activeId={activeGlJournalMenu} onSelect={setActiveGlJournalMenu} />
                  )}
                  {isSubmenuOpen && item.id === 'warehouse' && (
                    <CompanySubmenu id="company-warehouse-submenu" items={WAREHOUSE_MENU_SECTIONS} activeId={activeWarehouseMenu} onSelect={setActiveWarehouseMenu} />
                  )}
                  {isSubmenuOpen && item.id === 'cash' && (
                    <CompanySubmenu id="company-cash-submenu" items={CASH_SECTIONS} activeId={activeCashMenu} onSelect={setActiveCashMenu} />
                  )}
                  {isSubmenuOpen && item.id === 'fixed-assets' && (
                    <CompanySubmenu id="company-fixed-assets-submenu" items={ASSET_SECTIONS} activeId={activeAssetMenu} onSelect={setActiveAssetMenu} />
                  )}
                  {isSubmenuOpen && item.id === 'documents' && (
                    <div id="company-documents-submenu" className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
                      {[
                        { id: 'documents' as const, label: 'Documents' },
                        { id: 'invoices' as const, label: 'Invoices' },
                      ].map((subItem, index, items) => (
                        <div key={subItem.id} className="flex h-8 flex-row items-center gap-[14px]">
                          <SubmenuStepperDot isActive={activeDocumentsMenu === subItem.id} isFirst={index === 0} isLast={index === items.length - 1} />
                          <button type="button" onClick={() => setActiveDocumentsMenu(subItem.id)} aria-current={activeDocumentsMenu === subItem.id ? 'page' : undefined}
                            className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 transition-colors ${activeDocumentsMenu === subItem.id ? 'bg-[#007EA7]' : 'hover:bg-[#F0F7FA]'}`}>
                            <span className={`truncate font-montserrat text-[14px] font-medium leading-5 ${activeDocumentsMenu === subItem.id ? 'text-white' : 'text-[#10233A]'}`}>{uiText(subItem.label)}</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  {isSubmenuOpen && item.id === 'bank' && (
                    <CompanySubmenu id="company-bank-submenu" items={bankMenuItems} activeId={activeBankMenu} onSelect={setActiveBankMenu} />
                  )}
                  {isSubmenuOpen && item.id === 'activity' && (
                    <div id="company-activity-submenu" className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
                      {companyInformationMenuItems.map((label, index, items) => (
                        <div key={label} className="flex h-8 flex-row items-center gap-[14px]">
                          <SubmenuStepperDot isActive={activeCompanyInformationMenu === label} isFirst={index === 0} isLast={index === items.length - 1} />
                          <button
                            type="button"
                            onClick={() => setActiveCompanyInformationMenu(label)}
                            className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 transition-colors ${activeCompanyInformationMenu === label ? 'bg-[#007EA7]' : 'hover:bg-[#F0F7FA]'}`}
                          >
                            <span className={`truncate font-montserrat text-[14px] font-medium leading-5 ${activeCompanyInformationMenu === label ? 'text-white' : 'text-[#10233A]'}`}>{uiText(label)}</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>

          {/* Contact menu items — pinned to bottom */}
          <div className="flex flex-col gap-0 flex-shrink-0">
            {contactMenuItems.filter(item => companyMenuVisible(workspaceMode, item.id)).map((item) => {
              const isActive = activeMenu === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => selectCompanyMenu(item.id)}
                  title={!isExpanded ? item.label : undefined}
                  className={`h-9 flex flex-row items-center rounded transition-colors overflow-hidden ${
                    isExpanded ? 'w-full px-3' : 'w-9 justify-center px-[10px]'
                  } ${isActive ? 'bg-[#007EA7]' : 'hover:bg-[#F0F7FA]'}`}
                >
                  {!isExpanded && <Icon size={16} className={isActive ? 'text-white' : 'text-[#7288A3]'} />}
                  {isExpanded && (
                    <div className="flex min-w-0 items-center gap-2">
                      <Icon size={16} className={`flex-shrink-0 ${isActive ? 'text-white' : 'text-[#7288A3]'}`} />
                      <span className={`truncate whitespace-nowrap font-montserrat text-[14px] font-medium leading-5 ${isActive ? 'text-white' : 'text-[#10233A]'}`}>
                        {uiText(item.label)}
                      </span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {workspaceMode !== 'fh' && (activeMenu === 'overview' || activeMenu === 'documents') && <OcrAdditionalInformation key={currentCompany.id} companyId={currentCompany.id} companyName={currentCompany.name} />}
      {/* Main content */}
      <div data-app-main className="relative min-w-0 flex-1 overflow-x-hidden overflow-y-auto bg-white">
        {!companyMenuVisible(workspaceMode, activeMenu) ? null : activeMenu === 'manage-company' ? (
          <CompanyClientInformation company={currentCompany} workspaceMode={workspaceMode} activeTab="Client information" organizationMode onCompanyUpdated={setCurrentCompany} onBack={() => setActiveMenu('overview')} />
        ) : activeMenu === 'notifications' ? notificationsContent : activeMenu === 'documents' ? (
          activeDocumentsMenu === 'documents'
            ? <Documents companyId={currentCompany.id} companyName={currentCompany.name} company={currentCompany} generalLedgerName={currentCompany.general_ledger ?? ''} initialViewDocumentId={dashboardDocumentId} initialDocumentMode={initialDocumentMode} onInitialViewConsumed={() => setDashboardDocumentId(null)} onInitialViewBack={initialDocumentId ? onBack : () => setActiveMenu('overview')} onOpenGeneralLedger={openGeneralLedger} onStartChat={onOpenChat} />
            : <InvoicesView companyId={currentCompany.id} companyName={currentCompany.name} company={currentCompany} onStartChat={onOpenChat} />
        ) : activeMenu === 'overview' ? (
          <DashboardView
            companyId={currentCompany.id}
            clientName={currentCompany.name}
            workspaceMode={workspaceMode}
            onOpenDocument={(document) => {
              if (workspaceMode === 'ocr') { onOpenOcrDocument?.(document); return; }
              setDashboardDocumentId(document.id);
              setActiveDocumentsMenu('documents');
              setActiveMenu('documents');
              setExpandedMenu('documents');
            }}
          />
        ) : activeMenu === 'warehouse' ? (
          <Suspense fallback={<p className="p-9 text-[13px] text-[#7288A3]">{uiText("Loading warehouse…")}</p>}><CompanyWarehouseView key={`${currentCompany.id}:${activeWarehouseMenu}`} company={currentCompany} section={activeWarehouseMenu} /></Suspense>
        ) : activeMenu === 'fixed-assets' ? (
          <Suspense fallback={<p className="p-9 text-[13px] text-[#7288A3]">{uiText('Loading fixed assets…')}</p>}><CompanyFixedAssetsView key={`${currentCompany.id}:${activeAssetMenu}`} company={currentCompany} section={activeAssetMenu} /></Suspense>
        ) : activeMenu === 'cash' ? (
          <Suspense fallback={<p className="p-9 text-[13px] text-[#7288A3]">{uiText("Loading cash workspace…")}</p>}><CompanyCashView key={`${currentCompany.id}:${activeCashMenu}`} company={currentCompany} section={activeCashMenu} onSectionChange={setActiveCashMenu} /></Suspense>
        ) : activeMenu === 'gl-journal' ? (
          activeGlJournalMenu === 'chart-of-accounts'
            ? <GeneralLedgerView key={`${currentCompany.id}:${currentCompany.general_ledger ?? ''}`} companyId={currentCompany.id} companyName={currentCompany.name} assignedTemplateName={currentCompany.general_ledger ?? ''} companyContext="journal" onBack={() => setActiveGlJournalMenu('journal')} />
            : activeGlJournalMenu === 'financial-statement-items'
              ? <Suspense fallback={<p className="p-9 text-[13px] text-[#7288A3]">{uiText("Loading financial statement items…")}</p>}><FinancialStatementItemsView key={`${currentCompany.id}:${currentCompany.general_ledger ?? ''}`} company={currentCompany} /></Suspense>
              : <CompanyGlJournalView company={currentCompany} section={activeGlJournalMenu} onSectionChange={setActiveGlJournalMenu} initialReconciliationBatchId={linkedJournalBatch} onOpenReconciliation={id => { setLinkedReconciliationBatch(id); setLinkedJournalBatch(undefined); setActiveMenu('services'); setExpandedMenu(null); }} />
        ) : activeMenu === 'bank' ? (
          activeBankMenu === 'transactions'
            ? <CompanyBankView company={currentCompany} initialRecordId={relatedObject?.type === 'Bank operation' ? relatedRecordId : undefined} onRelatedObjectBack={backFromRelatedObject} onOpenReconciliation={() => selectCompanyMenu('services')} />
            : activeBankMenu === 'accounts'
              ? <CompanyBankAccountsView company={currentCompany} onCompanyUpdated={setCurrentCompany} />
              : <CompanySepaPaymentsView company={currentCompany} />
        ) : activeMenu === 'reports' ? (
          <CompanyDebtsView key={currentCompany.id} company={currentCompany} companyName={currentCompany.name} initialRecordId={relatedObject?.type === 'Debt' ? relatedRecordId : undefined} onRelatedObjectBack={backFromRelatedObject} />
        ) : activeMenu === 'activity' ? (
          activeCompanyInformationMenu === 'GL account'
            ? <GeneralLedgerView assignedTemplateName={currentCompany.general_ledger ?? ''} companyName={currentCompany.name} companyId={currentCompany.id} />
            : activeCompanyInformationMenu === 'Clients' && relatedObject?.type === 'Counterparty'
              ? <CompanyClientsView company={currentCompany} initialRecordId={relatedRecordId} onRelatedObjectBack={backFromRelatedObject} />
              : <CompanyClientInformation company={currentCompany} activeTab={activeCompanyInformationMenu} organizationDesign onCompanyUpdated={setCurrentCompany} />
        ) : activeMenu === 'services' ? (
          <CompanyReconciliationView key={currentCompany.id + ':examples-v2'} companyId={currentCompany.id} companyName={currentCompany.name} generalLedgerName={currentCompany.general_ledger ?? ''} baseCurrency={currentCompany.base_currency || 'EUR'} initialBatchId={linkedReconciliationBatch} onOpenJournal={id => { setLinkedJournalBatch(id); setLinkedReconciliationBatch(undefined); setActiveGlJournalMenu('journal'); setActiveMenu('gl-journal'); setExpandedMenu('gl-journal'); }} canEditGlAccounts={canEditReconciliation} initialRecordId={relatedObject?.type === 'Reconciliation' ? relatedRecordId : undefined} onRelatedObjectBack={backFromRelatedObject} />
        ) : activeMenu === 'counterparties' ? (
          <Companies key={currentCompany.id} title={uiText("Counterparties")} entityLabel="counterparty" dataSource="counterparties" counterpartyCompanyId={currentCompany.id} allowCreate breadcrumbs={['Companies', currentCompany.name, 'Counterparties']} />
        ) : activeMenu === 'company-settings' ? (
          <OrganizationEmailSettingsView key={currentCompany.id} companyId={currentCompany.id} companyName={currentCompany.name} />
        ) : activeMenu === 'settings' ? (
          <CompanyReportsView company={currentCompany} />
        ) : (
          <div className="px-9 py-14">
            <CompanyOverview company={currentCompany} sectionLabel={fallbackMenuLabel} />
          </div>
        )}
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="font-montserrat font-medium text-[11px] leading-4 text-[#7288A3] uppercase tracking-wide">{uiText(label)}</span>
      <span className="font-montserrat font-medium text-[14px] leading-5 text-[#10233A]">{value || '—'}</span>
    </div>
  );
}

function CompanyOverview({ company, sectionLabel }: { company: Company; sectionLabel: string }) {
  return (
    <div className="flex flex-col gap-8 max-w-3xl">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <h1 className="font-montserrat font-semibold text-[24px] leading-8 text-[#10233A]">{company.name}</h1>
        <span className="font-montserrat font-medium text-[13px] leading-5 text-[#7288A3]">{sectionLabel}</span>
      </div>
      <CompanyBreadcrumb companyName={company.name} items={[sectionLabel]} />

      {/* Info cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { label: 'Company code',   value: company.company_code },
          { label: 'VAT code',       value: company.vat_code },
          { label: 'Client since',   value: company.client_since },
          { label: 'Action required', value: company.action_required },
        ].map(({ label, value }) => (
          <div key={label} className="flex flex-col gap-3 px-5 py-4 bg-[#F8FDFF] border border-[#E6F2F6] rounded-xl">
            <InfoRow label={uiText(label)} value={value} />
          </div>
        ))}
      </div>

      {/* Placeholder sections */}
      {['Documents', 'Transactions'].map(section => (
        <div key={section} className="flex flex-col gap-4">
          <div className="flex flex-row items-center justify-between">
            <span className="font-montserrat font-semibold text-[16px] leading-6 text-[#10233A]">{section}</span>
            <span className="font-montserrat font-medium text-[13px] leading-5 text-[#007EA7] cursor-pointer hover:underline">{uiText("View all")}</span>
          </div>
          <div className="flex items-center justify-center h-24 rounded-xl border-2 border-dashed border-[#D3E1EC]">
            <span className="font-montserrat font-medium text-[13px] text-[#7288A3]">{uiText("No ")}{section.toLowerCase()}{uiText(" yet")}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
