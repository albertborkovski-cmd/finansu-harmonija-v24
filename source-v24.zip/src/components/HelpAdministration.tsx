import { ArrowLeft, ChevronDown, ChevronRight, EyeOff, FileText, Folder, FolderPlus, Plus, Search, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useLanguage } from '../i18n/language';
import { editorialArticles, helpCategories, newHelpArticle } from '../lib/helpEditorialCatalog';
import { isHelpGroupVisible, isHelpVisible, type EditableHelpArticle, type EditableHelpCategory } from '../lib/helpContent';
import { helpParent } from '../lib/helpEditing';
import { useHelpContent } from './HelpContentProvider';
import HelpArticleEditor, { HelpCategoryEditor, helpEditorButton } from './HelpArticleEditor';

type Selection = { kind: 'article'; article: EditableHelpArticle } | { kind: 'category'; category: EditableHelpCategory };
export default function HelpAdministration() {
  const { state, admin, error, reload } = useHelpContent(), lt = useLanguage() === 'lt', lang = lt ? 1 : 0;
  const entries = useMemo(() => editorialArticles(state), [state]);
  const categories = useMemo(() => helpCategories(state), [state]);
  const [selection, setSelection] = useState<Selection>(() => ({ kind: 'article', article: entries.find(item => item.key === new URLSearchParams(window.location.hash.split('?')[1] || '').get('edit')) || entries[0] }));
  const selectedKey = selection.kind === 'article' ? selection.article.key : `category:${selection.category.id}`;
  const selectedCategory = selection.kind === 'article' ? (state.articles[selection.article.key]?.category || selection.article.category) : selection.category.id;
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set([`category:${selectedCategory}`, ...(selection.kind === 'article' ? [helpParent(selection.article)] : [])]));
  const [query, setQuery] = useState(''), [pending, setPending] = useState<Selection | null>(null);
  const dirty = useRef(false);
  const setDirty = (value: boolean) => { dirty.current = value; };
  useEffect(() => { document.title = `${lt ? 'Pagalbos administravimas' : 'Help administration'} · Finansų harmonija`; }, [lt]);
  const choose = (next: Selection) => {
    const nextKey = next.kind === 'article' ? next.article.key : `category:${next.category.id}`;
    if (nextKey === selectedKey) return;
    if (dirty.current) { setPending(next); return; }
    dirty.current = false;
    setSelection(next);
  };
  const addArticle = (child: boolean) => {
    if (!categories.some(item => item.id === selectedCategory)) return;
    const next = newHelpArticle(selectedCategory);
    next.parentKey = child && selection.kind === 'article' ? selection.article.key : '';
    next.order = entries.length + 1;
    setExpanded(current => new Set([...current, `category:${selectedCategory}`, next.parentKey || '']));
    choose({ kind: 'article', article: next });
  };
  const toggle = (key: string) => setExpanded(current => { const next = new Set(current); if (next.has(key)) next.delete(key); else next.add(key); return next; });
  const tree = useMemo(() => {
    const index = new Map(entries.map((entry, i) => [entry.key, i]));
    const byKey = new Map(entries.map(entry => [entry.key, entry]));
    const children = new Map<string, EditableHelpArticle[]>();
    entries.forEach(entry => {
      const parent = helpParent(entry);
      const key = parent && byKey.get(parent)?.category === entry.category ? parent : `category:${entry.category}`;
      children.set(key, [...(children.get(key) || []), entry]);
    });
    children.forEach(list => list.sort((a, b) => (a.order ?? index.get(a.key)!) - (b.order ?? index.get(b.key)!)));
    const matched = new Set<string>();
    const search = query.trim().toLocaleLowerCase();
    if (search) entries.filter(entry => `${entry.title.join(' ')} ${entry.description.join(' ')}`.toLocaleLowerCase().includes(search)).forEach(entry => {
      matched.add(`category:${entry.category}`);
      let current: EditableHelpArticle | undefined = entry;
      const seen = new Set<string>();
      while (current && !seen.has(current.key)) { seen.add(current.key); matched.add(current.key); current = byKey.get(helpParent(current)); }
    });
    return { children, matched, search };
  }, [entries, query]);
  const renderNodes = (parent: string, depth = 0) => (tree.children.get(parent) || []).filter(item => !tree.search || tree.matched.has(item.key)).map(item => {
    const children = tree.children.has(item.key), open = Boolean(tree.search) || expanded.has(item.key), selected = selectedKey === item.key;
    return <li key={item.key}>
      <div className={`flex min-h-9 items-start rounded-lg ${selected ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#526B86] hover:bg-[#F3F8FB]'}`} style={{ paddingLeft: 8 + Math.min(depth, 6) * 15 }}>
        {children ? <button type="button" onClick={() => toggle(item.key)} aria-label={`${open ? (lt ? 'Suskleisti' : 'Collapse') : (lt ? 'Išskleisti' : 'Expand')} ${item.title[lang]}`} aria-expanded={open} className="mt-1 flex h-7 w-6 shrink-0 items-center justify-center rounded focus-visible:outline-[#007EA7]">{open ? <ChevronDown size={13} /> : <ChevronRight size={13} />}</button> : <span className="mt-2.5 flex w-6 shrink-0 justify-center"><FileText size={13} /></span>}
        <button type="button" onClick={() => choose({ kind: 'article', article: item })} aria-current={selected ? 'page' : undefined} className="min-w-0 flex-1 py-2 pr-2 text-left text-[11px] leading-5 focus-visible:outline-[#007EA7]">{item.title[lang] || item.title[1 - lang]}{!isHelpVisible(item.href, state) && <EyeOff size={12} className="ml-2 inline text-[#8CA1B4]" aria-label={lt ? 'Paslėpta' : 'Hidden'} />}</button>
      </div>{children && open && <ul>{renderNodes(item.key, depth + 1)}</ul>}
    </li>;
  });
  if (!admin) return <main className="p-8 font-montserrat"><h1 className="text-xl font-semibold">{lt ? 'Reikalingos administratoriaus teisės' : 'Administrator access required'}</h1><a href="./#help" className="mt-4 inline-block text-[#007EA7] underline">{lt ? 'Grįžti į pagalbą' : 'Back to help'}</a></main>;
  return <main className="flex h-screen min-h-[600px] flex-col bg-[#F7FAFC] pt-16 font-montserrat text-[#10233A]">
    <header className="shrink-0 border-b border-[#D3E1EC] bg-white px-5 pb-4 pt-3 sm:px-7">
      <a href="./#help" className="inline-flex items-center gap-2 text-xs font-semibold text-[#007EA7]"><ArrowLeft size={14} />{lt ? 'Pagalbos centras' : 'Help centre'}</a>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3"><div><h1 className="text-xl font-semibold">{lt ? 'Pagalbos administravimas' : 'Help administration'}</h1><p className="mt-1 text-xs text-[#7288A3]">{lt ? 'Pasirinkite temą medyje. Dešinėje redaguokite tekstą, nuorodas ir vaizdus.' : 'Choose a topic in the tree. Edit text, links and media on the right.'}</p></div>
        <div className="flex flex-wrap gap-2"><button className={helpEditorButton} disabled={Boolean(error)} onClick={() => choose({ kind: 'category', category: { id: `custom-${crypto.randomUUID()}`, title: ['', ''], description: ['', ''] } })}><FolderPlus size={15} />{lt ? 'Nauja skiltis' : 'New category'}</button><button className={helpEditorButton} disabled={Boolean(error)} onClick={() => addArticle(false)}><Plus size={15} />{lt ? 'Nauja tema' : 'New topic'}</button><button className={helpEditorButton} disabled={Boolean(error) || (selection.kind === 'article' && !entries.some(item => item.key === selection.article.key))} onClick={() => addArticle(true)}><Plus size={15} />{lt ? 'Pridėti potemę' : 'Add subtopic'}</button></div>
      </div>
    </header>
    {error && <div role="alert" className="m-3 rounded bg-red-50 p-3 text-sm text-red-700">{lt ? 'Nepavyko perskaityti pagalbos. Duomenys nepakeisti.' : error}<button className={helpEditorButton} onClick={reload}>{lt ? 'Atnaujinti' : 'Reload'}</button></div>}
    <div className="grid min-h-0 flex-1 grid-cols-[260px_minmax(0,1fr)] xl:grid-cols-[300px_minmax(0,1fr)]">
      <aside className="flex min-h-0 flex-col border-r border-[#D3E1EC] bg-white">
        <div className="border-b border-[#E5EDF9] p-3"><label className="flex items-center gap-2 rounded-lg border border-[#D3E1EC] px-3"><Search size={15} className="text-[#7288A3]" /><input aria-label={lt ? 'Ieškoti temos' : 'Search topics'} placeholder={lt ? 'Ieškoti temos…' : 'Search topics…'} value={query} onChange={event => setQuery(event.target.value)} className="h-10 w-full min-w-0 bg-transparent text-xs outline-none" />{query && <button aria-label={lt ? 'Išvalyti paiešką' : 'Clear search'} onClick={() => setQuery('')}><X size={13} /></button>}</label><div className="mt-2 flex justify-between text-[11px] text-[#007EA7]"><button onClick={() => setExpanded(new Set([...categories.map(item => `category:${item.id}`), ...entries.map(item => item.key)]))}>{lt ? 'Išskleisti viską' : 'Expand all'}</button><button onClick={() => setExpanded(new Set())}>{lt ? 'Suskleisti viską' : 'Collapse all'}</button></div></div>
        <nav aria-label={lt ? 'Pagalbos temų medis' : 'Help topic tree'} className="min-h-0 flex-1 overflow-y-auto p-2"><ul>{categories.filter(category => !tree.search || tree.matched.has(`category:${category.id}`)).map(category => {
          const key = `category:${category.id}`, open = Boolean(tree.search) || expanded.has(key);
          return <li key={key} className="mb-1"><div className={`flex items-center rounded-lg ${selectedKey === key ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#10233A] hover:bg-[#F3F8FB]'}`}><button aria-label={`${open ? (lt ? 'Suskleisti' : 'Collapse') : (lt ? 'Išskleisti' : 'Expand')} ${category.title[lang]}`} aria-expanded={open} onClick={() => toggle(key)} className="flex h-10 w-7 shrink-0 items-center justify-center">{open ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</button><button onClick={() => choose({ kind: 'category', category })} className="flex min-w-0 flex-1 items-center gap-2 py-2 text-left text-xs font-semibold leading-5"><Folder size={15} className="shrink-0 text-[#7288A3]" />{category.title[lang] || category.title[1 - lang]}</button>{!isHelpGroupVisible(category.id, state) && <EyeOff size={13} className="mx-2 shrink-0 text-[#8CA1B4]" />}</div>{open && <ul className="ml-3 border-l border-[#D3E1EC] pl-1">{renderNodes(key)}</ul>}</li>;
        })}</ul>{tree.search && !tree.matched.size && <p className="p-4 text-xs text-[#7288A3]">{lt ? 'Temų nerasta.' : 'No matching topics.'}</p>}</nav>
        <p className="border-t border-[#E5EDF9] px-4 py-3 text-[10px] leading-4 text-[#7288A3]">{lt ? 'Paslėptos temos lieka medyje. Turinys ir įkelti failai saugomi šioje naršyklėje.' : 'Hidden topics stay in the tree. Content and uploaded files are saved in this browser.'}</p>
      </aside>
      <div className="min-h-0 min-w-0 overflow-auto p-4 lg:p-5">{selection.kind === 'article' ? <HelpArticleEditor key={selectedKey} original={selection.article} onDirty={setDirty} /> : <HelpCategoryEditor key={selectedKey} original={selection.category} onDirty={setDirty} />}</div>
    </div>
    {pending && <div className="fixed inset-0 z-[200] flex items-center justify-center bg-[#10233A]/25 p-5"><section role="dialog" aria-modal="true" aria-labelledby="help-discard-title" className="w-full max-w-md rounded-xl border border-[#D3E1EC] bg-white p-6 shadow-xl"><h2 id="help-discard-title" className="text-lg font-semibold">{lt ? 'Neišsaugoti pakeitimai' : 'Unsaved changes'}</h2><p className="my-4 text-sm text-[#7288A3]">{lt ? 'Pereiti į kitą temą ir atmesti šios temos pakeitimus?' : 'Switch topic and discard the unsaved changes?'}</p><div className="flex justify-end gap-2"><button className={helpEditorButton} onClick={() => setPending(null)}>{lt ? 'Tęsti redagavimą' : 'Keep editing'}</button><button className={helpEditorButton} onClick={() => { dirty.current = false; setSelection(pending); setPending(null); }}>{lt ? 'Atmesti' : 'Discard'}</button></div></section></div>}
  </main>;
}
