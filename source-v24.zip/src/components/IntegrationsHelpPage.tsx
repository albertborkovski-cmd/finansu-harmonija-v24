import { ArrowLeft, ArrowUpRight, BookOpen, CheckCircle2, Settings2, ExternalLink, Info, Search } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLanguage, translateUi as t } from '../i18n/language';
import { INTEGRATION_ARTICLES, integrationArticle, type IntegrationArticle } from '../lib/integrationHelp';
import { exportHelpFields, exportFieldHelp, exportHelpHref } from '../lib/exportSettingsHelp';
import { API_EXPORT_STEPS, CURRENT_INTEGRATION_NOTICE, EXPORT_TUTORIALS, FILE_EXPORT_STEPS, RIVILE_GUIDE_SOURCES, type HelpText } from '../lib/exportHelpGuide';
import { HelpScreenshot, HelpVideo } from './HelpMedia';
import { integrationHelpHref } from './IntegrationHelpLink';

const methodLabels: Record<IntegrationArticle['method'], HelpText> = {
  api: ['API connection', 'API ryšys'], file: ['File export', 'Failo eksportas'], folder: ['Folder connection', 'Aplanko ryšys'],
  email: ['Email', 'El. paštas'], planned: ['Not connected', 'Neprijungta'],
};
const companyPath: HelpText = ['All Documents → Documents → select organization → gear → Documents & digitization setup → Export format', 'Visi dokumentai → Dokumentai → pasirinkite organizaciją → dantratis → Dokumentų ir skaitmeninimo nustatymai → Eksporto formatas'];

export default function IntegrationsHelpPage() {
  const lt = useLanguage() === 'lt', lang = lt ? 1 : 0;
  const [query, setQuery] = useState('');
  const article = integrationArticle(new URLSearchParams(window.location.hash.split('?')[1] || '').get('integration'));
  const accounting = article.group === 'accounting';
  const fields = accounting ? exportHelpFields(article.id, 'overview') : [];
  const filtered = INTEGRATION_ARTICLES.filter(item => `${item.name[lang]} ${item.summary[lang]}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  const steps = article.steps || (article.method === 'api' ? API_EXPORT_STEPS : article.method === 'email' ? [
    ['Configure the receiving email and code mappings for the organization.', 'Organizacijai nustatykite gavėjo el. paštą ir kodų atitikmenis.'],
    ['Once secure mail delivery is connected, prepare only the selected documents for that destination.', 'Prijungus saugų siuntimą, paruoškite tik tam gavėjui pažymėtus dokumentus.'],
    ['Check delivery and the receiving accounting import separately. The current frontend sends no email.', 'Pristatymą ir gavėjo importą tikrinkite atskirai. Dabartinis frontend laiškų nesiunčia.'],
  ] as HelpText[] : FILE_EXPORT_STEPS);
  const videos = EXPORT_TUTORIALS.filter(video => article.id.startsWith(video.format));
  useEffect(() => { document.title = `Finansų harmonija · ${lt ? 'Integracijos' : 'Integrations'} · ${article.name[lang]}`; }, [article, lang, lt]);
  return <main className="min-h-screen bg-[#F5F8FB] p-4 font-montserrat text-[#10233A] sm:p-8">
    <div className="mx-auto max-w-6xl">
      <a href="./#help/organization" className="mb-4 inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]"><ArrowLeft size={15} />{lt ? 'Pagalbos centras' : 'Help centre'}</a>
      <header className="mb-5 flex items-center gap-3"><BookOpen size={24} className="text-[#007EA7]" /><div><p className="text-[12px] font-medium text-[#7288A3]">Finansų harmonija · {t('Help')}</p><h1 className="text-[22px] font-semibold">{lt ? 'Integracijos' : 'Integrations'}</h1></div></header>
      <div className="grid items-start gap-5 md:grid-cols-[255px_minmax(0,1fr)]">
        <nav aria-label={lt ? 'Integracijų sąrašas' : 'Integration catalog'} className="rounded-xl border border-[#D3E1EC] bg-white p-3 md:sticky md:top-5">
          <label className="mb-3 flex items-center gap-2 rounded-lg border border-[#D3E1EC] px-3 py-2 focus-within:border-[#007EA7]"><Search size={16} className="shrink-0 text-[#7288A3]" /><input aria-label={lt ? 'Ieškoti integracijos' : 'Search integrations'} placeholder={lt ? 'Ieškoti integracijos' : 'Search integrations'} value={query} onChange={event => setQuery(event.target.value)} className="min-w-0 w-full bg-transparent text-[12px] outline-none" /></label>
          <div className="max-h-[65vh] space-y-4 overflow-y-auto pr-1">
            {(['collection', 'accounting'] as const).map(group => <section key={group}><h2 className="px-3 pb-2 pt-1 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{group === 'collection' ? (lt ? 'Dokumentų surinkimas' : 'Document collection') : (lt ? 'Apskaitos sistemos ir formatai' : 'Accounting systems & formats')} <span className="font-normal">({INTEGRATION_ARTICLES.filter(item => item.group === group).length})</span></h2>{filtered.filter(item => item.group === group).map(item => <a key={item.id} href={integrationHelpHref(item.id)} aria-current={article.id === item.id ? 'page' : undefined} className={`block rounded-md px-3 py-2 text-[13px] font-medium leading-5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] ${article.id === item.id ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#526B86] hover:bg-[#F2F6FA]'}`}>{item.name[lang]}</a>)}</section>)}
            {filtered.length === 0 && <p role="status" className="px-3 text-[12px] text-[#7288A3]">{lt ? 'Integracijų nerasta.' : 'No integrations found.'}</p>}
          </div>
        </nav>
        <div className="min-w-0 space-y-5">
          <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3"><h2 className="text-[21px] font-semibold">{article.name[lang]}</h2><span className="rounded-md bg-[#EBF5FA] px-3 py-1 text-[11px] font-semibold text-[#007EA7]">{methodLabels[article.method][lang]}</span></div>
            <p className="text-[13px] leading-6 text-[#526B86]">{article.summary[lang]}</p>
            <div className="mt-5 rounded-lg border border-[#D3E1EC] bg-[#F7FAFC] p-4"><h3 className="mb-2 flex items-center gap-2 text-[13px] font-semibold"><Settings2 size={16} className="text-[#007EA7]" />{lt ? 'Kur nustatyti ir nuo ko pradėti' : 'Where to configure and how to start'}</h3>{accounting && <p className="mb-3 text-[12px] leading-6 text-[#007EA7]">{companyPath[lang]}: <strong>{article.id}</strong></p>}<p className="text-[13px] leading-6 text-[#526B86]">{article.setup[lang]}</p></div>
            <aside className="mt-4 flex gap-2.5 text-[12px] leading-5 text-[#7288A3]"><Info size={16} className="mt-0.5 shrink-0 text-[#007EA7]" /><p>{accounting ? CURRENT_INTEGRATION_NOTICE[lang] : lt ? 'Šioje FH versijoje galima peržiūrėti ir išsaugoti nustatymus. Tikras surinkimas, autorizacija ir API rakto išdavimas dar neprijungti. Tikrų raktų į pagalbą ar pokalbį nekelkite.' : 'This FH version supports settings and previews. Live collection, authorization and API key issuance are not connected. Do not put real credentials in help or chat.'}</p></aside>
          </section>
          <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7"><h3 className="mb-5 text-[16px] font-semibold">{lt ? 'Veiksmų eiga' : 'Workflow'}</h3><ol className="space-y-4">{steps.map((step, index) => <li key={index} className="flex gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E5EDF9] text-[11px] font-semibold text-[#007EA7]">{index + 1}</span><p className="text-[13px] leading-6 text-[#526B86]">{step[lang]}</p></li>)}</ol></section>
          {(fields.length > 0 || article.fields) && <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7"><h3 className="text-[16px] font-semibold">{lt ? 'Laukai ir jų reikšmės' : 'Fields and their meanings'}</h3><dl className="mt-2 divide-y divide-[#E5EDF9]">{fields.map(field => <div key={field.key} className="py-4"><dt className="text-[13px] font-semibold">{t(field.label)}</dt><dd className="mt-1 text-[13px] leading-6 text-[#526B86]">{exportFieldHelp(field, lt)}</dd></div>)}{article.fields?.map(field => <div key={field.label[0]} className="py-4"><dt className="text-[13px] font-semibold">{field.label[lang]}</dt><dd className="mt-1 text-[13px] leading-6 text-[#526B86]">{field.description[lang]}</dd></div>)}</dl></section>}
          <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7"><h3 className="flex items-center gap-2 text-[16px] font-semibold"><CheckCircle2 size={18} className="text-[#007EA7]" />{lt ? 'Ką tikrinti, jei nepavyksta' : 'What to check if it fails'}</h3><p className="mt-3 text-[13px] leading-6 text-[#526B86]">{article.checks[lang]}</p>{accounting && <a href={exportHelpHref(article.id)} className="mt-4 inline-flex items-center gap-2 text-[13px] font-semibold text-[#007EA7] underline underline-offset-2">{lt ? 'Išsami formato, papildomų stulpelių ir klaidų pagalba' : 'Detailed format, additional-column and error guide'}<ArrowUpRight size={14} /></a>}</section>
          {accounting && <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7"><HelpScreenshot lt={lt} file="export-settings.jpg" caption={lt ? 'FH organizacijos nustatymų pavyzdys. Pasirinkus kitą eksporto formatą jo laukai pasikeičia.' : 'FH organization settings example. Selecting another export format changes its fields.'} /></section>}
          {['google-drive', 'sharepoint'].includes(article.id) && <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7"><HelpScreenshot lt={lt} file={`${article.id}.jpg`} caption={lt ? `FH: ${article.name[lang]} nustatymai. Prisijungimo duomenys neįvesti.` : `FH: ${article.name[lang]} settings. No credentials entered.`} /></section>}
          {videos.length > 0 && <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7"><h3 className="mb-3 text-[16px] font-semibold">{lt ? 'Vaizdo instrukcija gavėjo sistemai' : 'Destination-system video tutorial'}</h3><p className="mb-4 text-[12px] leading-5 text-[#7288A3]">{lt ? 'Išorinis originalus mokomasis įrašas; jame rodoma ne FH sąsaja. Įkeliamas tik paspaudus.' : 'Original external tutorial, not the FH interface. Loaded only when selected.'}</p>{videos.map(video => <HelpVideo key={video.id} {...video} lt={lt} />)}</section>}
          {(article.links || article.id.startsWith('Rivilė') || article.id === 'Business Central') && <footer className="rounded-lg border border-[#D3E1EC] bg-white p-4"><h3 className="mb-2 text-[12px] font-semibold">{lt ? 'Oficiali tiekėjo pagalba' : 'Official provider help'}</h3><div className="flex flex-wrap gap-4">{[...(article.links || []), ...(article.id.startsWith('Rivilė') ? RIVILE_GUIDE_SOURCES.filter(source => article.id === 'Rivilė ERP' ? source.title.includes('ERP') : !source.title.includes('ERP')).map(source => ({ label: source.title, url: source.url })) : []), ...(article.id === 'Business Central' ? [{ label: 'Microsoft Learn · Posting groups', url: 'https://learn.microsoft.com/en-us/dynamics365/business-central/finance-posting-groups' }] : [])].map(link => <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[12px] text-[#007EA7] underline">{link.label}<ExternalLink size={12} /></a>)}</div></footer>}
        </div>
      </div>
    </div>
  </main>;
}
