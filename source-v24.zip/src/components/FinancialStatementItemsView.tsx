import { useLanguage } from '../i18n/language';
import { statementText as uiText, statementMessage, statementArticleText, statementErrorText, statementAuditValueText } from '../i18n/financialStatements';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronDown, ChevronRight, Download, History, Info, Link2, ListChecks, Pencil, Plus, Unlink } from 'lucide-react';
import type { Company } from '../lib/supabase';
import { toggleFilteredSelection } from '../lib/tableSelection';
import { usePersistentState } from '../hooks/usePersistentState';
import useWorkspaceExpansion from '../hooks/useWorkspaceExpansion';
import { STATEMENT_OPERATIONS, STATEMENT_REPORTS, statementArticleUsed, statementLeafAccounts, statementMappingsCsv, statementStorageKey, suggestStatementMappings, type StatementAccount, type StatementArticle, type StatementCommand, type StatementOperation, type StatementReport, type StatementStore, type StatementSuggestion } from '../lib/financialStatementArticles';
import { loadStatementAccounts, loadStatementStore, statementArticleLinked, statementPermissions, STATEMENT_CHANGED, updateStatementStore } from '../lib/financialStatementStore';
import { PageActionButton, PageHeader } from './PageHeader';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import SearchableSelect from './SearchableSelect';
import OcrSearchField from './OcrSearchField';
import SystemAddFilters from './SystemAddFilters';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';
import RefreshAllButton from './RefreshAllButton';
import WorkspaceExpandButton from './WorkspaceExpandButton';
import GlJournalDialog from './GlJournalDialog';
import { RowDeleteButton } from './DeleteButtons';

const COLUMNS: ColConfig[] = [
  { key: 'accountCode', label: 'GL account', width: 115, visible: true },
  { key: 'accountName', label: 'Account name', width: 260, visible: true },
  { key: 'operation', label: 'Operation', width: 110, visible: true },
  { key: 'articleCode', label: 'Item code', width: 110, visible: true },
  { key: 'articleName', label: 'Financial statement item', width: 230, visible: true },
  { key: 'group', label: 'Group', width: 230, visible: false },
  { key: 'report', label: 'Report', width: 140, visible: false },
  { key: 'status', label: 'Status', width: 165, visible: true },
  { key: 'updatedBy', label: 'Updated by', width: 200, visible: false },
  { key: 'updatedAt', label: 'Last update', width: 170, visible: false },
];
type AccountRow = { id: string; articleId?: string; accountCode: string; accountName: string; operation: string; articleCode: string; articleName: string; group: string; report: string; status: string; updatedBy: string; updatedAt: string; inactive?: boolean };
type Mode = 'unassigned' | 'article' | 'all';
const input = 'h-9 w-full rounded-md border border-[#D3E1EC] bg-white px-3 text-[12px] text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10 disabled:bg-[#F2F5F9]';
const iconButton = 'flex h-7 w-7 shrink-0 items-center justify-center text-[#7288A3] transition-colors enabled:hover:text-[#007EA7] disabled:opacity-40';
const label = 'flex min-w-0 flex-col gap-1.5 text-[12px] text-[#7288A3]';
function SelectCheck({ checked, mixed, disabled = false, title, onClick }: { checked: boolean; mixed?: boolean; disabled?: boolean; title: string; onClick: () => void }) {
  return <button type="button" role="checkbox" aria-checked={mixed ? 'mixed' : checked} aria-label={uiText(title)} disabled={disabled} onClick={onClick} className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border disabled:opacity-40 ${checked || mixed ? 'border-[#007EA7] bg-[#007EA7] text-white' : 'border-[#A1B6C6] bg-white'}`}>{checked ? <Check size={12} strokeWidth={2.5} /> : mixed ? <span className="h-px w-2 bg-white" /> : null}</button>;
}

export default function FinancialStatementItemsView({ company }: { company: Company }) {
  const language = useLanguage();
  const locale = language === 'lt' ? 'lt-LT' : 'en-GB';
  const [root, setRoot] = useState<HTMLElement | null>(null);
  const [expanded, setExpanded] = useState(false);
  useWorkspaceExpansion(expanded, root, setExpanded);
  const [store, setStore] = useState<StatementStore | null>(null);
  const [accounts, setAccounts] = useState<StatementAccount[]>([]);
  const [loadError, setLoadError] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState<{ template: string; values?: Record<string, string | number> } | null>(null);
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState<StatementReport>('Balance sheet');
  const [articleId, setArticleId] = useState('statement-A-1.1');
  const [operation, setOperation] = useState<StatementOperation>('Debit');
  const [mode, setMode] = useState<Mode>('unassigned');
  const [treeSearch, setTreeSearch] = useState('');
  const [collapsed, setCollapsed] = useState(new Set<string>());
  const [query, setQuery] = useState('');
  const [filterKeys, setFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const [selections, setSelections] = useState<Record<string, Set<string>>>({});
  const [columns, setColumns] = usePersistentState<ColConfig[]>(`finansu-harmonija:v20:statement-item-columns:${company.id}`, COLUMNS);
  const [showColumns, setShowColumns] = useState(false);
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState<StatementArticle | null>(null);
  const [mappingEdit, setMappingEdit] = useState<{ mappingId: string; articleId: string; operation: StatementOperation } | null>(null);
  const [confirmation, setConfirmation] = useState<StatementCommand | null>(null);
  const [suggestions, setSuggestions] = useState<StatementSuggestion[] | null>(null);
  const [suggestionSelection, setSuggestionSelection] = useState(new Set<string>());
  const [history, setHistory] = useState(false);
  const [help, setHelp] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(columns, setColumns);
  const refresh = useCallback(() => {
    try { setStore(loadStatementStore(company)); setAccounts(loadStatementAccounts(company)); setLoadError(''); }
    catch (cause) { setLoadError(cause instanceof Error ? cause.message : 'Reporting mappings could not be loaded.'); setStore(null); setAccounts([]); }
  }, [company]);
  useEffect(() => {
    refresh();
    const onStorage = (event: StorageEvent) => { if (!event.key || event.key === statementStorageKey(company.id, company.general_ledger?.trim() || '') || event.key.includes('general-ledger') || event.key.includes('authenticated')) refresh(); };
    const onCompany = (event: Event) => { const id = (event as CustomEvent<{ companyId?: string }>).detail?.companyId; if (!id || id === company.id) refresh(); };
    window.addEventListener('storage', onStorage); window.addEventListener(STATEMENT_CHANGED, onCompany); window.addEventListener('company-general-ledger-updated', onCompany);
    return () => { window.removeEventListener('storage', onStorage); window.removeEventListener(STATEMENT_CHANGED, onCompany); window.removeEventListener('company-general-ledger-updated', onCompany); };
  }, [refresh, company.id, company.general_ledger]);
  const mayEdit = statementPermissions(company).edit && !loadError && !busy;
  const articles = store?.articles ?? [];
  const article = articles.find(item => item.id === articleId && item.report === report);
  const leaf = useMemo(() => statementLeafAccounts(accounts), [accounts]);
  const accountByCode = useMemo(() => new Map(leaf.map(item => [item.code, item])), [leaf]);
  const mapped = useMemo(() => store?.mappings.filter(m => store.articles.find(a => a.id === m.articleId)?.report === report) ?? [], [store, report]);
  const mappedCodes = new Set(mapped.map(m => m.accountCode));
  const unassigned = leaf.filter(account => !mappedCodes.has(account.code));
  const scope = `${report}:${mode}:${mode === 'article' ? articleId : ''}`;
  const selected = selections[scope] ?? new Set<string>();
  const setSelected = (ids: Set<string>) => setSelections(previous => ({ ...previous, [scope]: ids }));
  const rows: AccountRow[] = mode === 'unassigned'
    ? unassigned.map(account => ({ id: account.code, accountCode: account.code, accountName: account.name, operation: '', articleCode: '', articleName: '', group: '', report, status: 'Unassigned', updatedBy: '', updatedAt: '' }))
    : mapped.filter(m => mode === 'all' || m.articleId === articleId).map(m => {
      const a = articles.find(item => item.id === m.articleId)!;
      const liveAccount = accountByCode.get(m.accountCode);
      return { id: m.id, articleId: a.id, accountCode: m.accountCode, accountName: liveAccount?.name || m.accountName, operation: m.operation, articleCode: a.code, articleName: a.name, group: a.group, report: a.report, status: !liveAccount ? 'Account unavailable' : a.inactive ? 'Item inactive' : 'Linked', updatedBy: m.updatedBy, updatedAt: m.updatedAt, inactive: a.inactive || !liveAccount };
    });
  const rowText = (row: AccountRow, key: string): string => {
    const value = String(row[key as keyof AccountRow] || '—');
    if (['operation', 'report', 'status'].includes(key)) return uiText(value);
    if (key === 'updatedAt' && row.updatedAt) return new Date(row.updatedAt).toLocaleString(locale);
    const item = articles.find(a => a.id === row.articleId);
    if (item && key === 'articleName') return statementArticleText(item, 'name');
    if (item && key === 'group') return statementArticleText(item, 'group');
    return value;
  };
  const filtered = rows.filter(row => COLUMNS.some(column => `${row[column.key as keyof AccountRow] ?? ''} ${rowText(row, column.key)}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())) && filterKeys.every(key => !filterValues[key]?.length || filterValues[key].includes(String(row[key as keyof AccountRow] || '—'))));
  const sorter = useMultiColumnSort<AccountRow, string>(filtered, (row, key) => key === 'updatedAt' ? row.updatedAt : rowText(row, key));
  const visible = columns.filter(column => column.visible && (mode !== 'unassigned' || ['accountCode', 'accountName', 'status'].includes(column.key)));
  const eligibleSelected = rows.filter(row => selected.has(row.id));
  const allSelected = filtered.length > 0 && filtered.every(row => selected.has(row.id));
  const safePage = Math.min(page, Math.max(1, Math.ceil(filtered.length / 50)));
  const grid = `40px ${visible.map(column => `${column.width}px`).join(' ')} minmax(76px,1fr)`;
  const reportArticles = articles.filter(a => a.report === report).sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true }));
  const treeArticles = reportArticles.filter(a => `${a.code} ${a.name} ${a.group} ${statementArticleText(a, 'name')} ${statementArticleText(a, 'group')}`.toLocaleLowerCase().includes(treeSearch.trim().toLocaleLowerCase()));
  const groups = [...new Set(treeArticles.map(a => a.group))];
  const run = async (command: StatementCommand, success: string, values?: Record<string, string | number>) => {
    if (!store || busy) return;
    setBusy(true); setError(''); setMessage(null);
    try {
      const next = await updateStatementStore(company, store.revision, command); setStore(next); setMessage({ template: success, values });
      setEditing(null); setMappingEdit(null); setConfirmation(null); setSuggestions(null); setSelected(new Set());
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Changes could not be saved.'); }
    finally { setBusy(false); }
  };
  const chooseArticle = (a: StatementArticle) => { setArticleId(a.id); setOperation(a.operation); setPage(1); };
  const changeReport = (value: string) => { const next = value as StatementReport; setReport(next); const first = articles.find(a => a.report === next && !a.inactive); if (first) chooseArticle(first); setPage(1); setFilterKeys([]); setFilterValues({}); };
  const assign = (codes: string[]) => { if (article) void run({ type: 'assign', links: codes.map(accountCode => ({ accountCode, articleId: article.id, operation })) }, '{count} GL accounts linked to {code}.', { count: codes.length, code: article.code }); };
  const previewSuggestions = () => { if (!store) return; const items = suggestStatementMappings(store, accounts, report); setSuggestions(items); setSuggestionSelection(new Set(items.map(item => item.accountCode))); setError(''); };
  const exportMappings = () => {
    if (!store) return;
    const url = URL.createObjectURL(new Blob([statementMappingsCsv(store, { label: uiText, article: statementArticleText })], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = `financial-statement-mappings-${company.id}.csv`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return <main ref={setRoot} className="flex h-screen min-w-0 flex-col gap-5 overflow-hidden bg-white py-14 font-montserrat text-[#10233A]" style={{ paddingLeft: 'clamp(24px, 4vw, 56px)', paddingRight: 'clamp(24px, 4vw, 56px)' }}>
    <PageHeader title={uiText("Financial statement items")} actions={<><button type="button" aria-label={uiText("How financial statement items work")} title={uiText("How it works")} className={iconButton} onClick={() => setHelp(true)}><Info size={17} /></button><PageActionButton icon={<Plus size={15} />} disabled={!mayEdit || !store} onClick={() => { setError(''); setEditing({ id: crypto.randomUUID(), code: '', name: '', report, group: article?.group || '', operation: report === 'Balance sheet' ? 'Debit' : 'Credit', inactive: false }); }}>{uiText("New item")}</PageActionButton></>} />
    <CompanyBreadcrumb companyName={company.name} items={['GL journal', 'Financial statement items']} />
    <div data-table-workspace-overview className="flex shrink-0 flex-wrap items-center gap-x-6 gap-y-2 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3 text-[12px]">
      <span><strong className="mr-1 text-[#007EA7]">{new Set(mapped.filter(m => accountByCode.has(m.accountCode)).map(m => m.accountCode)).size}</strong>{uiText(" linked accounts")}</span><span><strong className="mr-1">{unassigned.length}</strong>{uiText(" unassigned")}</span><span className="ml-auto text-[#7288A3]">{uiText(company.general_ledger || '') || uiText('No company chart assigned')}</span>
    </div>
    {(loadError || error) && <p role="alert" className="shrink-0 text-[12px] text-[#B42318]">{statementErrorText(loadError || error)}</p>}
    {message && <p role="status" className="shrink-0 text-[12px] text-[#087A5B]">{statementMessage(message.template, message.values ?? {})}</p>}
    <div className="flex shrink-0 flex-wrap items-center justify-between gap-3">
      <div className="w-[220px]"><SearchableSelect ariaLabel={uiText("Financial report")} value={report} options={STATEMENT_REPORTS.map(value => ({ value, label: uiText(value) }))} onChange={changeReport} className={input} /></div>
      <div data-table-workspace-tools className="ml-auto flex items-center gap-4">
        <PageActionButton icon={<ListChecks size={15} />} disabled={!mayEdit || !unassigned.length} onClick={previewSuggestions}>{uiText("Suggest mappings")}</PageActionButton>
        <button type="button" className={iconButton} aria-label={uiText("Mapping history")} title={uiText("History")} disabled={!store?.audit.length} onClick={() => setHistory(true)}><History size={16} /></button>
        <ColumnSettingsButton onClick={() => setShowColumns(true)} />
        <button type="button" data-button-family="export" aria-label={uiText("Export mappings")} title={uiText("EXPORT")} className={iconButton} disabled={!store?.mappings.length} onClick={exportMappings}><Download size={16} /></button>
        <RefreshAllButton onRefresh={() => { setError(''); setMessage(null); refresh(); }} />
        <WorkspaceExpandButton expanded={expanded} onClick={() => setExpanded(value => !value)} />
      </div>
    </div>
    <div className="financial-statement-layout grid min-h-0 flex-1 grid-cols-[minmax(230px,290px)_minmax(0,1fr)] gap-4">
      <aside aria-label={uiText("Financial statement item tree")} className="flex min-h-0 flex-col overflow-hidden rounded-lg border border-[#D3E1EC]">
        <div className="shrink-0 border-b border-[#E5EDF9] p-3"><div className="mb-3 flex items-center justify-between text-[12px] font-semibold"><span>{uiText("Statement items")}</span><span className="text-[11px] font-medium text-[#7288A3]">{reportArticles.length}</span></div><OcrSearchField ariaLabel={uiText("Search statement items")} value={treeSearch} onChange={setTreeSearch} className="!w-full !min-w-0 !max-w-none" /></div>
        <div className="min-h-0 flex-1 overflow-y-auto p-2">{groups.map(group => <section key={group} className="mb-1"><button type="button" aria-expanded={!collapsed.has(group) || !!treeSearch} className="flex w-full items-center gap-1.5 rounded px-2 py-2 text-left text-[11px] font-semibold text-[#7288A3] hover:bg-[#F2F5F9]" onClick={() => setCollapsed(previous => toggleFilteredSelection(previous, [group]))}>{collapsed.has(group) && !treeSearch ? <ChevronRight size={14} className="shrink-0" /> : <ChevronDown size={14} className="shrink-0" />}<span>{statementArticleText(treeArticles.find(a => a.group === group)!, 'group')}</span></button>{(!collapsed.has(group) || !!treeSearch) && treeArticles.filter(a => a.group === group).map(a => <button key={a.id} type="button" aria-label={statementMessage('Select item {code} {name}', { code: a.code, name: statementArticleText(a, 'name') })} aria-pressed={a.id === articleId} data-static-selection="true" data-record-inactive={a.inactive || undefined} onClick={() => chooseArticle(a)} className={`my-0.5 flex min-h-10 w-full items-center gap-2 rounded-md px-2 py-2 text-left text-[12px] ${a.id === articleId ? 'bg-[#E5EDF9] text-[#007EA7]' : 'hover:bg-[#F8FDFF]'}`}><span className="w-12 shrink-0 text-[11px] font-medium">{a.code}</span><span className="min-w-0 flex-1 leading-4">{statementArticleText(a, 'name')}</span><span className="text-[10px] tabular-nums text-[#7288A3]">{mapped.filter(m => m.articleId === a.id).length}</span></button>)}</section>)}{!groups.length && <p className="p-3 text-[12px] text-[#7288A3]">{uiText("No matching items.")}</p>}</div>
      </aside>
      <section aria-label={uiText("GL account mappings")} className="flex min-h-0 min-w-0 flex-col gap-3">
        <div className="flex min-h-[70px] shrink-0 items-center gap-3 rounded-lg border border-[#D3E1EC] px-4 py-3">
          <div className="min-w-0 flex-1"><p className="mb-1 text-[10px] font-medium uppercase tracking-wide text-[#7288A3]">{uiText("Selected item")}</p><p className="truncate text-[13px] font-semibold" title={article ? `${article.code} · ${statementArticleText(article, 'name')}` : ''}>{article ? `${article.code} · ${statementArticleText(article, 'name')}` : uiText('Select an item from the tree')}{article?.inactive && <span className="ml-2 text-[11px] text-[#B42318]">{uiText("Inactive")}</span>}</p></div>
          <div className="w-[130px] shrink-0"><SearchableSelect ariaLabel={uiText("Mapping operation")} value={operation} options={STATEMENT_OPERATIONS.map(value => ({ value, label: uiText(value) }))} onChange={value => setOperation(value as StatementOperation)} disabled={!mayEdit || !article || article.inactive} className={input} /></div>
          <button type="button" aria-label={uiText("Edit selected statement item")} title={uiText("Edit item")} disabled={!mayEdit || !article} className={iconButton} onClick={() => { if (article) { setEditing({ ...article }); setError(''); } }}><Pencil size={16} /></button>
        </div>
        <div role="tablist" aria-label={uiText("Mapping views")} className="flex shrink-0 gap-5 border-b border-[#D3E1EC] text-[12px]">{([['unassigned', 'Unassigned accounts', unassigned.length], ['article', 'Selected item', mapped.filter(m => m.articleId === articleId).length], ['all', 'All mappings', mapped.length]] as const).map(([value, title, count]) => <button type="button" role="tab" aria-selected={mode === value} key={value} onClick={() => { setMode(value); setPage(1); }} className={`flex items-center gap-2 border-b-2 pb-2.5 font-medium ${mode === value ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3] hover:text-[#007EA7]'}`}>{uiText(title)}<span className="rounded bg-[#F2F5F9] px-1.5 py-0.5 text-[10px] tabular-nums">{count}</span></button>)}</div>
        <div className="flex shrink-0 flex-wrap items-center justify-between gap-2"><OcrSearchField ariaLabel={uiText("Search GL account mappings")} value={query} onChange={value => { setQuery(value); setPage(1); }} /><div className="flex items-center gap-2">{mode === 'unassigned' ? <PageActionButton icon={<Link2 size={15} />} disabled={!mayEdit || !article || article.inactive || !eligibleSelected.length} onClick={() => assign(eligibleSelected.map(row => row.accountCode))}>{uiText("Link selected")}{eligibleSelected.length ? ` (${eligibleSelected.length})` : ''}</PageActionButton> : <PageActionButton icon={<Unlink size={15} />} disabled={!mayEdit || !eligibleSelected.length} onClick={() => setConfirmation({ type: 'unlink', mappingIds: eligibleSelected.map(row => row.id) })}>{uiText("Unlink selected")}</PageActionButton>}</div></div>
        <SystemAddFilters columns={COLUMNS.map(column => ({ key: column.key, label: uiText(column.label), optionLabels: Object.fromEntries(rows.map(row => [String(row[column.key as keyof AccountRow] || '—'), rowText(row, column.key)])), options: [...new Set(rows.map(row => String(row[column.key as keyof AccountRow] || '—')))] }))} activeKeys={filterKeys} values={filterValues} onActiveKeysChange={setFilterKeys} onValuesChange={setFilterValues} />
        {selected.size > 0 && <div className="flex shrink-0 items-center gap-3 text-[11px] text-[#7288A3]"><span>{eligibleSelected.length}{uiText(" selected · selection is retained when filters change")}</span><button type="button" className="text-[#007EA7] hover:underline" onClick={() => setSelected(new Set())}>{uiText("Clear selection")}</button></div>}
        <div ref={scrollRef} role="region" aria-label={uiText("Financial statement GL accounts")} tabIndex={0} className="min-h-0 flex-1 overflow-auto overscroll-contain scrollbar-hide">
          <div role="table" aria-label={uiText("Financial statement account mappings")} className="w-full text-[12px]" style={{ minWidth: 116 + visible.reduce((total, column) => total + column.width, 0) }}>
            <div role="row" className="system-table-header-row sticky top-0 z-10 grid h-10 items-center border-b border-[#D3E1EC] bg-white font-medium" style={{ gridTemplateColumns: grid }}><div role="columnheader" className="px-3"><SelectCheck checked={allSelected} mixed={!allSelected && filtered.some(row => selected.has(row.id))} title={uiText("Select all filtered accounts")} onClick={() => setSelected(toggleFilteredSelection(selected, filtered.map(row => row.id)))} /></div>{visible.map(column => <div key={column.key} role="columnheader" className="relative flex min-w-0 items-center gap-1 px-3"><span className="truncate" title={uiText(column.label)}>{uiText(column.label)}</span><ColumnSortButton columnLabel={uiText(column.label)} direction={sorter.directionFor(column.key)} onDirectionChange={direction => sorter.changeSort(column.key, direction)} /><ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} /></div>)}<div role="columnheader" className="system-table-row-actions"><span className="sr-only">{uiText("Actions")}</span></div></div>
            {sorter.sortedRows.slice(0, safePage * 50).map((row, index) => <div key={row.id} role="row" data-record-inactive={row.inactive || undefined} className={`my-0.5 grid min-h-10 items-center rounded-lg ${selected.has(row.id) ? 'bg-[#E5EDF9]' : index % 2 ? 'bg-white' : 'bg-[#F8FDFF]'} hover:bg-[#E7F4F9]`} style={{ gridTemplateColumns: grid }}><div role="cell" className="px-3"><SelectCheck checked={selected.has(row.id)} title={statementMessage('Select GL account {code}', { code: row.accountCode })} onClick={() => setSelected(toggleFilteredSelection(selected, [row.id]))} /></div>{visible.map(column => <div key={column.key} role="cell" className="min-w-0 truncate px-3 py-2" title={rowText(row, column.key)}>{column.key === 'status' ? <span className={`rounded px-2 py-1 text-[10px] font-medium ${row.status === 'Linked' ? 'bg-[#E6F6EF] text-[#087A5B]' : row.inactive ? 'bg-[#FFF3DF] text-[#9A6300]' : 'bg-[#E5EDF9] text-[#7288A3]'}`}>{uiText(row.status)}</span> : rowText(row, column.key)}</div>)}<div role="cell" className="system-table-row-actions flex items-center justify-end gap-1 px-2">{mode === 'unassigned' ? <button type="button" className={iconButton} title={uiText("Link to selected item")} aria-label={statementMessage('Link {code} to selected item', { code: row.accountCode })} disabled={!mayEdit || !article || article.inactive} onClick={() => assign([row.accountCode])}><Link2 size={16} /></button> : <><button type="button" className={iconButton} title={uiText("Edit mapping")} aria-label={statementMessage('Edit mapping {code}', { code: row.accountCode })} disabled={!mayEdit || !accountByCode.has(row.accountCode)} onClick={() => { const m = store!.mappings.find(item => item.id === row.id)!; setMappingEdit({ mappingId: m.id, articleId: m.articleId, operation: m.operation }); setError(''); }}><Pencil size={15} /></button><button type="button" className={iconButton} title={uiText("Unlink account")} aria-label={statementMessage('Unlink {code}', { code: row.accountCode })} disabled={!mayEdit} onClick={() => setConfirmation({ type: 'unlink', mappingIds: [row.id] })}><Unlink size={15} /></button></>}</div></div>)}
            {!filtered.length && <div className="py-14 text-center text-[12px] text-[#7288A3]">{!company.general_ledger ? uiText('Assign a chart in Manage company → Accounting setup first.') : mode === 'article' ? uiText('No accounts linked to this item. Select accounts in Unassigned accounts.') : mode === 'unassigned' && !unassigned.length ? uiText('All available GL accounts are mapped in this report.') : uiText('No matching records.')}</div>}
          </div>
        </div>
        <HorizontalTableScrollbar scrollRef={scrollRef} expandable={false} />
        <TablePagination scrollRef={scrollRef} currentPage={safePage} totalPages={Math.max(1, Math.ceil(filtered.length / 50))} itemCount={filtered.length} itemsPerPage={50} onPageChange={setPage} />
      </section>
    </div>
    {showColumns && <ColumnSettingsPanel columns={columns.map(column => ({ ...column, label: uiText(column.label) }))} defaultColumns={COLUMNS.map(column => ({ ...column, label: uiText(column.label) }))} onSave={value => { setColumns(value.map(column => ({ ...column, label: COLUMNS.find(original => original.key === column.key)?.label ?? column.label }))); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
    {editing && <GlJournalDialog title={articles.some(a => a.id === editing.id) ? uiText('Edit financial statement item') : uiText('New financial statement item')} onClose={() => !busy && setEditing(null)} footer={<><div className="mr-auto">{articles.some(a => a.id === editing.id) && <RowDeleteButton variant="plain" label={statementMessage('Delete {code}', { code: editing.code })} linked={!!store && statementArticleLinked(store, editing.id)} inactive={editing.inactive} disabled={!mayEdit} onDelete={() => { setConfirmation({ type: 'remove-article', articleId: editing.id }); setEditing(null); }} />}</div><PageActionButton disabled={busy} onClick={() => setEditing(null)}>{uiText("Cancel")}</PageActionButton><PageActionButton disabled={!mayEdit} onClick={() => void run({ type: 'save-article', article: editing }, 'Financial statement item saved.')}>{uiText("Save")}</PageActionButton></>}>
      <div className="grid grid-cols-2 gap-4"><label className={label}>{uiText("Code *")}<input aria-label={uiText("Item code")} value={editing.code} onChange={event => setEditing({ ...editing, code: event.target.value })} className={input} maxLength={40} /></label><div className={label}>{uiText("Report *")}<SearchableSelect portalMenu ariaLabel={uiText("Item report")} value={editing.report} options={STATEMENT_REPORTS.map(value => ({ value, label: uiText(value) }))} disabled={!!store && statementArticleUsed(store, editing.id)} onChange={value => setEditing({ ...editing, report: value as StatementReport })} className={input} /></div><label className={`${label} col-span-2`}>{uiText("Name *")}<input aria-label={uiText("Item name")} value={statementArticleText(editing, 'name')} onChange={event => setEditing({ ...editing, name: event.target.value })} className={input} maxLength={180} /></label><label className={`${label} col-span-2`}>{uiText("Group *")}<input aria-label={uiText("Item group")} value={statementArticleText(editing, 'group')} onChange={event => setEditing({ ...editing, group: event.target.value })} className={input} maxLength={120} /></label><div className={label}>{uiText("Default operation")}<SearchableSelect portalMenu ariaLabel={uiText("Item default operation")} value={editing.operation} options={STATEMENT_OPERATIONS.map(value => ({ value, label: uiText(value) }))} onChange={value => setEditing({ ...editing, operation: value as StatementOperation })} className={input} /></div><div className={label}>{uiText("Status")}<SearchableSelect portalMenu ariaLabel={uiText("Item status")} value={editing.inactive ? 'Inactive' : 'Active'} options={['Active', 'Inactive'].map(value => ({ value, label: uiText(value) }))} onChange={value => setEditing({ ...editing, inactive: value === 'Inactive' })} className={input} /></div></div>
      {error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{statementErrorText(error)}</p>}
    </GlJournalDialog>}
    {mappingEdit && <GlJournalDialog title={uiText("Edit account mapping")} subtitle={store?.mappings.find(m => m.id === mappingEdit.mappingId)?.accountCode} onClose={() => !busy && setMappingEdit(null)} footer={<><PageActionButton disabled={busy} onClick={() => setMappingEdit(null)}>{uiText("Cancel")}</PageActionButton><PageActionButton disabled={!mayEdit} onClick={() => void run({ type: 'edit-mapping', ...mappingEdit }, 'Mapping updated.')}>{uiText("Save")}</PageActionButton></>}><div className="space-y-4"><div className={label}>{uiText("Financial statement item *")}<SearchableSelect portalMenu ariaLabel={uiText("Mapping item")} value={mappingEdit.articleId} options={articles.filter(a => !a.inactive).map(a => ({ value: a.id, label: `${a.code} · ${statementArticleText(a, 'name')} · ${uiText(a.report)}` }))} onChange={value => setMappingEdit({ ...mappingEdit, articleId: value })} className={input} /></div><div className={label}>{uiText("Operation *")}<SearchableSelect portalMenu ariaLabel={uiText("Edit mapping operation")} value={mappingEdit.operation} options={STATEMENT_OPERATIONS.map(value => ({ value, label: uiText(value) }))} onChange={value => setMappingEdit({ ...mappingEdit, operation: value as StatementOperation })} className={input} /></div></div>{error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{statementErrorText(error)}</p>}</GlJournalDialog>}
    {confirmation && <GlJournalDialog title={confirmation.type === 'unlink' ? uiText('Unlink GL accounts') : uiText('Remove financial statement item')} onClose={() => !busy && setConfirmation(null)} footer={<><PageActionButton disabled={busy} onClick={() => setConfirmation(null)}>{uiText("Cancel")}</PageActionButton><PageActionButton disabled={!mayEdit} onClick={() => void run(confirmation, confirmation.type === 'unlink' ? 'Mappings removed. GL accounts and postings are unchanged.' : 'Item updated. Used items are retained as inactive.')}>{uiText("Confirm")}</PageActionButton></>}><p className="text-[13px] leading-6">{confirmation.type === 'unlink' ? statementMessage('{count} mapping(s) will be removed. The accounts return to Unassigned accounts. GL entries are not changed and history is retained.', { count: confirmation.mappingIds.length }) : uiText('Used or linked items are deactivated and kept with their history. Only unused items can be deleted.')}</p>{error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{statementErrorText(error)}</p>}</GlJournalDialog>}
    {suggestions && <GlJournalDialog title={uiText("Review suggested mappings")} subtitle={statementMessage('{count} suggestions · {report}', { count: suggestions.length, report: uiText(report) })} wide onClose={() => !busy && setSuggestions(null)} footer={<><PageActionButton disabled={busy} onClick={() => setSuggestions(null)}>{uiText("Cancel")}</PageActionButton><PageActionButton disabled={!mayEdit || !suggestionSelection.size} onClick={() => void run({ type: 'assign', links: suggestions.filter(s => suggestionSelection.has(s.accountCode)).map(({ accountCode, articleId: target, operation: op }) => ({ accountCode, articleId: target, operation: op })) }, '{count} suggested mappings saved.', { count: suggestionSelection.size })}>{statementMessage('Apply selected ({count})', { count: suggestionSelection.size })}</PageActionButton></>}>
      <p className="mb-4 text-[12px] text-[#7288A3]">{uiText("Suggestions use account names. Review the item and Debit / Credit operation before applying. Existing mappings are never overwritten.")}</p>
      {suggestions.length ? <div className="overflow-auto"><table className="w-full text-left text-[12px]"><thead className="bg-[#F8FDFF]"><tr><th className="p-3"><SelectCheck title={uiText("Select all suggestions")} checked={suggestions.every(s => suggestionSelection.has(s.accountCode))} onClick={() => setSuggestionSelection(toggleFilteredSelection(suggestionSelection, suggestions.map(s => s.accountCode)))} /></th>{['GL account', 'Account name', 'Suggested item', 'Operation'].map(text => <th className="p-3 font-medium" key={text}>{uiText(text)}</th>)}</tr></thead><tbody>{suggestions.map(s => <tr key={s.accountCode} className="border-b border-[#E5EDF9]"><td className="p-3"><SelectCheck title={statementMessage('Select suggestion {code}', { code: s.accountCode })} checked={suggestionSelection.has(s.accountCode)} onClick={() => setSuggestionSelection(toggleFilteredSelection(suggestionSelection, [s.accountCode]))} /></td><td className="p-3">{s.accountCode}</td><td className="p-3">{s.accountName}</td><td className="p-3" title={statementMessage('Account name matches {name}. Review before applying.', { name: statementArticleText(articles.find(a => a.id === s.articleId)!, 'name') })}>{articles.find(a => a.id === s.articleId)?.code} · {statementArticleText(articles.find(a => a.id === s.articleId)!, 'name')}</td><td className="p-3">{uiText(s.operation)}</td></tr>)}</tbody></table></div> : <p className="py-8 text-center text-[13px]">{uiText("No unambiguous suggestions. Assign accounts manually from the Unassigned accounts list.")}</p>}
      {error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{statementErrorText(error)}</p>}
    </GlJournalDialog>}
    {history && <GlJournalDialog title={uiText("Mapping history")} subtitle={company.name} wide onClose={() => setHistory(false)} footer={<PageActionButton onClick={() => setHistory(false)}>{uiText("Close")}</PageActionButton>}><div className="overflow-auto"><table className="w-full text-left text-[12px]"><thead className="sticky top-0 bg-[#F8FDFF]"><tr>{['Time', 'User', 'Action', 'Item', 'GL account', 'Change'].map(text => <th key={text} className="p-3 font-medium">{uiText(text)}</th>)}</tr></thead><tbody>{[...(store?.audit ?? [])].reverse().map(a => <tr key={a.id} className="border-b border-[#E5EDF9]"><td className="whitespace-nowrap p-3">{new Date(a.at).toLocaleString(locale)}</td><td className="p-3">{a.by}</td><td className="p-3">{uiText(a.action)}</td><td className="p-3">{a.articleCode}</td><td className="p-3">{a.accountCode || '—'}</td><td className="max-w-xs truncate p-3" title={`${statementAuditValueText(a.before)} → ${statementAuditValueText(a.after)}`}>{statementAuditValueText(a.before)} → {statementAuditValueText(a.after)}</td></tr>)}</tbody></table></div></GlJournalDialog>}
    {help && <GlJournalDialog title={uiText("How it works")} onClose={() => setHelp(false)} footer={<PageActionButton onClick={() => setHelp(false)}>{uiText("Close")}</PageActionButton>}><ol className="list-decimal space-y-3 pl-5 text-[13px] leading-6"><li>{uiText("Select a report and an item in the left-hand tree.")}</li><li>{uiText("Select one or more company GL accounts and click Link selected. Only leaf accounts are offered, avoiding duplicate parent totals.")}</li><li>{uiText("Debit means debit minus credit; Credit means credit minus debit. Set the operation for each mapping.")}</li><li>{uiText("Use Selected item or All mappings to change or unlink assignments. Each account may appear only once per report.")}</li><li>{uiText("Suggest mappings prepares name-based proposals for review. Nothing is saved until you apply them.")}</li></ol><p className="mt-4 text-[12px] leading-5 text-[#7288A3]">{uiText("The starter items are editable reporting headings, not a statutory filing template. Links are saved only for this company and its assigned chart. This screen manages classification; it does not post entries or submit financial statements.")}</p></GlJournalDialog>}
  </main>;
}
