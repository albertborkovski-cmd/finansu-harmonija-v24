import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Eye, Pencil } from 'lucide-react';
import { supabase, applyDocumentIssueAction, type Company, type DbDocument } from '../lib/supabase';
import { canAccessIssueOrganization, canReviewDocumentIssues } from '../lib/documentIssueAccess';
import { canEditCompanyDocuments } from '../lib/documentEditAccess';
import { documentEditStateError, type InlineDocumentSource } from '../lib/documentInlineEditing';
import { documentIssueRows, filterDocumentIssueRows, openDocumentIssueRows, type DocumentIssueRow } from '../lib/documentIssueTable';
import { canViewTeamLeadWork, canViewTeamLeadOrganization } from '../lib/ocrTeamLeadAccess';
import { matchesIssueWorker, type OcrWorker } from '../lib/ocrTeamLeadWorkers';
import { usePersistentState } from '../hooks/usePersistentState';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import { REVIEW_COLUMNS } from '../lib/ocrDocumentColumns';
import { WorkspaceDocumentEditor } from './WorkspaceView';
import { DocumentIssueBadge } from './DocumentIssueDialog';
import OcrSearchField from './OcrSearchField';
import SystemAddFilters from './SystemAddFilters';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ColumnSettingsButton } from './ScopedActionButtons';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';

const COLUMNS: ColConfig[] = [
  { key: 'number', label: 'Document number', width: 180, visible: true },
  { key: 'organization', label: 'Organization', width: 190, visible: true },
  { key: 'reportedIssue', label: 'Reported issue', width: 340, visible: true },
  { key: 'issueStatus', label: 'Issue status', width: 150, visible: true },
  { key: 'assignedTo', label: 'Assigned to', width: 200, visible: true },
  ...REVIEW_COLUMNS.filter(column => !['number', 'organization'].includes(column.key))
    .map(column => column.key === 'clientCounterparty' ? { ...column, label: 'Counterparty' } : column),
  { key: 'documentSubtype', label: 'Invoice type', width: 170, visible: true },
  { key: 'amountWithoutVat', label: 'Amount excl. VAT', width: 170, visible: true },
  { key: 'vat', label: 'VAT amount', width: 150, visible: true },
  { key: 'vatPercent', label: 'VAT rate', width: 130, visible: true },
  { key: 'accountableResponsible', label: 'Accountable / Responsible person', width: 270, visible: true },
  { key: 'validFrom', label: 'Valid from', width: 150, visible: true },
  { key: 'note', label: 'Notes', width: 240, visible: true },
  { key: 'reportedBy', label: 'Reported by', width: 190, visible: true },
  { key: 'reportedAt', label: 'Reported at', width: 190, visible: true },
  { key: 'resolution', label: 'Resolution', width: 260, visible: true },
  { key: 'createdBy', label: 'Created by', width: 190, visible: true },
  { key: 'createdAt', label: 'Creation date', width: 190, visible: true },
];
const ROW_ACTION_CLASS = 'flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40';
const getSortValue = (row: DocumentIssueRow, key: string) => row.cells[key];

export default function DocumentIssueQueue({ teamLeadOverview = false, workerEmail = '', onOpenWorker, initialTarget, onEditingChange }: {
  teamLeadOverview?: boolean; workerEmail?: string; onOpenWorker?: (worker: OcrWorker) => void;
  initialTarget?: { documentId: string; issueId?: string };
  onEditingChange?: (editing: boolean) => void;
}) {
  const initialOpened = useRef(false);
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [query, setQuery] = useState('');
  const [activeFilterKeys, setActiveFilterKeys] = useState<string[]>(teamLeadOverview ? [] : ['issueStatus']);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>(teamLeadOverview ? {} : { issueStatus: ['Open', 'In progress', 'Awaiting OCR'] });
  const [columns, setColumns] = usePersistentState<ColConfig[]>('finansu-harmonija:v20:ocr:document-issues:columns', COLUMNS);
  const [showColumns, setShowColumns] = useState(false);
  const [page, setPage] = useState(1);
  const [error, setError] = useState('');
  const [queuedNotice, setQueuedNotice] = useState('');
  const [loading, setLoading] = useState(true);
  const [opening, setOpening] = useState(false);
  const [editing, setEditing] = useState<{ document: DbDocument; issueId: string; readOnly: boolean } | null>(null);
  const isEditing = Boolean(editing);
  useEffect(() => { onEditingChange?.(isEditing); }, [isEditing, onEditingChange]);
  const tableRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(columns, setColumns);
  const allowed = teamLeadOverview ? canViewTeamLeadWork() : canReviewDocumentIssues();
  const load = useCallback(async () => {
    if (!allowed) { setLoading(false); return; }
    setError('');
    const [docs, organizations] = await Promise.all([supabase.from('documents').select('*'), supabase.from('companies').select('*')]);
    if (docs.error || organizations.error) { setError(docs.error?.message || organizations.error?.message || 'Unable to load reports.'); setLoading(false); return; }
    const accessible = (organizations.data as unknown as Company[] ?? []).filter(company => teamLeadOverview ? canViewTeamLeadOrganization(company) : canAccessIssueOrganization(company));
    const companyIds = new Set(accessible.map(company => company.id));
    setCompanies(accessible);
    setDocuments((docs.data as unknown as DbDocument[] ?? []).filter(document => companyIds.has(document.company_id ?? '')));
    setLoading(false);
  }, [allowed, teamLeadOverview]);
  useEffect(() => {
    void load();
    const refresh = (event: Event) => { if (event.type === 'storage' || (event as CustomEvent).detail?.table === 'documents') void load(); };
    window.addEventListener('finansu-harmonija:data-changed', refresh);
    window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('finansu-harmonija:data-changed', refresh); window.removeEventListener('storage', refresh); };
  }, [load]);
  useEffect(() => setPage(1), [query, activeFilterKeys, filterValues, workerEmail]);
  useEffect(() => {
    setColumns(current => {
      const missing = COLUMNS.filter(column => !current.some(saved => saved.key === column.key));
      return missing.length ? [...current, ...missing] : current;
    });
  }, [setColumns]);
  const companyById = useMemo(() => new Map(companies.map(company => [company.id, company])), [companies]);
  const rows = useMemo(() => {
    const reports = documentIssueRows(documents, new Map(companies.map(company => [company.id, company.name])));
    return teamLeadOverview ? reports.filter(row => matchesIssueWorker(row.issue, workerEmail)) : openDocumentIssueRows(reports);
  }, [documents, companies, teamLeadOverview, workerEmail]);
  const filterColumns = useMemo(() => COLUMNS.map(column => ({ key: column.key, label: column.label,
    options: column.key === 'issueStatus' ? ['Open', 'In progress', 'Awaiting OCR', ...(teamLeadOverview ? ['Fixed'] : [])]
      : [...new Set(rows.map(row => row.cells[column.key]).filter(value => value && value !== '—'))].sort(),
  })), [rows, teamLeadOverview]);
  const filteredRows = useMemo(() => filterDocumentIssueRows(rows, query, activeFilterKeys, filterValues), [rows, query, activeFilterKeys, filterValues]);
  const { sortedRows, changeSort, directionFor } = useMultiColumnSort(filteredRows, getSortValue);
  const visibleColumns = columns.filter(column => column.visible);
  const gridTemplateColumns = [...visibleColumns.map(column => `${column.width}px`), 'minmax(120px, 1fr)'].join(' ');
  const totalPages = Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE));
  const safePage = Math.min(page, totalPages);
  const displayedRows = sortedRows.slice(0, safePage * TABLE_BATCH_SIZE);
  const editError = (document: DbDocument) => document.digitization_issues?.some(issue => issue.status === 'Awaiting OCR')
    ? 'Worker corrections are saved. This document is awaiting OCR reprocessing.'
    : !canEditCompanyDocuments(companyById.get(document.company_id ?? ''))
    ? 'You need Edit access to this company’s documents.'
    : documentEditStateError(document as unknown as InlineDocumentSource);
  const openEditor = async (document: DbDocument, issueId: string, readOnly = false) => {
    if (opening) return;
    setOpening(true); setError(''); setQueuedNotice('');
    try {
      const { data, error: loadError } = await supabase.from('documents').select('*').eq('id', document.id);
      if (loadError) throw new Error(loadError.message);
      const current = data?.[0] as unknown as DbDocument | undefined;
      const company = current && companyById.get(current.company_id ?? '');
      if (!current || !company || (teamLeadOverview ? !readOnly || !canViewTeamLeadOrganization(company) : !canReviewDocumentIssues() || !canAccessIssueOrganization(company))
        || !current.digitization_issues?.some(issue => issue.id === issueId)) throw new Error('This reported document is no longer accessible. Refresh the list.');
      if (teamLeadOverview && !matchesIssueWorker(current.digitization_issues!.find(issue => issue.id === issueId)!, workerEmail))
        throw new Error('This issue is no longer assigned to the selected worker. Refresh the list.');
      const reason = readOnly ? '' : editError(current);
      if (reason) throw new Error(reason);
      const issue = current.digitization_issues!.find(item => item.id === issueId)!;
      const assigned = !readOnly && issue.status !== 'Resolved' && !issue.assignedToEmail
        ? await applyDocumentIssueAction(current.id, current.company_id ?? '', { type: 'start', issueId }) : current;
      setEditing({ document: assigned, issueId, readOnly });
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to open document.'); }
    finally { setOpening(false); }
  };
  useEffect(() => {
    if (!initialTarget || initialOpened.current || loading || !allowed) return;
    initialOpened.current = true;
    const document = documents.find(row => row.id === initialTarget.documentId);
    if (document && initialTarget.issueId) void openEditor(document, initialTarget.issueId);
  }, [initialTarget, loading, allowed, documents]);
  if (!allowed) return null;
  if (editing) return <WorkspaceDocumentEditor key={`${editing.document.id}:${editing.issueId}`} documentId={editing.document.id}
    documentName={editing.document.file_case || editing.document.number} companyId={editing.document.company_id}
    reportedIssueId={editing.issueId} readOnly={editing.readOnly}
    onBack={() => { setEditing(null); void load(); }}
    onIssueFixed={document => {
      setQueuedNotice(`${document.number || document.file_case || 'Document'} · ${uiText('Awaiting OCR')}`);
      setEditing(null); void load();
    }} />;
  return <section aria-label={uiText("Reported document issues")} className="document-issue-queue flex min-h-0 min-w-0 flex-1 flex-col gap-3 font-montserrat text-[12px] text-[#10233A]">
    <div className="system-table-toolbar flex min-h-8 shrink-0 flex-wrap items-center gap-x-1 gap-y-2">
      <OcrSearchField ariaLabel={uiText("Search reported issues")} value={query} onChange={setQuery} />
      <SystemAddFilters columns={filterColumns} activeKeys={activeFilterKeys} values={filterValues}
        onActiveKeysChange={setActiveFilterKeys} onValuesChange={setFilterValues} onClearFilters={() => setQuery('')}
        persistenceKey={teamLeadOverview ? 'finansu-harmonija:v22:ocr:team-lead:issues:filters' : 'finansu-harmonija:v20:ocr:document-issues:filters'} />
      <div className="ml-auto flex h-7 shrink-0 items-center gap-3">
        <ColumnSettingsButton onClick={() => setShowColumns(true)} />
        <RefreshAllButton onRefresh={() => void load()} />
      </div>
    </div>
    {error && <p role="alert" className="rounded-lg bg-[#FFF0F0] px-3 py-2 text-[#B42318]">{error}</p>}
    {queuedNotice && <p role="status" className="rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-3 py-2 text-[#007EA7]">{queuedNotice}</p>}
    <div ref={tableRef} data-fill-table-viewport className="min-h-0 shrink-0 overflow-auto overscroll-contain scrollbar-hide">
      <div role="table" aria-label={uiText("Document issues")} style={{ minWidth: visibleColumns.reduce((sum, column) => sum + column.width, 120) }}>
        <div role="row" className="system-table-header-row mb-1 grid h-10 items-start border-b border-[#D3E1EC] bg-white" style={{ gridTemplateColumns }}>
          {visibleColumns.map((column, index) => <div key={column.key} role="columnheader"
            className={'relative flex min-w-0 items-center gap-1 px-3 ' + (index ? 'border-l border-[#D3E1EC]' : '')}>
            <span className="truncate" title={uiText(column.label)}>{uiText(column.label)}</span>
            <ColumnSortButton columnLabel={uiText(column.label)} direction={directionFor(column.key)} onDirectionChange={direction => { changeSort(column.key, direction); setPage(1); }} />
            <ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} />
          </div>)}
          <div role="columnheader" className="system-table-row-actions min-w-[120px]" aria-label={uiText("Actions")} />
        </div>
        <div role="rowgroup" className="flex flex-col gap-0.5">
          {displayedRows.map((row, index) => {
            const label = row.document.number || row.document.file_case;
            const disabledReason = editError(row.document);
            return <div role="row" key={row.id} style={{ gridTemplateColumns }} className={'grid h-10 items-center rounded-lg text-[12px] leading-[18px] hover:bg-[#E7F4F9] ' + (index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white')}>
              {visibleColumns.map(column => <div role="cell" key={column.key} className="flex h-10 min-w-0 items-center overflow-hidden px-3">
                {column.key === 'issueStatus' ? <DocumentIssueBadge status={row.issue.status} />
                  : column.key === 'assignedTo' && teamLeadOverview && row.issue.assignedToEmail && onOpenWorker
                    ? <button type="button" onClick={() => onOpenWorker({ email: row.issue.assignedToEmail!.trim().toLowerCase(), name: row.cells.assignedTo })}
                      title={row.issue.assignedToEmail} className="truncate text-left text-[#007EA7] hover:underline">{row.cells.assignedTo}</button>
                  : ['number', 'fileCase'].includes(column.key)
                    ? <button type="button" disabled={opening} onClick={() => void openEditor(row.document, row.issue.id, true)} title={row.cells[column.key]} className="block truncate text-left text-[#007EA7] hover:underline disabled:cursor-wait">{row.cells[column.key]}</button>
                    : <span className="block truncate" title={row.cells[column.key]}>{['reportedAt', 'createdAt'].includes(column.key) && row.cells[column.key] !== '—'
                      ? new Date(row.cells[column.key]).toLocaleString() : row.cells[column.key]}</span>}
              </div>)}
              <div role="cell" className="system-table-row-actions flex h-10 min-w-[120px] items-center justify-end gap-2 bg-inherit px-2">
                <button type="button" title={uiText("View document")} aria-label={'View document ' + label} disabled={opening} onClick={() => void openEditor(row.document, row.issue.id, true)} className={ROW_ACTION_CLASS}><Eye size={15} strokeWidth={1.8} /></button>
                {!teamLeadOverview && <button type="button" title={disabledReason || uiText('Edit document')} aria-label={'Edit document ' + label} disabled={opening || Boolean(disabledReason)}
                  onClick={() => void openEditor(row.document, row.issue.id)} className={ROW_ACTION_CLASS}><Pencil size={15} strokeWidth={1.8} /></button>}
              </div>
            </div>;
          })}
        </div>
      </div>
      {!displayedRows.length && <p className="py-12 text-center text-[#7288A3]">{loading ? uiText('Loading reported issues…') : uiText('No reported issues match the selected filters.')}</p>}
    </div>
    <HorizontalTableScrollbar scrollRef={tableRef} />
    <TablePagination currentPage={safePage} totalPages={totalPages} itemCount={sortedRows.length} onPageChange={setPage} scrollRef={tableRef} />
    {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={COLUMNS} onSave={next => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
  </section>;
}
