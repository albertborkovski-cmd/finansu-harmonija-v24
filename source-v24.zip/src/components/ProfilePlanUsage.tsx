import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { translateUi as t } from '../i18n/language';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { canAccessUnassignedDocuments, canViewCompanyDocuments } from '../lib/documentEditAccess';
import { companySaasUsage, SAAS_OVERAGE } from '../lib/companySaas';
import { contractPlanSaas, CONTRACT_PRICING_CHANGED, CONTRACT_PRICING_KEY, readContractPricing, type ContractPlan, type ContractPricingCatalog } from '../lib/contractPricing';
import { readProfileLimitPolicy, saveProfileLimitPolicy, type ProfileLimitPolicy } from '../lib/profileSaasPreferences';
import { PROFILE_COMPANY_DETAILS_KEY, PROFILE_COMPANY_DETAILS_CHANGED, readProfileCompanyName } from '../lib/profileCompanyDetails';
import SaasPlanUsageCard from './SaasPlanUsageCard';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';

function subscribeCompanyDetails(onChange: () => void) {
  const onStorage = (event: StorageEvent) => { if (!event.key || event.key === PROFILE_COMPANY_DETAILS_KEY) onChange(); };
  window.addEventListener(PROFILE_COMPANY_DETAILS_CHANGED, onChange);
  window.addEventListener('storage', onStorage);
  return () => {
    window.removeEventListener(PROFILE_COMPANY_DETAILS_CHANGED, onChange);
    window.removeEventListener('storage', onStorage);
  };
}

export default function ProfilePlanUsage({ email, selectedPlanId, confirmedPlan, selectedTierId }: { email: string; selectedPlanId: string; confirmedPlan?: ContractPlan; selectedTierId?: string }) {
  const companyName = useSyncExternalStore(subscribeCompanyDetails, () => readProfileCompanyName(window.localStorage), () => '');
  const [catalog, setCatalog] = useState<ContractPricingCatalog | null>(null), [documents, setDocuments] = useState<DbDocument[]>([]);
  const [loading, setLoading] = useState(true), [error, setError] = useState(''), [refresh, setRefresh] = useState(0);
  useEffect(() => {
    const read = (event?: Event) => { if (event instanceof StorageEvent && event.key && event.key !== CONTRACT_PRICING_KEY) return; try { setCatalog(readContractPricing(localStorage)); } catch (reason) { setError(reason instanceof Error ? reason.message : 'SaaS settings could not be loaded.'); } };
    read(); window.addEventListener(CONTRACT_PRICING_CHANGED, read); window.addEventListener('storage', read);
    return () => { window.removeEventListener(CONTRACT_PRICING_CHANGED, read); window.removeEventListener('storage', read); };
  }, []);
  useEffect(() => {
    let current = true; setLoading(true); setError('');
    void Promise.all([supabase.from('companies').select('*'), supabase.from('documents').select('*')]).then(([companies, docs]) => {
      if (companies.error || docs.error) throw new Error('Document usage could not be loaded. Please refresh.');
      const allowed = new Set(((companies.data || []) as unknown as Company[]).filter(canViewCompanyDocuments).map(company => company.id));
      const unassigned = canAccessUnassignedDocuments();
      if (current) setDocuments(((docs.data || []) as unknown as DbDocument[]).filter(document => String(document.entry_method || '').toLowerCase() !== 'manual' && (allowed.has(document.company_id || '') || (!document.company_id && unassigned))));
    }).catch(reason => { if (current) setError(reason instanceof Error ? reason.message : 'Document usage could not be loaded. Please refresh.'); }).finally(() => { if (current) setLoading(false); });
    return () => { current = false; };
  }, [email, refresh]);
  const plan = confirmedPlan || catalog?.plans.find(item => item.id === selectedPlanId);
  const settings = useMemo(() => plan ? contractPlanSaas(plan) : null, [plan]);
  const usage = useMemo(() => settings ? companySaasUsage('profile', documents.map(document => ({ ...document, company_id: 'profile' })), settings) : null, [documents, settings]);
  if (!plan || !settings || !usage) return error ? <p role="alert" className="text-[12px] text-[#B42318]">{t(error)}</p> : null;
  return <section className="grid items-start gap-4 xl:grid-cols-[minmax(0,1.2fr)_minmax(280px,1fr)]">
    <SaasPlanUsageCard name={companyName || t('Company name not specified')} planName={plan.name} settings={settings} plan={plan} selectedTierId={selectedTierId} usage={usage} loading={loading} error={error} onRefresh={() => setRefresh(value => value + 1)} accountScope />
    <LimitPreference key={`${email}:${plan.id}`} email={email} planId={plan.id} fallback={settings.virsijimas} />
  </section>;
}

function LimitPreference({ email, planId, fallback }: { email: string; planId: string; fallback: ProfileLimitPolicy }) {
  const [loaded] = useState(() => { try { return { policy: readProfileLimitPolicy(localStorage, email, planId, fallback), error: '' }; } catch (reason) { return { policy: fallback, error: reason instanceof Error ? reason.message : 'SaaS settings could not be loaded.' }; } });
  const [policy, setPolicy] = useState(loaded.policy), [savedPolicy, setSavedPolicy] = useState(loaded.policy), [error, setError] = useState(loaded.error), [feedback, setFeedback] = useState('');
  const save = () => { try { saveProfileLimitPolicy(localStorage, email, planId, policy); setSavedPolicy(policy); setError(''); setFeedback('Limit preference saved.'); } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to save SaaS settings.'); } };
  return <section className="rounded-lg border border-[#D3E1EC] bg-white p-5"><h3 className="mb-4 text-[16px] font-semibold">{t('When the limit is reached')}</h3><SearchableSelect ariaLabel="SaaS overage policy" value={policy} options={SAAS_OVERAGE.map(item => ({ ...item, label: t(item.label) }))} onChange={value => { setPolicy(value as ProfileLimitPolicy); setFeedback(''); }} portalMenu />
    <p className="mt-3 text-[12px] leading-5 text-[#7288A3]">{t(policy === 'charge' ? 'Continue processing documents beyond the limit using the selected plan pricing.' : 'Stop new document processing when the limit is reached. Existing documents remain available.')}</p>
    <p className="mt-3 text-[11px] leading-5 text-[#7288A3]">{t('This saves your account preference. Automatic enforcement and billing require a connected service.')}</p>
    <div className="mt-4 flex justify-end"><PageActionButton disabled={policy === savedPolicy || Boolean(loaded.error)} onClick={save}>{t('Save changes')}</PageActionButton></div>{error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{t(error)}</p>}{feedback && <p role="status" className="mt-3 text-[12px] text-[#087A55]">{t(feedback)}</p>}
  </section>;
}
