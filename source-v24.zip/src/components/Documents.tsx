import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { Fragment, useState, useRef, useEffect, useCallback, useMemo } from "react";
import { affectsDocumentRegister } from '../lib/accessInvalidation';
import { companyOcrAdditionalColumnRequirements, missingDocumentAccountingFields } from '../lib/documentAccountingRequirements';
import RequiredDocumentValue from './RequiredDocumentValue';
import { createPortal } from "react-dom";
import {
  Copy,
  ChevronDown,
  ChevronRight,
  Plus,
  Pencil,
  Info,
  X,
  Upload,
  AlertCircle,
  Check,
  Loader2,
  Eye,
  Download,
  ScanLine,
  Send,
  Trash2,
  FileMinus2,
  FilePlus2,
  Undo2,
  Archive,
  ReceiptText,
  DollarSign,
  ListTree,
} from "lucide-react";
import DocumentWarningIndicator from './DocumentWarningIndicator';
import { duplicateDocumentIds, documentDeliveryWarning, documentQuantityLineCount, documentRegisterTotals, lateDocumentSubmission, singleOrganizationSelection } from '../lib/documentRegisterIndicators';
import { loadOperationDateValidationRule } from './OperationDateValidationView';
import ColumnSettingsPanel, { type ColConfig } from "./ColumnSettingsPanel";
import { useColumnResize, ResizeHandle } from "./useColumnResize";
import DocumentDetailPanel from "./DocumentDetailPanel";
import AssignAdvanceEmployeeDialog from './AssignAdvanceEmployeeDialog';
import DocumentBulkAssignmentDialog from './DocumentBulkAssignmentDialog';
import { documentAssignmentSnapshot } from '../lib/documentBulkAssignment';
import DocumentRegisterActionsMenu from './DocumentRegisterActionsMenu';
import DocumentInlineTextCell from './DocumentInlineTextCell';
import DocumentInlineSelectCell from './DocumentInlineSelectCell';
import { documentPurposeCatalogOptions, documentPurposeSelection, globalDocumentColumns } from '../lib/documentPurposeCatalog';
import { globalDocumentDefaultColumns, globalDocumentColumnPersistence } from '../lib/globalDocumentColumnLayout';
import { documentTypeCatalogOptions, documentTypeCatalogSelection } from '../lib/documentTypeCatalog';
import { documentHasReceipt, documentIsSale } from '../lib/documentDetailEditing';
import { loadOrganizationReferenceRecords } from './OrganizationReferenceValuesView';
import DropdownPortal from './DropdownPortal';
import { documentEditStateError, documentInlineEditError, documentInlineSnapshot, documentInlineValue, isInlineDocumentField, type InlineDocumentSource } from '../lib/documentInlineEditing';
import { canCopyInvoiceDocument } from '../lib/invoiceCreation';
import { useApprovedDocumentEditWarning } from './ApprovedDocumentEditWarning';
import { canAccessUnassignedDocuments, canEditCompanyDocuments, canViewCompanyDocuments } from '../lib/documentEditAccess';
import { NO_BUYER_FILTER } from '../lib/documentOrganizationAssignment';
import { buildOrganizationDirectory, loadDirectoryCounterparties, matchesOrganizationDirectoryDocument } from '../lib/organizationDirectory';
import DocumentOrganizationAssignment from './DocumentOrganizationAssignment';
import DocumentDeliveryDialog from './DocumentDeliveryDialog';
import type { DocumentTestDelivery, TestDeliveryCommand } from '../lib/documentTestDelivery';
import { downloadDocumentExport, primaryDocumentDeliveryDestination, selectedDocumentRecords } from '../lib/documentExport';
import { buildDocumentAccountingExport } from '../lib/documentAccountingExport';
import { directDocumentDeliveryNotice, prepareDirectDocumentDelivery } from '../lib/documentDirectDelivery';
import { documentRegisterScope, isDocumentArchived } from '../lib/documentArchive';
import { uploadedDocumentSource, withUploadedDocumentUploader } from '../lib/uploadedDocumentSource';
import { loadLinkedDirectoryUsers, SETTINGS_DATA_CHANGED_EVENT } from '../lib/linkedSettingsData';
import { documentResponsibleOptions, documentResponsibleSelection } from '../lib/documentResponsibleUsers';
import DocumentIssueDialog, { DocumentIssueBadge } from './DocumentIssueDialog';
import DocumentIssueReceipts from './DocumentIssueReceipts';
import DocumentRowActionDialog from './DocumentRowActionDialog';
import DocumentRestoreButton from './DocumentRestoreButton';
import DocumentActionsMenu from './DocumentActionsMenu';
import { DocumentStornoDialog } from './DocumentStornoAction';
import { documentStornoPresentation } from '../lib/documentStorno';
import { canOpenDocumentRowAction, documentCorrectionKind, documentRowAction, type DocumentManagementActionKind, type DocumentRowAction } from '../lib/documentRowActions';
import { canCreateCompanyDocument, documentActionRights } from '../lib/documentRowActionAccess';
import { documentIssueStatus, documentIssueStatusLabel, hasBlockingDocumentIssue, isApprovedDocumentStatus, type DocumentIssue } from '../lib/documentIssues';
import { documentProcessingStatus, documentStatusOptions, documentStatusLabel } from '../lib/documentProcessingStatus';
import { ocrDocumentStatusPresentation, ocrDocumentRegisterStatus, ocrDocumentStatusOptions } from '../lib/ocrDocumentStatusPresentation';
import { ocrStatusLabel, ocrStatusGroup } from '../lib/ocrStatuses';
import useOcrStatusDescriptions from '../hooks/useOcrStatusDescriptions';
import { OcrDocumentStatusCell, OcrDocumentStatusPanel } from './OcrDocumentStatusDetails';
import CreateInvoiceForm from './invoices/CreateInvoiceForm';
import { usesManualInvoiceForm } from '../lib/invoiceDocumentForm';
import { PageActionButton, PageHeader } from "./PageHeader";
import HorizontalTableScrollbar from "./HorizontalTableScrollbar";
import { OrganizationSidebar } from './OcrDocumentsWorkspace';
import OrganizationDirectorySettings from './OrganizationDirectorySettings';
import WorkspaceExpandButton from './WorkspaceExpandButton';
import useWorkspaceExpansion from '../hooks/useWorkspaceExpansion';
import { usePersistentState } from '../hooks/usePersistentState';
import TablePagination from "./TablePagination";
import { TABLE_BATCH_SIZE } from "../lib/tablePaging";
import { supabase, ensureOcrRegisterExamples, applyDocumentInlineEdit, applyDocumentTestDelivery, assignDocumentFields, saveCompanyAccountingDestination, requestDocumentsDetailedDigitization, type Company, type DbDocument } from "../lib/supabase";
import ColumnSortButton, { useMultiColumnSort } from "./ColumnSortButton";
import {
  ColumnSettingsButton,
} from "./ScopedActionButtons";
import CompanyBreadcrumb from "./CompanyBreadcrumb";
import { SystemBreadcrumb } from './SystemNavigation';
import SearchableSelect from './SearchableSelect';
import GlJournalDialog from './GlJournalDialog';
import RefreshAllButton from "./RefreshAllButton";
import OcrSearchField from "./OcrSearchField";
import { getCurrentUserName, getCurrentUserIdentity } from "../lib/currentUser";
import { loadCompanyGeneralLedgerAccountOptions } from "./GeneralLedgerView";
import GeneralLedgerAccountSelect from "./GeneralLedgerAccountSelect";
import { useDropdownDismiss } from "./useDropdownDismiss";
import SendInvoicePanel from "./invoices/SendInvoicePanel";
import { InvoicePaymentPreviewPanel } from "./invoices/CreateInvoicePanel";
import type { InvoiceChatContext } from "./invoices/invoiceChat";
import {
  ensureOrganizationProductGroup,
  ensureOrganizationProductGroups,
} from "../lib/organizationProductGroups";

export type DocumentLineItem = {
  id: string;
  barcode: string;
  systemId: string;
  product: string;
  description?: string;
  productGroup?: string;
  unit: string;
  qty: string;
  code: string;
  price: string;
  subtotal: string;
  discount: string;
  vat: string;
  vatPct: string;
  total: string;
  department: string;
  object: string;
  series: string;
  center: string;
  expense: string;
  vatClass: string;
};

export type Document = {
  id: string;
  storno?: ReturnType<typeof documentStornoPresentation>;
  testDeliveries?: DocumentTestDelivery[];
  inlineSource: InlineDocumentSource;
  digitizationIssues?: DocumentIssue[];
  issueStatus?: string;
  companyId: string;
  organization?: string;
  receiveDate: string;
  clientCounterparty: string;
  counterpartyId: string;
  counterpartyCode: string;
  documentType: string;
  documentSubtype: string;
  source: string;
  totalAmount: string;
  dueEndDate: string;
  fileCase: string;
  orderNo: string;
  number: string;
  type: string;
  purposeCode?: string;
  documentDate: string;
  documentPurpose: string;
  invoiceContractDate: string;
  operationDate: string;
  expenseAccount: string;
  vatClassifier: string;
  productGroup: string;
  currency: string;
  amountWithoutVat: string;
  vat: string;
  vatPercent: string;
  departmentCode: string;
  objectProject: string;
  validForm: string;
  accountableResponsible: string;
  costCenter: string;
  series: string;
  note: string;
  accountingNoteStatus: string;
  debit: string;
  credit: string;
  status: string;
  processingStatus?: string;
  processingDetail?: string;
  imageUrl: string | null;
  hasProductDetails: boolean;
  lineItems: DocumentLineItem[];
  summaryLineItems: DocumentLineItem[];
};


function commonLineValue(
  lineItems: DocumentLineItem[],
  key: keyof DocumentLineItem,
  fallback: string,
) {
  if (lineItems.length === 0) return fallback;
  const values = lineItems.map((item) => String(item[key] ?? "").trim());
  const first = values[0];
  return first && values.every((value) => value === first) ? first : "";
}

function documentCellValue(document: Document, key: keyof Document) {
  if (key === 'status') return document.processingStatus
    ? ocrStatusLabel(documentDisplayStatus(document), statusText)
    : documentStatusLabel(documentDisplayStatus(document));
  if (document.storno && (key === 'totalAmount' || key === 'amountWithoutVat' || key === 'vat')) return document.storno.amounts[key]?.reversed ?? document[key];
  if (isInlineDocumentField(key)) return documentInlineValue(document.inlineSource, key);
  return document[key];
}

function documentDisplayStatus(document: Document) {
  return document.processingStatus || document.storno?.status || document.status;
}

function editableDocumentNumber(value: string) {
  return value
    .replace(/\s/g, "")
    .replace(/[^\d,.-]/g, "")
    .replace(",", ".");
}

function documentAmount(value: string) {
  return Number.parseFloat(editableDocumentNumber(value)) || 0;
}

export function mapRow(r: DbDocument): Document {
  const text = (value: unknown) =>
    value === null || value === undefined ? "" : String(value);
  const savedLineItems = Array.isArray(r.line_items) ? r.line_items : null;
  const lineItems = ((savedLineItems as DocumentLineItem[] | null) ?? []).map(
    (item) => ({
      ...item,
      productGroup:
        item.productGroup === text(r.document_type)
          ? ""
          : item.productGroup || "",
    }),
  );
  const savedSummaryLineItems = Array.isArray(r.summary_line_items)
    ? r.summary_line_items
    : null;
  const summaryLineItems = (
    (savedSummaryLineItems as DocumentLineItem[] | null) ?? []
  ).map((item) => ({
    ...item,
    productGroup:
      item.productGroup === text(r.document_type)
        ? ""
        : item.productGroup || "",
  }));
  return {
    id: text(r.id),
    storno: documentStornoPresentation(r),
    testDeliveries: r.accounting_test_deliveries ?? [],
    inlineSource: r as unknown as InlineDocumentSource,
    digitizationIssues: r.digitization_issues ?? [],
    issueStatus: documentIssueStatusLabel(documentIssueStatus(r)),
    companyId: text(r.company_id),
    receiveDate: text(r.receive_date),
    clientCounterparty: text(r.client_counterparty),
    counterpartyId: text(r.counterparty_id),
    counterpartyCode: text(r.counterparty_code),
    documentType: text(r.document_type),
    documentSubtype: text(r.document_subtype),
    source: text(r.source),
    totalAmount: text(r.total_amount),
    dueEndDate: text(r.due_end_date),
    fileCase: text(r.file_case),
    orderNo: text(r.order_no),
    number: text(r.number),
    type: text(r.type),
    purposeCode: documentPurposeSelection(r as unknown as Record<string, unknown>),
    documentDate: text(r.document_date),
    documentPurpose: text(r.document_purpose),
    invoiceContractDate: text(r.invoice_contract_date),
    operationDate: text(r.operation_date),
    expenseAccount: commonLineValue(
      summaryLineItems,
      "expense",
      text(r.expense_account),
    ),
    vatClassifier: commonLineValue(
      summaryLineItems,
      "vatClass",
      text(r.vat_classifier),
    ),
    productGroup: commonLineValue(
      summaryLineItems,
      "productGroup",
      "",
    ),
    currency: text(r.currency),
    amountWithoutVat: text(r.amount_without_vat),
    vat: text(r.vat),
    vatPercent: commonLineValue(summaryLineItems, "vatPct", text(r.vat_percent)),
    departmentCode: commonLineValue(
      summaryLineItems,
      "department",
      text(r.department_code),
    ),
    objectProject: commonLineValue(
      summaryLineItems,
      "object",
      text(r.object_project),
    ),
    validForm: text(r.valid_form),
    accountableResponsible: text(r.accountable_responsible),
    costCenter: commonLineValue(summaryLineItems, "center", text(r.cost_center)),
    series: text(r.series),
    note: text(r.notes),
    accountingNoteStatus: text(r.accounting_note_status),
    debit: text(r.debit),
    credit: text(r.credit),
    status: (text(r.status) || "Draft") as Document["status"],
    imageUrl: r.image_url,
    hasProductDetails:
      lineItems.length > 1 || summaryLineItems.length > 1,
    lineItems,
    summaryLineItems,
  };
}

const STATUS_COLORS: Partial<Record<Document["status"], string>> = {
  Manual: "#007EA7",
  Pending: "#EEB648",
  Paid: "#22C55E",
  Draft: "#A1B6C6",
  Processing: "#6366F1",
  Rejected: "#DC2626",
  "Provide Additional": "#F59E0B",
  Exception: "#EA580C",
  Transferred: "#0284C7",
  Duplicate: "#7C3AED",
  "Not Documented": "#9CA3AF",
  New: "#007EA7",
  Approved: "#22C55E",
  Correcting: "#EEB648",
  Reversed: "#007EA7",
};

export const DOCUMENT_BASE_COLUMNS: ColConfig[] = [
  { key: "status", label: "Status", width: 110, visible: true },
  { key: "issueStatus", label: "Issue status", width: 130, visible: true },
  { key: "receiveDate", label: "Receive date", width: 110, visible: true },
  {
    key: "clientCounterparty",
    label: "Counterparty",
    width: 170,
    visible: true,
  },
  {
    key: "counterpartyCode",
    label: "Counterparty code",
    width: 135,
    visible: true,
  },
  { key: "documentType", label: "Document type", width: 140, visible: true },
  { key: "source", label: "Source", width: 90, visible: true },
  { key: "totalAmount", label: "Total amount", width: 120, visible: true },
  { key: "dueEndDate", label: "Due/End date", width: 110, visible: true },
  { key: "fileCase", label: "File/Case", width: 150, visible: true },
  { key: "orderNo", label: "Order No.", width: 100, visible: true },
  { key: "number", label: "Document Number", width: 160, visible: true },
  { key: "type", label: "Type", width: 90, visible: true },
  { key: "documentDate", label: "Document date", width: 120, visible: true },
  {
    key: "documentPurpose",
    label: "Document purpose",
    width: 150,
    visible: true,
  },
  { key: "note", label: "Note", width: 220, visible: true },
  { key: "operationDate", label: "Operation date", width: 120, visible: true },
  { key: "expenseAccount", label: "GL account", width: 115, visible: true },
  { key: "vatClassifier", label: "VAT classifier", width: 120, visible: true },
  { key: "productGroup", label: "Product Group", width: 125, visible: true },
  { key: "currency", label: "Currency", width: 90, visible: true },
  {
    key: "amountWithoutVat",
    label: "Amount without VAT",
    width: 155,
    visible: true,
  },
  { key: "vat", label: "VAT", width: 90, visible: true },
  { key: "vatPercent", label: "VAT%", width: 75, visible: true },
  {
    key: "departmentCode",
    label: "Department code",
    width: 140,
    visible: true,
  },
  { key: "objectProject", label: "Object/Project", width: 130, visible: true },
  {
    key: "accountableResponsible",
    label: "Accountable/Responsible person",
    width: 210,
    visible: true,
  },
  { key: "costCenter", label: "Cost center", width: 110, visible: true },
  { key: "series", label: "Series", width: 90, visible: true },
];

type DetailLineMode = "quantity" | "summary";

function detailLineValue(
  document: Document,
  column: string,
  lineItem?: DocumentLineItem,
) {
  const amount = document.amountWithoutVat || document.totalAmount || "—";
  const values: Record<string, string> = {
    Barcode: lineItem?.barcode || "—",
    "System ID": lineItem?.systemId || "—",
    "Document Number": document.number || lineItem?.code || "—",
    Product:
      lineItem?.product ||
      document.documentPurpose ||
      document.documentType ||
      "—",
    "Unit of measure": lineItem?.unit || "—",
    Quantity: lineItem?.qty || "—",
    Price: lineItem?.price || amount,
    Amount: lineItem?.subtotal || amount,
    Discount: lineItem?.discount || "0.00",
    VAT: lineItem?.vat || document.vat || "0.00",
    "VAT %": lineItem?.vatPct || document.vatPercent || "0%",
    "Total amount": document.totalAmount || amount,
    "Total Amount": lineItem?.total || document.totalAmount || amount,
    Department: lineItem?.department || document.departmentCode || "—",
    Object: lineItem?.object || document.objectProject || "—",
    Series: lineItem?.series || document.series || "—",
    Center: lineItem?.center || document.costCenter || "—",
    "Product group": lineItem?.productGroup || "—",
    "GL account": lineItem?.expense || document.expenseAccount || "—",
    "VAT classifier": lineItem?.vatClass || document.vatClassifier || "—",
    "VAT Classifier": lineItem?.vatClass || document.vatClassifier || "—",
  };
  return values[column] ?? "—";
}

const QUANTITY_DETAIL_PARENT_MAP: Partial<Record<keyof Document, string>> = {
  status: "Barcode",
  receiveDate: "System ID",
  documentType: "Product",
  source: "Unit of measure",
  dueEndDate: "Quantity",
  fileCase: "Price",
  orderNo: "Discount",
  number: "Document Number",
  totalAmount: "Total Amount",
  amountWithoutVat: "Amount",
  vat: "VAT",
  vatPercent: "VAT %",
  productGroup: "Product group",
  departmentCode: "Department",
  objectProject: "Object",
  series: "Series",
  costCenter: "Center",
  expenseAccount: "GL account",
  vatClassifier: "VAT Classifier",
};

const SUMMARY_DETAIL_PARENT_MAP: Partial<Record<keyof Document, string>> = {
  documentType: "Unit of measure",
  dueEndDate: "Quantity",
  fileCase: "Price",
  totalAmount: "Total amount",
  amountWithoutVat: "Amount",
  vat: "VAT",
  vatPercent: "VAT %",
  productGroup: "Product group",
  departmentCode: "Department",
  objectProject: "Object",
  series: "Series",
  costCenter: "Center",
  expenseAccount: "GL account",
  vatClassifier: "VAT classifier",
};

export function ExpandedDocumentLines({
  document,
  parentColumns,
}: {
  document: Document;
  parentColumns: ColConfig[];
  generalLedgerName?: string;
  onOpenGeneralLedger?: () => void;
  onStartChat?: (context: InvoiceChatContext) => void;

}) {
  const quantityRows = document.lineItems.filter((line) =>
    [
      line.barcode,
      line.product,
      line.unit,
      line.qty,
      line.code,
      line.price,
      line.subtotal,
    ].some((value) => String(value ?? "").trim().length > 0),
  );
  const hasQuantityLines = quantityRows.length > 0;
  const hasSummaryLine = document.summaryLineItems.length > 0;
  const effectiveMode: DetailLineMode =
    document.summaryLineItems.length > 1 ? "summary" : "quantity";
  const rows: Array<DocumentLineItem | undefined> =
    effectiveMode === "quantity" ? quantityRows : document.summaryLineItems;
  const parentMap =
    effectiveMode === "quantity"
      ? QUANTITY_DETAIL_PARENT_MAP
      : SUMMARY_DETAIL_PARENT_MAP;
  const alignedColumns = parentColumns.map((parentColumn) => ({
    parentColumn,
    detailColumn: parentMap[parentColumn.key as keyof Document],
  }));
  return (
    <section
      aria-label={`Document line details ${document.fileCase}`}
      className="mb-2 overflow-hidden rounded-lg border border-[#D3E1EC] bg-white shadow-[0_2px_8px_rgba(16,35,58,0.06)]"
    >
      <div className="flex min-h-[44px] items-center justify-start gap-3 border-b border-[#E5EDF9] bg-[#F8FDFF] py-2 pl-[72px] pr-4">
        {(hasSummaryLine || hasQuantityLines) && (
          <div className="inline-flex flex-shrink-0 rounded-md bg-[#EEF4F7] p-0.5">
            <span className="flex h-7 items-center rounded bg-white px-3 font-montserrat text-[11px] font-semibold text-[#007EA7] shadow-[0_1px_3px_rgba(16,35,58,0.12)]">
              {effectiveMode === "summary" ? uiText("Summary lines") : uiText("Quantity lines")}
            </span>
          </div>
        )}
        <div className="flex min-w-0 items-center gap-2">
          <p className="flex-shrink-0 font-montserrat text-[12px] font-semibold text-[#10233A]">{uiText("Document lines")}</p>
          <span
            aria-hidden="true"
            className="h-3 w-px flex-shrink-0 bg-[#D3E1EC]"
          />
          <p
            className="min-w-0 truncate font-montserrat text-[11px] text-[#7288A3]"
            title={document.fileCase}
          >
            {document.fileCase}
          </p>
        </div>
      </div>
      <div className="min-w-max">
          <div className="flex h-7 items-center border-b border-[#E5EDF9] bg-[#F8FDFF] pl-3 pr-2">
            <div className="w-[60px] flex-shrink-0" />
            {alignedColumns.map(({ parentColumn, detailColumn }) => (
              <div
                key={parentColumn.key}
                className="flex-shrink-0 truncate border-l border-[#E5EDF9] px-3 font-montserrat text-[10px] font-semibold uppercase tracking-[0.02em] text-[#7288A3]"
                style={{ width: parentColumn.width }}
                title={detailColumn ?? ""}
              >
                {detailColumn ?? ""}
              </div>
            ))}
            <div className="w-[168px] flex-shrink-0" />
          </div>
          {rows.map((lineItem, rowIndex) => (
            <div
              key={lineItem?.id ?? `fallback-${rowIndex}`}
              className={`flex h-9 items-center pl-3 pr-2 ${rowIndex % 2 === 0 ? "bg-white" : "bg-[#F8FDFF]"}`}
            >
              <div className="flex w-[60px] flex-shrink-0 items-center justify-center font-montserrat text-[11px] text-[#7288A3]">
                #{rowIndex + 1}
              </div>
              {alignedColumns.map(({ parentColumn, detailColumn }) => {
                if (!detailColumn) {
                  return (
                    <div
                      key={parentColumn.key}
                      className="h-9 flex-shrink-0 border-l border-[#EEF3F7]"
                      style={{ width: parentColumn.width }}
                    />
                  );
                }
                const column = detailColumn;
                const value = detailLineValue(document, column, lineItem);
                return (
                  <div
                    key={parentColumn.key}
                    className="flex-shrink-0 truncate border-l border-[#EEF3F7] px-3 font-montserrat text-[12px] font-medium text-[#10233A]"
                    style={{ width: parentColumn.width }}
                    title={value}
                  >
                    {value}
                  </div>
                );
              })}
              <div className="w-[168px] flex-shrink-0" />
            </div>
          ))}
      </div>
    </section>
  );
}

const FIXED_FILTER_KEYS = new Set(["status", "clientCounterparty", "currency"]);

const PRIMARY_FILTER_COLUMNS = [
  { key: "period", label: "Period" },
  { key: "clientCounterparty", label: "Counterparty" },
  { key: "currency", label: "Currency" },
  { key: "rangeAmount", label: "Range amount" },
  { key: "status", label: "Status" },
] as const;

function SystemDocumentFilterDropdown({
  label,
  value,
  displayValue,
  options,
  open,
  onOpenChange,
  onChange,
  minWidth = 210,
  translateStatusLabels = true,
}: {
  label: string;
  value: string;
  displayValue?: string;
  options: Array<{ value: string; label: string }>;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChange: (value: string) => void;
  minWidth?: number;
  translateStatusLabels?: boolean;
}) {
  const dropdownRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  useDropdownDismiss(open, dropdownRef, () => onOpenChange(false), menuRef);
  return (
    <div ref={dropdownRef} className="relative flex-shrink-0">
      <button
        type="button"
        aria-label={`Filter by ${label}`}
        aria-expanded={open}
        onClick={() => onOpenChange(!open)}
        className="flex h-7 max-w-[240px] items-center gap-1 rounded bg-[#E5EDF9] px-2 font-montserrat text-[12px] font-medium text-[#7288A3] transition-colors hover:bg-[#DCE7F6]"
      >
        <span className="truncate whitespace-nowrap">
          {uiText(label)}
          {value && (
            <span className="text-[#10233A]">: {translateStatusLabels && (label === 'Status' || label === uiText('Status')) ? statusText(displayValue || value) : displayValue || value}</span>
          )}
        </span>
        {value ? (
          <X
            size={14}
            className="flex-shrink-0"
            onClick={(event) => {
              event.stopPropagation();
              onChange("");
              onOpenChange(false);
            }}
          />
        ) : (
          <ChevronDown
            size={14}
            className={`flex-shrink-0 transition-transform ${open ? "rotate-180" : ""}`}
          />
        )}
      </button>
      {open && (
        <DropdownPortal anchorRef={dropdownRef} menuRef={menuRef} width={minWidth} ariaLabel={`${label} filter options`}>
          <button
            type="button"
            aria-pressed={!value}
            data-static-selection="true"
            onClick={() => {
              onChange("");
              onOpenChange(false);
            }}
            className={`grid h-9 w-full grid-cols-[18px_minmax(0,1fr)] items-center gap-3 rounded-md px-2 text-left ${!value ? 'bg-[#E5EDF9]' : 'hover:bg-[#F2F7FC]'}`}
          >
            <span
              aria-hidden="true"
              className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${!value ? "border-[#007EA7] bg-[#007EA7]" : "border-[#A1B6C6] bg-white"}`}
            >
              {!value && (
                <Check size={12} strokeWidth={2.5} className="text-white" />
              )}
            </span>
            <span className="font-montserrat text-[13px] font-medium text-[#10233A]">{uiText("All")}</span>
          </button>
          <div className="min-h-0 overflow-y-auto overscroll-contain">
            {options.map((option) => {
              const checked = option.value === value;
              return (
                <button
                  key={option.value}
                  type="button"
                  aria-pressed={checked}
                  data-static-selection="true"
                  onClick={() => {
                    onChange(option.value);
                    onOpenChange(false);
                  }}
                  className={`grid h-9 w-full grid-cols-[18px_minmax(0,1fr)] items-center gap-3 rounded-md px-2 text-left ${checked ? 'bg-[#E5EDF9]' : 'hover:bg-[#F2F7FC]'}`}
                >
                  <span
                    aria-hidden="true"
                    className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${checked ? "border-[#007EA7] bg-[#007EA7]" : "border-[#A1B6C6] bg-white"}`}
                  >
                    {checked && (
                      <Check
                        size={12}
                        strokeWidth={2.5}
                        className="text-white"
                      />
                    )}
                  </span>
                  <span className="truncate font-montserrat text-[13px] font-medium text-[#10233A]">
                    {translateStatusLabels && (label === 'Status' || label === uiText('Status')) ? statusText(option.label) : option.value === '' ? uiText(option.label) : option.label}
                  </span>
                </button>
              );
            })}
          </div>
        </DropdownPortal>
      )}
    </div>
  );
}

const FILTERABLE_COLUMNS: { key: keyof Document; label: string }[] =
  DOCUMENT_BASE_COLUMNS.filter(
    (c) => !FIXED_FILTER_KEYS.has(c.key) && c.key !== "status",
  ).map((c) => ({ key: c.key as keyof Document, label: c.label }));

type LookupType =
  | "cost_center"
  | "series"
  | "object_project"
  | "department_code"
  | "vat_class"
  | "gl_account"
  | "product_group";

const LOOKUP_COL_MAP: Partial<Record<keyof Document, LookupType>> = {
  series: "series",
  departmentCode: "department_code",
  objectProject: "object_project",
  costCenter: "cost_center",
  expenseAccount: "gl_account",
  vatClassifier: "vat_class",
  productGroup: "product_group",
};

const COUNTERPARTIES_STORAGE_KEY =
  "finansu-harmonija:v7:settings:counterparties";

function loadDocumentCounterparties(): Company[] {
  try {
    const stored = window.localStorage.getItem(COUNTERPARTIES_STORAGE_KEY);
    const parsed = stored ? JSON.parse(stored) : [];
    return Array.isArray(parsed) ? (parsed as Company[]) : [];
  } catch {
    return [];
  }
}

function counterpartyCodeForName(counterparties: Company[], name: string) {
  const normalizedName = name.trim().toLocaleLowerCase();
  return (
    counterparties.find(
      (counterparty) =>
        counterparty.name.trim().toLocaleLowerCase() === normalizedName,
    )?.company_code ?? ""
  );
}

function LookupCellDropdown({
  docId,
  companyId,
  generalLedgerName,
  colKey,
  value,
  lookupType,
  width,
  onSave,
  tableSelect = false,
  framed = false,
  requiredLabel,
  disabled = false,
  onOpenGeneralLedger,
}: {
  docId: string;
  companyId: string;
  generalLedgerName?: string;
  colKey: string;
  value: string;
  lookupType: LookupType;
  width: number;
  onSave: (docId: string, colKey: string, newVal: string) => Promise<void>;
  tableSelect?: boolean;
  framed?: boolean;
  requiredLabel?: string;
  disabled?: boolean;
  onOpenGeneralLedger?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [newVal, setNewVal] = useState("");
  const [saving, setSaving] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ top: 0, left: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const scopedLookupType =
    ["department_code", "cost_center", "object_project", "product_group", "series"].includes(lookupType) && companyId
      ? `${lookupType}::company::${companyId}`
      : lookupType;
  const filteredOptions = options.filter((option) =>
    option.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()),
  );

  useEffect(() => {
    if (!open) return;
    supabase
      .from("lookup_values")
      .select("value")
      .eq("type", scopedLookupType)
      .order("value")
      .then(({ data }) => {
        const managedGlAccounts =
          lookupType === "gl_account"
            ? loadCompanyGeneralLedgerAccountOptions(
                companyId,
                generalLedgerName,
              )
            : [];
        setOptions(
          Array.from(new Set(
            lookupType === "gl_account"
              ? managedGlAccounts
              : (data ?? []).map((record) => String(record.value ?? "")),
          )).sort((left, right) =>
            left.localeCompare(right, undefined, { numeric: true }),
          ),
        );
      });
  }, [companyId, generalLedgerName, lookupType, open, scopedLookupType]);

  useDropdownDismiss(open, containerRef, () => {
    setOpen(false);
    setQuery("");
  }, menuRef);

  const updateMenuPosition = useCallback(() => {
    const anchor = containerRef.current;
    if (!anchor) return;
    const rect = anchor.getBoundingClientRect();
    const menuWidth = Math.max(width, 180);
    const estimatedHeight = 250;
    const availableBelow = window.innerHeight - rect.bottom;
    const top =
      availableBelow >= estimatedHeight
        ? rect.bottom + 4
        : Math.max(8, rect.top - estimatedHeight - 4);
    const left = Math.max(
      8,
      Math.min(rect.left, window.innerWidth - menuWidth - 8),
    );
    setMenuPosition({ top, left });
  }, [width]);

  useEffect(() => {
    if (!open || !tableSelect) return;
    updateMenuPosition();
    window.addEventListener("resize", updateMenuPosition);
    window.addEventListener("scroll", updateMenuPosition, true);
    return () => {
      window.removeEventListener("resize", updateMenuPosition);
      window.removeEventListener("scroll", updateMenuPosition, true);
    };
  }, [open, tableSelect, updateMenuPosition]);

  async function handleSelect(val: string) {
    if (disabled || saving) return;
    setSaving(true);
    try {
      await onSave(docId, colKey, val);
      if (lookupType === "product_group") await ensureOrganizationProductGroup(companyId, val);
      setOpen(false); setQuery("");
    } catch { /* The list displays the command error; retain the current value. */ }
    finally { setSaving(false); }
  }

  async function handleAdd() {
    const trimmed = newVal.trim();
    if (!trimmed || disabled || saving) return;
    setSaving(true);
    try {
      await onSave(docId, colKey, trimmed);
      await supabase
        .from("lookup_values")
        .upsert(
          { type: scopedLookupType, value: trimmed },
          { onConflict: "type,value" },
        );
      if (lookupType === "product_group") {
        await ensureOrganizationProductGroup(companyId, trimmed);
      }
      setOptions((prev) => [...new Set([...prev, trimmed])].sort());
      setNewVal("");
      setOpen(false);
    } catch { /* Failed commands must not replace the displayed document value. */ }
    finally { setSaving(false); }
  }

  if (lookupType === "gl_account") {
    return (
      <div className={`relative ${requiredLabel ? 'pl-[22px]' : ''}`} style={{ width: framed ? Math.max(0, width - 8) : width }}>
      {requiredLabel && <RequiredDocumentValue label={requiredLabel} field={colKey} />}
      <GeneralLedgerAccountSelect
        value={value}
        companyId={companyId}
        generalLedgerName={generalLedgerName}
        width={Math.max(0, width - (framed ? 8 : 0) - (requiredLabel ? 22 : 0))}
        compact
        borderless={tableSelect}
        tableFrame={framed}
        disabled={disabled}
        ariaLabel={`Select ${colKey}`}
        onChange={(nextValue) => { void onSave(docId, colKey, nextValue).catch(() => undefined); }}
        onOpenGeneralLedger={onOpenGeneralLedger}
      />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative"
      style={{ width: framed ? Math.max(0, width - 8) : width }}
      onClick={(e) => e.stopPropagation()}
    >
      <input
        role="combobox"
        disabled={disabled}
        aria-label={`Select ${colKey}`}
        aria-expanded={open}
        aria-invalid={Boolean(requiredLabel) || undefined}
        aria-describedby={requiredLabel ? `required-${docId}-${colKey}` : undefined}
        value={open ? query : value}
        style={requiredLabel ? { paddingLeft: 30 } : undefined}
        autoComplete="off"
        onFocus={(event) => {
          if (disabled) return;
          if (!open && tableSelect) updateMenuPosition();
          setQuery("");
          setOpen(true);
          event.currentTarget.select();
        }}
        onClick={() => { if (!disabled) setOpen(true); }}
        onChange={(event) => { setQuery(event.target.value); setOpen(true); }}
        className={
          framed
            ? `h-7 w-full rounded border border-transparent bg-transparent px-2 pr-9 font-montserrat text-[12px] font-normal text-[#10233A] outline-none ${disabled ? 'cursor-not-allowed opacity-60' : 'document-inline-field'}`
            : tableSelect
            ? `h-7 w-[calc(100%-8px)] border border-transparent bg-transparent px-2 pr-6 font-montserrat text-[11px] font-normal text-[#10233A] outline-none transition-colors ${disabled ? "cursor-not-allowed opacity-60" : "hover:text-[#007EA7]"}`
            : "h-7 w-full bg-transparent pr-6 font-montserrat text-[12px] font-medium leading-[18px] text-[#10233A] outline-none"
        }
      />
      {requiredLabel && <span id={`required-${docId}-${colKey}`} data-accounting-required={colKey} role="img"
        aria-label={`${requiredLabel}: ${uiText('Required by organization settings. Fill in this field.')}`}
        title={`${requiredLabel}: ${uiText('Required by organization settings. Fill in this field.')}`}
        className="pointer-events-none absolute left-2 top-1/2 flex h-4 w-4 -translate-y-1/2 items-center justify-center text-[#D64545]">
        <AlertCircle size={16} strokeWidth={2.5} aria-hidden="true" />
      </span>}
      <button type="button" data-static-selection tabIndex={-1} disabled={disabled} aria-label={`Open ${colKey} options`} onMouseDown={(event) => event.preventDefault()} onClick={() => { if (!open && tableSelect) updateMenuPosition(); setQuery(""); setOpen((current) => !current); }} className={`absolute right-0 top-0 flex items-center justify-center text-[#7288A3] disabled:hidden ${framed ? "h-7 w-9" : tableSelect ? "h-7 w-6" : "h-7 w-5"}`}>
        <ChevronDown
          size={framed ? 16 : tableSelect ? 12 : 11}
          className={`transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && !disabled &&
        (tableSelect ? createPortal(
        <div
          ref={menuRef}
          data-table-lookup-menu="true"
          className="fixed z-[1000] overflow-hidden rounded-lg border border-[#D3E1EC] bg-white shadow-[0_8px_24px_rgba(16,35,58,0.16)]"
          style={{
            top: menuPosition.top,
            left: menuPosition.left,
            minWidth: Math.max(width, 180),
          }}
          onClick={(event) => event.stopPropagation()}
        >
          <div className="max-h-44 overflow-y-auto">
            {value && (
              <button
                type="button"
                disabled={saving}
                onClick={() => handleSelect("")}
                className="flex w-full items-center gap-2 border-b border-[#E5EDF9] px-3 py-2 text-left font-montserrat text-[12px] font-medium text-[#7288A3] transition-colors hover:bg-[#F0F8FC] disabled:opacity-50"
              >
                <X size={13} />
                <span>{uiText("Clear value")}</span>
              </button>
            )}
            {filteredOptions.length === 0 && (
              <div className="px-3 py-2 text-[11px] text-[#A1B6C6] font-montserrat">{uiText("No options yet")}</div>
            )}
            {filteredOptions.map((opt) => (
              <button
                key={opt}
                type="button"
                disabled={saving}
                aria-pressed={opt === value}
                data-static-selection="true"
                onClick={() => handleSelect(opt)}
                className={`grid h-9 w-full grid-cols-[18px_minmax(0,1fr)] items-center gap-3 rounded-md px-3 text-left font-montserrat text-[12px] font-medium text-[#10233A] disabled:opacity-50 ${opt === value ? 'bg-[#E5EDF9]' : 'hover:bg-[#F0F8FC]'}`}
              >
                <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${opt === value ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6] bg-white'}`}>
                  {opt === value && <Check size={12} strokeWidth={2.5} className="text-white" />}
                </span>
                <span className="truncate">{opt}</span>
              </button>
            ))}
          </div>
          {lookupType !== "series" && <div className="border-t border-[#D3E1EC] p-2 flex gap-1">
            <input
              value={newVal}
              onChange={(e) => setNewVal(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleAdd();
                e.stopPropagation();
              }}
              placeholder={uiText("Add new...")}
              className="flex-1 min-w-0 px-2 py-1 text-[11px] font-montserrat border border-[#D3E1EC] rounded focus:outline-none focus:border-[#007EA7] transition-colors"
            />
            <button
              data-system-action="true"
              type="button"
              onClick={handleAdd}
              disabled={!newVal.trim() || saving}
              className="flex items-center justify-center w-6 h-6 rounded bg-[#007EA7] hover:bg-[#006a8e] disabled:opacity-40 transition-colors flex-shrink-0"
            >
              {saving ? (
                <Loader2 size={10} className="text-white animate-spin" />
              ) : (
                <Plus size={10} className="text-white" />
              )}
            </button>
          </div>}
        </div>,
        document.body,
      ) : (
        <div
          ref={menuRef}
          className="absolute left-0 top-full z-[100] mt-1 overflow-hidden rounded-lg border border-[#D3E1EC] bg-white shadow-lg"
          style={{ minWidth: Math.max(width, 160) }}
        >
          <div className="max-h-44 overflow-y-auto">
            {value && (
              <button
                type="button"
                disabled={saving}
                onClick={() => handleSelect("")}
                className="flex w-full items-center gap-2 border-b border-[#E5EDF9] px-3 py-2 text-left font-montserrat text-[12px] font-medium text-[#7288A3] transition-colors hover:bg-[#F0F8FC] disabled:opacity-50"
              >
                <X size={13} />
                <span>{uiText("Clear value")}</span>
              </button>
            )}
            {filteredOptions.length === 0 && (
              <div className="px-3 py-2 font-montserrat text-[11px] text-[#A1B6C6]">{uiText("No options yet")}</div>
            )}
            {filteredOptions.map((opt) => (
              <button
                key={opt}
                type="button"
                disabled={saving}
                aria-pressed={opt === value}
                data-static-selection="true"
                onClick={() => handleSelect(opt)}
                className={`grid h-9 w-full grid-cols-[18px_minmax(0,1fr)] items-center gap-3 rounded-md px-3 text-left font-montserrat text-[12px] font-medium text-[#10233A] disabled:opacity-50 ${opt === value ? 'bg-[#E5EDF9]' : 'hover:bg-[#F0F8FC]'}`}
              >
                <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${opt === value ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6] bg-white'}`}>
                  {opt === value && <Check size={12} strokeWidth={2.5} className="text-white" />}
                </span>
                <span className="truncate">{opt}</span>
              </button>
            ))}
          </div>
          {lookupType !== "series" && <div className="flex gap-1 border-t border-[#D3E1EC] p-2">
            <input
              value={newVal}
              onChange={(e) => setNewVal(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleAdd();
                e.stopPropagation();
              }}
              placeholder={uiText("Add new...")}
              className="min-w-0 flex-1 rounded border border-[#D3E1EC] px-2 py-1 font-montserrat text-[11px] transition-colors focus:border-[#007EA7] focus:outline-none"
            />
            <button
              data-system-action="true"
              type="button"
              onClick={handleAdd}
              disabled={!newVal.trim() || saving}
              className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded bg-[#007EA7] transition-colors hover:bg-[#006a8e] disabled:opacity-40"
            >
              {saving ? <Loader2 size={10} className="animate-spin text-white" /> : <Plus size={10} className="text-white" />}
            </button>
          </div>}
        </div>
      ))}
    </div>
  );
}

interface DocumentsProps {
  companyId?: string;
  companyName?: string;
  company?: Company;
  generalLedgerName?: string;
  title?: string;
  allCompanies?: boolean;
  editOnlyActions?: boolean;
  hideRowActions?: boolean;
  documentTypeFilter?: string;
  initialViewDocumentId?: string | null;
  initialDocumentMode?: 'view' | 'edit' | 'original-view';
  onInitialViewConsumed?: () => void;
  onInitialViewBack?: () => void;
  onOpenGeneralLedger?: () => void;
  onStartChat?: (context: InvoiceChatContext) => void;
}

type SavedDocumentFilters = {
  primaryKeys: string[];
  dynamicFilters: Record<string, string>;
};

function loadSavedDocumentFilters(key: string): SavedDocumentFilters | null {
  try {
    const stored = window.localStorage.getItem(key);
    if (stored === null) return null;
    const parsed = JSON.parse(stored) as Partial<SavedDocumentFilters>;
    const primaryKeys = Array.isArray(parsed.primaryKeys)
      ? parsed.primaryKeys.filter(
          (item): item is string => typeof item === "string",
        )
      : [];
    const dynamicFilters =
      parsed.dynamicFilters && typeof parsed.dynamicFilters === "object"
        ? Object.fromEntries(
            Object.entries(parsed.dynamicFilters).filter(
              ([key, value]) =>
                typeof key === "string" && typeof value === "string",
            ),
          )
        : {};
    const isLegacyAutomaticDefault =
      primaryKeys.length === PRIMARY_FILTER_COLUMNS.length &&
      PRIMARY_FILTER_COLUMNS.every((filter) =>
        primaryKeys.includes(filter.key),
      ) &&
      Object.keys(dynamicFilters).length === 0;
    return {
      primaryKeys: isLegacyAutomaticDefault ? [] : primaryKeys,
      dynamicFilters,
    };
  } catch {
    return null;
  }
}

export default function Documents({
  companyId = "",
  companyName = "",
  company,
  generalLedgerName = "",
  title = "Documents",
  allCompanies = false,
  editOnlyActions = false,
  hideRowActions = false,
  documentTypeFilter = "",
  initialViewDocumentId = null,
  initialDocumentMode = 'view',
  onInitialViewConsumed,
  onInitialViewBack,
  onOpenGeneralLedger,
  onStartChat,
}: DocumentsProps) {
  // OCR delivery/review actions belong to the global register, not company Documents.
  // The separate Invoices view retains its existing actions.
  const globalOcrRegister = allCompanies && !documentTypeFilter;
  const companyDocumentRegister = !allCompanies && !documentTypeFilter;
  const statusDescriptions = useOcrStatusDescriptions();
  const workspaceRef = useRef<HTMLDivElement>(null);
  const [workspaceExpanded, setWorkspaceExpanded] = useState(false);
  useWorkspaceExpansion(globalOcrRegister && workspaceExpanded, workspaceRef.current, setWorkspaceExpanded);
  // Keep old saved preferences compatible; multiple selections now mean all.
  const [savedOrganizationSelection, setOrganizationSelection] = usePersistentState<string[] | null>(
    'finansu-harmonija:v23:global-documents:organizations', null,
  );
  const organizationSelection = useMemo(() => singleOrganizationSelection(savedOrganizationSelection), [savedOrganizationSelection]);
  const filterPersistenceKey = `finansu-harmonija:v12:documents:filters:${
    allCompanies ? `all-companies:${documentTypeFilter || 'documents'}` : companyId || companyName || title
  }`;
  const initialSavedFilters = useRef(
    loadSavedDocumentFilters(filterPersistenceKey),
  );
  const [docs, setDocs] = useState<Document[]>([]);
  const [showArchive, setShowArchive] = useState(false);
  const archiveOpen = globalOcrRegister && showArchive;
  const registerDocs = useMemo(() => documentRegisterScope(docs, globalOcrRegister, archiveOpen), [docs, globalOcrRegister, archiveOpen, statusDescriptions]);
  const [documentCompanies, setDocumentCompanies] = useState<Company[]>(company ? [company] : []);
  const [settingsOrganizationId, setSettingsOrganizationId] = useState<string | null>(null);
  const [showCreateInvoice, setShowCreateInvoice] = useState(false);
  const [showCreateCompanyPicker, setShowCreateCompanyPicker] = useState(false);
  const [createCompanyId, setCreateCompanyId] = useState(companyId);
  const [accessRevision, setAccessRevision] = useState(0);
  const [responsibleUsers, setResponsibleUsers] = useState(() => loadLinkedDirectoryUsers('Internal users'));
  const responsibleOptions = useMemo(() => documentResponsibleOptions(responsibleUsers), [responsibleUsers]);
  useEffect(() => {
    const refresh = () => { setAccessRevision(value => value + 1); setResponsibleUsers(loadLinkedDirectoryUsers('Internal users')); };
    window.addEventListener('storage', refresh);
    window.addEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh);
    window.addEventListener('organization-reference-updated', refresh);
    return () => { window.removeEventListener('storage', refresh); window.removeEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh); window.removeEventListener('organization-reference-updated', refresh); };
  }, []);
  const editableCompanyIds = useMemo(() => new Set(documentCompanies.filter(canEditCompanyDocuments).map(item => item.id)), [documentCompanies, accessRevision]);
  const showNoBuyer = globalOcrRegister && canAccessUnassignedDocuments();
  const canAssignOrganization = showNoBuyer && canAccessUnassignedDocuments(true) && editableCompanyIds.size > 0;
  const restorableCompanyIds = useMemo(() => new Set(documentCompanies.filter(company => documentActionRights(company).delete).map(company => company.id)), [documentCompanies, accessRevision]);
  const creatableCompanyIds = useMemo(() => new Set(documentCompanies.filter(canCreateCompanyDocument).map(item => item.id)), [documentCompanies, accessRevision]);
  const canCreateInvoice = allCompanies ? creatableCompanyIds.size > 0 : creatableCompanyIds.has(companyId);
  const startCreateInvoice = () => {
    if (globalOcrRegister) return;
    if (!allCompanies) { setCreateCompanyId(companyId); setShowCreateInvoice(true); return; }
    const available = documentCompanies.filter(item => creatableCompanyIds.has(item.id));
    setCreateCompanyId(available[0]?.id || '');
    if (available.length === 1) setShowCreateInvoice(true);
    else setShowCreateCompanyPicker(true);
  };
  const rowActions = useMemo(() => {
    if (hideRowActions || editOnlyActions) return new Map<string, DocumentRowAction>();
    const rights = new Map(documentCompanies.map(item => [item.id, documentActionRights(item)]));
    return new Map(docs.map(doc => {
      const allowed = rights.get(doc.companyId) ?? { delete: false, create: false, storno: false };
      const action = documentRowAction(doc.inlineSource, allowed);
      return [doc.id, action];
    }));
  }, [docs, documentCompanies, accessRevision, hideRowActions, editOnlyActions]);
  const rowActionsWidth = archiveOpen ? 36 : editOnlyActions ? 74 : globalOcrRegister ? 76 : companyDocumentRegister ? 160 : 192;
  const documentTypeRecords = useMemo(() => loadOrganizationReferenceRecords('Document type'), [accessRevision]);
  const documentTypeOptions = useMemo<ReturnType<typeof documentTypeCatalogOptions>>(() => globalOcrRegister
    ? documentTypeCatalogOptions(documentTypeRecords)
    : documentTypeRecords.filter(record => record.status.toLowerCase() === 'active' && !record.parentCode)
      .map(record => ({ value: record.code, label: record.fullName || record.code })), [documentTypeRecords, globalOcrRegister]);
  const localizedDocumentTypeOptions = documentTypeOptions.map(option => ({ ...option,
    ...(option.description ? { description: option.description.split(' / ').map(label => uiText(label)).join(' / ') } : {}) }));
  const registerCellValue = (document: Document, key: keyof Document) => {
    if (globalOcrRegister && ['amountWithoutVat', 'vat', 'totalAmount'].includes(key)) return document[key];
    if (globalOcrRegister && key === 'documentType') {
      const selected = documentTypeCatalogSelection(document.inlineSource, documentTypeRecords);
      return uiText(documentTypeOptions.find(option => option.value === selected)?.label || selected);
    }
    return documentCellValue(document, key);
  };
  const purposeOptions = useMemo(() => documentPurposeCatalogOptions(), [accessRevision]);
  const inlineError = (document: Document, field: string) => hideRowActions ? 'Read-only view.' : documentInlineEditError(document.inlineSource, field, editableCompanyIds.has(document.companyId), globalOcrRegister);
  const [counterparties, setCounterparties] = useState<Company[]>(() =>
    loadDocumentCounterparties(),
  );
  const organizationDirectory = useMemo(() => globalOcrRegister
    ? buildOrganizationDirectory(documentCompanies, loadDirectoryCounterparties(documentCompanies, canAccessUnassignedDocuments()))
    : [], [documentCompanies, counterparties, accessRevision, globalOcrRegister]);
  const organizationClientIds = useMemo(() => new Set(organizationDirectory.filter(item => item.isOrganizationClient).map(item => item.id)), [organizationDirectory]);
  const settingsOrganization = organizationDirectory.find(item => item.id === settingsOrganizationId);
  const selectedOrganizationIds = useMemo(() => organizationDirectory
    .filter(item => !Array.isArray(organizationSelection) || organizationSelection.includes(item.id))
    .map(item => item.id), [organizationDirectory, organizationSelection]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const accountingRequirements = useMemo(() => new Map(documentCompanies.map(company => [company.id, companyOcrAdditionalColumnRequirements(company)])), [documentCompanies]);
  const duplicateIds = useMemo(() => duplicateDocumentIds(docs.map(document => document.inlineSource)), [docs]);
  const [periodRevision, setPeriodRevision] = useState(0);
  useEffect(() => {
    const refresh = () => setPeriodRevision(value => value + 1);
    window.addEventListener('operation-date-validation-updated', refresh);
    const storageRefresh = (event: StorageEvent) => { if (!event.key || event.key.includes('operation-date-validation:')) refresh(); };
    window.addEventListener('storage', storageRefresh);
    return () => { window.removeEventListener('operation-date-validation-updated', refresh); window.removeEventListener('storage', storageRefresh); };
  }, []);
  const periodPolicies = useMemo(() => new Map(documentCompanies.map(company => [company.id, loadOperationDateValidationRule(company.id)])), [documentCompanies, periodRevision]);
  // A delivery moves a record out of this workspace, not merely out of a search.
  // Remove those IDs from bulk actions while preserving selection across filters.
  useEffect(() => {
    const available = new Set(registerDocs.map(document => document.id));
    setSelectedIds(current => {
      const next = new Set([...current].filter(id => available.has(id)));
      return next.size === current.size ? current : next;
    });
  }, [registerDocs]);
  const [detailedDigitizationBusy, setDetailedDigitizationBusy] = useState(false);
  const detailedDigitizationPending = useRef(false);
  const selectionCompanyIds = new Set(docs.filter(doc => selectedIds.has(doc.id)).map(doc => doc.companyId));
  const selectionCompanyId = allCompanies ? (selectionCompanyIds.size === 1 ? [...selectionCompanyIds][0] : '') : companyId;
  const primaryDestination = primaryDocumentDeliveryDestination(documentCompanies.find(item => item.id === selectionCompanyId));
  const [advanceAssignmentIds, setAdvanceAssignmentIds] = useState<string[] | null>(null);
  const [fieldAssignmentIds, setFieldAssignmentIds] = useState<string[] | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = TABLE_BATCH_SIZE;
  const [showColumnPanel, setShowColumnPanel] = useState(false);
  const defaultColumns = useMemo<ColConfig[]>(() => globalOcrRegister
    ? globalDocumentDefaultColumns([
      { key: 'organization', label: 'Organization', width: 180, visible: false },
      ...globalDocumentColumns(DOCUMENT_BASE_COLUMNS),
    ])
    : allCompanies
      ? [{ key: 'organization', label: 'Organization', width: 180, visible: true }, ...DOCUMENT_BASE_COLUMNS]
      : DOCUMENT_BASE_COLUMNS, [allCompanies, globalOcrRegister]);
  const [activeColumns, setActiveColumns] = useState<ColConfig[]>(() => defaultColumns.map(column => ({ ...column })));
  const filterableColumns = allCompanies ? [{ key: 'organization' as const, label: 'Organization' }, ...(globalOcrRegister ? globalDocumentColumns(FILTERABLE_COLUMNS) : FILTERABLE_COLUMNS)] : FILTERABLE_COLUMNS;
  const [selectedPeriod, setSelectedPeriod] = useState<string | null>(null);
  const [showPeriodMenu, setShowPeriodMenu] = useState(false);
  const [showInfoPanel, setShowInfoPanel] = useState(false);
  const [showUploadPanel, setShowUploadPanel] = useState(false);
  const uploadPanelRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!showUploadPanel) return;
    const previous = document.activeElement as HTMLElement | null;
    uploadPanelRef.current?.focus();
    return () => { previous?.focus(); };
  }, [showUploadPanel]);
  const [duplicateSource, setDuplicateSource] = useState<Document | null>(null);
  const { confirm: confirmApprovedEdit, dialog: approvedEditDialog } = useApprovedDocumentEditWarning();
  const [openDoc, setOpenDoc] = useState<Document | null>(null);
  const [viewDoc, setViewDoc] = useState<Document | null>(null);
  const initialViewHandledRef = useRef(false);
  const entryDocumentIdRef = useRef(initialViewDocumentId);
  const [viewActionPanel, setViewActionPanel] = useState<
    "send" | "preview" | null
  >(null);
  const [uploadDocType] = useState("");
  const [uploadCompany] = useState("");
  const [uploadDatePeriod] = useState("");
  const [uploadFiles, setUploadFiles] = useState<File[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const periodRef = useRef<HTMLDivElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);
  const tableRef = useRef<HTMLDivElement>(null);
  const [delivery, setDelivery] = useState<{ mode: 'transfer' | 'export'; ids: string[] } | null>(null);
  const directTransferPending = useRef(false);
  const [transferBusy, setTransferBusy] = useState(false);
  const [transferNotice, setTransferNotice] = useState<{ error: boolean; message: string } | null>(null);
  const [selectedCurrency, setSelectedCurrency] = useState<string | null>(null);
  const [showCurrencyMenu, setShowCurrencyMenu] = useState(false);
  const currencyRef = useRef<HTMLDivElement>(null);
  const [selectedCounterparty, setSelectedCounterparty] = useState<
    string | null
  >(null);
  const [showCounterpartyMenu, setShowCounterpartyMenu] = useState(false);
  const counterpartyRef = useRef<HTMLDivElement>(null);
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
  const [statusDetailsId, setStatusDetailsId] = useState<string | null>(null);
  const statusDetailsDocument = globalOcrRegister ? docs.find(document => document.id === statusDetailsId) : undefined;
  const [reversedOnly, setReversedOnly] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const statusRef = useRef<HTMLDivElement>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [dynamicFilters, setDynamicFilters] = useState<Record<string, string>>(
    () => Object.fromEntries(Object.entries(initialSavedFilters.current?.dynamicFilters ?? (allCompanies ? { organization: '' } : {}))
      .filter(([key]) => !globalOcrRegister || !['documentPurpose', 'productGroup'].includes(key))),
  );
  useEffect(() => {
    if (!globalOcrRegister || archiveOpen) return;
    // Do not retain an archived/legacy status filter that cannot occur in this queue.
    if (selectedStatus && ocrStatusGroup(selectedStatus) !== 'Processed') setSelectedStatus(null);
    setDynamicFilters(current => current.status && ocrStatusGroup(current.status) !== 'Processed'
      ? { ...current, status: '' } : current);
  }, [globalOcrRegister, archiveOpen, selectedStatus, statusDescriptions]);
  const [openDynamicMenu, setOpenDynamicMenu] = useState<string | null>(null);
  const [showAddFilterMenu, setShowAddFilterMenu] = useState(false);
  const [pendingDynamicFilterKeys, setPendingDynamicFilterKeys] = useState<
    string[]
  >([]);
  const [activePrimaryFilterKeys, setActivePrimaryFilterKeys] = useState<
    string[]
  >(
    () => initialSavedFilters.current?.primaryKeys ?? [],
  );
  const addFilterRef = useRef<HTMLDivElement>(null);
  const addFilterMenuRef = useRef<HTMLDivElement>(null);
  const [filterColumnQuery, setFilterColumnQuery] = useState('');
  const dynamicFilterRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [rangeAmountMin, setRangeAmountMin] = useState("");
  const [rangeAmountMax, setRangeAmountMax] = useState("");
  const [appliedRangeMin, setAppliedRangeMin] = useState<number | null>(null);
  const [appliedRangeMax, setAppliedRangeMax] = useState<number | null>(null);
  const [showRangeAmountMenu, setShowRangeAmountMenu] = useState(false);
  const rangeAmountRef = useRef<HTMLDivElement>(null);
  const rangeAmountMenuRef = useRef<HTMLDivElement>(null);
  const [expandedDocumentIds, setExpandedDocumentIds] = useState<Set<string>>(
    new Set(),
  );
  const [statusDropdownDocId, setStatusDropdownDocId] = useState<string | null>(
    null,
  );
  const [issueDocument, setIssueDocument] = useState<Document | null>(null);
  const [rowActionDocument, setRowActionDocument] = useState<{ documentId: string; companyId: string; kind: DocumentManagementActionKind } | null>(null);
  const [creditNoteSource, setCreditNoteSource] = useState<{ documentId: string; companyId: string } | null>(null);
  const [issueError, setIssueError] = useState('');
  const statusDropdownRef = useRef<HTMLButtonElement | null>(null);
  const statusDropdownMenuRef = useRef<HTMLDivElement>(null);
  useDropdownDismiss(statusDropdownDocId !== null, statusDropdownRef, () => setStatusDropdownDocId(null), statusDropdownMenuRef);
  useDropdownDismiss(showAddFilterMenu, addFilterRef, () => setShowAddFilterMenu(false), addFilterMenuRef);
  useDropdownDismiss(showRangeAmountMenu, rangeAmountRef, () => setShowRangeAmountMenu(false), rangeAmountMenuRef);

  const toggleReversedDocuments = () => {
    if (!reversedOnly) {
      // This shortcut must show every reversed document in the current register,
      // even when an earlier search or amount/status filter was still active.
      setSearchQuery(''); setSelectedStatus(null); setSelectedPeriod(null);
      setSelectedCounterparty(null); setSelectedCurrency(null);
      setDynamicFilters(current => Object.fromEntries(Object.keys(current).map(key => [key, ''])));
      setRangeAmountMin(''); setRangeAmountMax(''); setAppliedRangeMin(null); setAppliedRangeMax(null);
    }
    setReversedOnly(value => !value); setCurrentPage(1);
  };

  useEffect(() => {
    window.localStorage.setItem(
      filterPersistenceKey,
      JSON.stringify({
        primaryKeys: activePrimaryFilterKeys,
        dynamicFilters,
      } satisfies SavedDocumentFilters),
    );
  }, [activePrimaryFilterKeys, dynamicFilters, filterPersistenceKey]);

  const applyFilterSelection = () => {
    const primaryKeys = pendingDynamicFilterKeys.filter((key) =>
      PRIMARY_FILTER_COLUMNS.some((filter) => filter.key === key),
    );
    const dynamicKeys = pendingDynamicFilterKeys.filter(
      (key) => !PRIMARY_FILTER_COLUMNS.some((filter) => filter.key === key),
    );
    setActivePrimaryFilterKeys(primaryKeys);
    setDynamicFilters((current) =>
      Object.fromEntries(
        dynamicKeys.map((key) => [key, current[key] ?? ""]),
      ),
    );
    if (!primaryKeys.includes("period")) setSelectedPeriod(null);
    if (!primaryKeys.includes("clientCounterparty"))
      setSelectedCounterparty(null);
    if (!primaryKeys.includes("currency")) setSelectedCurrency(null);
    if (!primaryKeys.includes("status")) setSelectedStatus(null);
    if (!primaryKeys.includes("rangeAmount")) {
      setRangeAmountMin("");
      setRangeAmountMax("");
      setAppliedRangeMin(null);
      setAppliedRangeMax(null);
    }
    setShowAddFilterMenu(false);
    setOpenDynamicMenu(null);
    setCurrentPage(1);
  };

  const updateDocField = useCallback(
    async (docId: string, colKey: string, newVal: string) => {
      const target = docs.find(document => document.id === docId);
      if (!target || !isInlineDocumentField(colKey)) throw new Error('This field cannot be edited directly.');
      if (!globalOcrRegister && !await confirmApprovedEdit(target.inlineSource)) throw new Error('');
      try {
        const saved = await applyDocumentInlineEdit(docId, target.companyId, colKey, newVal, documentInlineSnapshot(target.inlineSource), globalOcrRegister);
        const mapped = mapRow(saved);
        const update = (previous: Document) => ({ ...previous, ...mapped, counterpartyCode: previous.counterpartyCode });
        setDocs(previous => previous.map(document => document.id === docId ? update(document) : document));
        setOpenDoc(previous => previous?.id === docId ? update(previous) : previous);
        setIssueError('');
      } catch (error) {
        const message = error instanceof Error ? error.message : 'The document could not be saved.';
        setIssueError(message);
        throw new Error(message);
      }
    },
    [docs, confirmApprovedEdit, globalOcrRegister],
  );

  const fetchDocs = useCallback(async (showLoading = true) => {
    if (showLoading) setLoading(true);
    if (globalOcrRegister) {
      try { await ensureOcrRegisterExamples(); }
      catch (error) { setIssueError(error instanceof Error ? error.message : 'Could not prepare document examples.'); }
    }
    let query = supabase.from("documents").select("*", { includeDeleted: globalOcrRegister });
    if (!allCompanies) query = query.eq("company_id", companyId);
    const [{ data, error }, organizations] = await Promise.all([
      query.order("created_at", { ascending: false }),
      supabase.from('companies').select('*'),
    ]);
    const accessibleCompanies = ((organizations.data ?? []) as unknown as Company[]).filter(canViewCompanyDocuments);
    const companyById = new Map(accessibleCompanies.map(item => [item.id, item]));
    setDocumentCompanies(accessibleCompanies);
    if (!error && data) {
      const normalizedTypeFilter = documentTypeFilter
        .trim()
        .toLocaleLowerCase();
      const availableCounterparties = loadDocumentCounterparties();
      setCounterparties(availableCounterparties);
      const uploadUsers = globalOcrRegister ? [...loadLinkedDirectoryUsers('Internal users'), ...loadLinkedDirectoryUsers('External users')] : [];
      const mappedDocuments = (data as unknown as DbDocument[])
        // Load all accessible records; the workspace separates delivery archive below.
        .filter(document => companyById.has(document.company_id || '') || (globalOcrRegister && !document.company_id && canAccessUnassignedDocuments()))
        .map(document => mapRow(globalOcrRegister ? withUploadedDocumentUploader(document, uploadUsers) : document))
        .map((document) => {
          const linkedCounterparty = availableCounterparties.find(
            (counterparty) =>
              (document.counterpartyId &&
                counterparty.id === document.counterpartyId) ||
              (!document.counterpartyId &&
                counterparty.name.trim().toLocaleLowerCase() ===
                  document.clientCounterparty.trim().toLocaleLowerCase()),
          );
          if (linkedCounterparty && document.companyId && !document.counterpartyId && !document.inlineSource.document_deletion) {
            void supabase
              .from("documents")
              .update({ counterparty_id: linkedCounterparty.id })
              .eq("id", document.id);
          }
          return {
            ...document,
            ...(globalOcrRegister ? { processingStatus: ocrDocumentRegisterStatus(document.inlineSource as unknown as DbDocument),
              processingDetail: ocrDocumentRegisterStatus(document.inlineSource as unknown as DbDocument) } : {}),
            organization: companyById.get(document.companyId)?.name || uiText('Organization not identified'),
            counterpartyId:
              linkedCounterparty?.id ?? document.counterpartyId,
            clientCounterparty:
              linkedCounterparty?.name ?? document.clientCounterparty,
            counterpartyCode:
              document.inlineSource.counterparty_code != null ? document.counterpartyCode : linkedCounterparty?.company_code ??
              counterpartyCodeForName(
                availableCounterparties,
                document.clientCounterparty,
              ),
          };
        })
        .filter(
          (document) =>
            !normalizedTypeFilter ||
            document.documentType
              .trim()
              .toLocaleLowerCase()
              .includes(normalizedTypeFilter),
        );
      setDocs(mappedDocuments);
      setOpenDoc(current => {
        if (!current) return current;
        const fresh = mappedDocuments.find(document => document.id === current.id);
        return fresh ? { ...current, digitizationIssues: fresh.digitizationIssues, issueStatus: fresh.issueStatus } : null;
      });

      const productGroupsByCompany = new Map<string, string[]>();
      mappedDocuments.forEach((document) => {
        const assignedGroups = [
          ...document.lineItems,
          ...document.summaryLineItems,
        ]
          .map((line) => line.productGroup?.trim() ?? "")
          .filter(Boolean);
        if (assignedGroups.length === 0) return;
        productGroupsByCompany.set(document.companyId, [
          ...(productGroupsByCompany.get(document.companyId) ?? []),
          ...assignedGroups,
        ]);
      });
      await Promise.all(
        [...productGroupsByCompany.entries()].map(([organizationId, groups]) =>
          ensureOrganizationProductGroups(organizationId, groups),
        ),
      );
    }
    setLoading(false);
  }, [allCompanies, companyId, documentTypeFilter, accessRevision, globalOcrRegister]);

  useEffect(() => {
    fetchDocs();
  }, [fetchDocs]);

  useEffect(() => {
    const refresh = (event: Event) => {
      if (event.type === 'storage' ? affectsDocumentRegister((event as StorageEvent).key)
        : !(event as CustomEvent).detail?.table || ['documents', 'companies'].includes((event as CustomEvent).detail?.table)) void fetchDocs(false);
    };
    window.addEventListener('finansu-harmonija:data-changed', refresh);
    window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('finansu-harmonija:data-changed', refresh); window.removeEventListener('storage', refresh); };
  }, [fetchDocs]);

  useEffect(() => {
    if (!initialViewDocumentId || initialViewHandledRef.current || docs.length === 0) return;
    const documentToView = docs.find((document) => document.id === initialViewDocumentId);
    if (!documentToView) return;
    initialViewHandledRef.current = true;
    if (globalOcrRegister) setShowArchive(isDocumentArchived(documentToView.inlineSource));
    if (initialDocumentMode === 'edit' || initialDocumentMode === 'original-view') setOpenDoc(documentToView);
    else setViewDoc(documentToView);
    onInitialViewConsumed?.();
  }, [docs, initialViewDocumentId, initialDocumentMode, onInitialViewConsumed, globalOcrRegister]);

  useEffect(() => {
    const refreshCounterparties = () => {
      const next = loadDocumentCounterparties();
      setCounterparties(next);
      setDocs((current) =>
        current.map((document) => {
          const linkedCounterparty = next.find(
            (counterparty) =>
              (document.counterpartyId &&
                counterparty.id === document.counterpartyId) ||
              (!document.counterpartyId &&
                counterparty.name.trim().toLocaleLowerCase() ===
                  document.clientCounterparty.trim().toLocaleLowerCase()),
          );
          return {
            ...document,
            counterpartyId:
              linkedCounterparty?.id ?? document.counterpartyId,
            clientCounterparty:
              linkedCounterparty?.name ?? document.clientCounterparty,
            counterpartyCode:
              document.inlineSource.counterparty_code != null ? document.counterpartyCode : linkedCounterparty?.company_code ??
              counterpartyCodeForName(next, document.clientCounterparty),
          };
        }),
      );
    };
    window.addEventListener("counterparties-updated", refreshCounterparties);
    window.addEventListener("storage", refreshCounterparties);
    return () => {
      window.removeEventListener(
        "counterparties-updated",
        refreshCounterparties,
      );
      window.removeEventListener("storage", refreshCounterparties);
    };
  }, []);

  const { startResize } = useColumnResize(activeColumns, setActiveColumns,
    globalOcrRegister ? globalDocumentColumnPersistence(getCurrentUserIdentity().email) : undefined);

  const visibleColumns = activeColumns.filter((c) => c.visible);
  const showExpandableDetails = !editOnlyActions;

  async function handleStatusChange(
    doc: Document,
    newStatus: Document["status"],
  ) {
    if (!documentStatusOptions().some(option => option.value === newStatus)) return;
    if (!canEditCompanyDocuments(documentCompanies.find(company => company.id === doc.companyId))) {
      setIssueError('You need Edit access to Documents and access to this company.');
      setStatusDropdownDocId(null);
      return;
    }
    if (newStatus === doc.status) {
      setStatusDropdownDocId(null);
      return;
    }
    setStatusDropdownDocId(null);
    if (!await confirmApprovedEdit(doc.inlineSource)) return;
    const { data: savedDocuments, error } = await supabase
      .from("documents")
      .update({ status: newStatus })
      .eq("id", doc.id).eq('company_id', doc.companyId);
    if (error) setIssueError(error.message);
    if (!error) {
      await supabase.from("document_history").insert({
        document_id: doc.id,
        action: newStatus,
        user_name: getCurrentUserName(),
        details: `Status changed from ${doc.status} to ${newStatus}`,
      });
      setDocs((prev) =>
        prev.map((d) => (d.id === doc.id ? { ...d, ...(savedDocuments?.[0] ? mapRow(savedDocuments[0] as unknown as DbDocument) : { status: newStatus, inlineSource: { ...d.inlineSource, status: newStatus } }), counterpartyCode: d.counterpartyCode } : d)),
      );
      if (openDoc?.id === doc.id)
        setOpenDoc((prev) => (prev ? { ...prev, status: newStatus, inlineSource: { ...prev.inlineSource, status: newStatus } } : prev));
    }
    setStatusDropdownDocId(null);
  }

  async function digitizeSelectedInDetail() {
    if (!globalOcrRegister || detailedDigitizationPending.current || !selectedIds.size) return;
    const ids = [...selectedIds];
    detailedDigitizationPending.current = true; setDetailedDigitizationBusy(true);
    try {
      await requestDocumentsDetailedDigitization(ids);
      setSelectedIds(previous => new Set([...previous].filter(id => !ids.includes(id))));
      setTransferNotice({ error: false, message: `${uiText('Selected documents returned to OCR for detailed digitization:')} ${ids.length}` });
      await fetchDocs(false);
    } catch (error) {
      setTransferNotice({ error: true, message: uiText(error instanceof Error ? error.message : 'The documents could not be returned to OCR.') });
    } finally { detailedDigitizationPending.current = false; setDetailedDigitizationBusy(false); }
  }

  async function loadDeliveryRecords(request: { mode: 'transfer' | 'export'; ids: string[] }) {
    const [documentsResult, companiesResult] = await Promise.all([
      supabase.from('documents').select('*').in('id', request.ids),
      supabase.from('companies').select('*'),
    ]);
    if (documentsResult.error) throw new Error(documentsResult.error.message);
    if (companiesResult.error) throw new Error(companiesResult.error.message);
    const selected = selectedDocumentRecords((documentsResult.data ?? []) as unknown as DbDocument[], request.ids, allCompanies ? '' : companyId);
    const currentCompanies = (companiesResult.data ?? []) as unknown as Company[];
    for (const record of selected) {
      const organization = currentCompanies.find(item => item.id === record.company_id);
      const allowed = request.mode === 'transfer' ? canEditCompanyDocuments(organization) : canViewCompanyDocuments(organization);
      if (!allowed) throw new Error('You no longer have access to one of the selected documents. Refresh the list.');
      if (globalOcrRegister && request.mode === 'transfer' && isDocumentArchived(record as unknown as Record<string, unknown>)) {
        throw new Error(uiText('This document is already in the archive. Duplicate sending is not allowed.'));
      }
    }
    return { documents: selected.map(mapRow), companies: currentCompanies };
  }

  async function exportSelectedDocuments(destinationId: string) {
    if (!delivery || delivery.mode !== 'export') return;
    const { documents, companies } = await loadDeliveryRecords(delivery);
    const companyIds = new Set(documents.map(record => record.companyId));
    const company = companies.find(item => companyIds.has(item.id));
    if (companyIds.size !== 1 || !company) throw new Error('Select documents from one company for each export.');
    const file = buildDocumentAccountingExport(documents.map(record => record.inlineSource), delivery.ids, company, destinationId);
    downloadDocumentExport(file);
  }

  async function persistDocumentDelivery(command: TestDeliveryCommand) {
    const saved = (await applyDocumentTestDelivery(command)).map(record => ({
      ...mapRow(record),
      ...(globalOcrRegister ? {
        processingStatus: ocrDocumentRegisterStatus(record),
        processingDetail: ocrDocumentRegisterStatus(record),
      } : {}),
    }));
    const byId = new Map(saved.map(record => [record.id, record]));
    setDocs(current => current.map(record => byId.has(record.id) ? { ...record, ...byId.get(record.id)! } : record));
    setTransferNotice(directDocumentDeliveryNotice(saved, command.requestId));
    return saved;
  }

  async function testSelectedDocuments(command: TestDeliveryCommand) {
    if (!delivery || delivery.mode !== 'transfer' || (!allCompanies && command.companyId !== companyId)
      || [...new Set(delivery.ids)].sort().join('|') !== [...new Set(command.ids)].sort().join('|')) throw new Error('The selected documents changed. Reopen Send to accounting.');
    const saved = await persistDocumentDelivery({ ...command, ...(globalOcrRegister ? { sourceRegister: 'all-documents' as const } : {}) });
    setDelivery(null);
    return saved;
  }

  async function sendDocuments(ids: string[], expectedDestinationId?: string) {
    if (directTransferPending.current || delivery) return;
    directTransferPending.current = true;
    setTransferBusy(true);
    setTransferNotice(null);
    const request = { mode: 'transfer' as const, ids: [...new Set(ids)] };
    try {
      const current = await loadDeliveryRecords(request);
      setDocumentCompanies(current.companies);
      const command = prepareDirectDocumentDelivery(
        current.documents.map(record => record.inlineSource as unknown as DbDocument),
        current.companies, request.ids, allCompanies ? '' : companyId,
        expectedDestinationId, crypto.randomUUID(),
      );
      await persistDocumentDelivery({ ...command, ...(globalOcrRegister ? { sourceRegister: 'all-documents' as const } : {}) });
    } catch (cause) {
      setTransferNotice({ error: true, message: cause instanceof Error ? cause.message : 'Unable to process the selected documents. Please try again.' });
    } finally {
      directTransferPending.current = false;
      setTransferBusy(false);
    }
  }

  async function saveDeliveryDestination(targetCompanyId: string, destinationId: string) {
    if (!delivery || delivery.mode !== 'transfer' || (!allCompanies && targetCompanyId !== companyId)) throw new Error('Reopen Send to accounting to choose a destination.');
    const saved = await saveCompanyAccountingDestination(targetCompanyId, destinationId);
    setDocumentCompanies(current => current.map(item => item.id === saved.id ? saved : item));
    return saved;
  }

  function parseDate(d: string): number {
    if (!d) return 0;
    const [day, mon, yr] = d.split(".");
    if (!day || !mon || !yr) return 0;
    return new Date(Number(yr), Number(mon) - 1, Number(day)).getTime();
  }

  const MONTH_NAMES = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  function formatPeriod(ym: string) {
    const [yr, mo] = ym.split("-");
    return `${MONTH_NAMES[Number(mo) - 1]} ${yr}`;
  }

  const availablePeriods: string[] = Array.from(
    new Set(
      registerDocs.map((doc) => {
        const [, mon, yr] = doc.receiveDate.split(".");
        return yr && mon ? `${yr}-${mon}` : "";
      }),
    ),
  )
    .filter(Boolean)
    .sort((a, b) => b.localeCompare(a));

  const {
    sortedRows: baseDocs,
    changeSort,
    directionFor,
  } = useMultiColumnSort(registerDocs, (document, key) => {
    const value = registerCellValue(document, key as keyof Document);
    return key === "receiveDate"
      ? parseDate(String(value))
      : typeof value === "boolean"
        ? String(value)
        : (value as string | number | undefined);
  });

  const sortedDocs = (
    selectedPeriod
      ? baseDocs.filter((doc) => {
          const [, mon, yr] = doc.receiveDate.split(".");
          return Boolean(yr && mon) && `${yr}-${mon}` === selectedPeriod;
        })
      : baseDocs
  )
    .filter((doc) => !globalOcrRegister || matchesOrganizationDirectoryDocument(doc, organizationSelection, organizationDirectory))
    .filter((doc) => !reversedOnly || Boolean(doc.storno))
    .filter((doc) => !selectedCurrency || doc.currency === selectedCurrency)
    .filter(
      (doc) =>
        !selectedCounterparty ||
        doc.clientCounterparty === selectedCounterparty,
    )
    .filter((doc) => !selectedStatus || documentProcessingStatus(documentDisplayStatus(doc)) === selectedStatus)
    .filter((doc) => {
      return Object.entries(dynamicFilters).every(([key, val]) => {
        if (!val) return true;
        return (
          String(key === 'status' ? documentProcessingStatus(documentDisplayStatus(doc)) : registerCellValue(doc, key as keyof Document) ?? "").toLowerCase() ===
          val.toLowerCase()
        );
      });
    })
    .filter((doc) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.trim().toLowerCase();
      return Object.entries(doc).some(
        ([key, v]) => v != null && String(registerCellValue(doc, key as keyof Document)).toLowerCase().includes(q),
      );
    })
    .filter((doc) => {
      if (appliedRangeMin === null && appliedRangeMax === null) return true;
      const val = parseFloat(
        String(registerCellValue(doc, 'amountWithoutVat')).replace(/[^\d.,-]/g, "").replace(",", "."),
      );
      if (isNaN(val)) return false;
      if (appliedRangeMin !== null && val < appliedRangeMin) return false;
      if (appliedRangeMax !== null && val > appliedRangeMax) return false;
      return true;
    });

  const totalDocs = sortedDocs.length;
  const totalPages = Math.max(1, Math.ceil(totalDocs / itemsPerPage));
  const safePage = Math.min(currentPage, totalPages);
  const pageDocs = sortedDocs.slice(0, safePage * itemsPerPage);
  const registerTotals = globalOcrRegister ? documentRegisterTotals(sortedDocs.map(document => document.inlineSource)) : [];

  useEffect(() => setCurrentPage(1), [companyId, companyName, allCompanies, documentTypeFilter, title, selectedPeriod, selectedCurrency, selectedCounterparty, selectedStatus, reversedOnly, dynamicFilters, searchQuery, appliedRangeMin, appliedRangeMax, organizationSelection, archiveOpen]);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (infoRef.current && !infoRef.current.contains(e.target as Node)) {
        setShowInfoPanel(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  function goToPage(page: number) {
    setCurrentPage(Math.max(1, Math.min(totalPages, page)));
  }

  function toggleAll() {
    const pageIds = sortedDocs.map((d) => d.id);
    const allSelected = pageIds.every((id) => selectedIds.has(id));
    const next = new Set(selectedIds);
    if (allSelected) pageIds.forEach((id) => next.delete(id));
    else pageIds.forEach((id) => next.add(id));
    setSelectedIds(next);
  }

  function toggleRow(id: string) {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  }

  function toggleDocumentDetails(id: string) {
    setExpandedDocumentIds((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const viewedCounterparty = viewDoc
    ? counterparties.find(
        (counterparty) =>
          counterparty.id === viewDoc.counterpartyId ||
          counterparty.name.trim().toLocaleLowerCase() ===
            viewDoc.clientCounterparty.trim().toLocaleLowerCase(),
      )
    : undefined;
  const viewedDocumentTotal = viewDoc
    ? documentAmount(viewDoc.totalAmount)
    : 0;
  const activeDocument = openDoc || viewDoc;
  const activeDocumentCompany = documentCompanies.find(item => item.id === activeDocument?.companyId) ?? (globalOcrRegister ? undefined : company);
  const activeCompanyName = activeDocumentCompany?.name || companyName;
  const activeDocumentReadOnly = Boolean(viewDoc) || Boolean(activeDocument && (
    !editableCompanyIds.has(activeDocument.companyId) || documentEditStateError(activeDocument.inlineSource, globalOcrRegister)
    || (initialDocumentMode === 'original-view' && activeDocument.id === entryDocumentIdRef.current)));
  const closeDocument = () => {
    setOpenDoc(null); setViewDoc(null); setViewActionPanel(null);
    if (activeDocument?.id === entryDocumentIdRef.current) { entryDocumentIdRef.current = null; onInitialViewBack?.(); }
  };
  const openHistoryDocument = (document: DbDocument) => {
    setOpenDoc(null); setViewDoc(mapRow(document)); setViewActionPanel(null);
  };
  const openDocumentAction = (document: Document, kind: DocumentManagementActionKind) => {
    if (globalOcrRegister && kind !== 'delete') return;
    if (kind === 'correction' && documentCorrectionKind(document.inlineSource) === 'Credit note') {
      closeDocument();
      setCreditNoteSource({ documentId: document.id, companyId: document.companyId });
    } else setRowActionDocument({ documentId: document.id, companyId: document.companyId, kind });
  };
  const viewActions = viewDoc && !/accounting[\s_-]*note/i.test(viewDoc.documentType) ? <div className="flex flex-wrap items-center gap-2" data-view-allowed="true">
    <PageActionButton onClick={() => setViewActionPanel('send')} icon={<Send size={14} />}>{uiText("Send")}</PageActionButton>
    <PageActionButton onClick={() => setViewActionPanel('preview')} icon={<Eye size={14} />}>{uiText("Preview")}</PageActionButton>
    {!globalOcrRegister && onStartChat && <PageActionButton onClick={() => onStartChat({ storageKey: `${activeCompanyName}:${viewDoc.number || viewDoc.fileCase || 'document'}`,
      title: `${activeCompanyName} / ${viewDoc.number || viewDoc.fileCase || 'Document'}`, companyName: activeCompanyName, organizationId: viewDoc.companyId, subject: viewDoc.number || viewDoc.fileCase || 'Document', sourceType: 'Document' })}>{uiText("Chat")}</PageActionButton>}
  </div> : undefined;

  return (
    <div ref={workspaceRef} className={globalOcrRegister
      ? 'document-register-page global-documents-workspace flex h-dvh min-h-0 min-w-0 flex-col gap-3 overflow-hidden bg-white pb-0'
      : 'flex flex-col gap-8 px-4 sm:px-8 lg:px-[72px] py-14 min-w-0'}>
      {issueError && <div role="alert" className="flex items-center justify-between gap-3 rounded-lg bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{issueError}<button type="button" aria-label={uiText("Dismiss document error")} onClick={() => setIssueError('')}><X size={16} /></button></div>}
      {issueDocument && <DocumentIssueDialog documentId={issueDocument.id} companyId={issueDocument.companyId} onClose={() => setIssueDocument(null)} />}
      {!globalOcrRegister && rowActionDocument?.kind === 'storno' && <DocumentStornoDialog documentId={rowActionDocument.documentId} companyId={rowActionDocument.companyId} onClose={() => { setRowActionDocument(null); void fetchDocs(false); }} />}
      {rowActionDocument && rowActionDocument.kind !== 'storno' && <DocumentRowActionDialog documentId={rowActionDocument.documentId} companyId={rowActionDocument.companyId} mode={rowActionDocument.kind}
        retainedInList={globalOcrRegister}
        onClose={() => setRowActionDocument(null)}
        onDeleted={id => { if (activeDocument?.id === id) closeDocument(); setSelectedIds(previous => { const next = new Set(previous); next.delete(id); return next; }); void fetchDocs(false); }}
        onUpdated={document => { setViewDoc(null); setOpenDoc(mapRow(document)); void fetchDocs(false); }}
        onCreated={document => { setViewDoc(null); setOpenDoc(mapRow(document)); void fetchDocs(false); }} />}
      {/* Title row */}
      <PageHeader
        title={uiText(archiveOpen ? 'Document archive' : title)}
        className="lg:flex-nowrap lg:gap-2"
        actions={
          editOnlyActions ? undefined : (
            <div className="flex flex-nowrap items-center gap-1">
              {documentTypeFilter === 'invoice' && canCreateInvoice && <PageActionButton className="!px-1" onClick={startCreateInvoice} icon={<Plus size={14} />}>{uiText("Create invoice")}</PageActionButton>}
              {!globalOcrRegister && <div className="flex flex-row items-center gap-1.5">
                <div className="relative" ref={infoRef}>
                  <button
                    type="button"
                    aria-label={uiText("Document upload information")}
                    aria-expanded={showInfoPanel}
                    onClick={() => setShowInfoPanel((v) => !v)}
                    className="flex items-center justify-center"
                  >
                    <Info
                      size={24}
                      className={`flex-shrink-0 transition-colors ${showInfoPanel ? "text-[#007EA7]" : "text-[#A1B6C6] hover:text-[#007EA7]"}`}
                    />
                  </button>
                  {showInfoPanel && (
                    <div
                      className="absolute right-0 top-full mt-2 z-50 flex flex-col items-end"
                      style={{ filter: "drop-shadow(2px 0px 16px #E3EEFF)" }}
                    >
                      {/* Arrow */}
                      <div
                        className="mr-[4px] w-0 h-0"
                        style={{
                          borderLeft: "7px solid transparent",
                          borderRight: "7px solid transparent",
                          borderBottom: "8px solid #ffffff",
                        }}
                      />
                      {/* Panel */}
                      <div className="w-[min(706px,calc(100vw-32px))] max-h-[calc(100vh-140px)] overflow-y-auto bg-white rounded-3xl p-6 flex flex-col gap-4 font-montserrat text-[14px] leading-5 text-[#10233A]">
                        <p>{uiText("Upload one or multiple documents by drag & drop or by selecting files.")}</p>
                        <ul className="list-disc space-y-3 pl-5">
                          <li>{uiText("Documents for different organizations can be uploaded together - the system will identify and assign them during processing.")}</li>
                          <li>{uiText("You can also send documents to the email address shown above.")}</li>
                          <li>{uiText("After upload, documents are sent for processing and their status can be followed in Uploaded documents.")}</li>
                          <li><strong className="font-semibold">{uiText("On the company Dashboard or All documents, press Alt + P (Option ⌥ + P on Mac) while no text field is focused to open the ADDINFO form and manually enter additional information.")}</strong></li>
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              </div>}
            </div>
          )
        }
      />
      {companyId && companyName && (
        <CompanyBreadcrumb companyName={companyName} items={[documentTypeFilter === 'invoice' ? 'Invoices' : 'Documents']} />
      )}
      {allCompanies && (
        <SystemBreadcrumb items={['All Documents', title, ...(archiveOpen ? ['Document archive'] : [])]} />
      )}
      {!allCompanies && <DocumentIssueReceipts key={companyId} companyId={companyId} />}

      <div className={globalOcrRegister ? 'global-documents-layout grid min-h-0 flex-1 grid-cols-1 grid-rows-[auto_auto_minmax(0,1fr)] gap-3 lg:grid-cols-[224px_minmax(0,1fr)] lg:grid-rows-[auto_minmax(0,1fr)]' : 'contents'}>
        {globalOcrRegister && <OrganizationSidebar organizations={organizationDirectory} clientIds={organizationClientIds} singleOrAll
          integrated
          allOrganizationsSelected={organizationSelection === null}
          headerActions={<button type="button" aria-label={uiText(archiveOpen ? 'Back to documents' : 'Document archive')}
            title={uiText(archiveOpen ? 'Back to documents' : 'Document archive')} aria-pressed={archiveOpen}
            disabled={transferBusy || detailedDigitizationBusy}
            className={`flex h-7 w-7 shrink-0 items-center justify-center rounded border transition-colors disabled:cursor-not-allowed disabled:opacity-40 ${archiveOpen ? 'border-[#007EA7] bg-[#E5EDF9] text-[#007EA7]' : 'border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]'}`}
            onClick={() => { setShowArchive(value => !value); setSelectedIds(new Set()); setCurrentPage(1); }}><Archive size={15} /></button>}
          includeNoBuyer={showNoBuyer} noBuyerCount={registerDocs.filter(document => !document.companyId).length}
          onOpenSettings={organization => setSettingsOrganizationId(organization.id)}
          selectedIds={[...selectedOrganizationIds, ...(showNoBuyer && (organizationSelection === null || organizationSelection.includes(NO_BUYER_FILTER)) ? [NO_BUYER_FILTER] : [])]}
          onChange={ids => {
            setOrganizationSelection(ids.length === 1 ? ids : null);
            setDynamicFilters(previous => { const { organization: _organization, ...rest } = previous; return rest; });
          }} />}
      {!hideRowActions && !editOnlyActions && <div data-document-selection-toolbar className={`flex shrink-0 items-center justify-between gap-3 ${globalOcrRegister ? 'row-start-1 h-8 min-h-8 flex-nowrap overflow-x-auto overflow-y-hidden lg:col-span-2' : 'flex-wrap'}`}>
        {!globalOcrRegister && <span className="font-montserrat text-[12px] text-[#7288A3]">{selectedIds.size ? `${selectedIds.size} selected` : uiText('Select documents')}</span>}
        <div data-document-register-actions className={`flex items-center gap-3 ${globalOcrRegister ? 'ml-auto shrink-0 flex-nowrap justify-end' : 'flex-wrap'}`}>
          {globalOcrRegister && <span aria-hidden={selectedIds.size === 0} className={selectedIds.size === 0 ? 'invisible pointer-events-none' : ''}><PageActionButton
            disabled={selectedIds.size === 0 || transferBusy || detailedDigitizationBusy} icon={<Pencil size={15} />} ariaHasPopup="dialog"
            onClick={() => setFieldAssignmentIds([...selectedIds])}>{uiText('Assign to documents')}</PageActionButton></span>}
          {globalOcrRegister && !archiveOpen && <PageActionButton disabled={detailedDigitizationBusy || selectedIds.size === 0}
            icon={detailedDigitizationBusy ? <Loader2 size={15} className="animate-spin" /> : <ScanLine size={15} />}
            onClick={() => void digitizeSelectedInDetail()}>{uiText(detailedDigitizationBusy ? 'Returning to OCR…' : 'Digitize in detail')}</PageActionButton>}
          {!globalOcrRegister && <PageActionButton disabled={selectedIds.size === 0 || !editableCompanyIds.has(selectionCompanyId)} icon={<Check size={15} />} onClick={() => setAdvanceAssignmentIds([...selectedIds])}>{uiText('Assign advance employee')}</PageActionButton>}
          {!companyDocumentRegister && !archiveOpen && <PageActionButton disabled={transferBusy || selectedIds.size === 0 || !editableCompanyIds.has(selectionCompanyId)} icon={transferBusy ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />} onClick={() => void sendDocuments([...selectedIds], primaryDestination?.value)}>{`Send to ${primaryDestination?.label || 'accounting'}`}</PageActionButton>}
        </div>
      </div>}
        <div className={globalOcrRegister ? 'row-start-3 flex min-h-0 min-w-0 flex-col gap-3 lg:col-start-2 lg:row-start-2' : 'contents'}>
      {transferNotice && <div role={transferNotice.error ? 'alert' : 'status'} className={`flex shrink-0 items-start gap-2 rounded-lg border px-3 py-2 font-montserrat text-[12px] ${transferNotice.error ? 'border-[#E8D3AC] bg-[#FFF9EE] text-[#926317]' : 'border-[#D3E1EC] bg-[#F2F7FC] text-[#007EA7]'}`}>
        {transferNotice.error ? <AlertCircle size={16} className="mt-0.5 shrink-0" /> : <Info size={16} className="mt-0.5 shrink-0" />}
        <span className="min-w-0 flex-1">{transferNotice.message}</span>
        <button type="button" aria-label={uiText("Dismiss transfer result")} onClick={() => setTransferNotice(null)} className="flex h-5 w-5 shrink-0 items-center justify-center rounded hover:bg-[#E5EDF9]"><X size={14} /></button>
      </div>}

      {/* Filter bar */}
      <div className="flex flex-row items-end gap-4 flex-wrap">
        <div
          data-native-system-filters="true"
          className={`flex flex-row items-center gap-1 flex-wrap ${hideRowActions ? "min-w-0 flex-1" : ""}`}
        >
          {/* Period dropdown */}
          {activePrimaryFilterKeys.includes("period") && (
            <div ref={periodRef}>
              <SystemDocumentFilterDropdown
                label={uiText("Period")}
                value={selectedPeriod ?? ""}
                displayValue={selectedPeriod ? formatPeriod(selectedPeriod) : ""}
                options={availablePeriods.map((period) => ({
                  value: period,
                  label: formatPeriod(period),
                }))}
                open={showPeriodMenu}
                onOpenChange={setShowPeriodMenu}
                onChange={(value) => {
                  setSelectedPeriod(value || null);
                  setCurrentPage(1);
                }}
              />
            </div>
          )}
          {/* Counterparty filter */}
          {activePrimaryFilterKeys.includes("clientCounterparty") && (
            <div ref={counterpartyRef}>
              <SystemDocumentFilterDropdown
                label={uiText("Counterparty")}
                value={selectedCounterparty ?? ""}
                options={Array.from(
                  new Set(
                    docs.map((document) => document.clientCounterparty).filter(Boolean),
                  ),
                )
                  .sort()
                  .map((counterparty) => ({
                    value: counterparty,
                    label: counterparty,
                  }))}
                open={showCounterpartyMenu}
                onOpenChange={setShowCounterpartyMenu}
                onChange={(value) => {
                  setSelectedCounterparty(value || null);
                  setCurrentPage(1);
                }}
              />
            </div>
          )}
          {/* Currency filter */}
          {activePrimaryFilterKeys.includes("currency") && (
            <div ref={currencyRef}>
              <SystemDocumentFilterDropdown
                label={uiText("Currency")}
                value={selectedCurrency ?? ""}
                options={Array.from(
                  new Set(docs.map((document) => document.currency).filter(Boolean)),
                )
                  .sort()
                  .map((currency) => ({ value: currency, label: currency }))}
                open={showCurrencyMenu}
                onOpenChange={setShowCurrencyMenu}
                onChange={(value) => {
                  setSelectedCurrency(value || null);
                  setCurrentPage(1);
                }}
              />
            </div>
          )}
          {/* Range amount filter */}
          {activePrimaryFilterKeys.includes("rangeAmount") && (
          <div className="relative" ref={rangeAmountRef}>
            <button
              type="button"
              aria-label={uiText("Filter by Range amount")}
              aria-expanded={showRangeAmountMenu}
              onClick={() => setShowRangeAmountMenu((v) => !v)}
              className="flex h-7 max-w-[240px] items-center gap-1 rounded bg-[#E5EDF9] px-2 font-montserrat text-[12px] font-medium text-[#7288A3] transition-colors hover:bg-[#DCE7F6]"
            >
              <span className="truncate whitespace-nowrap">{uiText("Range amount")}{appliedRangeMin !== null || appliedRangeMax !== null
                  ? `: ${appliedRangeMin ?? ""}–${appliedRangeMax ?? ""}`
                  : ""}
              </span>
              {appliedRangeMin !== null || appliedRangeMax !== null ? (
                <X
                  size={14}
                  className="flex-shrink-0"
                  onClick={(event) => {
                    event.stopPropagation();
                    setRangeAmountMin("");
                    setRangeAmountMax("");
                    setAppliedRangeMin(null);
                    setAppliedRangeMax(null);
                    setShowRangeAmountMenu(false);
                    setCurrentPage(1);
                  }}
                />
              ) : (
                <ChevronDown
                  size={14}
                  className={`flex-shrink-0 transition-transform ${showRangeAmountMenu ? "rotate-180" : ""}`}
                />
              )}
            </button>
            {showRangeAmountMenu && (
              <DropdownPortal anchorRef={rangeAmountRef} menuRef={rangeAmountMenuRef} width={250} ariaLabel={uiText("Amount range filter")}>
              <div className="min-h-0 overflow-y-auto p-0.5">
                <p className="mb-2 font-montserrat text-[12px] font-semibold text-[#10233A]">{uiText("Amount without VAT range")}</p>
                <div className="flex flex-col gap-2">
                  <div className="flex flex-col gap-0.5">
                    <label className="font-montserrat text-[11px] text-[#7288A3]">{uiText("From")}</label>
                    <input
                      type="number"
                      value={rangeAmountMin}
                      onChange={(e) => setRangeAmountMin(e.target.value)}
                      placeholder={uiText("Min")}
                      className="w-full px-2 py-1.5 border border-[#D3E1EC] rounded text-[13px] font-montserrat text-[#10233A] outline-none focus:border-[#007EA7]"
                    />
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <label className="font-montserrat text-[11px] text-[#7288A3]">{uiText("To")}</label>
                    <input
                      type="number"
                      value={rangeAmountMax}
                      onChange={(e) => setRangeAmountMax(e.target.value)}
                      placeholder={uiText("Max")}
                      className="w-full px-2 py-1.5 border border-[#D3E1EC] rounded text-[13px] font-montserrat text-[#10233A] outline-none focus:border-[#007EA7]"
                    />
                  </div>
                  <div className="flex gap-2 mt-1">
                    <button
                      onClick={() => {
                        setAppliedRangeMin(
                          rangeAmountMin !== ""
                            ? parseFloat(rangeAmountMin)
                            : null,
                        );
                        setAppliedRangeMax(
                          rangeAmountMax !== ""
                            ? parseFloat(rangeAmountMax)
                            : null,
                        );
                        setCurrentPage(1);
                        setShowRangeAmountMenu(false);
                      }}
                      className="h-8 flex-1 rounded-md bg-[#007EA7] px-3 font-montserrat text-[12px] font-semibold text-white hover:bg-[#006D91]"
                    >{uiText("Apply")}</button>
                    {(appliedRangeMin !== null || appliedRangeMax !== null) && (
                      <button
                        onClick={() => {
                          setRangeAmountMin("");
                          setRangeAmountMax("");
                          setAppliedRangeMin(null);
                          setAppliedRangeMax(null);
                          setCurrentPage(1);
                          setShowRangeAmountMenu(false);
                        }}
                        className="h-8 rounded-md border border-[#D3E1EC] px-3 font-montserrat text-[12px] font-semibold text-[#7288A3] hover:bg-[#F8FDFF]"
                      >{uiText("Clear")}</button>
                    )}
                  </div>
                </div>
              </div>
              </DropdownPortal>
            )}
          </div>
          )}
          {/* Status filter */}
          {activePrimaryFilterKeys.includes("status") && (
            <div ref={statusRef}>
              <SystemDocumentFilterDropdown
                label={uiText("Status")}
                value={selectedStatus ?? ""}
                displayValue={globalOcrRegister && selectedStatus ? ocrStatusLabel(selectedStatus, statusText) : undefined}
                translateStatusLabels={!globalOcrRegister}
                options={(globalOcrRegister ? ocrDocumentStatusOptions(registerDocs.map(document => document.inlineSource as unknown as DbDocument), archiveOpen ? undefined : 'Processed') : Array.from(
                  new Set(docs.map((document) => documentProcessingStatus(documentDisplayStatus(document))).filter(Boolean)),
                ))
                  .sort()
                  .map((status) => ({ value: status, label: globalOcrRegister ? ocrStatusLabel(status, statusText) : documentStatusLabel(status) }))}
                open={showStatusMenu}
                onOpenChange={setShowStatusMenu}
                onChange={(value) => {
                  setSelectedStatus(value || null);
                  setCurrentPage(1);
                }}
              />
            </div>
          )}
          <OcrSearchField
            ariaLabel={uiText("Search documents")}
            value={searchQuery}
            onChange={(value) => {
              setSearchQuery(value);
              setCurrentPage(1);
            }}
          />
          {/* Dynamic filter chips */}
          {Object.entries(dynamicFilters).map(([key, val]) => {
            const col = filterableColumns.find((c) => c.key === key);
            if (!col) return null;
            const uniqueVals = Array.from(
              new Set(
                docs
                  .map((d) => String(registerCellValue(d, key as keyof Document) ?? ""))
                  .filter(Boolean),
              ),
            ).sort();
            return (
              <div
                key={key}
                ref={(el) => {
                  dynamicFilterRefs.current[key] = el;
                }}
              >
                <SystemDocumentFilterDropdown
                  label={uiText(col.label)}
                  value={val}
                  options={uniqueVals.map((option) => ({
                    value: option,
                    label: option,
                  }))}
                  open={openDynamicMenu === key}
                  onOpenChange={(open) =>
                    setOpenDynamicMenu(open ? key : null)
                  }
                  onChange={(value) => {
                    setDynamicFilters((current) => ({
                      ...current,
                      [key]: value,
                    }));
                    setCurrentPage(1);
                  }}
                />
              </div>
            );
          })}
          {/* Add filters */}
          <div className="relative" ref={addFilterRef}>
            <button
              type="button"
              aria-label={uiText("Add filters")}
              aria-expanded={showAddFilterMenu}
              onClick={() =>
                setShowAddFilterMenu((v) => {
                  if (!v) setFilterColumnQuery('');
                  if (!v)
                    setPendingDynamicFilterKeys([
                      ...activePrimaryFilterKeys,
                      ...Object.keys(dynamicFilters),
                    ]);
                  return !v;
                })
              }
              className="flex flex-row items-center gap-1 px-2 py-[5px] bg-[#E5EDF9] rounded"
            >
              <Plus size={16} className="text-[#7288A3]" />
              <span className="font-montserrat font-medium text-[12px] leading-[18px] text-[#7288A3]">{uiText("Add filters")}</span>
            </button>
            {showAddFilterMenu && (
              <DropdownPortal anchorRef={addFilterRef} menuRef={addFilterMenuRef} width={300} height={400} role="dialog" ariaLabel={uiText("Add document filters")}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    applyFilterSelection();
                  }
                }}
              >
                <input autoFocus aria-label={uiText("Search available filters")} placeholder={uiText("Search filters")} value={filterColumnQuery} onChange={event => setFilterColumnQuery(event.target.value)} className="mb-1 h-8 w-full shrink-0 rounded-md bg-[#F2F7FC] px-2 font-montserrat text-[12px] text-[#10233A] outline-none placeholder:text-[#7288A3] focus:ring-1 focus:ring-[#007EA7]/20" />
                <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
                  {[...PRIMARY_FILTER_COLUMNS, ...filterableColumns].filter(col => col.label.toLowerCase().includes(filterColumnQuery.trim().toLowerCase())).map((col) => {
                    const checked = pendingDynamicFilterKeys.includes(col.key);
                    return (
                      <button
                        key={col.key}
                        type="button"
                        aria-pressed={checked}
                        data-static-selection="true"
                        onClick={() => {
                          setPendingDynamicFilterKeys((current) =>
                            checked
                              ? current.filter((key) => key !== col.key)
                              : [...current, col.key],
                          );
                        }}
                        className={`grid h-9 w-full grid-cols-[18px_minmax(0,1fr)] items-center gap-3 rounded-md px-2 text-left font-montserrat font-medium text-[13px] text-[#10233A] ${checked ? 'bg-[#E5EDF9]' : 'hover:bg-[#F0F7FA]'}`}
                      >
                        <span
                          aria-hidden="true"
                          className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${checked ? "border-[#007EA7] bg-[#007EA7]" : "border-[#A1B6C6] bg-white"}`}
                        >
                          {checked && (
                            <Check
                              size={12}
                              strokeWidth={2.5}
                              className="text-white"
                            />
                          )}
                        </span>
                        <span className="truncate">{uiText(col.label)}</span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-1 flex shrink-0 items-center justify-between border-t border-[#E5EDF9] px-2 pt-2">
                  <span className="font-montserrat text-[11px] text-[#7288A3]">{uiText("Enter to apply")}</span>
                  <button
                    type="button"
                    onClick={applyFilterSelection}
                    className="h-8 rounded-md bg-[#007EA7] px-3 font-montserrat text-[12px] font-semibold text-white hover:bg-[#006D91]"
                  >{uiText("Apply")}</button>
                </div>
              </DropdownPortal>
            )}
          </div>
          <button
            type="button"
            onClick={() => {
              setSearchQuery("");
              if (globalOcrRegister) setOrganizationSelection(null);
              setActivePrimaryFilterKeys([]);
              setDynamicFilters({});
              setPendingDynamicFilterKeys([]);
              setSelectedPeriod(null);
              setSelectedCounterparty(null);
              setSelectedCurrency(null);
              setSelectedStatus(null);
              setReversedOnly(false);
              setRangeAmountMin("");
              setRangeAmountMax("");
              setAppliedRangeMin(null);
              setAppliedRangeMax(null);
              setShowAddFilterMenu(false);
              setOpenDynamicMenu(null);
              setShowRangeAmountMenu(false);
              setCurrentPage(1);
            }}
            className="flex h-7 flex-shrink-0 items-center gap-1 whitespace-nowrap rounded bg-[#E5EDF9] px-2 py-[5px] font-montserrat text-[12px] font-medium leading-[18px] text-[#7288A3] hover:bg-[#DCE7F6]"
          >
            <X size={15} />
            <span>{uiText("Clear filters")}</span>
          </button>
          {!globalOcrRegister && !editOnlyActions && <button type="button" aria-label={uiText("Show reversed documents")} aria-pressed={reversedOnly} data-static-selection="true"
            onClick={toggleReversedDocuments}
            className={`flex h-7 shrink-0 items-center gap-1.5 whitespace-nowrap rounded border px-2 font-montserrat text-[12px] font-medium transition-colors ${reversedOnly ? 'border-[#007EA7] bg-[#E5EDF9] text-[#007EA7]' : 'border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]'}`}>
            <Undo2 size={14} /><span>{uiText("Reversed")}</span><span className="tabular-nums">{docs.filter(document => document.storno).length}</span>
          </button>}
        </div>
        <div className="ml-auto flex h-7 flex-row items-center gap-4 rounded bg-white">
          <ColumnSettingsButton onClick={() => setShowColumnPanel((v) => !v)} />
          {globalOcrRegister && <WorkspaceExpandButton expanded={workspaceExpanded} onClick={() => setWorkspaceExpanded(value => !value)} />}
          <button
            type="button"
            data-button-family="export"
            data-export-icon="download"
            aria-label={uiText("Export selected documents")}
            title={uiText("Export selected documents")}
            aria-haspopup="dialog"
            disabled={selectedIds.size === 0}
            onClick={() => setDelivery({ mode: 'export', ids: [...selectedIds] })}
            className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] disabled:cursor-not-allowed disabled:text-[#B4B6B8]"
          >
            <Download size={16} strokeWidth={1.8} />
          </button>
          {!allCompanies && !hideRowActions && !editOnlyActions && <button type="button" data-button-family="import" aria-label={uiText("Import documents")} title={uiText("Import documents")} aria-haspopup="dialog" aria-expanded={showUploadPanel} disabled={!editableCompanyIds.has(companyId)} onClick={() => setShowUploadPanel(true)} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] disabled:cursor-not-allowed disabled:text-[#B4B6B8]"><Upload size={16} strokeWidth={1.8} /></button>}
          <RefreshAllButton onRefresh={() => { void fetchDocs(); }} />
        </div>
      </div>

      {/* Table */}
      <div
        ref={tableRef}
        className={globalOcrRegister ? 'flex min-h-0 flex-1 flex-col gap-0 overflow-auto scrollbar-hide' : 'flex flex-col gap-0 overflow-x-auto scrollbar-hide'}
      >
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <svg
              className="animate-spin h-6 w-6 text-[#007EA7]"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
                fill="none"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
              />
            </svg>
          </div>
        ) : (
          <>
            {/* Column headers */}
            <div className={hideRowActions ? "mb-3 flex h-6 min-w-max items-center" : "mb-1 flex min-w-max flex-row items-center gap-0 py-0 pr-2"}>
              <div data-table-header-select="true" className="flex flex-shrink-0 self-start items-center pl-3" style={{ width: globalOcrRegister ? 90 : 42 }}>
                <input
                  type="checkbox"
                  checked={
                    sortedDocs.length > 0 &&
                    sortedDocs.every((d) => selectedIds.has(d.id))
                  }
                  onChange={toggleAll}
                  className="w-[18px] h-[18px] rounded border border-[#A1B6C6] accent-[#007EA7] cursor-pointer"
                />
              </div>
              {visibleColumns.map((col, visibleIndex) => {
                const colIdx = activeColumns.findIndex(
                  (c) => c.key === col.key,
                );
                return (
                  <div
                    key={col.key}
                    className={hideRowActions ? `relative flex flex-shrink-0 items-center gap-1 px-3 ${visibleIndex ? "border-l border-[#D3E1EC]" : ""}` : showExpandableDetails && visibleIndex === 0 ? "relative flex flex-shrink-0 items-center px-3" : "flex flex-row items-center flex-shrink-0"}
                    style={hideRowActions || (showExpandableDetails && visibleIndex === 0) ? { width: col.width } : undefined}
                  >
                    <div
                      style={hideRowActions || (showExpandableDetails && visibleIndex === 0) ? undefined : { width: col.width, position: "relative" }}
                      className="flex min-w-0 items-center gap-1"
                    >
                      <span
                        className={`font-montserrat font-medium text-[12px] leading-[18px] truncate ${directionFor(col.key) ? "text-[#10233A]" : "text-[#7288A3]"}`}
                      >
                        {uiText(col.label)}
                      </span>
                      <ColumnSortButton
                        columnLabel={uiText(col.label)}
                        direction={directionFor(col.key)}
                        onDirectionChange={(direction) => {
                          changeSort(col.key, direction);
                          setCurrentPage(1);
                        }}
                      />
                      <ResizeHandle
                        onMouseDown={(e) => startResize(colIdx, e)}
                      />
                    </div>
                  </div>
                );
              })}
              {!hideRowActions && (
                <div
                  className="system-table-row-actions flex-shrink-0"
                  style={{ width: rowActionsWidth }}
                />
              )}
            </div>

            {/* Rows */}
            <div className="flex flex-col gap-0 min-w-max">
              {reversedOnly && pageDocs.length === 0 && <p role="status" className="sticky left-0 px-4 py-12 text-center font-montserrat text-sm text-[#7288A3]">{uiText("No reversed documents match the current filters.")}</p>}
              {pageDocs.map((doc, i) => {
                const source = globalOcrRegister ? uploadedDocumentSource(doc.inlineSource as unknown as DbDocument, uiText) : null;
                const isSelected = selectedIds.has(doc.id);
                const missingAccountingFields = globalOcrRegister ? missingDocumentAccountingFields(doc.inlineSource, accountingRequirements.get(doc.companyId)) : new Set<string>();
                const isEven = i % 2 === 0;
                const contextAction = rowActions.get(doc.id);
                const deleted = Boolean(doc.inlineSource.document_deletion);
                const deliveryWarning = globalOcrRegister ? documentDeliveryWarning(doc.inlineSource) : null;
                const policy = periodPolicies.get(doc.companyId);
                const lateSubmission = globalOcrRegister && policy ? lateDocumentSubmission(doc.inlineSource, policy) : null;
                const quantityCount = documentQuantityLineCount(doc.inlineSource);
                const globalDeleteReason = contextAction?.kind === 'delete'
                  ? contextAction.disabledReason : 'Confirmed documents cannot be deleted.';
                return (
                  <Fragment key={doc.id}>
                    <div
                      data-record-inactive={deleted || undefined}
                      className={`${hideRowActions ? "group flex h-10 items-center rounded-lg" : "group flex flex-row items-center gap-0 rounded-lg pr-2"} transition-colors ${
                        isSelected
                          ? "bg-[#EEF6FA]"
                          : isEven
                            ? "bg-[#F8FDFF]"
                            : "bg-white"
                      } hover:bg-[#EEF6FA]`}
                    >
                      <div data-document-selection-cell className="flex flex-shrink-0 items-center gap-1 py-[9px] pl-3" style={{ width: globalOcrRegister ? 90 : 42 }}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleRow(doc.id)}
                          className="w-[18px] h-[18px] rounded border border-[#A1B6C6] accent-[#007EA7] cursor-pointer"
                        />
                        {globalOcrRegister && <span className="flex h-5 w-12 shrink-0 items-center gap-1">
                          <span className="flex h-5 w-5 items-center justify-center" data-receipt-indicator-slot>
                            {documentHasReceipt(doc.inlineSource) && <span role="img" tabIndex={0} aria-label={uiText('With receipt · Paid')} title={uiText('With receipt · Paid')} className="text-[#32966E]"><ReceiptText size={16} aria-hidden="true" /></span>}
                          </span>
                          <span className="flex h-5 w-5 items-center justify-center" data-delivery-error-slot>
                            {deliveryWarning && <DocumentWarningIndicator error message={`${uiText('Transfer failed')} · ${deliveryWarning.destination}: ${uiText(deliveryWarning.reason)}`} />}
                          </span>
                        </span>}
                      </div>
                      {visibleColumns.map((col, visibleIndex) => (
                        <div
                          key={col.key}
                          className={hideRowActions ? "flex-shrink-0 overflow-hidden px-3" : showExpandableDetails && visibleIndex === 0 ? "flex flex-shrink-0 items-center px-3" : "flex flex-row items-center flex-shrink-0"}
                          style={hideRowActions || (showExpandableDetails && visibleIndex === 0) ? { width: col.width } : undefined}
                        >
                          {showExpandableDetails && visibleIndex === 0 && doc.hasProductDetails && (
                            <button
                              type="button"
                              title={expandedDocumentIds.has(doc.id) ? uiText("Collapse document details") : uiText("Expand document details")}
                              aria-label={`${expandedDocumentIds.has(doc.id) ? "Collapse" : "Expand"} document details ${doc.fileCase}`}
                              aria-expanded={expandedDocumentIds.has(doc.id)}
                              onClick={() => toggleDocumentDetails(doc.id)}
                              className="-ml-2 mr-1 flex h-6 w-6 flex-shrink-0 items-center justify-center rounded text-[#8AA0B8] transition-colors hover:bg-[#EAF4F8] hover:text-[#007EA7]"
                            >
                              {globalOcrRegister && quantityCount > 1 ? <ListTree size={16} strokeWidth={1.8} data-quantity-lines-indicator aria-label={`${uiText('Quantity lines')}: ${quantityCount}`} /> : <ChevronRight
                                size={15}
                                strokeWidth={1.8}
                                className={`transition-transform ${expandedDocumentIds.has(doc.id) ? "rotate-90" : ""}`}
                              />}
                            </button>
                          )}
                          <div
                            style={hideRowActions || (showExpandableDetails && visibleIndex === 0) ? undefined : { width: col.width }}
                            className={`relative ${hideRowActions ? "min-w-0" : showExpandableDetails && visibleIndex === 0 ? "min-w-0 flex-1 py-[9px]" : "py-[9px]"}`}
                          >
                            {col.key === "status" ? (
                              globalOcrRegister ? (
                                <OcrDocumentStatusCell {...ocrDocumentStatusPresentation(doc.inlineSource as unknown as DbDocument, statusDescriptions)}
                                  status={documentDisplayStatus(doc)} documentName={doc.fileCase || doc.number || doc.id}
                                  onOpen={() => setStatusDetailsId(doc.id)} />
                              ) : hideRowActions ? (
                                <span title={doc.processingDetail ? statusText(doc.processingDetail) : undefined} className="flex min-w-0 items-center gap-2 font-montserrat text-[12px] font-normal leading-[18px] text-[#10233A]">
                                  <span
                                    className="h-1.5 w-1.5 flex-shrink-0 rounded-full"
                                    style={{ background: ({ Processing: '#007EA7', Processed: '#32966E', 'Needs attention': '#D99420' } as Record<string, string>)[documentDisplayStatus(doc)] || STATUS_COLORS[documentDisplayStatus(doc)] || '#A1B6C6' }}
                                  />
                                  <span className="min-w-0"><span className="block truncate">{statusText(documentStatusLabel(documentDisplayStatus(doc)) || '—')}</span>
                                    </span>
                                </span>
                              ) : (
                              <div className="relative">
                                <button
                                  type="button"
                                  aria-label={`Status for ${doc.number || doc.id}`}
                                  aria-haspopup="listbox"
                                  aria-expanded={statusDropdownDocId === doc.id}
                                  title={doc.storno ? `Reversed on ${doc.storno.date} · ${doc.storno.number}. The original operation is preserved.` : documentEditStateError(doc.inlineSource) || uiText('Change document status')}
                                  disabled={Boolean(doc.storno) || !editableCompanyIds.has(doc.companyId)}
                                  data-static-selection="true"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    statusDropdownRef.current = e.currentTarget;
                                    setStatusDropdownDocId((prev) =>
                                      prev === doc.id ? null : doc.id,
                                    );
                                  }}
                                  className="flex flex-row items-center gap-1 hover:opacity-75 transition-opacity"
                                >
                                  <div
                                    className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                                    style={{
                                      background: STATUS_COLORS[documentDisplayStatus(doc)] ?? '#A1B6C6',
                                    }}
                                  />
                                  <span className="font-montserrat font-normal text-[12px] leading-[18px] text-[#10233A]">
                                    {statusText(documentStatusLabel(documentDisplayStatus(doc)) || '—')}
                                  </span>
                                  {!doc.storno && editableCompanyIds.has(doc.companyId) && <ChevronDown size={12} className="shrink-0 text-[#007EA7]" />}
                                </button>
                                {statusDropdownDocId === doc.id && (
                                  <DropdownPortal anchorRef={statusDropdownRef} menuRef={statusDropdownMenuRef} width={230} height={360}
                                    role="listbox"
                                    ariaLabel={uiText("Document status options")}
                                  >
                                    <div className="min-h-0 overflow-y-auto overscroll-contain">
                                    {documentStatusOptions().map(({ value: s, label }) => (
                                      <button
                                        key={s}
                                        type="button"
                                        role="option"
                                        aria-selected={doc.status === s}
                                        disabled={hasBlockingDocumentIssue({ status: doc.status, digitization_issues: doc.digitizationIssues }) && isApprovedDocumentStatus(s)}
                                        title={hasBlockingDocumentIssue({ status: doc.status, digitization_issues: doc.digitizationIssues }) && isApprovedDocumentStatus(s) ? uiText('Resolve the reported issue first') : undefined}
                                        data-static-selection="true"
                                        onClick={() =>
                                          handleStatusChange(doc, s)
                                        }
                                        className={`grid h-9 w-full grid-cols-[18px_minmax(0,1fr)] items-center gap-3 rounded-md px-2 font-montserrat text-[12px] text-left text-[#10233A] disabled:cursor-not-allowed disabled:opacity-40 ${doc.status === s ? "bg-[#E5EDF9]" : "hover:bg-[#F0F7FA]"}`}
                                      >
                                        <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${doc.status === s ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6] bg-white'}`}>
                                          {doc.status === s && <Check size={12} strokeWidth={2.5} className="text-white" />}
                                        </span>
                                        <span className="flex min-w-0 items-center gap-2"><span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: STATUS_COLORS[s] }} /><span className="truncate">{statusText(label)}</span></span>
                                      </button>
                                    ))}
                                    </div>
                                  </DropdownPortal>
                                )}
                              </div>
                              )
                            ) : globalOcrRegister && ['amountWithoutVat', 'vat', 'totalAmount'].includes(col.key) ? (
                              <span data-ocr-original-amount className="block truncate font-montserrat text-[12px] font-normal leading-[18px] tabular-nums text-[#10233A]">{String(doc[col.key as keyof Document] ?? '')}</span>
                            ) : !globalOcrRegister && doc.storno && (col.key === 'totalAmount' || col.key === 'amountWithoutVat' || col.key === 'vat') && doc.storno.amounts[col.key] ? (
                              <div className="min-w-0 font-montserrat text-[12px] leading-[18px]" title={`${doc.storno.number} · ${doc.storno.date}`}>
                                <span className="block truncate font-medium tabular-nums text-[#007EA7]">{doc.storno.amounts[col.key]!.reversed}</span>
                                {!globalOcrRegister && <span className="block truncate text-[10px] tabular-nums text-[#7288A3]">{uiText("Original: ")}{doc.storno.amounts[col.key]!.original}</span>}
                              </div>
                            ) : col.key === 'issueStatus' ? (
                              <button type="button" aria-label={`Issue history for ${doc.number || doc.fileCase}`} onClick={() => setIssueDocument(doc)}><DocumentIssueBadge status={documentIssueStatus({ digitization_issues: doc.digitizationIssues })} /></button>
                            ) : col.key === "fileCase" ? (
                              <a
                                href="#"
                                className="font-montserrat font-normal text-[12px] leading-[18px] text-[#007EA7] underline block truncate"
                              >
                                {doc[col.key as keyof Document] as string}
                              </a>
                            ) : col.key === 'source' && source ? (
                              <div data-document-source-cell className="flex min-w-0 flex-col items-start gap-0.5 pr-3">
                                <span className="block max-w-full truncate font-montserrat text-[12px] font-medium leading-[18px] text-[#10233A]" title={uiText(source.type)}>{uiText(source.type)}</span>
                                <span data-document-source-detail className="block max-w-full truncate font-montserrat text-[11px] font-normal leading-[16px] text-[#7288A3]" title={source.detail} aria-label={`${uiText('Source details')}: ${source.detail}`}>
                                  {source.detail}
                                </span>
                              </div>
                            ) : col.key === 'documentDate' && globalOcrRegister ? (
                              <div className="flex min-w-0 items-center gap-1 pr-2 font-montserrat text-[12px] font-normal text-[#10233A]">
                                {deliveryWarning?.periodLocked && <DocumentWarningIndicator error message={`${uiText('Accounting period unavailable')} · ${deliveryWarning.destination}: ${uiText(deliveryWarning.reason)}`} />}
                                <span className="min-w-0 truncate" title={doc.documentDate}>{doc.documentDate || '—'}</span>
                                {lateSubmission && <span className="ml-auto inline-flex shrink-0"><DocumentWarningIndicator message={`${uiText('Late invoice')} · ${uiText('Submission deadline')}: ${lateSubmission.deadline}`} /></span>}
                              </div>
                            ) : col.key === "number" ? (
                              <span className="flex min-w-0 items-center gap-1 pr-2">
                              <span className="min-w-0 flex-1 font-montserrat font-normal text-[12px] leading-[18px] text-[#10233A] block truncate" title={doc.number || undefined}>
                                {doc.number || "—"}
                              </span>
                              {globalOcrRegister && duplicateIds.has(doc.id) && <DocumentWarningIndicator message={`${uiText('Another document with this number already exists in this organization.')} ${doc.number}`} />}
                              </span>
                            ) : col.key === "clientCounterparty" ? (
                              <div data-document-counterparty-cell className="flex min-w-0 items-center gap-1 pr-2">
                                <span className="min-w-0 flex-1 truncate font-montserrat text-[12px] font-normal leading-[18px] text-[#10233A]" title={doc.clientCounterparty || undefined}>
                                  {doc.clientCounterparty || "—"}
                                </span>
                                {globalOcrRegister && <span className="flex h-5 w-5 shrink-0 items-center" data-document-indicator-slots>
                                  <span className="flex h-5 w-5 shrink-0 items-center justify-center" data-sale-indicator-slot>
                                    {documentIsSale(doc.inlineSource) && <span role="img" tabIndex={0} aria-label={uiText('Sale document')} data-tooltip={uiText('Sale document')}
                                      className="inline-flex h-5 w-5 items-center justify-center rounded text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]">
                                      <DollarSign size={16} aria-hidden="true" className="shrink-0" />
                                    </span>}
                                  </span>
                                </span>}
                              </div>
                            ) : col.key === "counterpartyCode" ? (
                              <span className="block truncate font-montserrat text-[12px] font-normal leading-[18px] text-[#10233A]">
                                {doc.counterpartyCode || "—"}
                              </span>
                            ) : col.key === 'documentType' ? (
                              <DocumentInlineSelectCell framed={globalOcrRegister} value={globalOcrRegister ? documentTypeCatalogSelection(doc.inlineSource, documentTypeRecords) : doc.documentType} label={uiText(col.label)}
                                options={localizedDocumentTypeOptions} localizeOptions={globalOcrRegister} disabledReason={inlineError(doc, col.key)}
                                onSave={value => updateDocField(doc.id, globalOcrRegister ? 'documentClassification' : col.key, value)} />
                            ) : col.key === 'purposeCode' ? (
                              <DocumentInlineSelectCell framed={globalOcrRegister} value={doc.purposeCode || ''} label={uiText(col.label)}
                                options={purposeOptions} localizeOptions disabledReason={inlineError(doc, col.key)}
                                onSave={value => updateDocField(doc.id, col.key, value)} />
                            ) : col.key === 'accountableResponsible' ? (
                              <DocumentInlineSelectCell framed={globalOcrRegister} value={documentResponsibleSelection(doc.inlineSource, responsibleUsers)}
                                requiredLabel={missingAccountingFields.has(col.key) ? uiText(col.label) : undefined}
                                storedLabel={doc.accountableResponsible} label={uiText(col.label)} options={responsibleOptions}
                                disabledReason={inlineError(doc, col.key)}
                                onSave={value => updateDocField(doc.id, col.key, value)} />
                            ) : ['note', 'documentPurpose', 'orderNo', 'type'].includes(col.key) ? (
                              <DocumentInlineTextCell framed={globalOcrRegister} value={String(documentCellValue(doc, col.key as keyof Document) ?? '')}
                                requiredLabel={missingAccountingFields.has(col.key) ? uiText(col.label) : undefined}
                                label={uiText(col.label)} disabledReason={inlineError(doc, col.key)}
                                onSave={value => updateDocField(doc.id, col.key, value)} />
                            ) : LOOKUP_COL_MAP[col.key as keyof Document] ? (
                              <span title={inlineError(doc, col.key)} className="block">
                              <LookupCellDropdown
                                docId={doc.id}
                                companyId={doc.companyId}
                                generalLedgerName={documentCompanies.find(item => item.id === doc.companyId)?.general_ledger ?? generalLedgerName}
                                colKey={col.key}
                                value={String(
                                  documentCellValue(
                                    doc,
                                    col.key as keyof Document,
                                  ) ?? "",
                                )}
                                lookupType={
                                  LOOKUP_COL_MAP[col.key as keyof Document]!
                                }
                                width={col.width}
                                onSave={updateDocField}
                                tableSelect
                                framed={globalOcrRegister}
                                requiredLabel={missingAccountingFields.has(col.key) ? uiText(col.label) : undefined}
                                disabled={Boolean(inlineError(doc, col.key))}
                                onOpenGeneralLedger={onOpenGeneralLedger}
                              />
                              </span>
                            ) : (
                              <span className="font-montserrat font-normal text-[12px] leading-[18px] text-[#10233A] block truncate">
                                {String(
                                  documentCellValue(
                                    doc,
                                    col.key as keyof Document,
                                  ) ?? "",
                                )}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                      {hideRowActions ? null : archiveOpen ? (
                        <div data-document-archive-actions className="system-table-row-actions flex flex-shrink-0 items-center justify-end" style={{ width: rowActionsWidth }}>
                          <button type="button" title={uiText('Report issue')} aria-label={`${uiText('Report issue')}: ${doc.fileCase || doc.number}`}
                            disabled={deleted} onClick={() => setIssueDocument(doc)}
                            className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40">
                            <AlertCircle size={14} />
                          </button>
                        </div>
                      ) : editOnlyActions ? (
                        <div className="system-table-row-actions flex w-[74px] flex-shrink-0 items-center justify-end gap-1">
                          <button
                            type="button"
                            title={uiText("EDIT")}
                            aria-label={`EDIT ${doc.fileCase}`}
                            onClick={() => {
                              setViewDoc(null);
                              setOpenDoc(doc);
                            }}
                            className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7]"
                          >
                            <Pencil size={14} />
                          </button>
                          <button
                            type="button"
                            title={uiText("VIEW")}
                            aria-label={`VIEW ${doc.fileCase}`}
                            onClick={() => {
                              setOpenDoc(null);
                              setViewDoc(doc);
                            }}
                            className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7]"
                          >
                            <Eye size={14} />
                          </button>
                        </div>
                      ) : (
                        <div className="system-table-row-actions flex flex-shrink-0 flex-row items-center justify-end gap-1" style={{ width: rowActionsWidth }}>
                          {!companyDocumentRegister && !globalOcrRegister && <button type="button" title={uiText("Report issue")} aria-label={`Report issue for ${doc.fileCase || doc.number}`} disabled={deleted} onClick={() => setIssueDocument(doc)} className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40"><AlertCircle size={14} /></button>}
                          <button
                            type="button"
                            title={uiText("EDIT")}
                            aria-label={`EDIT ${doc.fileCase}`}
                            disabled={deleted}
                            onClick={() => {
                              setViewDoc(null);
                              setOpenDoc(doc);
                            }}
                            className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40"
                          >
                            <Pencil size={14} />
                          </button>
                          {!globalOcrRegister && <><button
                            type="button"
                            title={uiText("VIEW")}
                            aria-label={`VIEW ${doc.fileCase}`}
                            onClick={() => {
                              setOpenDoc(null);
                              setViewDoc(doc);
                            }}
                            className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7]"
                          >
                            <Eye size={14} />
                          </button>
                          {canCopyInvoiceDocument(doc.inlineSource) && <button
                            type="button"
                            title={uiText("COPY")}
                            aria-label={`COPY ${doc.fileCase || doc.number || doc.id}`}
                            disabled={!creatableCompanyIds.has(doc.companyId)}
                            onClick={() => setDuplicateSource(doc)}
                            className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40"
                          >
                            <Copy size={14} />
                          </button>}</>}
                          {globalOcrRegister && deleted && <DocumentRestoreButton
                            document={doc.inlineSource as unknown as DbDocument}
                            allowed={restorableCompanyIds.has(doc.companyId)}
                            onRestored={() => { setIssueError(''); void fetchDocs(false); }}
                            onError={setIssueError}
                          />}
                          {!companyDocumentRegister && !globalOcrRegister && <button type="button" title={`Send to ${primaryDocumentDeliveryDestination(documentCompanies.find(item => item.id === doc.companyId))?.label || 'accounting'}`} aria-label={`Send ${doc.fileCase || doc.number || doc.id} to accounting`} disabled={deleted || transferBusy || !editableCompanyIds.has(doc.companyId)} onClick={() => void sendDocuments([doc.id], primaryDocumentDeliveryDestination(documentCompanies.find(item => item.id === doc.companyId))?.value)} className={`flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white ${doc.testDeliveries?.length ? 'text-[#007EA7]' : 'text-[#7288A3]'} transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:border-[#E5EDF9] disabled:text-[#B4B6B8]`}><Send size={14} /></button>}
                          {globalOcrRegister && <DocumentRegisterActionsMenu
                            documentLabel={doc.fileCase || doc.number || doc.id} disabled={deleted}
                            canEdit={editableCompanyIds.has(doc.companyId) && !documentEditStateError(doc.inlineSource, globalOcrRegister)}
                            excluded={Boolean(doc.inlineSource.excluded_from_export)} exported={doc.inlineSource.manual_export_status === 'Exported'}
                            issueBlocksExport={hasBlockingDocumentIssue(doc.inlineSource)}
                            onReportIssue={() => setIssueDocument(doc)} onError={setIssueError}
                            onExportAction={async action => {
                              await assignDocumentFields([doc.id], { other: action }, { [doc.id]: documentAssignmentSnapshot(doc.inlineSource) });
                              setTransferNotice({ error: false, message: uiText(action === 'exclude' ? 'Document excluded from export.' : 'Document marked as exported.') });
                              await fetchDocs(false);
                            }}
                          />}
                          {!globalOcrRegister && contextAction && !(companyDocumentRegister && contextAction.kind === 'delete') && (contextAction.kind !== 'storno' || !contextAction.disabledReason) && <span title={contextAction.disabledReason ? `${contextAction.label}: ${contextAction.disabledReason}` : contextAction.label} className="inline-flex h-7 w-7 shrink-0">
                            <button type="button" data-document-context-action={contextAction.kind}
                              aria-label={`${contextAction.label} ${doc.number || doc.fileCase}`} aria-haspopup="dialog"
                              disabled={!canOpenDocumentRowAction(contextAction)}
                              onClick={() => openDocumentAction(doc, contextAction.kind)}
                              className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:border-[#E5EDF9] disabled:text-[#B4B6B8]">
                              {contextAction.kind === 'delete' ? <Trash2 size={14} aria-hidden="true" />
                                : contextAction.kind === 'storno' ? <Undo2 size={14} aria-hidden="true" />
                                  : contextAction.label === 'Create debit note' ? <FilePlus2 size={14} aria-hidden="true" />
                                    : <FileMinus2 size={14} aria-hidden="true" />}
                            </button>
                          </span>}
                          {companyDocumentRegister && <span title={uiText(globalDeleteReason || 'Delete')} className="inline-flex h-7 w-7 shrink-0">
                            <button type="button" data-document-context-action="delete"
                              aria-label={`${uiText('Delete')} ${doc.number || doc.fileCase}`} aria-haspopup="dialog"
                              disabled={deleted || Boolean(globalDeleteReason)}
                              onClick={() => openDocumentAction(doc, 'delete')}
                              className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:border-[#E5EDF9] disabled:text-[#B4B6B8]">
                              <Trash2 size={14} aria-hidden="true" />
                            </button>
                          </span>}
                        </div>
                      )}
                    </div>
                    {showExpandableDetails &&
                      doc.hasProductDetails &&
                      expandedDocumentIds.has(doc.id) && (
                        <ExpandedDocumentLines
                          document={doc}
                          parentColumns={visibleColumns}
                          generalLedgerName={documentCompanies.find(item => item.id === doc.companyId)?.general_ledger ?? generalLedgerName}
                          onOpenGeneralLedger={onOpenGeneralLedger}
                        />
                      )}
                  </Fragment>
                );
              })}
            </div>
          </>
        )}
      </div>

      <HorizontalTableScrollbar scrollRef={tableRef} expandable={!globalOcrRegister} fixed={!globalOcrRegister} />

      {/* Accumulated row count and automatic loading */}
      {!globalOcrRegister && <div className="flex flex-row items-center justify-between mt-2">
        <TablePagination
          scrollRef={tableRef}
          currentPage={safePage}
          totalPages={totalPages}
          itemCount={totalDocs}
          itemsPerPage={itemsPerPage}
          onPageChange={goToPage}
        />
      </div>}

        </div>
      </div>
      {globalOcrRegister && <div data-document-register-footer className="-mx-4 -mt-3 flex h-7 min-h-7 shrink-0 items-center gap-3 border-t border-[#E5EDF9] bg-white px-3 sm:-mx-8 lg:-mx-[56px]">
        <div data-document-totals className="flex min-w-0 flex-1 flex-nowrap items-center gap-5 overflow-x-auto whitespace-nowrap font-montserrat text-[10px] leading-[22px] text-[#7288A3] [scrollbar-width:thin]">
          {registerTotals.map(total => <span className="shrink-0" key={`${total.direction}:${total.currency}`}>
            {uiText(total.direction === 'Sale' ? 'Sales total' : 'Purchases total')} ({total.count}): <span className="font-medium tabular-nums text-[#10233A]">{(total.total / 100).toFixed(2)} {total.currency}</span> ({uiText('Excl. VAT')}: <span className="tabular-nums">{(total.net / 100).toFixed(2)}</span>)
          </span>)}
        </div>
        <div className="shrink-0"><TablePagination fixed={false} className="!h-6 [&_[role=status]]:!h-6 [&_span]:!text-[10px]" scrollRef={tableRef}
          currentPage={safePage} totalPages={totalPages} itemCount={totalDocs} itemsPerPage={itemsPerPage} onPageChange={goToPage} /></div>
      </div>}
      {/* Column settings overlay + panel */}
      {showColumnPanel && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setShowColumnPanel(false)}
          />
          <ColumnSettingsPanel
            columns={activeColumns}
            defaultColumns={globalOcrRegister ? defaultColumns : undefined}
            onSave={(cols) => setActiveColumns(cols)}
            onClose={() => setShowColumnPanel(false)}
          />
        </>
      )}

      {/* Upload document panel */}
      {showUploadPanel && createPortal(
        <>
          <div
            className="fixed inset-0 z-[5000] bg-black/10"
            onClick={() => setShowUploadPanel(false)}
          />
          <div
            ref={uploadPanelRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label={uiText("Upload new file")}
            onKeyDown={event => { if (event.key === 'Escape') { event.stopPropagation(); setShowUploadPanel(false); } }}
            className="fixed top-0 right-0 h-full max-w-full z-[5001] flex flex-col bg-white overflow-y-auto"
            style={{
              width: 340,
              boxShadow: "-2px 0px 0px #E5EDF9",
              padding: "24px 24px 32px",
              gap: 24,
              display: "flex",
            }}
          >
            {/* Header */}
            <div className="flex flex-row justify-between items-center gap-2 flex-shrink-0">
              <div className="flex flex-row items-center gap-1">
                <span className="font-montserrat font-semibold text-[22px] leading-8 text-[#10233A]">{uiText("Upload new file")}</span>
                <AlertCircle
                  size={24}
                  className="text-[#A1B6C6] flex-shrink-0"
                />
              </div>
              <button type="button" aria-label={uiText("Close document import")} onClick={() => setShowUploadPanel(false)}>
                <X
                  size={24}
                  className="text-[#7288A3] hover:text-[#10233A] transition-colors"
                />
              </button>
            </div>

            {/* Body */}
            <div className="flex flex-col gap-8 flex-1">
              {/* Drop zone */}
              <div
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(false);
                  const files = Array.from(e.dataTransfer.files);
                  if (files.length)
                    setUploadFiles((prev) => [...prev, ...files]);
                }}
                className="flex flex-col items-center justify-center gap-6 rounded-lg cursor-pointer transition-colors"
                style={{
                  padding: 32,
                  border: `1px dashed ${dragOver ? "#007EA7" : "#7288A3"}`,
                  background: dragOver ? "#F0F9FF" : "#FFFFFF",
                  minHeight: 164,
                }}
              >
                <Upload size={28} className="text-[#7288A3] flex-shrink-0" />
                <span className="font-montserrat font-medium italic text-[16px] leading-6 text-[#7288A3] text-center">
                  {uploadFiles.length > 0
                    ? uploadFiles.map((f) => f.name).join(", ")
                    : uiText("Click to browse files or drag & drop files here")}
                </span>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => {
                  const files = Array.from(e.target.files ?? []);
                  if (files.length)
                    setUploadFiles((prev) => [...prev, ...files]);
                  e.target.value = "";
                }}
              />

              {/* Selects */}
              <div className="flex flex-col gap-6">
                {/* Document type */}
                <div className="flex flex-col gap-2">
                  <span className="font-montserrat font-semibold text-[14px] leading-5 text-[#10233A]">{uiText("Document type")}</span>
                  <div className="flex flex-row justify-between items-center px-[14px] py-[11px] border border-[#D3E1EC] rounded-lg bg-white cursor-pointer">
                    <span
                      className={`font-montserrat font-medium text-[14px] leading-5 ${uploadDocType ? "text-[#10233A]" : "text-[#A1B6C6]"}`}
                    >
                      {uploadDocType || uiText("Select document type")}
                    </span>
                    <ChevronDown
                      size={16}
                      className="text-[#7288A3] flex-shrink-0"
                    />
                  </div>
                </div>

                {/* Company */}
                <div className="flex flex-col gap-2">
                  <span className="font-montserrat font-semibold text-[14px] leading-5 text-[#10233A]">{uiText("Company")}</span>
                  <div className="flex flex-row justify-between items-center px-[14px] py-[11px] border border-[#D3E1EC] rounded-lg bg-white cursor-pointer">
                    <span
                      className={`font-montserrat font-medium text-[14px] leading-5 ${uploadCompany ? "text-[#10233A]" : "text-[#A1B6C6]"}`}
                    >
                      {uploadCompany || uiText("Select company")}
                    </span>
                    <ChevronDown
                      size={16}
                      className="text-[#7288A3] flex-shrink-0"
                    />
                  </div>
                </div>

                {/* Date period */}
                <div className="flex flex-col gap-2">
                  <span className="font-montserrat font-semibold text-[14px] leading-5 text-[#10233A]">{uiText("Operation type")}</span>
                  <div className="flex flex-row justify-between items-center px-[14px] py-[11px] border border-[#D3E1EC] rounded-lg bg-white cursor-pointer">
                    <span
                      className={`font-montserrat font-medium text-[14px] leading-5 ${uploadDatePeriod ? "text-[#10233A]" : "text-[#A1B6C6]"}`}
                    >
                      {uploadDatePeriod || uiText("Select operation type")}
                    </span>
                    <ChevronDown
                      size={16}
                      className="text-[#7288A3] flex-shrink-0"
                    />
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-4 mt-auto">
                <button
                  disabled={uploadFiles.length === 0}
                  className="flex flex-row justify-center items-center px-4 py-[9px] rounded-lg font-montserrat font-semibold text-[16px] leading-6 transition-colors"
                  style={{
                    background: uploadFiles.length > 0 ? "#007EA7" : "#F5F5F5",
                    color: uploadFiles.length > 0 ? "#FFFFFF" : "#B4B6B8",
                  }}
                >{uiText("Upload document")}</button>
                <button
                  onClick={() => setShowUploadPanel(false)}
                  className="flex flex-row justify-center items-center px-4 py-[9px] rounded-lg font-montserrat font-semibold text-[16px] leading-6 border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#7288A3] transition-colors"
                >{uiText("Cancel")}</button>
              </div>
            </div>
          </div>
        </>, document.body
      )}
      {approvedEditDialog}
      {activeDocument && openDoc && !activeDocument.companyId && canAssignOrganization && !documentEditStateError(activeDocument.inlineSource) ? (
        <DocumentOrganizationAssignment key={activeDocument.id} document={activeDocument.inlineSource as unknown as DbDocument}
          organizations={documentCompanies.filter(item => editableCompanyIds.has(item.id))}
          onClose={closeDocument} onAssigned={() => { closeDocument(); void fetchDocs(false); }} />
      ) : activeDocument && !globalOcrRegister && usesManualInvoiceForm(activeDocument.inlineSource) ? (
        <CreateInvoiceForm key={`${activeDocument.id}:${activeDocumentReadOnly ? 'view' : 'edit'}:${activeDocument.status}`}
          companyId={activeDocument.companyId} companyName={activeCompanyName} sectionName={title}
          documentId={activeDocument.id} mode={activeDocumentReadOnly ? 'view' : 'edit'} documentActions={viewActions}
          onOpenRelatedDocument={openHistoryDocument}
          documentManagementActions={!globalOcrRegister && !hideRowActions && !editOnlyActions ? state => (
            <DocumentActionsMenu documentId={activeDocument.id} companyId={activeDocument.companyId} {...state}
              onDuplicate={record => { closeDocument(); setDuplicateSource(mapRow(record)); }}
              onAction={kind => openDocumentAction(activeDocument, kind)} />
          ) : undefined}
          onClose={closeDocument} onCreated={() => { void fetchDocs(false); }} />
      ) : activeDocument ? (
        <DocumentDetailPanel
          key={`${activeDocument.id}:${activeDocument.companyId}:${activeDocumentReadOnly ? 'view' : 'edit'}:${activeDocument.status}`}
          ocrRegister={globalOcrRegister}
          onRegisterExported={action => {
            const patch = action === 'exclude' ? { excluded_from_export: true } : { manual_export_status: 'Exported' };
            setOpenDoc(previous => previous?.id === activeDocument.id ? { ...previous, inlineSource: { ...previous.inlineSource, ...patch } } : previous);
            void fetchDocs(false);
          }}
          onDetailedDigitization={() => {
            setTransferNotice({ error: false, message: uiText('Document returned to OCR for detailed digitization.') });
            void fetchDocs(false);
          }}
          allowStorno={!globalOcrRegister && Boolean(activeDocument.companyId)}
          readOnly={activeDocumentReadOnly}
          doc={activeDocument}
          onOpenRelatedDocument={openHistoryDocument}
          documentActions={viewActions}
          documentManagementActions={!globalOcrRegister && !hideRowActions && !editOnlyActions ? state => (
            <DocumentActionsMenu documentId={activeDocument.id} companyId={activeDocument.companyId} {...state}
              onDuplicate={record => { closeDocument(); setDuplicateSource(mapRow(record)); }}
              onAction={kind => openDocumentAction(activeDocument, kind)} />
          ) : undefined}
          companyName={activeCompanyName}
          generalLedgerName={activeDocumentCompany?.general_ledger ?? generalLedgerName}
          onOpenGeneralLedger={onOpenGeneralLedger}
          onClose={closeDocument}
          onImageUpload={(docId, imageUrl) => {
            setDocs((prev) =>
              prev.map((d) => (d.id === docId ? { ...d, imageUrl } : d)),
            );
            setOpenDoc((prev) =>
              prev && prev.id === docId ? { ...prev, imageUrl } : prev,
            );
          }}
          onSaved={(docId, values, savedDocument) => {
            void fetchDocs(false);
            const savedValues = { ...values, ...mapRow(savedDocument) };
            setDocs((prev) =>
              prev.map((d) => (d.id === docId ? { ...d, ...savedValues } : d)),
            );
            setOpenDoc((prev) =>
              prev && prev.id === docId ? { ...prev, ...savedValues } : prev,
            );
          }}
        />
      ) : null}

      {viewDoc && viewActionPanel === "preview" && createPortal(<div className="fixed inset-0 z-[5400]">
        <InvoicePaymentPreviewPanel
          invoiceNumber={viewDoc.number || viewDoc.fileCase || "Document"}
          total={viewedDocumentTotal}
          currency={viewDoc.currency || "EUR"}
          onClose={() => setViewActionPanel(null)}
        />
      </div>, document.body)}

      {viewDoc && viewActionPanel === "send" && createPortal(<div className="fixed inset-0 z-[5400]">
        <SendInvoicePanel
          invoice={{
            id: viewDoc.id,
            number: viewDoc.number || viewDoc.fileCase || "Document",
            buyer: viewDoc.clientCounterparty,
            totalAmount: viewedDocumentTotal,
            currency: viewDoc.currency || "EUR",
          }}
          organizationId={viewDoc.companyId}
          senderName={activeCompanyName}
          senderEmail={activeDocumentCompany?.email}
          senderDetails={{
            name: activeCompanyName,
            companyCode: activeDocumentCompany?.company_code,
            vatCode: activeDocumentCompany?.vat_code,
            address: activeDocumentCompany?.address,
            email: activeDocumentCompany?.email,
            phone: activeDocumentCompany?.phone,
          }}
          recipientName={
            viewedCounterparty?.name || viewDoc.clientCounterparty
          }
          recipientEmail={viewedCounterparty?.email || ""}
          recipientDetails={{
            name: viewedCounterparty?.name || viewDoc.clientCounterparty,
            companyCode:
              viewedCounterparty?.company_code || viewDoc.counterpartyCode,
            vatCode: viewedCounterparty?.vat_code,
            address: viewedCounterparty?.address,
            email: viewedCounterparty?.email,
            phone: viewedCounterparty?.phone,
          }}
          reconciliationDate={new Date().toISOString().slice(0, 10)}
          onClose={() => setViewActionPanel(null)}
        />
      </div>, document.body)}

      {delivery && <DocumentDeliveryDialog mode={delivery.mode} ids={delivery.ids} loadRecords={() => loadDeliveryRecords(delivery)} onExport={exportSelectedDocuments} onTestTransfer={testSelectedDocuments} onSaveDestination={saveDeliveryDestination} onClose={() => setDelivery(null)} />}
      {advanceAssignmentIds && <AssignAdvanceEmployeeDialog companyId={selectionCompanyId} ids={advanceAssignmentIds} onClose={() => setAdvanceAssignmentIds(null)} onSaved={() => { void fetchDocs(false); setTransferNotice({ error: false, message: uiText('Advance employee assigned. Original GL entries remain unchanged.') }); }} />}

      {globalOcrRegister && fieldAssignmentIds && <DocumentBulkAssignmentDialog ids={fieldAssignmentIds}
        onClose={() => setFieldAssignmentIds(null)} onSaved={count => {
          void fetchDocs(false);
          setTransferNotice({ error: false, message: `${uiText('Document fields updated:')} ${count}` });
        }} />}
      {statusDetailsDocument && <OcrDocumentStatusPanel document={statusDetailsDocument.inlineSource as unknown as DbDocument}
        organizationName={statusDetailsDocument.organization} descriptions={statusDescriptions} displayDetail
        onClose={() => setStatusDetailsId(null)} />}
      {globalOcrRegister && settingsOrganization && <OrganizationDirectorySettings entry={settingsOrganization}
        onClose={() => setSettingsOrganizationId(null)} onUpdated={updated => {
          setDocumentCompanies(current => current.some(item => item.id === updated.id)
            ? current.map(item => item.id === updated.id ? updated : item) : [...current, updated]);
          setOrganizationSelection(current => current?.map(id => id === settingsOrganization.id ? updated.id : id) ?? null);
          setSettingsOrganizationId(updated.id);
          void fetchDocs(false);
        }} />}
      {!globalOcrRegister && showCreateCompanyPicker && <GlJournalDialog title="Create invoice" onClose={() => setShowCreateCompanyPicker(false)}
        footer={<><PageActionButton onClick={() => setShowCreateCompanyPicker(false)}>{uiText('Cancel')}</PageActionButton>
          <PageActionButton disabled={!creatableCompanyIds.has(createCompanyId)} onClick={() => { setShowCreateCompanyPicker(false); setShowCreateInvoice(true); }}>{uiText('Continue')}</PageActionButton></>}>
        <div className="flex flex-col gap-2"><span className="text-[14px] font-medium text-[#7288A3]">{uiText('Organization')} *</span>
          <SearchableSelect ariaLabel={uiText('Organization')} value={createCompanyId} onChange={setCreateCompanyId} portalMenu
            options={documentCompanies.filter(item => creatableCompanyIds.has(item.id)).map(item => ({ value: item.id, label: item.name }))} />
        </div>
      </GlJournalDialog>}
      {!globalOcrRegister && showCreateInvoice && <CreateInvoiceForm companyId={createCompanyId} companyName={documentCompanies.find(item => item.id === createCompanyId)?.name || companyName} onClose={() => setShowCreateInvoice(false)} onCreated={() => { void fetchDocs(false); }} />}

      {!globalOcrRegister && duplicateSource && <CreateInvoiceForm key={`copy:${duplicateSource.id}`}
        companyId={duplicateSource.companyId}
        companyName={documentCompanies.find(item => item.id === duplicateSource.companyId)?.name || companyName}
        sectionName={title} copySourceDocumentId={duplicateSource.id}
        onClose={() => setDuplicateSource(null)} onCreated={() => { void fetchDocs(false); }} />}
      {!globalOcrRegister && creditNoteSource && <CreateInvoiceForm key={`credit:${creditNoteSource.documentId}`}
        companyId={creditNoteSource.companyId}
        companyName={documentCompanies.find(item => item.id === creditNoteSource.companyId)?.name || companyName}
        sectionName={title} creditNoteSourceDocumentId={creditNoteSource.documentId}
        onClose={() => setCreditNoteSource(null)} onCreated={() => { void fetchDocs(false); }} />}
    </div>
  );
}
