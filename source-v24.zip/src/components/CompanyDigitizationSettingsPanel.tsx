import { translateUi as uiText } from '../i18n/language';
import { PageActionButton } from './PageHeader';
import SearchableSelect from './SearchableSelect';

interface SettingField {
  key: string;
  label: string;
  value: string;
  options?: string[];
}

interface Props {
  fields: SettingField[];
  onChange: (key: string, value: string) => void;
  onSave: () => void;
  onClose?: () => void;
  saving: boolean;
  saved: boolean;
  error: string;
  canSave: boolean;
}

/** Compact presentation of the existing company-scoped digitization settings. */
export default function CompanyDigitizationSettingsPanel({ fields, onChange, onSave, onClose, saving, saved, error, canSave }: Props) {
  return <div className="flex h-full min-h-0 min-w-0 flex-col font-montserrat" data-company-digitization-dialog>
    <div className="min-h-0 flex-1 space-y-5 overflow-y-auto pb-5 pr-1 [scrollbar-gutter:stable]">
    {[
      { title: 'Document processing', fields: fields.filter(field => field.key !== 'primaryExportFormat') },
      { title: 'Export settings', fields: fields.filter(field => field.key === 'primaryExportFormat') },
    ].map(group => <section key={group.title} className="rounded-lg border border-[#D3E1EC]">
      <h3 className="rounded-t-lg border-b border-[#E5EDF9] bg-[#F2F6FA] px-4 py-3 text-[13px] font-semibold text-[#10233A]">{uiText(group.title)}</h3>
      <div className="grid grid-cols-1 gap-x-5 gap-y-4 p-4 sm:grid-cols-2">
        {group.fields.map(field => <div key={field.key} className={`flex min-w-0 flex-col gap-2 ${field.key === 'primaryExportFormat' ? 'sm:col-span-2' : ''}`}>
          <span className="text-[12px] font-medium leading-[18px] text-[#7288A3]">{uiText(field.label)}</span>
          <SearchableSelect value={field.value} options={field.options ?? []} ariaLabel={uiText(field.label)}
            onChange={value => onChange(field.key, value)} disabled={saving || !canSave} portalMenu localizeOptions
            className="h-10 w-full rounded-md border border-[#D3E1EC] bg-white px-3 font-montserrat text-[13px] font-medium text-[#10233A] outline-none focus:border-[#007EA7]" />
        </div>)}
      </div>
    </section>)}
    </div>
    <div className="flex min-h-[60px] shrink-0 flex-wrap items-center justify-end gap-2 border-t border-[#D3E1EC] pt-4">
      <div className="mr-auto text-[12px] leading-5" aria-live="polite">
        {error ? <p role="alert" className="text-[#B42318]">{uiText(error)}</p>
          : saved ? <p role="status" className="text-[#27845E]">{uiText('Changes saved successfully.')}</p> : null}
      </div>
      {onClose && <PageActionButton disabled={saving} onClick={onClose}>{uiText('Close')}</PageActionButton>}
      <PageActionButton disabled={saving || !canSave} onClick={onSave}>{uiText(saving ? 'Saving…' : 'Save changes')}</PageActionButton>
    </div>
  </div>;
}
