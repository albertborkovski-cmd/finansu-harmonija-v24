import { useEffect, useRef, useState } from 'react';
import { ChevronRight, FileText, Pencil, Plus } from 'lucide-react';
import { translateUi as uiText, translateStatus as statusText } from '../i18n/language';
import { OCR_STATUS_CATALOG_GROUPS, ocrStatusRecords, ocrStatusLabel, ocrStatusDescription, saveOcrStatusDescription, createOcrStatus, removeOcrStatus, OCR_STATUS_SETTINGS_CHANGED } from '../lib/ocrStatuses';
import { isOcrStatusLinked } from '../lib/ocrStatusLifecycle';
import { supabase, type DbDocument } from '../lib/supabase';
import { canEditMenu, parseSession } from '../lib/accessControl';
import { AUTH_SESSION_KEY, getCurrentUserIdentity } from '../lib/currentUser';
import { PageHeader, PageActionButton } from './PageHeader';
import { HeaderBackButton } from './SystemNavigation';
import GlJournalDialog from './GlJournalDialog';
import OcrSearchField from './OcrSearchField';
import SystemAddFilters from './SystemAddFilters';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';
import { RowDeleteButton } from './DeleteButtons';

const GROUP_COLUMNS: ColConfig[] = [
  { key: 'status', label: 'Status', width: 285, visible: true },
  { key: 'substatusCount', label: 'Substatuses', width: 160, visible: true },
  { key: 'description', label: 'Description', width: 500, visible: true },
];
const SUBSTATUS_COLUMNS: ColConfig[] = [
  { key: 'status', label: 'Status', width: 285, visible: true },
  { key: 'description', label: 'Description', width: 660, visible: true },
];
const GROUP_DESCRIPTIONS: Record<string, string> = {
  Processing: 'Documents awaiting processing or review.',
  Processed: 'Documents with completed OCR processing.',
  'Needs attention': 'Documents with issues that require attention.',
  'Other statuses': 'Additional states outside automatic processing groups.',
};
type StatusGroup = typeof OCR_STATUS_CATALOG_GROUPS[number]['name'];
type ListFilters = { search: string; keys: string[]; values: Record<string, string[]> };
const EMPTY_FILTERS: ListFilters = { search: '', keys: [], values: {} };
const canEdit = () => {
  const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
  return Boolean(session && canEditMenu(session, 'settings-organizations-document-status'));
};

export default function OcrStatusSettingsView() {
  const [selectedGroup, setSelectedGroup] = useState<StatusGroup | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [creating, setCreating] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [originalName, setOriginalName] = useState('');
  const [removing, setRemoving] = useState<{ status: string; linked: boolean } | null>(null);
  const [busy, setBusy] = useState(false);
  const [documents, setDocuments] = useState<DbDocument[] | null>(null);
  const [, refresh] = useState(0);
  const [listFilters, setListFilters] = useState<Record<string, ListFilters>>({});
  const [groupColumns, setGroupColumns] = useState<ColConfig[]>(GROUP_COLUMNS);
  const [substatusColumns, setSubstatusColumns] = useState<ColConfig[]>(SUBSTATUS_COLUMNS);
  const [showColumns, setShowColumns] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const groupResize = useColumnResize(groupColumns, setGroupColumns, 'ocr-status-groups');
  const substatusResize = useColumnResize(substatusColumns, setSubstatusColumns, 'ocr-status-settings');
  const columns = selectedGroup ? substatusColumns : groupColumns;
  const setColumns = selectedGroup ? setSubstatusColumns : setGroupColumns;
  const { startResize } = selectedGroup ? substatusResize : groupResize;
  const visibleColumns = columns.filter(column => column.visible);
  const statusRecords = ocrStatusRecords();
  const groups = OCR_STATUS_CATALOG_GROUPS.map(group => ({
    id: group.name, status: group.name, label: statusText(group.name), description: GROUP_DESCRIPTIONS[group.name], substatusCount: statusRecords.filter(row => row.group === group.name).length, inactive: false,
  }));
  const substatuses = statusRecords.filter(row => row.group === selectedGroup).map(row => ({
    id: row.status, status: row.status, label: row.displayName ?? statusText(row.status), description: ocrStatusDescription(row.status), substatusCount: 0, inactive: Boolean(row.inactive),
  }));
  const sortValue = (row: typeof groups[number] | typeof substatuses[number], key: string) =>
    key === 'status' ? row.label : key === 'substatusCount' ? row.substatusCount : uiText(row.description);
  const groupSorter = useMultiColumnSort(groups, sortValue);
  const substatusSorter = useMultiColumnSort(substatuses, sortValue);
  const sorter = selectedGroup ? substatusSorter : groupSorter;
  const scope = selectedGroup ?? 'groups';
  const { search, keys: filterKeys, values: filterValues } = listFilters[scope] ?? EMPTY_FILTERS;
  const updateFilters = (patch: Partial<ListFilters>) => setListFilters(current => ({
    ...current, [scope]: { ...(current[scope] ?? EMPTY_FILTERS), ...patch },
  }));
  const rows = selectedGroup ? substatuses : groups;
  const statusFilter = filterKeys.includes('status') ? filterValues.status ?? [] : [];
  const query = search.trim().toLocaleLowerCase();
  const visibleRows = sorter.sortedRows.filter(row => (!statusFilter.length || statusFilter.includes(row.status))
    && (!query || [row.status, row.label, row.description, uiText(row.description),
      ...(!selectedGroup ? statusRecords.filter(item => item.group === row.status).flatMap(({ status, displayName }) => [status, displayName ?? statusText(status), ocrStatusDescription(status), uiText(ocrStatusDescription(status))]) : [])]
      .some(value => value.toLocaleLowerCase().includes(query))));
  const actionWidth = selectedGroup ? 80 : 48;
  const tableWidth = visibleColumns.reduce((sum, column) => sum + column.width, 0) + actionWidth;
  const editable = canEdit();
  const navigate = (group: StatusGroup | null) => {
    setSelectedGroup(group);
    setShowColumns(false);
    scrollRef.current?.scrollTo({ top: 0, left: 0 });
  };
  const editStatus = (status: string, value: string) => {
    if (!canEdit()) return;
    setEditing(status);
    const name = ocrStatusLabel(status, statusText);
    setNewStatus(name);
    setOriginalName(name);
    setDescription(value);
    setError('');
  };
  const linked = (status: string, source = documents) => source === null || isOcrStatusLinked(status, source, localStorage);
  const readDocuments = async () => {
    const result = await supabase.from('documents').select('*');
    if (result.error) throw new Error('Unable to check OCR status usage. Try again.');
    const rows = (result.data ?? []) as unknown as DbDocument[];
    setDocuments(rows);
    return rows;
  };

  useEffect(() => {
    let current = true;
    supabase.from('documents').select('*').then(result => {
      if (current && !result.error) setDocuments((result.data ?? []) as unknown as DbDocument[]);
    }).catch(() => { /* Unknown usage keeps deletion disabled until a fresh check succeeds. */ });
    return () => { current = false; };
  }, []);

  const openRemove = async (status: string) => {
    if (!canEdit() || busy) return;
    setBusy(true); setError('');
    try {
      const fresh = await readDocuments();
      setRemoving({ status, linked: linked(status, fresh) });
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to save.'); }
    finally { setBusy(false); }
  };
  const remove = async () => {
    if (!removing || busy) return;
    setBusy(true); setError('');
    try {
      if (!canEdit()) throw new Error('You do not have permission to edit OCR status settings.');
      const fresh = await readDocuments();
      if (!canEdit()) throw new Error('You do not have permission to edit OCR status settings.');
      const isLinked = linked(removing.status, fresh);
      if (isLinked !== removing.linked) {
        setRemoving({ ...removing, linked: isLinked });
        throw new Error('OCR status usage changed. Review the action and confirm again.');
      }
      removeOcrStatus(removing.status, isLinked, getCurrentUserIdentity().fullName, localStorage);
      window.dispatchEvent(new Event(OCR_STATUS_SETTINGS_CHANGED));
      setRemoving(null);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to save.'); }
    finally { setBusy(false); }
  };

  useEffect(() => {
    const reload = () => refresh(value => value + 1);
    window.addEventListener(OCR_STATUS_SETTINGS_CHANGED, reload);
    window.addEventListener('storage', reload);
    return () => {
      window.removeEventListener(OCR_STATUS_SETTINGS_CHANGED, reload);
      window.removeEventListener('storage', reload);
    };
  }, []);

  const save = () => {
    try {
      if ((!editing && !creating) || !canEdit()) throw new Error('You do not have permission to edit OCR status settings.');
      if (ocrStatusRecords().some(row => row.status !== editing
        && (row.displayName ?? statusText(row.status)).trim().toLocaleLowerCase() === newStatus.trim().toLocaleLowerCase()))
        throw new Error('An OCR status with this name already exists or the name is reserved.');
      if (creating && selectedGroup) createOcrStatus(selectedGroup, newStatus, description, getCurrentUserIdentity().fullName, localStorage);
      else if (editing) saveOcrStatusDescription(editing, description, getCurrentUserIdentity().fullName, localStorage,
        newStatus.trim() === originalName ? undefined : newStatus);
      window.dispatchEvent(new Event(OCR_STATUS_SETTINGS_CHANGED));
      setEditing(null);
      setCreating(false);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to save.'); }
  };

  return <main className="flex h-screen min-w-0 flex-1 flex-col gap-8 overflow-hidden bg-white py-14 font-montserrat"
    style={{ paddingLeft: 'clamp(24px, 5vw, 72px)', paddingRight: 'clamp(24px, 5vw, 72px)' }}>
    <PageHeader title={selectedGroup ? statusText(selectedGroup) : uiText('OCR status')}
      leading={selectedGroup && <HeaderBackButton label="Back to OCR statuses" onClick={() => navigate(null)} />}
      actions={selectedGroup && <PageActionButton icon={<Plus size={16} />} disabled={!editable || busy}
        onClick={() => { setNewStatus(''); setDescription(''); setError(''); setCreating(true); }}>{uiText('Add record')}</PageActionButton>} />
    <nav data-system-breadcrumb aria-label={uiText('Breadcrumb')}
      className="flex min-h-[18px] flex-wrap items-center gap-2 font-montserrat text-[12px] font-medium leading-[18px] text-[#7288A3]">
      <span>{uiText('Settings')}</span><span>/</span><span>{uiText('General settings')}</span><span>/</span><span>{uiText('Status')}</span><span>/</span>
      {selectedGroup ? <>
        <button type="button" onClick={() => navigate(null)} className="hover:text-[#007EA7]">{uiText('OCR status')}</button>
        <span>/</span><span aria-current="page" className="text-[#A1B6C6]">{statusText(selectedGroup)}</span>
      </> : <span aria-current="page" className="text-[#A1B6C6]">{uiText('OCR status')}</span>}
    </nav>

    <div className="flex flex-wrap items-center justify-between gap-4">
      <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1" data-native-system-filters="true">
        <OcrSearchField value={search} onChange={value => updateFilters({ search: value })}
          ariaLabel={uiText(selectedGroup ? 'Search OCR substatuses' : 'Search OCR statuses')}
          className="!w-[260px] !min-w-[260px] !max-w-[260px] !flex-none" />
        <SystemAddFilters key={scope} persistenceKey={`finansu-harmonija:v23:filters:ocr-status-settings:${scope}`}
          columns={[{ key: 'status', label: 'Status', options: rows.map(row => row.status), optionLabels: Object.fromEntries(rows.map(row => [row.status, row.label])) }]}
          activeKeys={filterKeys} values={filterValues} onActiveKeysChange={keys => updateFilters({ keys })}
          onValuesChange={values => updateFilters({ values })} />
      </div>
      <div className="flex items-center gap-4">
        <ColumnSettingsButton onClick={() => setShowColumns(true)} />
        <RefreshAllButton onRefresh={() => refresh(value => value + 1)} />
      </div>
    </div>
    {error && !editing && !creating && !removing && <p role="alert" className="text-[12px] text-[#B42318]">{uiText(error)}</p>}

    <div ref={scrollRef} className="min-h-0 flex-1 overflow-auto scrollbar-hide" data-ocr-status-table>
      <div style={{ minWidth: tableWidth }}>
        <div className="mb-3 flex h-6 items-center">
          {visibleColumns.map(column => <div key={column.key} style={{ width: column.width }}
            className="relative flex h-6 shrink-0 items-center gap-1 border-l border-[#D3E1EC] px-3 text-[12px] font-medium text-[#10233A]">
            <span className="truncate">{uiText(column.label)}</span>
            <ColumnSortButton columnLabel={uiText(column.label)} direction={sorter.directionFor(column.key)}
              onDirectionChange={direction => sorter.changeSort(column.key, direction)} />
            <ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} />
          </div>)}
          <div className="system-table-row-actions h-6 shrink-0" style={{ width: actionWidth }} />
        </div>
        <div className="flex flex-col gap-0.5">
          {visibleRows.map((row, index) => <div key={row.id} data-ocr-status-row={row.status}
                data-record-inactive={row.inactive || undefined}
                onClick={!selectedGroup ? () => navigate(row.status as StatusGroup) : undefined}
                className={`group flex h-10 items-center rounded-lg text-[12px] text-[#10233A] ${!selectedGroup ? 'cursor-pointer' : ''} ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'} hover:bg-[#E7F4F9]`}>
                {visibleColumns.map(column => <div key={column.key} style={{ width: column.width }} className="shrink-0 overflow-hidden px-3">
                  {column.key === 'status' ? selectedGroup ? <span className="block max-w-full truncate font-medium leading-[18px] text-[#10233A]" title={row.label}>
                    {row.label}
                  </span> : <button type="button"
                    aria-label={`${uiText('Open')} · ${statusText(row.status)}`}
                    onClick={event => { event.stopPropagation(); navigate(row.status as StatusGroup); }}
                    className="block max-w-full truncate text-left font-medium leading-[18px] text-[#007EA7] hover:underline focus:underline">
                    {statusText(row.status)}
                  </button> : <span className="block truncate" title={column.key === 'description' ? uiText(row.description) : undefined}>
                    {column.key === 'substatusCount' ? row.substatusCount : uiText(row.description)}
                  </span>}
                </div>)}
                <div onClick={event => event.stopPropagation()} style={{ width: actionWidth }} className="system-table-row-actions flex h-10 shrink-0 items-center justify-end gap-2 pr-2">
                  {selectedGroup ? <><button type="button" aria-label={`${uiText('Edit')} · ${row.label}`} title={uiText('Edit')} disabled={!editable || busy}
                    onClick={() => editStatus(row.status, row.description)}
                    className="flex h-8 w-8 items-center justify-center rounded text-[#7288A3] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40"><Pencil size={16} /></button>
                    <RowDeleteButton variant="plain" label={`Delete ${row.label}`} title={uiText('Delete')}
                      linked={linked(row.status)} inactive={row.inactive} disabled={!editable || busy}
                      onDelete={() => void openRemove(row.status)} /></>
                    : <button type="button" aria-label={`${uiText('Open substatuses')} · ${statusText(row.status)}`}
                      onClick={() => navigate(row.status as StatusGroup)}
                      className="flex h-8 w-8 items-center justify-center rounded text-[#7288A3] hover:text-[#007EA7]"><ChevronRight size={16} /></button>}
                </div>
              </div>)}
          {visibleRows.length === 0 && <div className="flex min-h-[220px] flex-col items-center justify-center gap-3 text-[#7288A3]">
            <FileText size={30} /><span className="text-[13px] font-semibold">{uiText('No records found')}</span>
          </div>}
        </div>
      </div>
    </div>
    <HorizontalTableScrollbar scrollRef={scrollRef} />
    <TablePagination scrollRef={scrollRef} currentPage={1} totalPages={1} itemCount={visibleRows.length} itemsPerPage={50} onPageChange={() => {}} />

    {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={selectedGroup ? SUBSTATUS_COLUMNS : GROUP_COLUMNS}
      onSave={next => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
    {(editing || creating) && <GlJournalDialog title={creating ? 'Add OCR status' : 'Edit OCR status'} subtitle={creating ? statusText(selectedGroup || '') : originalName}
      onClose={() => { setEditing(null); setCreating(false); }} footer={<>
      <PageActionButton onClick={() => { setEditing(null); setCreating(false); }}>{uiText('Cancel')}</PageActionButton>
      <PageActionButton disabled={!description.trim() || !newStatus.trim() || !editable} onClick={save}>{uiText(creating ? 'Create' : 'Save changes')}</PageActionButton>
    </>}>
      <label className="mb-4 flex flex-col gap-2 text-[12px] font-medium text-[#7288A3]">{uiText('Status name')} *
        <input autoFocus value={newStatus} maxLength={100} onChange={event => setNewStatus(event.target.value)}
          className="h-10 w-full rounded-md border border-[#D3E1EC] bg-white px-3 font-montserrat text-[13px] font-normal text-[#10233A] outline-none focus:border-[#007EA7]" />
      </label>
      <label className="flex flex-col gap-2 text-[12px] font-medium text-[#7288A3]">{uiText('Description')}
        <textarea value={description} maxLength={5000} onChange={event => setDescription(event.target.value)} rows={5}
          className="w-full resize-y rounded-md border border-[#D3E1EC] bg-white p-3 text-[13px] font-normal text-[#10233A] outline-none focus:border-[#007EA7]" />
      </label>{error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{uiText(error)}</p>}
    </GlJournalDialog>}
    {removing && <GlJournalDialog title={removing.linked ? 'Deactivate OCR status' : 'Delete OCR status'} subtitle={ocrStatusLabel(removing.status, statusText)}
      onClose={() => { if (!busy) setRemoving(null); }} footer={<>
        <PageActionButton disabled={busy} onClick={() => setRemoving(null)}>{uiText('Cancel')}</PageActionButton>
        <PageActionButton disabled={busy || !editable} onClick={() => void remove()}>{uiText(removing.linked ? 'Deactivate' : 'Delete')}</PageActionButton>
      </>}>
      <p className="text-[13px] leading-6 text-[#10233A]">{uiText(removing.linked
        ? 'This status is used by documents or history. It will remain visible as inactive; existing document states will not change.'
        : 'Delete this unused OCR status from the list? Existing documents and their history will not change.')}</p>
      {error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{uiText(error)}</p>}
    </GlJournalDialog>}
  </main>;
}
