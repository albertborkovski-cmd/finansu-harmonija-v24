import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Expand, Loader2, Maximize2, Minimize2, MoveHorizontal, RotateCcw, RotateCw, Upload, ZoomIn, ZoomOut } from 'lucide-react';
import type { PDFDocumentProxy, PDFPageProxy, RenderTask } from 'pdfjs-dist';
import { translateUi as uiText } from '../i18n/language';
import { clampPreviewZoom, documentPreviewLayout, MAX_PREVIEW_ZOOM, MIN_PREVIEW_ZOOM, rotatePreview, type PreviewFit } from '../lib/documentPreview';
import { PageActionButton } from './PageHeader';

type Props = { url: string; kind: 'pdf' | 'image'; filename: string; onReplace?: () => void; uploading?: boolean; uploadError?: string };

/** Pure viewing controls. Rotation and zoom never update the source document. */
export default function DocumentFileViewer(props: Props) {
  return <FileViewer key={`${props.kind}:${props.url}`} {...props} />;
}

function FileViewer({ url, kind, filename, onReplace, uploading, uploadError }: Props) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [available, setAvailable] = useState({ width: 320, height: 700 });
  const [size, setSize] = useState({ width: 794, height: 1123 });
  const [fit, setFit] = useState<PreviewFit>('width');
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [page, setPage] = useState(1);
  const [pdfPage, setPdfPage] = useState<PDFPageProxy | null>(null);
  const layout = documentPreviewLayout(size, available, rotation, fit, zoom);

  useEffect(() => {
    const element = viewportRef.current;
    if (!element) return;
    const measure = () => setAvailable({ width: element.clientWidth, height: element.clientHeight });
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (kind !== 'pdf') return;
    let cancelled = false;
    let task: ReturnType<typeof import('pdfjs-dist')['getDocument']> | undefined;
    void import('pdfjs-dist').then(async pdfjs => {
      if (cancelled) return;
      pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString();
      task = pdfjs.getDocument(url);
      const document = await task.promise;
      if (!cancelled) setPdf(document);
    }).catch(() => { if (!cancelled) { setError(true); setLoading(false); } });
    return () => { cancelled = true; void task?.destroy().catch(() => undefined); };
  }, [kind, url]);

  useEffect(() => {
    if (!pdf) return;
    let cancelled = false;
    setLoading(true);
    setPdfPage(null);
    setError(false);
    void pdf.getPage(page).then(nextPage => {
      if (cancelled) return;
      const bounds = nextPage.getViewport({ scale: 1 });
      setSize({ width: bounds.width, height: bounds.height });
      setPdfPage(nextPage);
    }).catch(() => { if (!cancelled) { setError(true); setLoading(false); } });
    viewportRef.current?.scrollTo({ top: 0, left: 0 });
    return () => { cancelled = true; };
  }, [pdf, page]);

  useEffect(() => {
    if (!pdfPage || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    if (!context) return;
    const viewport = pdfPage.getViewport({ scale: layout.scale, rotation: (pdfPage.rotate + rotation) % 360 });
    const density = Math.min(window.devicePixelRatio || 1, 2, 8192 / Math.max(viewport.width, viewport.height));
    canvas.width = Math.ceil(viewport.width * density);
    canvas.height = Math.ceil(viewport.height * density);
    let cancelled = false;
    let task: RenderTask | undefined;
    try {
      task = pdfPage.render({ canvasContext: context, viewport, transform: [density, 0, 0, density, 0, 0] });
      void task.promise.then(() => { if (!cancelled) setLoading(false); }).catch(cause => {
        if (!cancelled && cause?.name !== 'RenderingCancelledException') { setError(true); setLoading(false); }
      });
    } catch { setError(true); setLoading(false); }
    return () => { cancelled = true; task?.cancel(); };
  }, [pdfPage, layout.scale, rotation]);

  function changeZoom(direction: -1 | 1) {
    setZoom(clampPreviewZoom(Math.round((layout.scale + direction * 0.1) * 100) / 100));
    setFit('manual');
  }

  const unavailable = loading || error;
  return <aside aria-label={uiText('Document preview')} data-document-viewer className="sticky left-0 top-0 flex h-dvh shrink-0 flex-col self-start border-r border-[#D3E1EC] bg-[#F0F7FA]" style={{ width: expanded ? 'min(65vw, 960px)' : 'clamp(280px, 30vw, 440px)' }}>
    <div className="shrink-0 border-b border-[#D3E1EC] bg-white px-2 py-2">
      <div role="toolbar" aria-label={uiText('Document viewing controls')} className="flex flex-wrap items-center justify-center gap-1">
        <PageActionButton iconOnly icon={<ZoomOut size={16}/>} disabled={unavailable || layout.scale <= MIN_PREVIEW_ZOOM} onClick={() => changeZoom(-1)}>Zoom out</PageActionButton>
        <button type="button" data-tooltip={uiText('Actual size')} aria-label={uiText('Actual size')} disabled={unavailable} onClick={() => { setZoom(1); setFit('manual'); }} className="h-8 w-12 shrink-0 rounded-md font-montserrat text-xs font-semibold tabular-nums text-[#7288A3] hover:bg-[#E5EDF9] disabled:opacity-50"><span aria-live="polite">{Math.round(layout.scale * 100)}%</span></button>
        <PageActionButton iconOnly icon={<ZoomIn size={16}/>} disabled={unavailable || layout.scale >= MAX_PREVIEW_ZOOM} onClick={() => changeZoom(1)}>Zoom in</PageActionButton>
        <PageActionButton iconOnly icon={<MoveHorizontal size={16}/>} disabled={unavailable} onClick={() => setFit('width')}>Fit to width</PageActionButton>
        <PageActionButton iconOnly icon={<Expand size={16}/>} disabled={unavailable} onClick={() => setFit('page')}>Fit whole page</PageActionButton>
        <PageActionButton iconOnly icon={<RotateCcw size={16}/>} disabled={unavailable} onClick={() => setRotation(value => rotatePreview(value, -1))}>Rotate left</PageActionButton>
        <PageActionButton iconOnly icon={<RotateCw size={16}/>} disabled={unavailable} onClick={() => setRotation(value => rotatePreview(value, 1))}>Rotate right</PageActionButton>
        <PageActionButton iconOnly icon={expanded ? <Minimize2 size={16}/> : <Maximize2 size={16}/>} onClick={() => setExpanded(value => !value)}>{expanded ? 'Reduce document preview' : 'Expand document preview'}</PageActionButton>
      </div>
      <div className="mt-2 flex h-8 items-center gap-2">
        <span className="min-w-0 flex-1 truncate font-montserrat text-xs font-medium text-[#7288A3]">{filename}</span>
        {pdf && <div className="flex shrink-0 items-center gap-1">
          <PageActionButton iconOnly icon={<ChevronLeft size={14}/>} disabled={page === 1 || loading} onClick={() => setPage(value => value - 1)}>Previous page</PageActionButton>
          <span aria-label={uiText('Page')} className="font-montserrat text-xs tabular-nums text-[#7288A3]">{page} / {pdf.numPages}</span>
          <PageActionButton iconOnly icon={<ChevronRight size={14}/>} disabled={page === pdf.numPages || loading} onClick={() => setPage(value => value + 1)}>Next page</PageActionButton>
        </div>}
        {onReplace && <PageActionButton iconOnly icon={uploading ? <Loader2 size={16} className="animate-spin"/> : <Upload size={16}/>} disabled={uploading} onClick={onReplace}>Replace image</PageActionButton>}
      </div>
      {uploadError && <p role="alert" className="mt-1 text-xs text-[#D64545]">{uploadError}</p>}
    </div>
    <div ref={viewportRef} tabIndex={0} aria-label={uiText('Document preview area')} data-preview-viewport data-preview-zoom={layout.scale} data-preview-rotation={rotation} className="relative min-h-0 flex-1 overflow-auto overscroll-contain outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#007EA7]">
      {loading && !error && <div role="status" className="absolute inset-x-0 top-8 z-10 flex justify-center"><span className="flex items-center gap-2 rounded-md bg-white px-3 py-2 font-montserrat text-xs text-[#7288A3]"><Loader2 size={16} className="animate-spin"/>{uiText('Loading document…')}</span></div>}
      {error ? <div role="alert" className="p-6 font-montserrat text-sm text-[#7288A3]">{uiText('Document preview could not be loaded.')}<a href={url} target="_blank" rel="noreferrer" className="mt-3 block text-[#007EA7] underline">{uiText('Open original document')}</a></div> :
        <div className="box-content min-w-[calc(100%-32px)] p-4" style={{ width: layout.width }}>
          <div className="relative mx-auto bg-white shadow-sm" style={{ width: layout.width, height: layout.height }}>
            {kind === 'pdf' ? <canvas ref={canvasRef} aria-label={`${filename} · ${uiText('Page')} ${page}`} style={{ width: layout.width, height: layout.height }} /> :
              <img src={url} alt={filename} draggable={false} onLoad={event => { setSize({ width: event.currentTarget.naturalWidth, height: event.currentTarget.naturalHeight }); setLoading(false); }} onError={() => { setError(true); setLoading(false); }} className="absolute left-1/2 top-1/2 max-w-none select-none" style={{ width: size.width * layout.scale, height: size.height * layout.scale, transform: `translate(-50%, -50%) rotate(${rotation}deg)` }} />}
          </div>
        </div>}
    </div>
  </aside>;
}
