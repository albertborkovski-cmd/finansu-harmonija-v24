import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Loader2, Upload } from 'lucide-react';
import type { PDFDocumentProxy, PDFPageProxy, RenderTask } from 'pdfjs-dist';
import { translateUi as uiText } from '../i18n/language';
import { clampPreviewZoom, documentPreviewLayout, rotatePreview, type PreviewFit } from '../lib/documentPreview';
import { PageActionButton } from './PageHeader';
import DocumentPreviewControls from './DocumentPreviewControls';

type Props = { url: string; kind: 'pdf' | 'image'; filename: string; onReplace?: () => void; uploading?: boolean; uploadError?: string; embedded?: boolean };

/** Pure viewing controls. Rotation and zoom never update the source document. */
export default function DocumentFileViewer(props: Props) {
  return <FileViewer key={`${props.kind}:${props.url}`} {...props} />;
}

function FileViewer({ url, kind, filename, onReplace, uploading, uploadError, embedded = false }: Props) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [available, setAvailable] = useState({ width: 320, height: 700 });
  const [size, setSize] = useState({ width: 794, height: 1123 });
  const [fit, setFit] = useState<PreviewFit>('width');
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [page, setPage] = useState(1);
  const [pdfPage, setPdfPage] = useState<PDFPageProxy | null>(null);
  const layout = documentPreviewLayout(size, available, rotation, fit, zoom);

  useEffect(() => {
    if (!embedded || !expanded) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !(event.target instanceof Element && event.target.closest('[role="dialog"]'))) {
        event.preventDefault(); event.stopPropagation(); setExpanded(false);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [embedded, expanded]);

  useEffect(() => {
    const element = viewportRef.current;
    if (!element) return;
    const measure = () => setAvailable({ width: element.clientWidth, height: element.clientHeight });
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (kind !== 'pdf') return;
    let cancelled = false;
    let task: ReturnType<typeof import('pdfjs-dist')['getDocument']> | undefined;
    void import('pdfjs-dist').then(async pdfjs => {
      if (cancelled) return;
      pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString();
      task = pdfjs.getDocument(url);
      const document = await task.promise;
      if (!cancelled) setPdf(document);
    }).catch(() => { if (!cancelled) { setError(true); setLoading(false); } });
    return () => { cancelled = true; void task?.destroy().catch(() => undefined); };
  }, [kind, url]);

  useEffect(() => {
    if (!pdf) return;
    let cancelled = false;
    setLoading(true);
    setPdfPage(null);
    setError(false);
    void pdf.getPage(page).then(nextPage => {
      if (cancelled) return;
      const bounds = nextPage.getViewport({ scale: 1 });
      setSize({ width: bounds.width, height: bounds.height });
      setPdfPage(nextPage);
    }).catch(() => { if (!cancelled) { setError(true); setLoading(false); } });
    viewportRef.current?.scrollTo({ top: 0, left: 0 });
    return () => { cancelled = true; };
  }, [pdf, page]);

  useEffect(() => {
    if (!pdfPage || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    if (!context) return;
    const viewport = pdfPage.getViewport({ scale: layout.scale, rotation: (pdfPage.rotate + rotation) % 360 });
    const density = Math.min(window.devicePixelRatio || 1, 2, 8192 / Math.max(viewport.width, viewport.height));
    canvas.width = Math.ceil(viewport.width * density);
    canvas.height = Math.ceil(viewport.height * density);
    let cancelled = false;
    let task: RenderTask | undefined;
    try {
      task = pdfPage.render({ canvasContext: context, viewport, transform: [density, 0, 0, density, 0, 0] });
      void task.promise.then(() => { if (!cancelled) setLoading(false); }).catch(cause => {
        if (!cancelled && cause?.name !== 'RenderingCancelledException') { setError(true); setLoading(false); }
      });
    } catch { setError(true); setLoading(false); }
    return () => { cancelled = true; task?.cancel(); };
  }, [pdfPage, layout.scale, rotation]);

  function changeZoom(scale: number) {
    setZoom(clampPreviewZoom(scale));
    setFit('manual');
  }

  const unavailable = loading || error;
  return <aside aria-label={uiText('Document preview')} data-document-viewer className={`${embedded ? expanded ? 'fixed inset-4 z-[5000] rounded-xl border shadow-xl' : 'relative h-full min-h-0 w-full' : 'sticky left-0 top-0 h-dvh shrink-0 self-start border-r'} flex flex-col overflow-hidden border-[#D3E1EC] bg-[#F0F7FA]`} style={embedded ? undefined : { width: expanded ? 'min(65vw, 960px)' : 'clamp(280px, 30vw, 440px)' }}>
    <div className="shrink-0 border-b border-[#D3E1EC] bg-white px-2 py-2">
      <DocumentPreviewControls scale={layout.scale} disabled={unavailable} expanded={expanded} onZoom={changeZoom} onFit={setFit} onRotate={direction => setRotation(value => rotatePreview(value, direction))} onExpand={() => setExpanded(value => !value)} />
      <div className="mt-2 flex h-8 items-center gap-2">
        <span className="min-w-0 flex-1 truncate font-montserrat text-xs font-medium text-[#7288A3]">{filename}</span>
        {pdf && <div className="flex shrink-0 items-center gap-1">
          <PageActionButton iconOnly icon={<ChevronLeft size={14}/>} disabled={page === 1 || loading} onClick={() => setPage(value => value - 1)}>Previous page</PageActionButton>
          <span aria-label={uiText('Page')} className="font-montserrat text-xs tabular-nums text-[#7288A3]">{page} / {pdf.numPages}</span>
          <PageActionButton iconOnly icon={<ChevronRight size={14}/>} disabled={page === pdf.numPages || loading} onClick={() => setPage(value => value + 1)}>Next page</PageActionButton>
        </div>}
        {onReplace && <PageActionButton iconOnly icon={uploading ? <Loader2 size={16} className="animate-spin"/> : <Upload size={16}/>} disabled={uploading} onClick={onReplace}>Replace image</PageActionButton>}
      </div>
      {uploadError && <p role="alert" className="mt-1 text-xs text-[#D64545]">{uploadError}</p>}
    </div>
    <div ref={viewportRef} tabIndex={0} aria-label={uiText('Document preview area')} data-preview-viewport data-preview-zoom={layout.scale} data-preview-rotation={rotation} className="relative min-h-0 flex-1 overflow-auto overscroll-contain outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#007EA7]">
      {loading && !error && <div role="status" className="absolute inset-x-0 top-8 z-10 flex justify-center"><span className="flex items-center gap-2 rounded-md bg-white px-3 py-2 font-montserrat text-xs text-[#7288A3]"><Loader2 size={16} className="animate-spin"/>{uiText('Loading document…')}</span></div>}
      {error ? <div role="alert" className="p-6 font-montserrat text-sm text-[#7288A3]">{uiText('Document preview could not be loaded.')}<a href={url} target="_blank" rel="noreferrer" className="mt-3 block text-[#007EA7] underline">{uiText('Open original document')}</a></div> :
        <div className="box-content min-w-[calc(100%-32px)] p-4" style={{ width: layout.width }}>
          <div className="relative mx-auto bg-white shadow-sm" style={{ width: layout.width, height: layout.height }}>
            {kind === 'pdf' ? <canvas ref={canvasRef} aria-label={`${filename} · ${uiText('Page')} ${page}`} style={{ width: layout.width, height: layout.height }} /> :
              <img src={url} alt={filename} draggable={false} onLoad={event => { setSize({ width: event.currentTarget.naturalWidth, height: event.currentTarget.naturalHeight }); setLoading(false); }} onError={() => { setError(true); setLoading(false); }} className="absolute left-1/2 top-1/2 max-w-none select-none" style={{ width: size.width * layout.scale, height: size.height * layout.scale, transform: `translate(-50%, -50%) rotate(${rotation}deg)` }} />}
          </div>
        </div>}
    </div>
  </aside>;
}
