import { translateUi as uiText } from '../i18n/language';
import { useEffect, useState } from "react";
import { GLOBAL_DOCUMENT_MENU_ITEMS, isGlobalDocumentsMenu } from '../lib/globalDocumentNavigation';
import { workspaceMenuVisible, type WorkspaceMode } from '../lib/workspaceMode';
import {
  User,
  Menu,
  LogOut,
  Home,
  MessageSquare,
  ListTodo,
  Settings,
  FolderOpen,
  ChevronDown,
  ScanText,
  Monitor,
  BrainCircuit,
  UserCheck,
  LayoutDashboard,
  BarChart3,
  ArrowLeft,
  ClipboardCheck,
  FileUp,
  Layers3,
} from "lucide-react";

interface SidebarProps {
  notificationCount?: number;
  isExpanded: boolean;
  onToggle: () => void;
  activeMenu: string;
  onMenuClick: (menu: string) => void;
  clientName: string;
  onLogout: () => void;
  visibleMainMenuIds: string[];
  canViewMenu: (menu: string) => boolean;
  workspaceMode?: WorkspaceMode;
}

interface SubMenuItem {
  id: string;
  label: string;
}

const mainMenuItems = [
  { id: "global-dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "uploaded-documents", label: "All Documents", icon: FileUp, hasDropdown: true },
  { id: "dashboard", label: "Companies", icon: Home },
  { id: "messages", label: "Chats", icon: MessageSquare },
  { id: "notifications", label: "Tasks", icon: ListTodo },
  { id: "settings", label: "Settings", icon: Settings, hasDropdown: true },
  { id: 'saas', label: 'SaaS', icon: Layers3 },
  { id: "settings-analytics", label: "Analytics", icon: BarChart3 },
  { id: "info", label: "FAQ", icon: FolderOpen },
  { id: "ocr", label: "OCR", icon: ScanText },
  { id: "audit-history", label: "Action history", icon: ClipboardCheck },
];

const settingsGroups = [
  {
    id: "settings-internal",
    label: "Internal Users",
    children: [
      { id: "settings-internal-roles", label: "Roles" },
      { id: "settings-internal-users", label: "Users" },
    ],
  },
  {
    id: "settings-external",
    label: "External Users",
    children: [
      { id: "settings-external-roles", label: "Roles" },
      { id: "settings-external-users", label: "Users" },
    ],
  },
];

const settingsCatalogItems: SubMenuItem[] = [
  { id: "settings-organizations", label: "General settings" },
];

const organizationReferenceItems: SubMenuItem[] = [
  { id: "settings-general-ledger", label: "General ledger" },
  { id: "settings-organizations-tax-country", label: "Tax country" },
  { id: "settings-organizations-legal-form", label: "Legal form" },
  { id: "settings-organizations-base-currency", label: "Currency" },
  { id: "settings-organizations-exchange-rates", label: "Exchange rates" },
  { id: "settings-organizations-type", label: "Document purpose" },
  { id: "ocr-admin-document-type", label: "Document type" },
  { id: "settings-organizations-unit", label: "Unit" },
  { id: "settings-organizations-operation-date-validation", label: "Period locking" },
  { id: "settings-vat-classifications", label: "VAT classifications" },
  { id: "settings-administrator", label: "Administrator settings" },
  { id: "settings-organizations-document-status", label: "Status" },
  { id: "ocr-admin-activity", label: "Activity Log" },
];

const ocrSubMenuItems = [
  { id: "ocr-workspace", label: "Workspace", icon: Monitor, hasDropdown: true },
  {
    id: "ocr-ml",
    label: "TeamLead",
    icon: UserCheck,
  },
  {
    id: "ocr-machine-learning",
    label: "Machine learning",
    icon: BrainCircuit,
  },
  { id: "ocr-review", label: "Review", icon: ClipboardCheck, hasDropdown: true },
];

const workspaceSubItems: SubMenuItem[] = [
  { id: "ocr-workspace-my-tasks", label: "My tasks" },
  { id: "ocr-workspace-document-issues", label: "Document issues" },
];

const reviewSubItems: SubMenuItem[] = [
  { id: "ocr-review-analytics", label: "Analytics" },
];

const allDocumentsSubItems: SubMenuItem[] = [
  { id: "ocr-all-documents-processed", label: "Processing documents" },
  { id: "ocr-all-documents-uploaded", label: "Uploaded document" },
];

const adminSubItems: SubMenuItem[] = [
  { id: "ocr-admin-document-type", label: "Document type" },
  { id: "ocr-admin-activity", label: "Activity Log" },
];

function isOcrSection(activeMenu: string) {
  return !isGeneralSettingsOcrMenu(activeMenu) && (activeMenu === "ocr" || activeMenu.startsWith("ocr-"));
}

// Keep stored permission/route keys while presenting these existing pages in Settings.
function isGeneralSettingsOcrMenu(activeMenu: string) {
  return activeMenu === 'ocr-admin-document-type' || activeMenu === 'ocr-admin-activity' || activeMenu.startsWith('ocr-admin-activity-');
}

function isTeamLeadActive(activeMenu: string) {
  return activeMenu === "ocr-ml" || activeMenu.startsWith("ocr-ml-");
}

function isReviewActive(activeMenu: string) {
  return activeMenu === "ocr-review" || activeMenu.startsWith("ocr-review-");
}

function isWorkspaceActive(activeMenu: string) {
  return activeMenu === "ocr-workspace" || activeMenu.startsWith("ocr-workspace-");
}

function isAllDocumentsActive(activeMenu: string) {
  return (
    activeMenu === "ocr-all-documents" ||
    activeMenu.startsWith("ocr-all-documents-")
  );
}

function isAdminActive(activeMenu: string) {
  return activeMenu === "ocr-admin" || activeMenu.startsWith("ocr-admin-");
}

function isSettingsActive(activeMenu: string) {
  return (
    activeMenu === "settings" ||
    isGeneralSettingsOcrMenu(activeMenu) ||
    (activeMenu.startsWith("settings-") && activeMenu !== "settings-analytics" && activeMenu !== "settings-counterparties")
  );
}

function getProfileInitials(fullName: string) {
  const nameParts = fullName.trim().split(/\s+/).filter(Boolean);

  if (nameParts.length === 0) return "";
  if (nameParts.length === 1) return nameParts[0].charAt(0).toUpperCase();

  return `${nameParts[0].charAt(0)}${nameParts[nameParts.length - 1].charAt(0)}`.toUpperCase();
}

function StepperDot({
  isActive,
  isFirst,
  isLast,
}: {
  isActive: boolean;
  isFirst: boolean;
  isLast: boolean;
}) {
  return (
    <div className="flex flex-col items-center w-1 self-stretch">
      <div
        className="flex-1 w-0"
        style={{
          borderLeft: "1px solid #007EA7",
          opacity: isFirst ? 0 : 0.2,
        }}
      />
      <div
        className="w-1 h-1 rounded-full flex-shrink-0"
        style={{
          background: "#007EA7",
          opacity: isActive ? 1 : 0.2,
        }}
      />
      <div
        className="flex-1 w-0"
        style={{
          borderLeft: "1px solid #007EA7",
          opacity: isLast ? 0 : 0.2,
        }}
      />
    </div>
  );
}

export default function Sidebar({
  notificationCount = 0,
  isExpanded,
  onToggle,
  activeMenu,
  onMenuClick,
  clientName,
  onLogout,
  visibleMainMenuIds,
  canViewMenu,
  workspaceMode = 'combined',
}: SidebarProps) {
  const [globalDocumentsExpanded, setGlobalDocumentsExpanded] = useState(isGlobalDocumentsMenu(activeMenu));
  useEffect(() => {
    if (isGlobalDocumentsMenu(activeMenu)) setGlobalDocumentsExpanded(true);
  }, [activeMenu]);
  const globalDocumentItems = GLOBAL_DOCUMENT_MENU_ITEMS.filter(item => canViewMenu(item.id));
  const [settingsExpanded, setSettingsExpanded] = useState(
    isSettingsActive(activeMenu),
  );
  const [internalUsersExpanded, setInternalUsersExpanded] = useState(
    activeMenu.startsWith("settings-internal"),
  );
  const [externalUsersExpanded, setExternalUsersExpanded] = useState(
    activeMenu.startsWith("settings-external"),
  );
  const [organizationsExpanded, setOrganizationsExpanded] = useState(isGeneralSettingsOcrMenu(activeMenu));
  const [statusExpanded, setStatusExpanded] = useState(activeMenu.startsWith('settings-organizations-document-status'));
  const [activityExpanded, setActivityExpanded] = useState(activeMenu.startsWith('ocr-admin-activity'));
  useEffect(() => {
    if (isGeneralSettingsOcrMenu(activeMenu)) { setSettingsExpanded(true); setOrganizationsExpanded(true); }
    if (activeMenu.startsWith('ocr-admin-activity-')) setActivityExpanded(true);
    if (activeMenu.startsWith('settings-organizations-document-status')) setStatusExpanded(true);
  }, [activeMenu]);
  const [allDocumentsExpanded, setAllDocumentsExpanded] = useState(
    isAllDocumentsActive(activeMenu),
  );
  const [reviewExpanded, setReviewExpanded] = useState(isReviewActive(activeMenu));
  const [workspaceExpanded, setWorkspaceExpanded] = useState(isWorkspaceActive(activeMenu));
  useEffect(() => {
    if (activeMenu.startsWith("ocr-workspace-")) setWorkspaceExpanded(true);
  }, [activeMenu]);
  useEffect(() => {
    if (isReviewActive(activeMenu)) setReviewExpanded(true);
  }, [activeMenu]);
  const [adminExpanded, setAdminExpanded] = useState(isAdminActive(activeMenu));
  const menuItems = isOcrSection(activeMenu)
    ? ocrSubMenuItems.filter((item) => canViewMenu(item.id))
    : mainMenuItems.filter(item => workspaceMenuVisible(workspaceMode, item.id)).filter((item) =>
        item.id === 'saas' ? canViewMenu('saas') : item.id === 'uploaded-documents' ? visibleMainMenuIds.includes('dashboard') && canViewMenu(item.id)
        : item.id === "settings-analytics" || item.id === "settings-counterparties"
          ? visibleMainMenuIds.includes("settings") && canViewMenu(item.id)
          : visibleMainMenuIds.includes(
              item.id === "global-dashboard" || item.id === "uploaded-documents" ? "dashboard" : item.id,
            ),
      );

  const handleMenuClick = (id: string) => {
    if (id === 'uploaded-documents') {
      const inDocuments = isGlobalDocumentsMenu(activeMenu);
      setGlobalDocumentsExpanded(expanded => !inDocuments || !expanded);
      if (!inDocuments && globalDocumentItems[0]) onMenuClick(globalDocumentItems[0].id);
    } else if (id === "settings") {
      setSettingsExpanded(!settingsExpanded);
      if (!isSettingsActive(activeMenu)) {
      const target = [
          "settings-internal-roles", "settings-internal-users",
          "settings-external-roles", "settings-external-users",
          "settings-organizations",
          "settings-general-ledger",
        ].find(canViewMenu);
        if (target) {
          setInternalUsersExpanded(target.startsWith("settings-internal"));
          setExternalUsersExpanded(target.startsWith("settings-external"));
          onMenuClick(target);
        }
      }
    } else if (id === "ocr-all-documents") {
      setAllDocumentsExpanded(!allDocumentsExpanded);
      if (!isAllDocumentsActive(activeMenu)) {
        onMenuClick("ocr-all-documents-processed");
      }
    } else if (id === "ocr-workspace") {
      const target = workspaceSubItems.find(sub => canViewMenu(sub.id));
      const isNavigating = !!target && activeMenu !== target.id;
      setWorkspaceExpanded(expanded => isNavigating || !expanded);
      if (target && isNavigating) onMenuClick(target.id);
    } else if (id === "ocr-ml") {
      onMenuClick("ocr-ml");
    } else if (id === "ocr-review") {
      setReviewExpanded(!reviewExpanded);
      if (!isReviewActive(activeMenu)) {
        onMenuClick("ocr-review-analytics");
      }
    } else if (id === "ocr-admin") {
      setAdminExpanded(!adminExpanded);
      const target = adminSubItems.find(sub => canViewMenu(sub.id));
      if (!isAdminActive(activeMenu) && target) {
        onMenuClick(target.id);
      }
    } else if (id === "settings-analytics") {
      setSettingsExpanded(false);
      onMenuClick(id);
    } else {
      onMenuClick(id);
    }
  };

  return (
    <div className="flex">
      {/* Blue strip */}
      <div className="w-12 min-h-screen bg-[#E6F2F6] flex flex-col justify-between items-center py-4 z-10">
        <div className="group relative flex h-8 w-12 items-center justify-center">
          <button
            onClick={() => onMenuClick("profile")}
            aria-label={uiText("Profile settings")}
            aria-current={activeMenu === "profile" ? "page" : undefined}
            data-tooltip-side="right"
            className={`peer w-8 h-8 flex items-center justify-center rounded transition-colors ${
              activeMenu === "profile" ? "bg-[#007EA7]" : "hover:bg-[#D0E8EF]"
            }`}
          >
            <User
              size={16}
              className={activeMenu === "profile" ? "text-white" : "text-[#7288A3]"}
            />
          </button>
        </div>

        <div className="flex flex-col items-center gap-1">
          <div className="group relative flex h-8 w-12 items-center justify-center">
            <button
              onClick={onToggle}
              aria-label={uiText("Collapse sidebar")}
              data-tooltip-side="right"
              className="peer w-12 h-8 flex items-center justify-center hover:bg-[#D0E8EF] rounded transition-colors"
            >
              <Menu size={16} className="text-[#006080]" />
            </button>
          </div>
          <button
            className="w-12 h-8 flex items-center justify-center hover:bg-[#D0E8EF] rounded transition-colors"
            title={uiText("Logout")}
            onClick={onLogout}
          >
            <LogOut size={16} className="text-[#006080] rotate-90" />
          </button>
        </div>
      </div>

      {/* White panel */}
      <div
        className="min-h-screen bg-white border-r-2 border-[#E6F2F6] flex flex-col transition-all duration-300 overflow-hidden flex-shrink-0"
        style={{ width: isExpanded ? "288px" : "36px" }}
      >
        <div
          className="flex flex-col h-full"
          style={{ width: isExpanded ? 288 : 36 }}
        >
          {/* Header */}
          <div
            className={`flex-shrink-0 pb-2 pt-4 ${isExpanded ? "px-4" : "px-0"}`}
          >
            <div
              className={`flex h-8 items-center ${isExpanded ? "px-[9px]" : "justify-center px-0"}`}
            >
              {isOcrSection(activeMenu) ? (
                <button
                  type="button"
                  onClick={() => onMenuClick("global-dashboard")}
                  title={uiText("Back to main menu")}
                  aria-label={uiText("Back to main menu")}
                  className={`flex h-8 items-center text-[#007EA7] transition-opacity hover:opacity-70 ${isExpanded ? "w-full gap-2" : "justify-center"}`}
                >
                  <ArrowLeft size={11} className="flex-shrink-0" strokeWidth={2.5} />
                  {isExpanded && (
                    <span className="whitespace-nowrap font-montserrat text-[14px] font-semibold leading-5">{uiText("Back")}</span>
                  )}
                </button>
              ) : isExpanded ? (
                <span className="font-montserrat font-semibold text-[16px] leading-5 text-[#10233A] whitespace-nowrap">
                  {clientName}
                </span>
              ) : (
                <span
                  className="font-montserrat text-[11px] font-semibold leading-4 text-[#10233A]"
                  title={clientName}
                  aria-label={clientName}
                >
                  {getProfileInitials(clientName)}
                </span>
              )}
            </div>
          </div>

          {/* Menu items */}
          <nav
            className={`flex flex-col gap-0 ${isExpanded ? "px-4" : "px-0 pt-2"}`}
          >
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive =
                item.id === 'uploaded-documents'
                  ? isGlobalDocumentsMenu(activeMenu)
                  : item.id === "ocr-ml"
                  ? isTeamLeadActive(activeMenu)
                  : item.id === "ocr-all-documents"
                    ? isAllDocumentsActive(activeMenu)
                    : item.id === "ocr-workspace"
                      ? isWorkspaceActive(activeMenu)
                    : item.id === "ocr-review"
                      ? isReviewActive(activeMenu)
                    : item.id === "ocr-admin"
                      ? isAdminActive(activeMenu)
                      : item.id === "settings"
                        ? isSettingsActive(activeMenu)
                        : activeMenu === item.id;
              const hasDropdown = "hasDropdown" in item && item.hasDropdown;
              const showGlobalDocumentsSub = item.id === 'uploaded-documents' && globalDocumentsExpanded && isExpanded;
              const showAllDocumentsSub =
                item.id === "ocr-all-documents" &&
                allDocumentsExpanded &&
                isExpanded;
              const showAdminSub =
                item.id === "ocr-admin" && adminExpanded && isExpanded;
              const showReviewSub =
                item.id === "ocr-review" && reviewExpanded && isExpanded;
              const showWorkspaceSub =
                item.id === "ocr-workspace" && workspaceExpanded && isExpanded;
              const showSettingsSub =
                item.id === "settings" && settingsExpanded && isExpanded;

              return (
                <div key={item.id}>
                  {isExpanded ? (
                    <button
                      onClick={() => handleMenuClick(item.id)}
                      aria-expanded={item.id === 'uploaded-documents' ? showGlobalDocumentsSub : undefined}
                      aria-controls={showGlobalDocumentsSub ? 'global-documents-submenu' : undefined}
                      className={`h-9 w-full flex flex-row items-center justify-between px-2 rounded transition-colors ${
                        isActive ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"
                      }`}
                    >
                      <div className="flex flex-row items-center gap-2">
                        <Icon
                          size={16}
                          className={isActive ? "text-white" : "text-[#7288A3]"}
                        />
                        <span
                          className={`font-montserrat font-medium text-[14px] leading-5 whitespace-nowrap ${isActive ? "text-white" : "text-[#10233A]"}`}
                        >
                          {uiText(item.label)}
                        </span>
                      </div>
                      {item.id === "notifications" && notificationCount > 0 ? (
                        <span aria-label={`${uiText("Active notifications")}: ${notificationCount}`} className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#E34242] px-1.5 font-montserrat text-[11px] font-semibold leading-5 text-white">
                          {notificationCount}
                        </span>
                      ) : <ChevronDown
                        size={16}
                        className={`flex-shrink-0 transition-transform ${hasDropdown ? "opacity-100" : "opacity-0"} ${isActive ? "text-white" : "text-[#10233A]"} ${showGlobalDocumentsSub || showAllDocumentsSub || showWorkspaceSub || showReviewSub || showAdminSub || showSettingsSub ? "rotate-180" : ""}`}
                      />}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleMenuClick(item.id)}
                      title={uiText(item.label)}
                      className={`w-9 h-9 flex items-center justify-center rounded transition-colors mx-auto ${
                        isActive ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"
                      }`}
                    >
                      <Icon
                        size={16}
                        className={isActive ? "text-white" : "text-[#7288A3]"}
                      />
                    </button>
                  )}

                  {showGlobalDocumentsSub && (
                    <div id="global-documents-submenu" className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
                      {globalDocumentItems.map((subItem, index) => {
                        const selected = activeMenu === subItem.id || (activeMenu === 'uploaded-documents' && index === 0);
                        return <div key={subItem.id} className="flex h-8 flex-row items-center gap-[14px]">
                          <StepperDot isActive={selected} isFirst={index === 0} isLast={index === globalDocumentItems.length - 1} />
                          <button type="button" onClick={() => onMenuClick(subItem.id)} aria-current={selected ? 'page' : undefined}
                            className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 font-montserrat text-[14px] font-medium transition-colors ${selected ? 'bg-[#007EA7] text-white' : 'text-[#10233A] hover:bg-[#F0F7FA]'}`}>
                            <span className="truncate">{uiText(subItem.label)}</span>
                          </button>
                        </div>;
                      })}
                    </div>
                  )}
                  {showSettingsSub && (
                    <div className="mt-1.5 flex flex-col gap-1 pb-1 pl-[14px]">
                      {settingsGroups.filter((group) => canViewMenu(group.id)).map((group, groupIndex) => {
                        const groupActive = activeMenu.startsWith(group.id);
                        const groupExpanded =
                          group.id === "settings-internal"
                            ? internalUsersExpanded
                            : externalUsersExpanded;
                        const toggleGroup = () => {
                          if (group.id === "settings-internal") {
                            setInternalUsersExpanded(!internalUsersExpanded);
                          } else {
                            setExternalUsersExpanded(!externalUsersExpanded);
                          }
                        };

                        return (
                          <div key={group.id}>
                            <div className="flex h-8 flex-row items-center gap-[14px]">
                              <StepperDot
                                isActive={groupActive}
                                isFirst={groupIndex === 0}
                                isLast={false}
                              />
                              <button
                                onClick={toggleGroup}
                                className="flex h-8 min-w-0 flex-1 items-center justify-between rounded-md px-3 transition-colors hover:bg-[#F0F7FA]"
                              >
                                <span
                                  className={`truncate font-montserrat text-[13px] font-semibold leading-5 ${groupActive ? "text-[#007EA7]" : "text-[#10233A]"}`}
                                >
                                  {uiText(group.label)}
                                </span>
                                <ChevronDown
                                  size={14}
                                  className={`flex-shrink-0 text-[#7288A3] transition-transform ${groupExpanded ? "rotate-180" : ""}`}
                                />
                              </button>
                            </div>

                            {groupExpanded && (
                              <div className="ml-[18px] mt-0.5 flex flex-col gap-0.5 border-l border-[#D9E8F0] pl-[13px]">
                                {group.children.filter((child) => canViewMenu(child.id)).map((child) => {
                                  const childActive = activeMenu === child.id;
                                  return (
                                    <button
                                      key={child.id}
                                      onClick={() => onMenuClick(child.id)}
                                      className={`flex h-8 min-w-0 items-center rounded-md px-3 text-left transition-colors ${childActive ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"}`}
                                    >
                                      <span
                                        className={`truncate font-montserrat text-[13px] font-medium leading-5 ${childActive ? "text-white" : "text-[#10233A]"}`}
                                      >
                                        {uiText(child.label)}
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                      {settingsCatalogItems.filter((item) => canViewMenu(item.id)).map((item, itemIndex) => {
                        const isOrganizations =
                          item.id === "settings-organizations";
                        const itemActive = isOrganizations
                          ? activeMenu === item.id ||
                            activeMenu.startsWith("settings-organizations-") ||
                            activeMenu === "settings-vat-classifications" ||
                            activeMenu === "settings-general-ledger" || isGeneralSettingsOcrMenu(activeMenu)
                          : activeMenu === item.id;
                        return (
                          <div key={item.id}>
                            <div className="flex h-8 flex-row items-center gap-[14px]">
                              <StepperDot
                                isActive={itemActive}
                                isFirst={false}
                                isLast={
                                  itemIndex ===
                                    settingsCatalogItems.length - 1 &&
                                  !organizationsExpanded
                                }
                              />
                              <div
                                className={`flex h-8 min-w-0 flex-1 items-center rounded-md transition-colors ${itemActive && !isOrganizations ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"}`}
                              >
                                <button
                                  onClick={() => { if (isOrganizations) { setOrganizationsExpanded(true); onMenuClick(workspaceMode === 'ocr' ? 'settings-organizations-document-status-ocr' : "settings-general-ledger"); } else onMenuClick(item.id); }}
                                  className="flex h-8 min-w-0 flex-1 items-center px-3 text-left"
                                >
                                  <span
                                    className={`truncate font-montserrat text-[13px] leading-5 ${isOrganizations ? "font-semibold" : "font-medium"} ${itemActive ? isOrganizations ? "text-[#007EA7]" : "text-white" : "text-[#10233A]"}`}
                                  >
                                    {uiText(item.label)}
                                  </span>
                                </button>
                                {isOrganizations && (
                                  <button
                                    type="button"
                                    aria-label={uiText("Expand organization settings")}
                                    aria-expanded={organizationsExpanded}
                                    onClick={() =>
                                      setOrganizationsExpanded(
                                        (current) => !current,
                                      )
                                    }
                                    className="mr-3 flex h-8 w-[14px] flex-shrink-0 appearance-none items-center justify-center border-0 bg-transparent p-0 leading-none text-[#7288A3] hover:text-[#007EA7]"
                                  >
                                    <ChevronDown
                                      size={14}
                                      className={`transition-transform ${organizationsExpanded ? "rotate-180" : ""}`}
                                    />
                                  </button>
                                )}
                              </div>
                            </div>
                            {isOrganizations && organizationsExpanded && (
                              <div className="ml-[18px] mt-0.5 flex flex-col gap-0.5 pl-[13px]">
                                {organizationReferenceItems.filter((child) => canViewMenu(child.id)).map((child, childIndex, visibleChildren) => {
                                  const childActive = activeMenu === child.id;
                                  const ocrStatusActive = activeMenu === 'settings-organizations-document-status-ocr';
                                  if (child.id === 'settings-organizations-document-status') return <div key={child.id} data-status-navigation>
                                    <div className="flex h-8 flex-row items-center gap-[14px]">
                                      <StepperDot isActive={childActive || ocrStatusActive} isFirst={childIndex === 0} isLast={!statusExpanded && childIndex === visibleChildren.length - 1} />
                                      <div className="flex h-8 min-w-0 flex-1 items-center rounded-md transition-colors hover:bg-[#F0F7FA]">
                                        <button type="button" onClick={() => { setStatusExpanded(value => childActive || ocrStatusActive ? !value : true); if (!childActive && !ocrStatusActive) onMenuClick(workspaceMode === 'ocr' ? 'settings-organizations-document-status-ocr' : child.id); }} className={`h-full min-w-0 flex-1 px-3 text-left font-montserrat text-[13px] font-medium ${childActive || ocrStatusActive ? 'text-[#007EA7]' : 'text-[#10233A]'}`}>{uiText(child.label)}</button>
                                        <button type="button" aria-label={uiText('Status sections')} aria-expanded={statusExpanded} aria-controls="settings-ocr-status-submenu" onClick={() => setStatusExpanded(value => !value)} className="mr-3 flex h-8 w-[14px] shrink-0 items-center justify-center text-[#7288A3]"><ChevronDown size={14} className={`transition-transform ${statusExpanded ? 'rotate-180' : ''}`} /></button>
                                      </div>
                                    </div>
                                    {statusExpanded && <div id="settings-ocr-status-submenu" className="ml-[18px] mt-0.5 flex flex-col gap-0.5 pl-[13px]">
                                      {[
                                        { id: 'settings-organizations-document-status', label: 'Finansų harmonija' },
                                        { id: 'settings-organizations-document-status-ocr', label: 'OCR status' },
                                      ].filter(sub => canViewMenu(sub.id) && (workspaceMode !== 'ocr' || sub.id.endsWith('-ocr'))).map((sub, index, items) => <div key={sub.id} className="flex h-8 flex-row items-center gap-[14px]">
                                        <StepperDot isActive={activeMenu === sub.id} isFirst={index === 0} isLast={index === items.length - 1} />
                                        <button type="button" aria-current={activeMenu === sub.id ? 'page' : undefined} onClick={() => onMenuClick(sub.id)}
                                          className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 text-left font-montserrat text-[13px] font-medium transition-colors ${activeMenu === sub.id ? 'bg-[#007EA7] text-white' : 'text-[#10233A] hover:bg-[#F0F7FA]'}`}><span className="truncate">{uiText(sub.label)}</span></button>
                                      </div>)}
                                    </div>}
                                  </div>;
                                  if (child.id === 'ocr-admin-activity') {
                                    const activityActive = activeMenu.startsWith('ocr-admin-activity');
                                    return <div key={child.id} data-activity-navigation>
                                      <div className="flex h-8 flex-row items-center gap-[14px]">
                                        <StepperDot isActive={activityActive} isFirst={childIndex === 0} isLast={childIndex === visibleChildren.length - 1} />
                                        <div className="flex h-8 min-w-0 flex-1 items-center rounded-md transition-colors hover:bg-[#F0F7FA]">
                                          <button type="button" onClick={() => { setActivityExpanded(value => activityActive ? !value : true); if (!activityActive) onMenuClick('ocr-admin-activity-ocr'); }} className={`h-full min-w-0 flex-1 px-3 text-left font-montserrat text-[13px] font-medium ${activityActive ? 'text-[#007EA7]' : 'text-[#10233A]'}`}>{uiText(child.label)}</button>
                                          <button type="button" aria-label={uiText('Activity log sections')} aria-expanded={activityExpanded} aria-controls="settings-activity-submenu" onClick={() => setActivityExpanded(value => !value)} className="mr-3 flex h-8 w-[14px] shrink-0 items-center justify-center text-[#7288A3]"><ChevronDown size={14} className={`transition-transform ${activityExpanded ? 'rotate-180' : ''}`} /></button>
                                        </div>
                                      </div>
                                      {activityExpanded && <div id="settings-activity-submenu" className="ml-[18px] mt-0.5 flex flex-col gap-0.5 pl-[13px]">
                                        {[
                                          { id: 'ocr-admin-activity-ocr', label: 'OCR activity log' },
                                          { id: 'ocr-admin-activity-fh', label: 'Finansų harmonija activity log' },
                                        ].filter(sub => canViewMenu(sub.id)).map((sub, index, items) => <div key={sub.id} className="flex min-h-8 flex-row items-stretch gap-[14px]">
                                          <StepperDot isActive={activeMenu === sub.id || childActive && index === 0} isFirst={index === 0} isLast={index === items.length - 1} />
                                          <button type="button" aria-current={activeMenu === sub.id || childActive && index === 0 ? 'page' : undefined} onClick={() => onMenuClick(sub.id)}
                                            className={`flex min-h-8 min-w-0 flex-1 items-center rounded-md px-3 py-1.5 text-left font-montserrat text-[13px] font-medium leading-5 transition-colors ${activeMenu === sub.id || childActive && index === 0 ? 'bg-[#007EA7] text-white' : 'text-[#10233A] hover:bg-[#F0F7FA]'}`}><span>{uiText(sub.label)}</span></button>
                                        </div>)}
                                      </div>}
                                    </div>;
                                  }
                                  return (
                                    <div key={child.id} className="flex h-8 flex-row items-center gap-[14px]">
                                      <StepperDot isActive={childActive} isFirst={childIndex === 0} isLast={childIndex === visibleChildren.length - 1} />
                                      <button
                                      type="button"
                                      aria-current={childActive ? 'page' : undefined}
                                      onClick={() => onMenuClick(child.id)}
                                      className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 text-left transition-colors ${childActive ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"}`}
                                    >
                                      <span
                                        className={`truncate font-montserrat text-[13px] font-medium leading-5 ${childActive ? "text-white" : "text-[#10233A]"}`}
                                      >
                                        {uiText(child.label)}
                                      </span>
                                    </button>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {showAllDocumentsSub && (
                    <div className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
                      {allDocumentsSubItems.filter((sub) => canViewMenu(sub.id)).map((sub, idx) => {
                        const isSubActive =
                          activeMenu === sub.id ||
                          (activeMenu === "ocr-all-documents" && idx === 0);
                        return (
                          <div
                            key={sub.id}
                            className="flex h-8 flex-row items-center gap-[14px]"
                          >
                            <StepperDot
                              isActive={isSubActive}
                              isFirst={idx === 0}
                              isLast={idx === allDocumentsSubItems.length - 1}
                            />
                            <button
                              onClick={() => onMenuClick(sub.id)}
                              className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 transition-colors ${isSubActive ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"}`}
                            >
                              <span
                                className={`truncate font-montserrat text-[13px] font-medium leading-5 ${isSubActive ? "text-white" : "text-[#10233A]"}`}
                              >
                                {uiText(sub.label)}
                              </span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {showWorkspaceSub && (
                    <div className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
                      {workspaceSubItems.filter(sub => canViewMenu(sub.id)).map((sub, index, visibleItems) => {
                        const isSubActive = activeMenu === sub.id;
                        return (
                          <div key={sub.id} className="flex h-8 flex-row items-center gap-[14px]">
                            <StepperDot isActive={isSubActive} isFirst={index === 0} isLast={index === visibleItems.length - 1} />
                            <button type="button" onClick={() => onMenuClick(sub.id)} aria-current={isSubActive ? 'page' : undefined}
                              className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 transition-colors ${isSubActive ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"}`}>
                              <span className={`truncate font-montserrat text-[13px] font-medium leading-5 ${isSubActive ? "text-white" : "text-[#10233A]"}`}>{uiText(sub.label)}</span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {showReviewSub && (
                    <div className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
                      {reviewSubItems.filter((sub) => canViewMenu(sub.id)).map((sub, idx) => {
                        const isSubActive = activeMenu === sub.id || (activeMenu === "ocr-review" && idx === 0);
                        return (
                          <div key={sub.id} className="flex h-8 flex-row items-center gap-[14px]">
                            <StepperDot isActive={isSubActive} isFirst={idx === 0} isLast={idx === reviewSubItems.length - 1} />
                            <button onClick={() => onMenuClick(sub.id)} className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 transition-colors ${isSubActive ? "bg-[#007EA7]" : "hover:bg-[#F0F7FA]"}`}>
                              <span className={`truncate font-montserrat text-[13px] font-medium leading-5 ${isSubActive ? "text-white" : "text-[#10233A]"}`}>{uiText(sub.label)}</span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {showAdminSub && (
                    <div className="mt-1.5 flex flex-col gap-0.5 pb-1 pl-[14px]">
                      {adminSubItems.filter((sub) => canViewMenu(sub.id)).map((sub, idx) => {
                        const isSubActive =
                          activeMenu === sub.id ||
                          (activeMenu === "ocr-admin" && idx === 0);
                        return (
                          <div
                            key={sub.id}
                            className="flex h-8 flex-row items-center gap-[14px]"
                          >
                            <StepperDot
                              isActive={isSubActive}
                              isFirst={idx === 0}
                              isLast={idx === adminSubItems.length - 1}
                            />
                            <button
                              onClick={() => onMenuClick(sub.id)}
                              className={`flex h-8 min-w-0 flex-1 items-center rounded-md px-3 transition-colors ${
                                isSubActive
                                  ? "bg-[#007EA7]"
                                  : "hover:bg-[#F0F7FA]"
                              }`}
                            >
                              <span
                                className={`font-montserrat font-medium text-[14px] leading-5 whitespace-nowrap ${
                                  isSubActive ? "text-white" : "text-[#10233A]"
                                }`}
                              >
                                {uiText(sub.label)}
                              </span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}
