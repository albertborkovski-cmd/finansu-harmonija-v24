import { Fragment } from 'react';
import { isHelpVisible, safeHelpUrl } from '../lib/helpContent';
import { useHelpContent } from './HelpContentProvider';
import HelpUploadedMedia from './HelpUploadedMedia';

/** Small, text-only Markdown subset. Raw HTML and executable URLs are never rendered. */
export default function HelpArticleBody({ body }: { body: string }) {
  const { state } = useHelpContent();
  const inline = (text: string) => text.split(/(\[[^\]]+\]\([^\s)]+\)|\*\*[^*]+\*\*|\*[^*]+\*)/g).map((part, index) => {
    const match = part.match(/^\[([^\]]+)\]\(([^\s)]+)\)$/);
    if (match) {
      const href = safeHelpUrl(match[2]);
      return href && !href.startsWith('help-media:') && (!href.startsWith('./#help') || isHelpVisible(href, state)) ? <a key={index} href={href} target={href.startsWith('https:') ? '_blank' : undefined} rel="noopener noreferrer" className="text-[#007EA7] underline underline-offset-4">{match[1]}</a> : <Fragment key={index}>{match[1]}</Fragment>;
    }
    return part.startsWith('**') && part.endsWith('**') ? <strong key={index}>{part.slice(2, -2)}</strong> : part.startsWith('*') && part.endsWith('*') ? <em key={index}>{part.slice(1, -1)}</em> : <Fragment key={index}>{part}</Fragment>;
  });
  const blocks = body.replace(/\r/g, '').split(/\n\s*\n/);
  return <div className="space-y-5 text-[13px] leading-7 text-[#526B86] [&_th]:!resize-none [&_th]:after:!hidden">{blocks.map((block, index) => {
    const uploaded = block.match(/^([!@])\[([^\]]*)\]\((help-media:[a-f0-9-]{36})\)$/);
    if (uploaded) return <HelpUploadedMedia key={index + uploaded[3]} source={uploaded[3]} caption={uploaded[2]} video={uploaded[1] === '@'} />;
    const image = block.match(/^!\[([^\]]*)\]\((help\/[a-zA-Z0-9._/-]+)\)$/);
    if (image && safeHelpUrl(image[2])) return <figure key={index} className="overflow-hidden rounded-lg border border-[#D3E1EC]"><a href={import.meta.env.BASE_URL + image[2]} target="_blank" rel="noopener noreferrer"><img src={import.meta.env.BASE_URL + image[2]} alt={image[1]} loading="lazy" className="h-auto w-full" /></a><figcaption className="bg-[#F3F8FB] px-4 py-2 text-[11px]">{image[1]}</figcaption></figure>;
    if (/^```/.test(block)) return <pre key={index} className="overflow-x-auto rounded-lg border border-[#D3E1EC] bg-[#F3F8FB] p-4"><code>{block.replace(/^```[^\n]*\n?/, '').replace(/\n?```$/, '')}</code></pre>;
    if (/^#{1,3} /.test(block)) return <h2 key={index} className="pt-3 text-[18px] font-semibold text-[#10233A]">{inline(block.replace(/^#{1,3} /, ''))}</h2>;
    const rows = block.split('\n');
    if (rows.length > 1 && rows.every(row => /^\|.*\|$/.test(row)) && /^\|[\s|:-]+\|$/.test(rows[1])) {
      const cells = (row: string) => row.slice(1, -1).split('|').map(cell => cell.trim());
      return <div key={index} className="overflow-x-auto rounded-lg border border-[#D3E1EC]"><table className="w-full text-left text-[12px]"><thead className="bg-[#F3F8FB]"><tr>{cells(rows[0]).map((cell, i) => <th key={i} className="px-4 py-2 font-semibold">{inline(cell)}</th>)}</tr></thead><tbody>{rows.slice(2).map((row, i) => <tr key={i} className="border-t border-[#E5EDF9]">{cells(row).map((cell, j) => <td key={j} className="px-4 py-2 align-top">{inline(cell)}</td>)}</tr>)}</tbody></table></div>;
    }
    if (rows.every(row => /^\d+\. |^- /.test(row))) return <ul key={index} className="space-y-2">{rows.map((row, i) => <li key={i} className="flex gap-3"><span className="shrink-0 font-semibold text-[#007EA7]">{row.match(/^\d+\./)?.[0] || '•'}</span><span>{inline(row.replace(/^\d+\. |^- /, ''))}</span></li>)}</ul>;
    return <p key={index} className="whitespace-pre-wrap">{inline(block)}</p>;
  })}</div>;
}
