import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import { PageActionButton } from './PageHeader';

export default function DocumentNoteDialog({ value, readOnly, onApply, onClose }: {
  value: string; readOnly: boolean; onApply: (note: string) => void; onClose: () => void;
}) {
  const [note, setNote] = useState(value);
  const titleId = useId();
  const root = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    (input.current || root.current)?.focus();
    return () => { if (previous?.isConnected) previous.focus(); };
  }, []);
  return createPortal(<div className="fixed inset-0 z-[5500] flex items-center justify-center bg-[#10233A]/35 p-4" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90vh] w-full max-w-[600px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[13px] text-[#10233A] shadow-xl" onKeyDown={event => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); onClose(); }
      if (event.key === 'Tab') {
        const nodes = [...(root.current?.querySelectorAll<HTMLElement>('button:not(:disabled),textarea') || [])];
        const first = nodes[0], last = nodes.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    }}>
      <header className="flex items-center justify-between border-b border-[#D3E1EC] px-6 py-4"><h2 id={titleId} className="text-[18px] font-semibold">{uiText('Note')}</h2><PageActionButton ariaLabel={uiText('Close')} onClick={onClose} className="!w-8 !px-0"><X size={16}/></PageActionButton></header>
      <div className="space-y-2 overflow-y-auto p-6"><label htmlFor={`${titleId}-note`} className="font-medium">{uiText('Document note')}</label><textarea ref={input} id={`${titleId}-note`} readOnly={readOnly} value={note} onChange={event => setNote(event.target.value)} maxLength={5000} rows={5} className="w-full resize-y rounded-lg border border-[#D3E1EC] bg-white p-3 outline-none focus:border-[#007EA7]"/>{!readOnly && <p className="text-[12px] text-[#7288A3]">{uiText('The note is saved together with the document.')}</p>}</div>
      <footer className="flex justify-end gap-2 border-t border-[#D3E1EC] px-6 py-4"><PageActionButton onClick={onClose}>{uiText(readOnly ? 'Close' : 'Cancel')}</PageActionButton>{!readOnly && <PageActionButton onClick={() => { onApply(note); onClose(); }}>{uiText('Apply')}</PageActionButton>}</footer>
    </div>
  </div>, document.body);
}
