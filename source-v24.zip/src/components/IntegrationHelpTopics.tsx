import { ArrowLeft, ArrowRight, BookOpen, ChevronRight, Info } from 'lucide-react';
import { integrationTopic, integrationTopics } from '../lib/integrationHelpTopics';
import { exportHelpHref } from '../lib/exportSettingsHelp';
import { integrationHelpHref } from './IntegrationHelpLink';
import { HelpScreenshot, HelpVideo } from './HelpMedia';

const panel = 'rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7';

export default function IntegrationHelpTopics({ integration, topicId, lt }: { integration: string; topicId: string | null; lt: boolean }) {
  const lang = lt ? 1 : 0;
  const topics = integrationTopics(integration);
  const topic = integrationTopic(integration, topicId);
  const next = topic ? topics[topics.indexOf(topic) + 1] : undefined;

  if (!topic) return <section className={panel} aria-labelledby="integration-topics-title">
    <div className="mb-3 flex items-center gap-2 text-[12px] text-[#7288A3]"><BookOpen size={15} />{lt ? 'Integracijos' : 'Integrations'}<ChevronRight size={13} />{integration}</div>
    <h2 id="integration-topics-title" className="text-[23px] font-semibold">{integration}</h2>
    <p className="mt-2 text-[13px] leading-6 text-[#526B86]">{lt ? 'Pasirinkite temą. Kiekviename aprašyme atskirti veiksmai apskaitos sistemoje ir Finansų harmonijoje.' : 'Choose a topic. Each guide separates accounting-system steps from Finansų harmonija steps.'}</p>
    <p className="mb-3 mt-6 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{lt ? 'Pagalbos temos' : 'Help topics'} · {topics.length}</p>
    <div className="divide-y divide-[#E5EDF9] overflow-hidden rounded-lg border border-[#D3E1EC]">
      {topics.map((item, index) => <a key={item.id} href={integrationHelpHref(integration, item.id)} className="group flex items-center gap-4 px-4 py-5 transition-colors hover:bg-[#F2F8FB] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#007EA7]">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#EAF4F9] text-[12px] font-semibold text-[#007EA7]">{index + 1}</span>
        <span className="min-w-0 flex-1"><span className="block text-[14px] font-semibold text-[#007EA7]">{item.title[lang]}</span><span className="mt-1 block text-[12px] leading-5 text-[#7288A3]">{item.description[lang]}</span></span>
        <ChevronRight size={18} className="shrink-0 text-[#7288A3] group-hover:text-[#007EA7]" />
      </a>)}
    </div>
    <a className="mt-5 inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7] underline underline-offset-2" href={exportHelpHref(integration)}>{lt ? 'Eksporto nustatymų laukų paaiškinimai' : 'Export-setting field descriptions'}<ArrowRight size={14} /></a>
  </section>;

  return <article className="space-y-5" aria-labelledby="integration-topic-title">
    <header className={panel}>
      <a href={integrationHelpHref(integration)} className="mb-4 inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]"><ArrowLeft size={14} />{lt ? `Visos ${integration} temos` : `All ${integration} topics`}</a>
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{integration} · {topics.indexOf(topic) + 1} / {topics.length}</p>
      <h2 id="integration-topic-title" className="text-[21px] font-semibold leading-8">{topic.title[lang]}</h2>
      <p className="mt-2 text-[13px] leading-6 text-[#526B86]">{topic.description[lang]}</p>
    </header>
    {topic.sections.map(section => <section key={section.title[0]} className={panel}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h3 className="text-[16px] font-semibold">{section.title[lang]}</h3><span className="rounded-md bg-[#EBF5FA] px-2 py-1 text-[10px] font-semibold text-[#007EA7]">{section.system === 'FH' ? 'Finansų harmonija' : section.system}</span></div>
      {section.paragraphs?.map(paragraph => <p key={paragraph[0]} className="mb-3 text-[13px] leading-6 text-[#526B86]">{paragraph[lang]}</p>)}
      {section.steps && <ol className="space-y-4">{section.steps.map((step, index) => <li key={step[0]} className="flex gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E5EDF9] text-[11px] font-semibold text-[#007EA7]">{index + 1}</span><p className="text-[13px] leading-6 text-[#526B86]">{step[lang]}</p></li>)}</ol>}
    </section>)}
    {topic.note && <aside className="flex gap-3 rounded-xl border border-[#D3E1EC] bg-[#EEF6FA] p-5"><Info size={18} className="mt-0.5 shrink-0 text-[#007EA7]" /><div><h3 className="mb-1 text-[13px] font-semibold">{lt ? 'Dabartinė FH funkcija' : 'Current FH capability'}</h3><p className="text-[12px] leading-6 text-[#526B86]">{topic.note[lang]}</p></div></aside>}
    {topic.screenshot && <section className={panel}><HelpScreenshot lt={lt} file={topic.screenshot.file} caption={topic.screenshot.caption[lang]} /></section>}
    {topic.video && <section className={panel}><h3 className="mb-3 text-[16px] font-semibold">{lt ? 'Agnum vaizdo instrukcija' : 'Agnum video tutorial'}</h3><HelpVideo {...topic.video} lt={lt} /></section>}
    <footer className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-[#D3E1EC] bg-white p-4">
      <a href={integrationHelpHref(integration)} className="inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]"><ArrowLeft size={14} />{lt ? 'Visos temos' : 'All topics'}</a>
      {next && <a href={integrationHelpHref(integration, next.id)} className="inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]">{next.title[lang]}<ArrowRight size={14} /></a>}
    </footer>
  </article>;
}
