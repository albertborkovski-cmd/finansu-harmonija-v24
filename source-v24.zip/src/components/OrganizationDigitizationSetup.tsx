import { useState, type ReactNode } from 'react';
import { Info, Save } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { supabase, recordAdministrativeAction, type Company } from '../lib/supabase';
import { canEditCompanySettings } from '../lib/documentEditAccess';
import { isInactiveRecord } from '../lib/recordLifecycle';
import { COMPANY_EXPORT_FORMATS, DEFAULT_DIGITIZATION_SETTINGS, parseCompanyDigitizationSettings, serializeCompanyDigitizationSettings, SALES_OPERATION_TYPES, PURCHASE_OPERATION_TYPES, type CompanyDigitizationSettings } from '../lib/companyDigitizationSettings';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import AdditionalColumnSettings from './AdditionalColumnSettings';

const inputClass = 'h-10 w-full rounded-md border border-[#D3E1EC] bg-white px-3 font-montserrat text-[13px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-1 focus:ring-[#007EA7]/20 disabled:bg-[#F5F8FB]';
function Section({ title, children, description }: { title: string; children: ReactNode; description?: string }) {
  return <section className="rounded-lg border border-[#D3E1EC] bg-white">
    <h4 className="rounded-t-lg border-b border-[#E5EDF9] bg-[#F2F6FA] px-4 py-3 text-[13px] font-semibold text-[#10233A]">{t(title)}</h4>
    <div className="space-y-4 p-4">{description && <p className="text-[12px] leading-5 text-[#7288A3]">{t(description)}</p>}{children}</div>
  </section>;
}
function Field({ label, children }: { label: string; children: ReactNode }) {
  return <div className="min-w-0 space-y-1.5"><p className="text-[12px] font-medium leading-[18px] text-[#7288A3]">{t(label)}</p>{children}</div>;
}

export default function OrganizationDigitizationSetup({ company, onUpdated, onClose }: { company: Company; onUpdated: (company: Company) => void; onClose: () => void }) {
  const [initial] = useState(() => {
    try { return { settings: parseCompanyDigitizationSettings(company.document_export_settings, company as unknown as Record<string, unknown>), error: '' }; }
    catch { return { settings: { ...DEFAULT_DIGITIZATION_SETTINGS }, error: 'Could not read export settings.' }; }
  });
  const [settings, setSettings] = useState(initial.settings);
  const [format, setFormat] = useState(company.primary_export_format || 'Rivilė');
  const [saving, setSaving] = useState(false), [saved, setSaved] = useState(false), [error, setError] = useState(initial.error);
  // Never store an API key in localStorage, the demo data file, history or exported source.
  const [apiKey, setApiKey] = useState('');
  const allowed = !initial.error && !isInactiveRecord(company) && canEditCompanySettings(company);
  const disabled = saving || !allowed;
  const rivile = /^rivil/i.test(format);
  const update = <K extends keyof CompanyDigitizationSettings>(key: K, value: CompanyDigitizationSettings[K]) => {
    setSettings(previous => ({ ...previous, [key]: value })); setSaved(false); setError('');
  };
  const textField = (key: keyof CompanyDigitizationSettings, label: string, placeholder?: string) => <Field label={label}>
    <input aria-label={t(label)} className={inputClass} maxLength={500} value={String(settings[key])} placeholder={placeholder} disabled={disabled} onChange={event => update(key, event.target.value)} />
  </Field>;
  const check = (key: keyof CompanyDigitizationSettings, label: string) => <label className="flex min-h-8 cursor-pointer items-start gap-2.5 text-[13px] font-medium leading-5 text-[#10233A]">
    <input type="checkbox" className="mt-0.5 shrink-0" checked={Boolean(settings[key])} disabled={disabled} onChange={event => update(key, event.target.checked)} /><span>{t(label)}</span>
  </label>;
  const select = (key: keyof CompanyDigitizationSettings, label: string, options: { value: string; label: string }[]) => <Field label={label}>
    <SearchableSelect ariaLabel={t(label)} value={String(settings[key])} options={options.map(option => ({ ...option, label: t(option.label) }))} disabled={disabled} onChange={value => update(key, value)} className={inputClass} portalMenu />
  </Field>;
  const save = async () => {
    if (disabled) return;
    setSaving(true); setError(''); setSaved(false);
    try {
      const { data, error: readError } = await supabase.from('companies').select('*').eq('id', company.id);
      const current = data?.[0] as unknown as Company | undefined;
      if (readError || !current) throw new Error('Could not load organization settings.');
      if (!canEditCompanySettings(current) || isInactiveRecord(current)) throw new Error('You do not have permission to change this organization.');
      if (current.document_export_settings !== company.document_export_settings || current.primary_export_format !== company.primary_export_format) throw new Error('Settings changed in another window. Reopen this panel and try again.');
      const patch = { primary_export_format: format, document_export_settings: serializeCompanyDigitizationSettings(settings) };
      const result = await supabase.from('companies').update(patch).eq('id', company.id);
      if (result.error) throw new Error(result.error.message);
      await recordAdministrativeAction(company.id, 'Organization settings', 'Export settings updated', `Export format: ${format}`);
      onUpdated({ ...current, ...patch }); setApiKey(''); setSaved(true);
      window.dispatchEvent(new CustomEvent('finansu-harmonija:settings-data-changed', { detail: { scope: 'organizations' } }));
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save.'); }
    finally { setSaving(false); }
  };
  return <div className="flex h-full min-h-0 min-w-0 flex-col font-montserrat" data-company-digitization-dialog>
    <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pb-5 pr-2 [scrollbar-gutter:stable]">
      <Section title="Export settings"><Field label="Export format"><SearchableSelect value={format} options={[...new Set([...COMPANY_EXPORT_FORMATS, format])]} ariaLabel={t('Export format')} onChange={value => { setFormat(value); setSaved(false); }} disabled={disabled} portalMenu className={inputClass} /></Field></Section>
      {rivile && <Section title="Rivilė settings">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Field label="API key"><input type="password" aria-label={t('API key')} autoComplete="off" value={apiKey} onChange={event => setApiKey(event.target.value)} disabled={disabled} className={inputClass} />
            <p className="text-[11px] leading-4 text-[#7288A3]">{t('Contact Rivilė to create an API key and enter it here.')}</p></Field>
          {textField('database', 'Database', 'EILONA')}
          {textField('itemAccountLinkCode', 'Item account link code')}{textField('itemType', 'Item type')}
        </div>
        <p className="flex items-start gap-2 rounded-md bg-[#F2F6FA] px-3 py-2 text-[11px] leading-4 text-[#7288A3]"><Info size={14} className="mt-0.5 shrink-0" />{t('The API connection is not configured. API keys are not saved in this browser; saving stores settings only.')}</p>
      </Section>}
      <Section title="Expense update settings"><div className="grid grid-cols-1 gap-x-5 gap-y-2 lg:grid-cols-2">
        {check('updateProducts', 'Automatically update products')}{check('updateServices', 'Automatically update services')}{check('updateCodes', 'Automatically update codes')}
        {rivile && check('postInRivile', 'Automatically post the document in Rivilė')}
      </div></Section>
      <Section title="Payment account codes"><div className="grid grid-cols-1 gap-4 lg:grid-cols-2">{textField('salesPaymentAccount', 'Sales payment account code')}{textField('purchasePaymentAccount', 'Purchase payment account code')}</div></Section>
      {rivile && <Section title="Operation type" description="Choose the operation type to send to Rivilė."><div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {select('salesOperation', 'Sales operation type', SALES_OPERATION_TYPES.map(value => ({ value, label: value })))}
        {select('purchaseOperation', 'Purchase operation type', PURCHASE_OPERATION_TYPES.map(value => ({ value, label: value })))}
      </div></Section>}
      <Section title="Individual buyer code"><div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {select('individualBuyerCode', 'Code assignment', [{ value: 'unique', label: 'Unique value per person' }, { value: 'fixed', label: 'Fixed value' }])}
        {settings.individualBuyerCode === 'fixed' && textField('fixedBuyerCode', 'Fixed buyer code')}
      </div></Section>
      <Section title="Primary line code">{select('primaryLineCode', 'Primary line code', [{ value: 'barcode', label: 'Barcode' }, { value: 'code', label: 'Code' }])}
        <p className="text-[12px] leading-5 text-[#7288A3]">{t(settings.primaryLineCode === 'barcode' ? 'Export uses the barcode. If it is missing, the line code is used.' : 'Export uses the line code.')}</p>
      </Section>
      <Section title="Automatic additional column assignment">{select('additionalColumnsAt', 'Assignment stage', [{ value: 'digitization', label: 'During digitization' }, { value: 'export', label: 'During export' }])}</Section>
      <Section title="Other settings">{select('vatSeparation', 'VAT separation', [{ value: 'automatic', label: 'Automatic' }, { value: 'separate-non-payers', label: 'Separate invoice VAT for non-VAT payers' }, { value: 'include-payers', label: 'Do not separate invoice VAT for VAT payers' }])}
        <div className="space-y-2">{check('foreignVatAsCompanyCode', 'Use VAT number as company code for foreign companies')}{check('dueDateFromInvoiceDate', 'Use invoice date as due date if no due date is specified')}{check('createCompaniesOnExport', 'Create new companies during export')}{check('createProductsOnExport', 'Create new products during export')}{check('exportAfterDigitization', 'Export invoices immediately after digitization')}</div>
      </Section>
      <Section title="Additional column settings"><AdditionalColumnSettings company={company} value={settings.additionalColumns} disabled={disabled} onChange={value => update('additionalColumns', value)} /></Section>
    </div>
    <footer className="flex min-h-[60px] shrink-0 items-center justify-end gap-2 border-t border-[#D3E1EC] pt-4">
      <div aria-live="polite" className="mr-auto text-[12px]">{error ? <p role="alert" className="text-[#B42318]">{t(error)}</p> : saved ? <p role="status" className="text-[#27845E]">{t('Changes saved successfully.')}</p> : null}</div>
      <PageActionButton disabled={saving} onClick={onClose}>{t('Close')}</PageActionButton><PageActionButton disabled={disabled} icon={<Save size={15} />} onClick={() => void save()}>{t(saving ? 'Saving…' : 'Save changes')}</PageActionButton>
    </footer>
  </div>;
}
