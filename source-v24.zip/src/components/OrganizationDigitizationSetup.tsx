import { useState, type ReactNode } from 'react';
import { Info, Save } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { supabase, recordAdministrativeAction, type Company } from '../lib/supabase';
import { canEditCompanySettings } from '../lib/documentEditAccess';
import { isInactiveRecord } from '../lib/recordLifecycle';
import { COMPANY_EXPORT_FORMATS, DEFAULT_DIGITIZATION_SETTINGS, initializeExportFormat, normalizeFormatProfile, parseCompanyDigitizationSettings, serializeCompanyDigitizationSettings, type ExportFormatProfile } from '../lib/companyDigitizationSettings';
import { exportSchema, exportSections, EXPORT_OPTION_LABELS, type ExportField } from '../lib/exportFormatSchemas';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import AdditionalColumnSettings from './AdditionalColumnSettings';
import ExportSettingsHelpLink from './ExportSettingsHelpLink';
import IntegrationHelpLink from './IntegrationHelpLink';

const inputClass = 'h-10 w-full rounded-md border border-[#D3E1EC] bg-white px-3 font-montserrat text-[13px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-1 focus:ring-[#007EA7]/20 disabled:bg-[#F5F8FB]';
function Section({ title, children, format }: { title: string; children: ReactNode; format: string }) {
  return <section className="rounded-lg border border-[#D3E1EC] bg-white">
    <h4 className="flex items-center justify-between gap-3 rounded-t-lg border-b border-[#E5EDF9] bg-[#F2F6FA] px-4 py-3 text-[13px] font-semibold text-[#10233A]">{t(title)}<ExportSettingsHelpLink format={format} topic={title === 'Export settings' ? 'overview' : title} label={title} /></h4>
    <div className="space-y-4 p-4">{children}</div>
  </section>;
}
function Field({ label, children, help }: { label: string; children: ReactNode; help?: ReactNode }) {
  return <div className="min-w-0 space-y-1.5"><div className="flex items-center gap-1.5 text-[12px] font-medium leading-[18px] text-[#7288A3]">{t(label)}{help}</div>{children}</div>;
}

export default function OrganizationDigitizationSetup({ company, onUpdated, onClose }: { company: Company; onUpdated: (company: Company) => void; onClose: () => void }) {
  const [format, setFormat] = useState(company.primary_export_format || 'Rivilė');
  const [initial] = useState(() => {
    try { return { settings: initializeExportFormat(parseCompanyDigitizationSettings(company.document_export_settings, company as unknown as Record<string, unknown>), company.primary_export_format || 'Rivilė'), error: '' }; }
    catch { return { settings: { ...DEFAULT_DIGITIZATION_SETTINGS }, error: 'Could not read export settings.' }; }
  });
  const [settings, setSettings] = useState(initial.settings);
  const [saving, setSaving] = useState(false), [saved, setSaved] = useState(false), [error, setError] = useState(initial.error);
  // Credentials exist only in memory. They never enter company data, audit history or exports.
  const [credentials, setCredentials] = useState<Record<string, string>>({});
  const allowed = !initial.error && !isInactiveRecord(company) && canEditCompanySettings(company);
  const disabled = saving || !allowed;
  const schema = exportSchema(format);
  const sections = exportSections(format);
  const profile = settings.formatProfiles[format] || normalizeFormatProfile(format, undefined);
  const changed = () => { setSaved(false); setError(''); };
  const updateProfile = (patch: Partial<ExportFormatProfile>) => {
    setSettings(previous => ({ ...previous, formatProfiles: { ...previous.formatProfiles, [format]: { ...normalizeFormatProfile(format, previous.formatProfiles[format]), ...patch } } }));
    changed();
  };
  const updateField = (key: string, value: string | boolean) => updateProfile({ fields: { ...profile.fields, [key]: value } });
  const renderField = (field: ExportField) => {
    const value = profile.fields[field.key];
    if (field.key === 'fixedBuyerCode' && profile.fields.individualBuyerCode !== 'fixed') return null;
    if (field.type === 'checkbox') return <div key={field.key} className="flex min-h-10 items-start gap-2 py-2"><label className="flex cursor-pointer items-start gap-2.5 text-[13px] font-medium leading-5 text-[#10233A]">
      <input type="checkbox" className="mt-0.5 shrink-0" checked={value === true} disabled={disabled} onChange={event => updateField(field.key, event.target.checked)} /><span>{t(field.label)}</span>
    </label><span className="mt-0.5"><ExportSettingsHelpLink format={format} topic={field.key} label={field.label} /></span></div>;
    return <Field key={field.key} label={field.label} help={<ExportSettingsHelpLink format={format} topic={field.key} label={field.label} />}>
      {field.type === 'select' ? <SearchableSelect value={String(value ?? '')} options={(field.options || []).map(option => ({ value: option, label: t(EXPORT_OPTION_LABELS[option] || option) }))} ariaLabel={t(field.label)} disabled={disabled} onChange={next => updateField(field.key, next)} className={inputClass} portalMenu />
        : field.type === 'password' ? <input type="password" aria-label={t(field.label)} autoComplete="new-password" value={credentials[field.key] || ''} disabled={disabled} className={inputClass} onChange={event => { setCredentials(previous => ({ ...previous, [field.key]: event.target.value })); changed(); }} />
        : <input type={field.type === 'number' ? 'number' : 'text'} min={field.type === 'number' ? 0 : undefined} step={field.type === 'number' ? 'any' : undefined} aria-label={t(field.label)} maxLength={500} value={String(value ?? '')} disabled={disabled} className={inputClass} onChange={event => updateField(field.key, event.target.value)} />}
      {field.help && <p className="text-[11px] leading-4 text-[#7288A3]">{t(field.help)}</p>}
    </Field>;
  };
  const save = async () => {
    if (disabled) return;
    setSaving(true); setError(''); setSaved(false);
    try {
      const { data, error: readError } = await supabase.from('companies').select('*').eq('id', company.id);
      const current = data?.[0] as unknown as Company | undefined;
      if (readError || !current) throw new Error('Could not load organization settings.');
      if (!canEditCompanySettings(current) || isInactiveRecord(current)) throw new Error('You do not have permission to change this organization.');
      if (current.document_export_settings !== company.document_export_settings || current.primary_export_format !== company.primary_export_format) throw new Error('Settings changed in another window. Reopen this panel and try again.');
      const patch = { primary_export_format: format, document_export_settings: serializeCompanyDigitizationSettings(settings, format) };
      const result = await supabase.from('companies').update(patch).eq('id', company.id);
      if (result.error) throw new Error(result.error.message);
      await recordAdministrativeAction(company.id, 'Organization settings', 'Export settings updated', `Export format: ${format}`);
      onUpdated({ ...current, ...patch }); setCredentials({}); setSaved(true);
      window.dispatchEvent(new CustomEvent('finansu-harmonija:settings-data-changed', { detail: { scope: 'organizations' } }));
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save.'); }
    finally { setSaving(false); }
  };
  return <div className="flex h-full min-h-0 min-w-0 flex-col font-montserrat" data-company-digitization-dialog>
    <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pb-5 pr-2 [scrollbar-gutter:stable]">
      <Section title="Export settings" format={format}><Field label="Export format" help={<IntegrationHelpLink integration={format} label={format} />}><SearchableSelect value={format} options={[...new Set([...COMPANY_EXPORT_FORMATS, format])]} ariaLabel={t('Export format')} onChange={next => { setFormat(next); setCredentials({}); changed(); }} disabled={disabled} portalMenu className={inputClass} /></Field></Section>
      {sections.some(section => section.fields.some(field => field.type === 'password')) && <p className="flex items-start gap-2 rounded-md border border-[#D3E1EC] bg-[#F2F6FA] px-3 py-2 text-[11px] leading-4 text-[#7288A3]"><Info size={14} className="mt-0.5 shrink-0" />{t('The API connection is not configured. API keys are not saved in this browser; saving stores settings only.')}</p>}
      {sections.map((section, index) => <Section key={`${format}:${index}`} title={section.title} format={format}>
        <div className="grid grid-cols-1 gap-x-5 gap-y-4 lg:grid-cols-2">{section.fields.map(renderField)}</div>
        {section.title === 'Primary line code' && <p className="text-[12px] leading-5 text-[#7288A3]">{t(profile.fields.primaryLineCode === 'barcode' ? 'Export uses the barcode. If it is missing, the line code is used.' : 'Export uses the line code.')}</p>}
      </Section>)}
      <Section title="Additional column settings" format={format}><AdditionalColumnSettings company={company} columns={schema.columns} value={profile.columns} disabled={disabled} helpFormat={format} onChange={columns => updateProfile({ columns })} /></Section>
    </div>
    <footer className="flex min-h-[60px] shrink-0 items-center justify-end gap-2 border-t border-[#D3E1EC] pt-4">
      <div aria-live="polite" className="mr-auto text-[12px]">{error ? <p role="alert" className="text-[#B42318]">{t(error)}</p> : saved ? <p role="status" className="text-[#27845E]">{t('Changes saved successfully.')}</p> : null}</div>
      <PageActionButton disabled={saving} onClick={onClose}>{t('Close')}</PageActionButton><PageActionButton disabled={disabled} icon={<Save size={15} />} onClick={() => void save()}>{t(saving ? 'Saving…' : 'Save changes')}</PageActionButton>
    </footer>
  </div>;
}
