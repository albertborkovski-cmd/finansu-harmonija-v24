import { translateUi as uiText } from '../i18n/language';
import { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { supabase, type Company } from '../lib/supabase';
import { getOcrDocumentTypeRouting, type OcrDocumentTypeRouting } from '../lib/ocrApprovalRouting';
import { canEditOcrApprovalRouting, loadOcrApprovalRouting } from '../lib/ocrApprovalRoutingStore';
import type { OrganizationReferenceRecord } from './OrganizationReferenceValuesView';
import SearchableSelect from './SearchableSelect';
import MultiSelectField from './MultiSelectField';
import { SaveButton, CancelButton } from './ScopedActionButtons';

export default function OcrDocumentTypeEditor({ record, isNew, parentName, onClose, onSave }: {
  record: OrganizationReferenceRecord; isNew: boolean; parentName?: string;
  onClose: () => void;
  onSave: (record: OrganizationReferenceRecord, routing: OcrDocumentTypeRouting | null) => void;
}) {
  const [draft, setDraft] = useState(record);
  const [initial] = useState(() => {
    try { return { routing: getOcrDocumentTypeRouting(loadOcrApprovalRouting().rules, record.code), error: '' }; }
    catch (error) { return { routing: { mode: 'inherit', organizationIds: [] } as OcrDocumentTypeRouting, error: (error as Error).message }; }
  });
  const [routing, setRouting] = useState(initial.routing);
  const [routingChanged, setRoutingChanged] = useState(false);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [companyError, setCompanyError] = useState('');
  const [error, setError] = useState('');
  const panelRef = useRef<HTMLElement>(null);
  const editable = canEditOcrApprovalRouting();
  useEffect(() => {
    const previousFocus = document.activeElement as HTMLElement | null;
    panelRef.current?.querySelector<HTMLInputElement>('input')?.focus();
    return () => previousFocus?.focus();
  }, []);
  useEffect(() => {
    let active = true;
    void supabase.from('companies').select('*').then(result => {
      if (!active) return;
      if (result.error) setCompanyError('Organizations could not be loaded. Please reopen the form to try again.');
      else setCompanies(result.data as unknown as Company[]);
      setLoading(false);
    }).catch(() => { if (active) { setCompanyError('Organizations could not be loaded. Please reopen the form to try again.'); setLoading(false); } });
    return () => { active = false; };
  }, []);
  const companyOptions = companies.map(company => ({ id: company.id,
    label: companies.filter(other => other.name === company.name).length > 1 ? `${company.name} · ${company.id}` : company.name }));
  const companyLabels = routing.organizationIds.map(id => companyOptions.find(option => option.id === id)?.label || id);
  const updateRouting = (next: OcrDocumentTypeRouting) => { setRouting(next); setRoutingChanged(true); setError(''); };
  const submit = () => {
    try {
      if (initial.error) throw new Error(initial.error);
      if (routingChanged && routing.mode === 'organizations') {
        if (loading || companyError) throw new Error(companyError || 'Wait for organizations to load.');
        if (!routing.organizationIds.length) throw new Error('Select at least one organization.');
        if (routing.organizationIds.some(id => !companies.some(company => company.id === id))) throw new Error('Select available organizations.');
      }
      onSave(draft, routingChanged ? routing : null);
    } catch (cause) { setError((cause as Error).message); }
  };
  return <div className="fixed inset-0 z-[150] flex justify-end bg-[#10233A]/10" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <aside ref={panelRef} role="dialog" aria-modal="true" aria-labelledby="document-type-editor-title"
      className="flex h-full w-[480px] max-w-[calc(100vw-24px)] flex-col bg-white shadow-[-2px_0_0_#E5EDF9] font-montserrat"
      onKeyDown={event => {
        if (event.key === 'Escape' && !event.defaultPrevented && !document.querySelector('[role="listbox"]')) { event.stopPropagation(); onClose(); }
        if (event.key === 'Tab') {
          const fields = Array.from(panelRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled)') || []).filter(element => element.offsetParent !== null);
          const first = fields[0], last = fields.at(-1);
          if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
        }
      }}>
      <header className="flex shrink-0 items-center justify-between gap-4 border-b border-[#D3E1EC] p-6">
        <div><h2 id="document-type-editor-title" className="text-[20px] font-semibold text-[#10233A]">{isNew ? uiText('Create document type') : uiText('Edit document type')}</h2><p className="mt-1 text-[12px] text-[#7288A3]">{parentName ? `${parentName} / ` : ''}{record.fullName || uiText('New document type')}</p></div>
        <button type="button" aria-label={uiText("Close document type form")} onClick={onClose} className="text-[#7288A3] hover:text-[#007EA7]"><X size={22} /></button>
      </header>
      <form id="document-type-edit-form" onSubmit={event => { event.preventDefault(); submit(); }} className="min-h-0 flex-1 overflow-y-auto p-6">
        <fieldset disabled={!editable || Boolean(initial.error)} className="flex min-w-0 flex-col gap-5">
          {([{ key: 'code', label: 'Code', required: true }, { key: 'fullName', label: 'Name', required: true }, { key: 'description', label: 'Description' }] as const).map(field => <label key={field.key} className="flex flex-col gap-2 text-[14px] font-semibold text-[#10233A]">
            <span>{uiText(field.label)}{'required' in field && <span className="ml-1 text-[#FF4550]">*</span>}</span>
            <input aria-label={uiText(field.label)} required={'required' in field} value={draft[field.key]} onChange={event => setDraft(current => ({ ...current, [field.key]: event.target.value }))}
              className="h-[42px] w-full rounded-lg border border-[#D3E1EC] px-3 text-[14px] font-medium outline-none focus:border-[#007EA7]" />
          </label>)}
          <div className="flex flex-col gap-2"><span className="text-[14px] font-semibold text-[#10233A]">{uiText("Status")}</span><SearchableSelect ariaLabel={uiText("Document type status")} value={draft.status} options={['Active', 'Inactive']} onChange={status => setDraft(current => ({ ...current, status }))} portalMenu menuClassName="!z-[5200]" /></div>
          <section aria-labelledby="teamlead-routing-title" className="mt-1 border-t border-[#D3E1EC] pt-5">
            <h3 id="teamlead-routing-title" className="mb-4 text-[14px] font-semibold text-[#10233A]">{uiText("TeamLead approval")}</h3>
            <div className="flex flex-col gap-2"><span className="text-[13px] font-medium text-[#7288A3]">{uiText("Send to TeamLead")}</span>
              <SearchableSelect ariaLabel={uiText("Send to TeamLead")} value={routing.mode} onChange={mode => updateRouting({ ...routing, mode: mode as OcrDocumentTypeRouting['mode'] })}
                options={[{ value: 'inherit', label: parentName ? `Inherit from ${parentName}` : 'Use default routing' },
                  { value: 'disabled', label: 'Disabled — send to FH' }, { value: 'all', label: 'Enabled — all organizations' },
                  { value: 'organizations', label: 'Enabled — selected organizations' },
                  ...(initial.routing.mode === 'custom' ? [{ value: 'custom', label: 'Keep existing routing rules' }] : [])]} portalMenu menuClassName="!z-[5200]" />
            </div>
            {routing.mode === 'organizations' && <div className="mt-4">
              <MultiSelectField label={uiText("Organizations")} required options={companyOptions.map(option => option.label)} value={companyLabels} placeholder={loading ? uiText('Loading organizations…') : uiText('Select organizations')} showSelectionActions portalMenu
                onChange={labels => updateRouting({ ...routing, organizationIds: labels.map(label => companyOptions.find(option => option.label === label)?.id || label) })} />
              {companyError && <p role="alert" className="mt-2 text-[12px] text-[#B42318]">{companyError}</p>}
              <p className="mt-2 text-[12px] leading-5 text-[#7288A3]">{uiText("Only selected organizations require TeamLead approval. Other organizations are sent to FH after OCR review.")}</p>
            </div>}
            {routing.mode === 'inherit' && <p className="mt-3 text-[12px] leading-5 text-[#7288A3]">{parentName ? `Uses the ${parentName} routing settings.` : uiText('Uses existing organization settings. Without a matching setting, TeamLead approval is required.')}</p>}
          </section>
        </fieldset>
        {(error || initial.error) && <p role="alert" className="mt-4 text-[12px] text-[#B42318]">{error || initial.error}</p>}
        {!editable && <p role="status" className="mt-4 text-[12px] text-[#7288A3]">{uiText("You do not have permission to edit document types.")}</p>}
      </form>
      <footer className="flex shrink-0 justify-end gap-3 border-t border-[#D3E1EC] bg-white px-6 py-5"><CancelButton onClick={onClose} /><SaveButton onClick={submit} disabled={!editable || Boolean(initial.error) || !draft.code.trim() || !draft.fullName.trim() || (routing.mode === 'organizations' && !routing.organizationIds.length)}>{isNew ? uiText('Create') : uiText('Save changes')}</SaveButton></footer>
    </aside>
  </div>;
}
