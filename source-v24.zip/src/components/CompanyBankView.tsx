import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useMemo, useRef, useState, type SetStateAction } from "react";
import { Landmark, Loader2, Pencil, Plus, Upload, X } from "lucide-react";
import { supabase, saveBankProcessingStatus, type Company, type DbDocument } from "../lib/supabase";
import { importMenuRecords } from "../lib/menuImport";
import { mapRow, type Document } from "./Documents";
import { usePersistentState } from "../hooks/usePersistentState";
import ColumnSettingsPanel, { type ColConfig } from "./ColumnSettingsPanel";
import ColumnSortButton, { useMultiColumnSort } from "./ColumnSortButton";
import CompanyBreadcrumb from "./CompanyBreadcrumb";
import HorizontalTableScrollbar from "./HorizontalTableScrollbar";
import OcrSearchField from "./OcrSearchField";
import { PageActionButton, PageHeader } from "./PageHeader";
import RefreshAllButton from "./RefreshAllButton";
import { ColumnSettingsButton, ImportDataButton } from "./ScopedActionButtons";
import SystemAddFilters from "./SystemAddFilters";
import TablePagination from "./TablePagination";
import { TABLE_BATCH_SIZE } from "../lib/tablePaging";
import { ResizeHandle, useColumnResize } from "./useColumnResize";
import RelatedObjectPreview from "./RelatedObjectPreview";
import BankTransactionEditor from './BankTransactionEditor';
import { BANK_RECONCILIATION_STATUSES, bankPaymentPurpose, bankReconciliationForDisplay, bankReconciliationKey, companyBankAccounts, type BankTransaction } from '../lib/bankTransaction';
import { canEditCompanyBankEntries, loadCompanyBankDocument } from '../lib/companyBankEditing';
import { SETTINGS_DATA_CHANGED_EVENT } from '../lib/linkedSettingsData';
import { BANK_DEFAULT_COLUMNS as DEFAULT_COLUMNS, resolveBankColumns } from '../lib/companyBankColumns';
import { companyBankAmount, formatBankAmount } from '../lib/companyBankAmounts';
import { companyBankAccountLabel } from '../lib/companyBankAccountDisplay';
import { BANK_PROCESSING_STATUSES, bankProcessingStatus, bankProcessingStatusEditError } from '../lib/bankProcessingStatus';
import DocumentInlineSelectCell from './DocumentInlineSelectCell';
import { canCreateCompanyBankTransaction, newBankTransactionDocument } from '../lib/bankTransactionCreation';
import BankStatementImportDialog from './BankStatementImportDialog';

type BankColumnKey =
  | "bankAccount" | "accountCode" | "transferNo" | "date"
  | "counterpartyName" | "counterpartyCode" | "postingType" | "amount"
  | "counterpartyIban" | "bookingDate"
  | "currency" | "exchangeRateDate" | "paymentPurpose" | "referenceNo"
  | "costCenter" | "notes" | "glAccounts" | "settledDocuments"
  | "id" | "attachmentsCount" | "status" | "reconciliationStatus";

type BankRow = Record<BankColumnKey, string> & { documentId: string; amountValue: number | null; statusDisabledReason: string; reconciliationDemo: boolean };
const BANK_STATUS_OPTIONS = [...BANK_PROCESSING_STATUSES];
const RECONCILIATION_BADGE_STYLES: Record<string, string> = {
  Unmatched: 'bg-[#FFF3E5] text-[#A45C00]',
  'Partially matched': 'bg-[#E5EDF9] text-[#007EA7]',
  Matched: 'bg-[#E7F5ED] text-[#237A4B]',
};

type BankAccount = {
  iban?: string;
  bank?: string;
  bankCode?: string;
  primary?: boolean;
};

const COUNTERPARTIES_STORAGE_KEY = "finansu-harmonija:v7:settings:counterparties";

function parseBankAccount(company: Company): BankAccount {
  try {
    const accounts = JSON.parse(company.organization_bank_accounts ?? "[]") as BankAccount[];
    if (!Array.isArray(accounts)) return {};
    return accounts.find((account) => account.primary) ?? accounts[0] ?? {};
  } catch {
    return {};
  }
}

function documentGlAccounts(document: Document) {
  const values = [
    document.expenseAccount,
    ...document.lineItems.map((line) => line.expense),
    ...document.summaryLineItems.map((line) => line.expense),
  ].map((value) => value.trim()).filter(Boolean);
  return Array.from(new Set(values)).join(", ") || "—";
}

function loadCounterpartyCodes() {
  try {
    const parsed = JSON.parse(window.localStorage.getItem(COUNTERPARTIES_STORAGE_KEY) ?? "[]") as Company[];
    return new Map(
      (Array.isArray(parsed) ? parsed : []).map((counterparty) => [
        counterparty.name.trim().toLocaleLowerCase(),
        counterparty.company_code || "—",
      ]),
    );
  } catch {
    return new Map<string, string>();
  }
}

function toBankRow(document: Document, account: BankAccount, counterpartyCodes: Map<string, string>, company: Company): BankRow {
  const date = document.operationDate || document.documentDate || document.receiveDate || "—";
  const bank = document.inlineSource.bank_transaction as BankTransaction | undefined;
  const transactionAccount = bank ? {
    ...companyBankAccounts(company).find(row => row.iban.replace(/\s/g, '') === bank.bankAccount.replace(/\s/g, '')),
    iban: bank.bankAccount,
  } : account;
  const amountValue = companyBankAmount({ id: document.id, total_amount: document.totalAmount,
    amount_without_vat: document.amountWithoutVat, type: document.type,
    document_purpose: document.documentPurpose, bank_transaction: bank });
  const reconciliation = bankReconciliationForDisplay(document.id, company.id, localStorage.getItem(bankReconciliationKey(company.id)));
  return {
    documentId: document.id,
    amountValue,
    statusDisabledReason: bankProcessingStatusEditError(document.inlineSource, true),
    bankAccount: companyBankAccountLabel(document.id, company.id, transactionAccount),
    accountCode: account.bankCode || "—",
    transferNo: document.orderNo || document.number || "—",
    date,
    counterpartyName: document.clientCounterparty || "—",
    counterpartyCode: document.counterpartyCode || counterpartyCodes.get(document.clientCounterparty.trim().toLocaleLowerCase()) || "—",
    counterpartyIban: bank?.counterpartyIban?.trim() || '—',
    bookingDate: bank?.bookingDate?.trim() || '—',
    postingType: document.documentPurpose || document.type || "—",
    amount: formatBankAmount(amountValue),
    currency: document.currency || "—",
    exchangeRateDate: date,
    paymentPurpose: bankPaymentPurpose(document.id, company.id, document.note || document.documentSubtype || document.documentType || "—"),
    referenceNo: document.number || document.orderNo || "—",
    costCenter: document.costCenter || "—",
    notes: document.note || "—",
    glAccounts: documentGlAccounts(document),
    settledDocuments: reconciliation.documents.map(row => row.number).join(', ') || '—',
    status: bankProcessingStatus(document.inlineSource),
    reconciliationStatus: reconciliation.status,
    reconciliationDemo: reconciliation.demo,
    id: document.id,
    attachmentsCount: document.imageUrl ? "1" : "0",
    ...(bank ? {
      transferNo: bank.transferNo || '—', date: bank.date,
      accountCode: companyBankAccounts(company).find(row => row.iban === bank.bankAccount)?.bankCode || '—',
      counterpartyName: bank.counterpartyName || '—', counterpartyCode: bank.counterpartyCode || '—',
      currency: bank.currency, exchangeRateDate: bank.exchangeRateDate,
      paymentPurpose: bank.paymentPurpose || '—', referenceNo: bank.referenceNo || '—', notes: bank.notes || '—',
      glAccounts: [...new Set(bank.allocations.map(row => row.glAccount).filter(Boolean))].join(', ') || '—',
      costCenter: [...new Set(bank.allocations.map(row => row.costCenter).filter(Boolean))].join(', ') || '—',
      postingType: [...new Set(bank.allocations.map(row => row.description).filter(Boolean))].join(', ') || '—',
      attachmentsCount: String(bank.attachments.length + (document.imageUrl ? 1 : 0)),
    } : {}),
  };
}

export default function CompanyBankView({ company, initialRecordId, onRelatedObjectBack, onOpenReconciliation }: { company: Company; initialRecordId?: string; onRelatedObjectBack?: () => void; onOpenReconciliation?: () => void }) {
  const [editor, setEditor] = useState<DbDocument>();
  const [newTransaction, setNewTransaction] = useState<DbDocument>();
  const [showStatementImport, setShowStatementImport] = useState(false);
  const [importNotice, setImportNotice] = useState('');
  const [canCreate, setCanCreate] = useState(() => canCreateCompanyBankTransaction(company));
  const [openingId, setOpeningId] = useState('');
  const [editError, setEditError] = useState('');
  const [canEdit, setCanEdit] = useState(() => canEditCompanyBankEntries(company));
  const editRequest = useRef(0);
  const [relatedObjectClosed, setRelatedObjectClosed] = useState(false);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [refreshRevision, setRefreshRevision] = useState(0);
  const [showColumns, setShowColumns] = useState(false);
  const [filterKeys, setFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const [page, setPage] = useState(1);
  const [savedColumns, setSavedColumns] = usePersistentState<ColConfig[]>(
    `finansu-harmonija:v12:company-bank-columns:${company.id}`,
    DEFAULT_COLUMNS,
  );
  const columns = useMemo(() => resolveBankColumns(savedColumns), [savedColumns]);
  const setColumns = useCallback((next: SetStateAction<ColConfig[]>) => {
    setSavedColumns(previous => typeof next === 'function' ? next(resolveBankColumns(previous)) : next);
  }, [setSavedColumns]);
  useEffect(() => {
    if (JSON.stringify(savedColumns) !== JSON.stringify(columns)) setSavedColumns(columns);
  }, [savedColumns, columns, setSavedColumns]);
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const visibleColumns = columns.filter((column) => column.visible);
  const { startResize } = useColumnResize(columns, setColumns);

  const loadDocuments = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from("documents").select("*")
      .eq("company_id", company.id).order("created_at", { ascending: false });
    if (!error && data)
      setDocuments((data as unknown as DbDocument[]).map(mapRow));
    setLoading(false);
  }, [company.id]);

  useEffect(() => { void loadDocuments(); }, [loadDocuments, refreshRevision]);

  useEffect(() => {
    setEditor(undefined); setNewTransaction(undefined); setShowStatementImport(false); setImportNotice(''); setOpeningId(''); setEditError('');
    const refreshAccess = () => {
      const allowed = canEditCompanyBankEntries(company);
      setCanEdit(allowed);
      const createAllowed = canCreateCompanyBankTransaction(company);
      setCanCreate(createAllowed);
      if (!createAllowed) { setNewTransaction(undefined); setShowStatementImport(false); }
      if (!allowed) { editRequest.current += 1; setEditor(undefined); setOpeningId(''); }
    };
    refreshAccess();
    window.addEventListener('storage', refreshAccess);
    window.addEventListener(SETTINGS_DATA_CHANGED_EVENT, refreshAccess);
    return () => {
      editRequest.current += 1;
      window.removeEventListener('storage', refreshAccess);
      window.removeEventListener(SETTINGS_DATA_CHANGED_EVENT, refreshAccess);
    };
  }, [company]);

  async function openEditor(documentId: string) {
    if (!canEdit || openingId) return;
    const request = ++editRequest.current;
    setOpeningId(documentId); setEditError('');
    try {
      const document = await loadCompanyBankDocument(documentId, company.id);
      if (request === editRequest.current) setEditor(document);
    } catch (cause) {
      if (request === editRequest.current) setEditError(cause instanceof Error ? cause.message : 'Could not open this bank entry.');
    } finally { if (request === editRequest.current) setOpeningId(''); }
  }
  const closeEditor = () => { setEditor(undefined); void loadDocuments(); };
  const openNewTransaction = () => {
    if (!canCreateCompanyBankTransaction(company)) { setEditError('You do not have permission to create bank transactions.'); return; }
    setNewTransaction(newBankTransactionDocument(company, crypto.randomUUID()));
  };
  async function changeStatus(row: BankRow, value: string) {
    const updated = mapRow(await saveBankProcessingStatus(row.documentId, company.id, value, row.status));
    setDocuments(previous => previous.map(document => document.id === updated.id ? updated : document));
  }

  const rows = useMemo(() => {
    void refreshRevision;
    const account = parseBankAccount(company);
    const counterpartyCodes = loadCounterpartyCodes();
    return documents.map((document) => toBankRow(document, account, counterpartyCodes, company));
  }, [company, documents, refreshRevision]);

  const filterColumns = useMemo(() => DEFAULT_COLUMNS.map((column) => ({
    key: column.key,
    label: column.label,
    options: Array.from(new Set([
      ...(column.key === 'reconciliationStatus' ? BANK_RECONCILIATION_STATUSES : []),
      ...rows.map((row) => row[column.key as BankColumnKey]),
    ])),
  })), [rows]);

  const filteredRows = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return rows.filter((row) => {
      if (normalized && !DEFAULT_COLUMNS.some((column) => row[column.key as BankColumnKey].toLocaleLowerCase().includes(normalized))) return false;
      return filterKeys.every((key) => {
        if (!DEFAULT_COLUMNS.some(column => column.key === key)) return true;
        const selected = filterValues[key] ?? [];
        return selected.length === 0 || selected.includes(row[key as BankColumnKey]);
      });
    });
  }, [filterKeys, filterValues, query, rows]);

  const { sortedRows, changeSort, directionFor } = useMultiColumnSort<BankRow, BankColumnKey>(
    filteredRows,
    (row, key) => key === 'amount' ? row.amountValue : row[key],
  );
  const itemsPerPage = TABLE_BATCH_SIZE;
  const totalPages = Math.max(1, Math.ceil(sortedRows.length / itemsPerPage));
  const currentPage = Math.min(page, totalPages);
  const visibleRows = sortedRows.slice(0, currentPage * itemsPerPage);

  useEffect(() => setPage(1), [company.id, filterKeys, filterValues, query]);

  if (initialRecordId && !relatedObjectClosed) {
    const record = rows.find(row => row.documentId === initialRecordId);
    return <RelatedObjectPreview companyName={company.name} section="Bank transaction" title={record ? `Bank operation · ${record.transferNo}` : uiText('Bank operation')}
      fields={record ? DEFAULT_COLUMNS.map(column => ({ label: column.label, value: record[column.key as BankColumnKey] })) : []}
      loading={loading} unavailable={!loading && !record} onBack={onRelatedObjectBack ?? (() => setRelatedObjectClosed(true))} />;
  }

  return (
    <div className="flex min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
      <PageHeader title={uiText("Bank transaction")} actions={<>
        <PageActionButton icon={<Upload size={16} />} onClick={() => { if (canCreateCompanyBankTransaction(company)) { setImportNotice(''); setShowStatementImport(true); } }} disabled={!canCreate || Boolean(openingId)} ariaHasPopup="dialog">{uiText("Import statement")}</PageActionButton>
        <PageActionButton icon={<Plus size={16} />} onClick={openNewTransaction} disabled={!canCreate || Boolean(openingId)} ariaHasPopup="dialog">{uiText("New transaction")}</PageActionButton>
      </>} />
      <CompanyBreadcrumb companyName={company.name} items={["Bank", "Bank transaction"]} />
      {editError && <div role="alert" className="flex items-center justify-between gap-3 rounded-lg bg-[#FFF0F0] p-3 font-montserrat text-[12px] text-[#B42318]">{editError}<button type="button" aria-label={uiText("Dismiss bank entry error")} onClick={() => setEditError('')}><X size={16} /></button></div>}
      {importNotice && <div role="status" className="flex items-center justify-between gap-3 rounded-lg bg-[#E7F5ED] p-3 font-montserrat text-[12px] text-[#237A4B]">{importNotice}<button type="button" aria-label={uiText("Dismiss statement import result")} onClick={() => setImportNotice('')}><X size={16} /></button></div>}
      <div className="flex flex-wrap items-center gap-2">
        <OcrSearchField ariaLabel={uiText("Search bank entries")} value={query} onChange={(value) => { setQuery(value); setPage(1); }} />
        <SystemAddFilters columns={filterColumns} activeKeys={filterKeys} values={filterValues} onActiveKeysChange={setFilterKeys} onValuesChange={setFilterValues} persistenceKey={`finansu-harmonija:v12:company-bank-filters:${company.id}`} />
        <div className="ml-auto flex flex-wrap items-center justify-end gap-4">
          <ColumnSettingsButton onClick={() => setShowColumns(true)} />
          <ImportDataButton
            disabled={rows.length === 0}
            onClick={() => importMenuRecords(`company:${company.id}:bank`, rows.map((row) => row.documentId))}
          />
          <RefreshAllButton onRefresh={() => setRefreshRevision((value) => value + 1)} />
        </div>
      </div>

      <div ref={tableScrollRef} className="min-h-0 flex-1 overflow-x-auto scrollbar-hide">
        <div style={{ minWidth: visibleColumns.reduce((sum, column) => sum + column.width, 0) + 52 }}>
          <div className="system-table-header-row mb-3 flex min-h-9 items-start">
            {visibleColumns.map((column) => {
              const key = column.key as BankColumnKey;
              const realIndex = columns.findIndex((item) => item.key === column.key);
              return <div key={column.key} style={{ width: column.width }} className="relative flex flex-shrink-0 items-start gap-1 px-3">
                <span>{uiText(column.label)}</span>
                <ColumnSortButton columnLabel={uiText(column.label)} direction={directionFor(key)} onDirectionChange={(direction) => changeSort(key, direction)} />
                <ResizeHandle onMouseDown={(event) => startResize(realIndex, event)} />
              </div>;
            })}
            <div className="system-table-row-actions w-[52px] px-3" aria-label={uiText("Row actions")} />
          </div>
          <div className="flex flex-col gap-0.5">
            {visibleRows.map((row, index) => <div key={row.documentId} tabIndex={canEdit ? 0 : undefined} role="group" aria-label={`Bank transaction ${row.transferNo}`}
              onClick={event => { if (!(event.target as Element).closest('button,input,textarea,select,a,[role="combobox"],[role="option"],[role="listbox"]')) void openEditor(row.documentId); }}
              onKeyDown={event => { if (event.target === event.currentTarget && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); void openEditor(row.documentId); } }}
              className={`flex h-10 items-center rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-[#007EA7] ${canEdit ? 'cursor-pointer' : ''} ${index % 2 === 0 ? "bg-[#F8FDFF]" : "bg-white"} hover:bg-[#E7F4F9]`}>
              {visibleColumns.map((column) => <div key={column.key} style={{ width: column.width }} title={row[column.key as BankColumnKey]} className="flex-shrink-0 truncate px-3 font-montserrat text-[12px] font-normal text-[#10233A]">
                {column.key === 'status' ? <DocumentInlineSelectCell
                  value={row.status} label={`bank status ${row.transferNo}`} options={BANK_STATUS_OPTIONS} localizeOptions="status"
                  disabledReason={!canEdit ? 'You do not have permission to edit this company’s bank entries.' : row.statusDisabledReason}
                  onSave={value => changeStatus(row, value)}
                /> : column.key === 'reconciliationStatus' ? <span
                  title={row.reconciliationDemo ? uiText('Demonstration reconciliation status') : row.reconciliationStatus}
                  className={`inline-flex max-w-full items-center gap-1.5 rounded-full px-2 py-1 text-[10px] font-semibold leading-4 ${RECONCILIATION_BADGE_STYLES[row.reconciliationStatus] || 'bg-[#F3F6FA] text-[#7288A3]'}`}>
                  <span aria-hidden="true" className="h-1.5 w-1.5 shrink-0 rounded-full bg-current" />
                  <span className="truncate">{statusText(row.reconciliationStatus)}</span>
                </span> : row[column.key as BankColumnKey]}
              </div>)}
              <div className="system-table-row-actions flex w-[52px] items-center justify-end px-3">
                <button type="button" aria-label={`Edit bank entry ${row.transferNo === '—' ? row.documentId : row.transferNo}`} title={canEdit ? uiText('Edit bank entry') : uiText('You do not have permission to edit bank entries')}
                  disabled={!canEdit || Boolean(openingId)} onClick={() => void openEditor(row.documentId)}
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:border-[#E5EDF9] disabled:text-[#B4B6B8]">
                  {openingId === row.documentId ? <Loader2 size={14} className="animate-spin" aria-hidden="true" /> : <Pencil size={14} aria-hidden="true" />}
                </button>
              </div>
            </div>)}
            {!loading && visibleRows.length === 0 && <div className="flex min-h-[260px] flex-col items-center justify-center gap-3 font-montserrat text-[#7288A3]">
              <Landmark size={30} />
              <span className="text-[14px] font-semibold">{uiText("No bank entries")}</span>
              <span className="text-[12px]">{uiText("Bank entries will appear when the company has related documents.")}</span>
            </div>}
          </div>
        </div>
      </div>
      <HorizontalTableScrollbar scrollRef={tableScrollRef} />
      <TablePagination scrollRef={tableScrollRef} currentPage={currentPage} totalPages={totalPages} itemCount={sortedRows.length} itemsPerPage={itemsPerPage} onPageChange={setPage} />
      {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={DEFAULT_COLUMNS} onSave={(next) => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
      {showStatementImport && <BankStatementImportDialog company={company} onClose={() => setShowStatementImport(false)} onImported={result => {
        setShowStatementImport(false); setImportNotice(`${result.imported} transaction(s) imported.${result.duplicates ? ` ${result.duplicates} previously imported transaction(s) skipped.` : ''}`);
        setQuery(''); setFilterKeys([]); setFilterValues({}); setPage(1); void loadDocuments();
      }} />}
      {newTransaction && <BankTransactionEditor key={newTransaction.id} mode="create" document={newTransaction} company={company}
        onClose={() => setNewTransaction(undefined)} onSaved={() => { setQuery(''); setFilterKeys([]); setFilterValues({}); setPage(1); void loadDocuments(); }} />}
      {editor && <BankTransactionEditor key={editor.id} document={editor} company={company} onClose={closeEditor}
        onOpenReconciliation={onOpenReconciliation ? () => { setEditor(undefined); onOpenReconciliation(); } : undefined}
        onSaved={document => { const updated = mapRow(document); setDocuments(previous => previous.map(row => row.id === updated.id ? updated : row)); }} />}
    </div>
  );
}
