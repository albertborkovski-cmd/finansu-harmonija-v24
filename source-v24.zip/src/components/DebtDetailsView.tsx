import { lazy, Suspense, useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { ArrowLeft, ChevronDown, ExternalLink } from 'lucide-react';
import { getLanguage, translateMessage, translateUi as uiText } from '../i18n/language';
import type { Company } from '../lib/supabase';
import type { DebtRow } from '../lib/companyRelatedObjectData';
import { debtCommunicationHistory, debtCommunicationStatus, debtCommunicationType, debtMoney, debtPayments, type DebtPaymentDetail } from '../lib/debtDetails';
import { loadOrganizationEmailHistory, type OrganizationEmailHistoryEntry } from '../lib/organizationEmail';
import { parseReconciliationState } from '../lib/reconciliation';
import { reconciliationStorageKey, RECONCILIATION_CHANGED } from '../lib/reconciliationJournal';
import { PageActionButton, PageHeader } from './PageHeader';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import RelatedObjectPreview from './RelatedObjectPreview';

const DebtLinkedDocumentView = lazy(() => import('./DebtLinkedDocumentView'));
type Preview = { type: 'payment' | 'reconciliation'; payment: DebtPaymentDetail } | { type: 'message'; message: OrganizationEmailHistoryEntry } | { type: 'document' };
const linkClass = 'text-left font-medium text-[#007EA7] underline decoration-[#A1B6C6] underline-offset-2 hover:decoration-[#007EA7] focus-visible:rounded focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]';
const cellClass = 'px-4 py-3 text-left align-top';

function DebtDetailsScreen({ children }: { children: ReactNode }) {
  return <div className="debt-details-page fixed inset-0 z-[60] overflow-y-auto overscroll-contain bg-white">{children}</div>;
}

function DetailSection({ number, title, children }: { number: number; title: string; children: ReactNode }) {
  const [open, setOpen] = useState(true);
  const id = useId();
  return <section className="shrink-0 overflow-hidden rounded-lg border border-[#D3E1EC] bg-white">
    <h2><button type="button" aria-expanded={open} aria-controls={id} onClick={() => setOpen(value => !value)} className="flex w-full items-center justify-between gap-3 bg-[#F1F6FA] px-5 py-3 text-left text-[14px] font-semibold text-[#10233A] hover:bg-[#EAF2F8]">
      <span>{number}. {uiText(title)}</span><ChevronDown aria-hidden="true" size={17} className={`shrink-0 text-[#7288A3] transition-transform ${open ? 'rotate-180' : ''}`} />
    </button></h2>
    <div id={id} hidden={!open}>{children}</div>
  </section>;
}

function DebtStatus({ status }: { status: string }) {
  return <span className={`inline-flex items-center gap-1.5 rounded px-2.5 py-1 text-[12px] font-medium ${status === 'Partially paid' ? 'bg-[#E5EDF9] text-[#007EA7]' : 'bg-[#EFF3F7] text-[#536B85]'}`}><span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />{uiText(status)}</span>;
}

function displayDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value || '—';
  return value.includes('T') ? date.toLocaleString(getLanguage() === 'lt' ? 'lt-LT' : 'en-GB') : value;
}

export default function DebtDetailsView({ debt, company, companyName, onBack, actions, message }: {
  debt: DebtRow; company?: Company; companyName: string; onBack: () => void; actions?: ReactNode; message?: ReactNode;
}) {
  const [preview, setPreview] = useState<Preview | null>(null);
  const [payments, setPayments] = useState<DebtPaymentDetail[]>([]);
  const [history, setHistory] = useState<OrganizationEmailHistoryEntry[]>([]);
  const [paymentError, setPaymentError] = useState(false);
  const headingRef = useRef<HTMLDivElement>(null);
  useEffect(() => { headingRef.current?.focus({ preventScroll: true }); }, [debt.id, preview]);
  useEffect(() => {
    const update = () => {
      if (!company) { setPayments([]); setHistory([]); return; }
      try {
        const raw = window.localStorage.getItem(reconciliationStorageKey(company.id));
        setPayments(debtPayments(debt, company.id, raw ? parseReconciliationState(raw, company.id) : null));
        setPaymentError(false);
      } catch { setPayments([]); setPaymentError(true); }
      setHistory(debtCommunicationHistory(loadOrganizationEmailHistory(), company.id, company.name, debt));
    };
    update();
    window.addEventListener('storage', update);
    window.addEventListener(RECONCILIATION_CHANGED, update);
    window.addEventListener('organization-email-history-updated', update);
    return () => {
      window.removeEventListener('storage', update);
      window.removeEventListener(RECONCILIATION_CHANGED, update);
      window.removeEventListener('organization-email-history-updated', update);
    };
  }, [company, debt]);

  if (preview?.type === 'document') return <DebtDetailsScreen><Suspense fallback={<p role="status" className="p-6 text-[#7288A3]">{uiText('Loading related object…')}</p>}><DebtLinkedDocumentView debt={debt} company={company} companyName={companyName} onBack={() => setPreview(null)} /></Suspense></DebtDetailsScreen>;
  if (preview) {
    const fields = preview.type === 'message' ? [
      { label: 'Date', value: displayDate(preview.message.sentAt) }, { label: 'Type', value: uiText(debtCommunicationType(preview.message)) },
      { label: 'Recipient', value: `${preview.message.recipient} · ${preview.message.recipientEmail}` },
      { label: 'Status', value: uiText(debtCommunicationStatus(preview.message)) }, { label: 'Document No.', value: preview.message.documentReference },
      { label: 'Subject', value: preview.message.subject }, { label: 'Message', value: preview.message.body },
      { label: 'Reply received', value: preview.message.responseReceivedAt ? displayDate(preview.message.responseReceivedAt) : '—' },
    ] : [
      { label: 'Date', value: displayDate(preview.type === 'payment' ? preview.payment.date : preview.payment.reconciledAt) },
      { label: 'Payment reference', value: preview.payment.reference }, { label: 'Counterparty', value: debt.counterpartyName },
      { label: 'Document No.', value: debt.documentReference }, { label: 'Purpose of payment', value: preview.payment.purpose },
      { label: 'Amount', value: debtMoney(preview.payment.paymentMinor, preview.payment.paymentCurrency) },
      { label: 'Matched amount', value: debtMoney(preview.payment.matchedMinor, preview.payment.currency) },
      { label: 'Reconciliation', value: preview.payment.reconciliationId }, { label: 'Created by', value: preview.payment.actor },
    ];
    return <DebtDetailsScreen><RelatedObjectPreview companyName={companyName} section="Debts" title={preview.type === 'message' ? 'Communication details' : preview.type === 'payment' ? preview.payment.kind === 'Payment' ? 'Bank transaction details' : 'Document' : 'Reconciliation details'}
      backLabel="Back to debt details" fields={fields} onBack={() => setPreview(null)} /></DebtDetailsScreen>;
  }

  return <DebtDetailsScreen><div ref={headingRef} tabIndex={-1} data-debt-details={debt.id} className="debt-details-screen flex min-h-full w-full min-w-0 flex-col gap-5 bg-white px-4 py-8 font-montserrat text-[#10233A] outline-none sm:px-8 lg:px-[56px]">
    <div><PageActionButton icon={<ArrowLeft size={16} />} onClick={onBack}>{uiText('Back to debts')}</PageActionButton></div>
    <PageHeader title={uiText('Debt details')} afterTitle={<span className="truncate text-[17px] font-semibold text-[#536B85]">{debt.documentReference}</span>}
      className="!h-auto !min-h-[46px] !flex-wrap gap-y-3 [&>div:last-child]:flex-wrap"
      actions={<><PageActionButton icon={<ExternalLink size={15} />} onClick={() => setPreview({ type: 'document' })}>{uiText('Open document')}</PageActionButton>{actions}</>} />
    <CompanyBreadcrumb companyName={companyName} items={['Debts', debt.documentReference]} />
    <div className="flex flex-wrap items-center gap-2"><DebtStatus status={debt.debtStatus} />{debt.daysOverdue > 0 && <span className="rounded bg-[#FFF1F0] px-2.5 py-1 text-[12px] font-semibold text-[#B42318]">{translateMessage('{count} days overdue', { count: debt.daysOverdue })}</span>}</div>
    {message}
    <DetailSection number={1} title="Debt information">
      <dl className="debt-details-fields grid gap-x-6 gap-y-5 p-5">
        {[["Counterparty", debt.counterpartyName], ["Document No.", debt.documentReference], ["Issue date", debt.issueDate], ["Due date", debt.dueDate]].map(([label, value]) => <div key={label} className="min-w-0"><dt className="text-[12px] text-[#7288A3]">{uiText(label)}</dt><dd className="m-0 mt-2 break-words text-[13px] font-semibold">{value || '—'}</dd></div>)}
      </dl>
      <dl className="debt-details-totals mx-5 mb-5 grid gap-x-6 gap-y-5 rounded-lg bg-[#F3F8FC] p-5">
        {[["Total amount", debt.totalAmount], ["Paid amount", debt.paidAmount], ["Outstanding amount", debt.outstandingAmount]].map(([label, value]) => <div key={label}><dt className="text-[12px] text-[#7288A3]">{uiText(label)}</dt><dd className={`m-0 mt-2 text-[19px] font-semibold tabular-nums ${label === 'Outstanding amount' ? 'text-[#007EA7]' : ''}`}>{value} <span className="text-[13px]">{debt.currency}</span></dd></div>)}
        <div><dt className="text-[12px] text-[#7288A3]">{uiText('Debt status')}</dt><dd className="m-0 mt-2"><DebtStatus status={debt.debtStatus} /></dd></div>
      </dl>
    </DetailSection>
    <DetailSection number={2} title="Payments & Reconciliation">
      {paymentError ? <p role="alert" className="p-5 text-[13px] text-[#B42318]">{uiText('Payment history could not be loaded. Existing records have not been changed.')}</p>
        : payments.length === 0 ? <p className="p-5 text-[13px] text-[#7288A3]">{uiText('No related payments or reconciliations.')}</p>
        : <div className="max-h-[360px] overflow-auto p-3"><table aria-label={uiText('Payments & Reconciliation')} className="w-full min-w-[520px] border-collapse text-[12px]">
          <thead className="sticky top-0 bg-[#F8FBFD] text-[#7288A3]"><tr>{['Date', 'Payment reference', 'Matched amount', 'Details'].map(label => <th key={label} className={`${cellClass} font-medium ${label === 'Matched amount' ? '!text-right' : ''}`}>{uiText(label)}</th>)}</tr></thead>
          <tbody>{payments.map(payment => <tr key={payment.id} className="border-b border-[#E5EDF9] hover:bg-[#F8FDFF]"><td className={cellClass}>{payment.date}</td><td className={cellClass}>{payment.reference}</td><td className={`${cellClass} whitespace-nowrap !text-right font-medium tabular-nums`}>{debtMoney(payment.matchedMinor, payment.currency)}</td><td className={cellClass}><div className="flex flex-wrap gap-x-4 gap-y-2"><button type="button" className={linkClass} onClick={() => setPreview({ type: 'payment', payment })}>{uiText(payment.kind === 'Payment' ? 'View bank transaction' : 'View details')}</button><button type="button" className={linkClass} onClick={() => setPreview({ type: 'reconciliation', payment })}>{uiText('View reconciliation')}</button></div></td></tr>)}</tbody>
          <tfoot className="bg-[#F3F8FC] font-semibold"><tr><td colSpan={2} className={cellClass}>{uiText('Total matched amount')}</td><td className={`${cellClass} whitespace-nowrap !text-right tabular-nums`}>{debtMoney(payments.reduce((sum, payment) => sum + payment.matchedMinor, 0), debt.currency)}</td><td /></tr></tfoot>
        </table></div>}
    </DetailSection>
    <DetailSection number={3} title="Communication history">
      {history.length === 0 ? <p className="p-5 text-[13px] text-[#7288A3]">{uiText('No reminders or balance confirmations yet.')}</p> : <div className="max-h-[360px] overflow-auto p-3"><table aria-label={uiText('Communication history')} className="w-full min-w-[520px] border-collapse text-[12px]">
        <thead className="sticky top-0 bg-[#F8FBFD] text-[#7288A3]"><tr>{['Date', 'Type', 'Recipient', 'Status', 'Details'].map(label => <th key={label} className={`${cellClass} font-medium`}>{uiText(label)}</th>)}</tr></thead>
        <tbody>{history.map(entry => <tr key={entry.id} className="border-b border-[#E5EDF9] last:border-b-0 hover:bg-[#F8FDFF]"><td className={cellClass}>{displayDate(entry.sentAt)}</td><td className={cellClass}>{uiText(debtCommunicationType(entry))}</td><td className={`${cellClass} break-all`}>{entry.recipientEmail}</td><td className={cellClass}><span className="inline-flex whitespace-nowrap rounded bg-[#E8F5EF] px-2 py-1 font-medium text-[#25734D]">{uiText(debtCommunicationStatus(entry))}</span></td><td className={cellClass}><button type="button" className={linkClass} onClick={() => setPreview({ type: 'message', message: entry })}>{uiText('View')}</button></td></tr>)}</tbody>
      </table></div>}
    </DetailSection>
  </div></DebtDetailsScreen>;
}
