import { useState, type ReactNode } from 'react';
import { Cloud, Download, Folder, KeyRound, Settings2, ShieldCheck } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { COMPANY_EXPORT_FORMATS } from '../lib/companyDigitizationSettings';
import { profileDocumentStatistics, readProfileOcrSettings, saveProfileOcrSettings, type ProfileOcrSettings } from '../lib/profileOcrSettings';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { canViewCompanyDocuments } from '../lib/documentEditAccess';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import CompanySharePointSettings from './CompanySharePointSettings';
import { IntegrationFieldHelp, IntegrationHelpLink, IntegrationInstructions, PROFILE_INTEGRATION_LINKS as helpLinks } from './ProfileIntegrationHelp';

const inputClass = 'h-[42px] w-full rounded-lg border border-[#D3E1EC] bg-white px-3.5 text-[14px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] disabled:bg-[#F4F8FC] disabled:text-[#7288A3]';
function SettingCard({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return <section className="rounded-lg border border-[#D3E1EC] bg-white"><h3 className="border-b border-[#E5EDF9] bg-[#F4F8FC] px-5 py-3 text-[14px] font-semibold">{t(title)}</h3><div className="space-y-4 p-5">{description && <p className="text-[12px] leading-5 text-[#7288A3]">{t(description)}</p>}{children}</div></section>;
}
function Choice({ label, value, options, onChange }: { label: string; value: string; options: Array<[string, string]>; onChange: (value: string) => void }) {
  return <div className="grid gap-2 sm:grid-cols-[minmax(180px,1fr)_minmax(180px,340px)] sm:items-center"><span className="text-[13px] font-medium">{t(label)}</span><SearchableSelect ariaLabel={t(label)} value={value} options={options.map(([value, label]) => ({ value, label: t(label) }))} onChange={onChange} portalMenu /></div>;
}
const tabs = [{ id: 'general', label: 'Working with the system', icon: Settings2 }, { id: 'gdrive', label: 'Google Drive', icon: Cloud }, { id: 'sharepoint', label: 'SharePoint', icon: Folder }] as const;
type SetupTab = typeof tabs[number]['id'];

export default function ProfileOcrSetup({ email, onOpenSecurity }: { email: string; onOpenSecurity?: () => void }) {
  useLanguage();
  const [loaded] = useState(() => { try { return { value: readProfileOcrSettings(window.localStorage, email), error: '' }; } catch (cause) { return { value: null, error: cause instanceof Error ? cause.message : 'Could not read profile OCR settings.' }; } });
  const [settings, setSettings] = useState(loaded.value);
  const [tab, setTab] = useState<SetupTab>('general');
  const [message, setMessage] = useState(''), [error, setError] = useState(loaded.error), [busy, setBusy] = useState(false);
  if (!settings) return <p role="alert" className="text-sm text-red-600">{t(error)}</p>;
  const changeGeneral = <K extends keyof ProfileOcrSettings['general']>(key: K, value: ProfileOcrSettings['general'][K]) => { setSettings(current => current && ({ ...current, general: { ...current.general, [key]: value } })); setMessage(''); setError(''); };
  const changeDrive = <K extends keyof ProfileOcrSettings['gdrive']>(key: K, value: ProfileOcrSettings['gdrive'][K]) => { setSettings(current => current && ({ ...current, gdrive: { ...current.gdrive, [key]: value } })); setMessage(''); setError(''); };
  const changeApi = <K extends keyof ProfileOcrSettings['api']>(key: K, value: ProfileOcrSettings['api'][K]) => { setSettings(current => current && ({ ...current, api: { ...current.api, [key]: value } })); setMessage(''); setError(''); };
  const save = (section: 'general' | 'gdrive' | 'api') => {
    try { setSettings(saveProfileOcrSettings(window.localStorage, email, section, settings[section])); setMessage('Profile settings saved.'); setError(''); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save setup.'); }
  };
  const report = async () => {
    if (busy) return;
    setBusy(true); setError('');
    try {
      const [companies, documents] = await Promise.all([supabase.from('companies').select('*'), supabase.from('documents').select('*')]);
      if (companies.error || documents.error) throw Error('Could not load document statistics.');
      const data = profileDocumentStatistics(((companies.data || []) as unknown as Company[]).filter(canViewCompanyDocuments), (documents.data || []) as unknown as DbDocument[]);
      const cell = (value: unknown) => {
        const text = String(value), safe = /^\s*[=+@-]/.test(text) ? `'${text}` : text;
        return `"${safe.replaceAll('"', '""')}"`;
      };
      const rows = [[t('Organization'), t('Company code'), ...data.months, t('Total')], ...data.entries.map(entry => [entry.name, entry.code, ...entry.counts, entry.counts.reduce((sum, count) => sum + count, 0)])];
      const url = URL.createObjectURL(new Blob(['\ufeff' + rows.map(row => row.map(cell).join(';')).join('\r\n')], { type: 'text/csv;charset=utf-8' }));
      const link = document.createElement('a'); link.href = url; link.download = 'fh-document-statistics.csv'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not load document statistics.'); }
    finally { setBusy(false); }
  };
  return <div className="flex min-w-0 flex-col gap-4 font-montserrat text-[#10233A]">
    <p className="text-[12px] leading-5 text-[#7288A3]">{t('These settings belong to your profile and do not change company settings.')}</p>
    <div className="grid min-w-0 gap-5 lg:grid-cols-[220px_minmax(0,1fr)]">
      <nav aria-label={t('Setup & integration sections')} className="self-start rounded-lg border border-[#D3E1EC] bg-white p-2"><div role="tablist" aria-label={t('Setup & integration sections')} className="flex flex-col gap-1">{tabs.map(item => <button key={item.id} role="tab" aria-selected={tab === item.id} type="button" onClick={() => { setTab(item.id); setMessage(''); setError(''); }} className={`flex min-h-[44px] items-center gap-3 rounded-md px-3 py-2 text-left text-[13px] font-semibold ${tab === item.id ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#7288A3] hover:bg-[#F4F8FC] hover:text-[#10233A]'}`}><item.icon size={17} className="shrink-0" />{t(item.label)}</button>)}</div></nav>
      <div className="min-w-0 space-y-5">
        {tab === 'general' && <>
          <div className="grid gap-5 2xl:grid-cols-2">
            <SettingCard title="API key">
              <label className="flex items-center gap-3 text-[13px] font-medium"><input type="checkbox" checked={settings.api.enabled} onChange={event => changeApi('enabled', event.target.checked)} className="h-[18px] w-[18px] shrink-0 rounded-[6px] accent-[#007EA7]" />{t('Use API access')}</label>
              {settings.api.enabled && <>
                <label className="block space-y-2 text-[12px] font-medium text-[#7288A3]"><span>{t('API key name')}</span><input maxLength={120} value={settings.api.name} onChange={event => changeApi('name', event.target.value)} className={inputClass} /></label>
                <fieldset className="space-y-3"><legend className="mb-3 text-[12px] font-medium text-[#7288A3]">{t('API permissions')}</legend>{([['uploadDocuments', 'Upload documents'], ['readResults', 'Read processing results']] as const).map(([key, label]) => <label key={key} className="flex items-center gap-3 text-[13px]"><input type="checkbox" checked={settings.api[key]} onChange={event => changeApi(key, event.target.checked)} className="h-[18px] w-[18px] shrink-0 rounded-[6px] accent-[#007EA7]" />{t(label)}</label>)}</fieldset>
                <div className="flex items-start gap-2 rounded-lg bg-[#F4F8FC] p-3 text-[12px] leading-5 text-[#7288A3]"><KeyRound size={16} className="mt-0.5 shrink-0" /><span>{t('API preferences can be saved. A server connection is required to issue a working key; no key or access is created here.')}</span></div>
              </>}
              <div className="flex justify-end"><PageActionButton onClick={() => save('api')}>{t('Save API settings')}</PageActionButton></div>
            </SettingCard>
            <SettingCard title="Two-factor authentication (2FA)" description="Manage your sign-in verification methods in Authorization notifications."><PageActionButton icon={<ShieldCheck size={16} />} onClick={onOpenSecurity} disabled={!onOpenSecurity}>{t('Authorization notifications')}</PageActionButton></SettingCard>
          </div>
          <SettingCard title="Document access restriction" description="This is a saved preference. Public-link access requires server enforcement; saving it does not change current document permissions."><Choice label="Document access" value={settings.general.documentAccess} options={[["restricted", 'Restricted'], ['link', 'Anyone with the link']]} onChange={value => changeGeneral('documentAccess', value as 'restricted' | 'link')} /></SettingCard>
          <SettingCard title="Invoice digitization" description="Default processing preferences for newly uploaded documents. Existing documents remain unchanged.">
            <Choice label="Digitization mode" value={settings.general.digitization} options={[["detailed", 'Detailed with lines'], ['summary', 'Summarized totals']]} onChange={value => changeGeneral('digitization', value as 'summary' | 'detailed')} />
            <Choice label="Document splitting" value={String(settings.general.splitDocuments)} options={[["true", 'Split into separate invoices'], ['false', 'Do not split']]} onChange={value => changeGeneral('splitDocuments', value === 'true')} />
            <Choice label="Duplicate rejection" value={String(settings.general.rejectDuplicates)} options={[["true", 'Reject'], ['false', 'Do not reject']]} onChange={value => changeGeneral('rejectDuplicates', value === 'true')} />
            <Choice label="Non-invoice rejection" value={String(settings.general.rejectNonInvoices)} options={[["true", 'Reject'], ['false', 'Do not reject']]} onChange={value => changeGeneral('rejectNonInvoices', value === 'true')} />
            <Choice label="Primary export format" value={settings.general.exportFormat} options={[["", 'Select export format'], ...COMPANY_EXPORT_FORMATS.map(value => [value, value] as [string, string])]} onChange={value => changeGeneral('exportFormat', value)} />
          </SettingCard>
          <div className="flex justify-end"><PageActionButton onClick={() => save('general')}>{t('Save changes')}</PageActionButton></div>
          <SettingCard title="Invoice statistics by counterparty" description="Document counts for the last six months, by document date, for your accessible starred client organizations."><PageActionButton icon={<Download size={16} />} disabled={busy} onClick={() => void report()}>{t(busy ? 'Loading…' : 'Download report')}</PageActionButton></SettingCard>
        </>}
        {tab === 'gdrive' && <>
          <div className="flex items-center justify-between gap-3"><h2 className="text-[20px] font-semibold">Google Drive</h2><span className="rounded-md bg-[#F4F8FC] px-3 py-1 text-[12px] text-[#7288A3]">{t('Not connected')}</span></div>
          <p className="text-[12px] leading-5 text-[#7288A3]">{t('Import and archive connections are separate. Neither connection is active yet.')}</p>
          <SettingCard title="Automatic document import" description="Prepare a Google Drive folder for hourly imports. Reading folders requires a connected FH service account.">
            <IntegrationInstructions title="How to prepare document import" steps={[
              'Open Google Drive and create a separate folder for documents to be digitized. Enter its name below.',
              'Open that folder and copy its full address into Google Drive folder URL.',
              'When the FH connector is configured, an administrator will provide its service account and required folder permissions. Do not share FH documents with an account from another service’s instructions.',
              'After connecting the service, use Check connection before enabling scheduled import. Saving these fields alone does not start an import.',
            ]}><IntegrationHelpLink href={helpLinks.drive}>{t('Open Google Drive')}</IntegrationHelpLink></IntegrationInstructions>
            <div className="grid gap-4 xl:grid-cols-2">
              <label className="space-y-2 text-[13px] font-medium"><span className="block">{t('Import folder name')}</span><input aria-describedby="gdrive-import-name-help" value={settings.gdrive.importFolder} onChange={event => changeDrive('importFolder', event.target.value)} className={inputClass} /><IntegrationFieldHelp id="gdrive-import-name-help">{t('Use the exact name of the folder created in Google Drive.')}</IntegrationFieldHelp></label>
              <label className="space-y-2 text-[13px] font-medium"><span className="block">{t('Google Drive folder URL')}</span><input aria-describedby="gdrive-import-url-help" value={settings.gdrive.importUrl} placeholder="https://drive.google.com/drive/folders/…" onChange={event => changeDrive('importUrl', event.target.value)} className={inputClass} /><IntegrationFieldHelp id="gdrive-import-url-help">{t('Paste the folder address from the browser, not a link to an individual invoice.')}</IntegrationFieldHelp></label>
            </div>
            <div className="space-y-1"><label className="flex items-center gap-3 text-[13px]"><input type="checkbox" aria-describedby="gdrive-subfolders-help" checked={settings.gdrive.includeSubfolders} onChange={event => changeDrive('includeSubfolders', event.target.checked)} className="h-[18px] w-[18px] shrink-0 rounded-[6px] accent-[#007EA7]" />{t('Include subfolders')}</label><IntegrationFieldHelp id="gdrive-subfolders-help">{t('Include documents inside nested folders as well as the selected root folder. The saved preference will be used by the connected import service.')}</IntegrationFieldHelp></div>
            <div className="flex flex-wrap items-center justify-between gap-3"><p className="text-[12px] text-[#7288A3]">{t('Service account: not configured. No folder has been shared or read.')}</p><PageActionButton disabled>{t('Check connection')}</PageActionButton></div>
          </SettingCard>
          <SettingCard title="Archive processed documents" description="After connection, selected client documents can be archived by organization and month.">
            <IntegrationInstructions title="How to prepare the archive" steps={[
              'Choose a destination folder for processed PDF documents. Import and archive folders serve different purposes.',
              'If you use a Google Workspace shared drive, open it and copy its ID from the address bar into Shared drive ID. Leave this field empty for a personal drive.',
              'Client organizations are identified by the star in All Documents. The archive is organized by organization and month.',
              'Google authorization and file transfers become available only after the FH connector is configured. No archive is created by saving these preferences.',
            ]}><IntegrationHelpLink href={helpLinks.driveAbout}>{t('About Google Drive')}</IntegrationHelpLink></IntegrationInstructions>
            <div className="grid gap-4 xl:grid-cols-2">
              <label className="space-y-2 text-[13px] font-medium"><span className="block">{t('Archive folder name')}</span><input aria-describedby="gdrive-archive-name-help" value={settings.gdrive.archiveFolder} onChange={event => changeDrive('archiveFolder', event.target.value)} className={inputClass} /><IntegrationFieldHelp id="gdrive-archive-name-help">{t('The destination folder for processed PDFs. This is separate from the incoming document folder.')}</IntegrationFieldHelp></label>
              <label className="space-y-2 text-[13px] font-medium"><span className="block">{t('Shared drive ID (optional)')}</span><input aria-describedby="gdrive-shared-id-help" value={settings.gdrive.sharedDriveId} onChange={event => changeDrive('sharedDriveId', event.target.value)} className={inputClass} /><IntegrationFieldHelp id="gdrive-shared-id-help">{t('Enter only the shared drive identifier, not the complete URL. Your connected Google account must have access to that drive.')}</IntegrationFieldHelp></label>
            </div>
            <PageActionButton disabled>{t('Connect Google Drive')}</PageActionButton>
          </SettingCard>
          <SettingCard title="Connection help">
            <p className="text-[12px] leading-5 text-[#7288A3]">{t('If a connection fails, check the folder address, Google account and granted permissions. To stop a connected import, remove the FH service account from the folder’s sharing settings. This does not delete your source documents.')}</p>
            <p className="text-[12px] leading-5 text-[#7288A3]">{t('Finansų harmonija uses its own integration, permissions and service accounts. Ask your administrator for the correct connection details.')}</p>
          </SettingCard>
          <div className="flex justify-end"><PageActionButton onClick={() => save('gdrive')}>{t('Save changes')}</PageActionButton></div>
        </>}
        {tab === 'sharepoint' && <CompanySharePointSettings profileEmail={email} />}
        {message && <p role="status" className="text-[13px] text-[#087A55]">{t(message)}</p>}
        {error && <p role="alert" className="text-[13px] text-[#B42318]">{t(error)}</p>}
      </div>
    </div>
  </div>;
}
