import { ExternalLink, Play } from 'lucide-react';
import { useState } from 'react';

export function HelpScreenshot({ file, caption, lt }: { file: string; caption: string; lt: boolean }) {
  const src = `${import.meta.env.BASE_URL}help/${file}`;
  return <figure className="my-5 overflow-hidden rounded-lg border border-[#D3E1EC] bg-[#F5F8FB]">
    <a href={src} target="_blank" rel="noopener noreferrer" aria-label={`${caption} · ${lt ? 'Atidaryti didesnį vaizdą' : 'Open larger image'}`}><img src={src} alt={caption} loading="lazy" className="h-auto w-full" /></a>
    <figcaption className="flex items-center justify-between gap-3 px-4 py-3 text-[11px] leading-5 text-[#526B86]"><span>{caption}</span><ExternalLink size={14} className="shrink-0" aria-hidden="true" /></figcaption>
  </figure>;
}

export function HelpVideo({ id, format, lt }: { id: string; format: string; lt: boolean }) {
  const [playing, setPlaying] = useState(false);
  const title = `${format} · ${lt ? 'Sąskaitų importo vaizdo įrašas' : 'Invoice import tutorial'}`;
  return <article className="overflow-hidden rounded-lg border border-[#D3E1EC] bg-white">
    {playing ? <iframe src={`https://www.youtube-nocookie.com/embed/${id}`} title={title} className="aspect-video w-full" allow="encrypted-media; picture-in-picture" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" /> : <button type="button" onClick={() => setPlaying(true)} className="flex aspect-video w-full flex-col items-center justify-center gap-3 bg-[#EFF6FA] text-[#007EA7] hover:bg-[#E5EDF9] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]"><span className="rounded-full border border-[#C8DDE9] bg-white p-4"><Play size={24} aria-hidden="true" /></span><span className="text-[13px] font-semibold">{title}</span></button>}
    <div className="space-y-2 p-4"><p className="text-[11px] leading-5 text-[#7288A3]">{lt ? 'Originalus išorinis mokomasis įrašas. Jame rodoma kita sąsaja; FH veiksmus atlikite pagal šio puslapio žingsnius.' : 'Original external tutorial, showing a different interface. Follow the steps on this page for FH actions.'}</p><a href={`https://www.youtube.com/watch?v=${id}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-[12px] font-medium text-[#007EA7] underline underline-offset-2">{lt ? 'Žiūrėti YouTube · autorius ir šaltinis' : 'Watch on YouTube · author and source'}<ExternalLink size={13} /></a></div>
  </article>;
}
