import { useEffect, useState } from 'react';
import { translateUi as uiText } from '../i18n/language';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import type { DebtRow } from '../lib/companyRelatedObjectData';
import { mapRow } from './Documents';
import DocumentDetailPanel from './DocumentDetailPanel';
import RelatedObjectPreview from './RelatedObjectPreview';

/** Open a real source document where one exists; sample debts have a read-only source snapshot. */
export default function DebtLinkedDocumentView({ debt, company, companyName, onBack }: { debt: DebtRow; company?: Company; companyName: string; onBack: () => void }) {
  const [document, setDocument] = useState<DbDocument | null>(null);
  const [loading, setLoading] = useState(true);
  const [unavailable, setUnavailable] = useState(false);
  useEffect(() => {
    let cancelled = false;
    setLoading(true); setDocument(null); setUnavailable(false);
    const load = async () => {
      if (!company) { if (!cancelled) { setUnavailable(true); setLoading(false); } return; }
      try {
        const { data, error } = await supabase.from('documents').select('*').eq('company_id', company.id).eq('number', debt.documentReference);
        if (error) throw error;
        const matches = (data as unknown as DbDocument[] || []).filter(row => row.company_id === company.id && row.number === debt.documentReference
          && row.currency === debt.currency && row.client_counterparty?.trim().toLocaleLowerCase() === debt.counterpartyName.trim().toLocaleLowerCase());
        if (!cancelled) {
          const missing = matches.length > 1 || Boolean(matches[0]?.document_deletion);
          setDocument(!missing && matches.length === 1 ? matches[0] : null); setUnavailable(missing);
        }
      } catch { if (!cancelled) setUnavailable(true); }
      finally { if (!cancelled) setLoading(false); }
    };
    void load();
    return () => { cancelled = true; };
  }, [company, debt]);
  if (document) return <DocumentDetailPanel doc={mapRow(document)} readOnly companyName={companyName} onClose={onBack} />;
  return <RelatedObjectPreview companyName={companyName} section="Debts" title={`${uiText('Document')} · ${debt.documentReference}`} backLabel="Back to debt details" onBack={onBack} loading={loading} unavailable={unavailable}
    fields={[
      { label: 'Document No.', value: debt.documentReference }, { label: 'Document type', value: uiText(debt.documentType) },
      { label: 'Counterparty', value: debt.counterpartyName }, { label: 'Counterparty code', value: debt.counterpartyCode },
      { label: 'Issue date', value: debt.issueDate }, { label: 'Due date', value: debt.dueDate },
      { label: 'Total amount', value: `${debt.totalAmount} ${debt.currency}` }, { label: 'Paid amount', value: `${debt.paidAmount} ${debt.currency}` },
      { label: 'Outstanding amount', value: `${debt.outstandingAmount} ${debt.currency}` }, { label: 'Debt status', value: uiText(debt.debtStatus) },
    ]} />;
}
