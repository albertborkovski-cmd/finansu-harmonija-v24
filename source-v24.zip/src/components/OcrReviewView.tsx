import { translateUi as uiText, translateStatus } from '../i18n/language';
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { CheckCircle2, ChevronDown, ChevronRight, Clock3, Download, Eye, FileText, UserRound } from "lucide-react";
import type { Company, DbDocument } from "../lib/supabase";
import { supabase } from "../lib/supabase";
import { loadSavedReviewDocumentTask, loadSavedReviewDocumentTasks } from "../lib/ocrReviewDocuments";
import { buildReviewAnalytics, reviewAnalyticsColumns, REVIEW_ANALYTICS_COLUMNS, type WorkerAnalytics } from "../lib/ocrReviewAnalytics";
import type { LearningEvidence } from "../lib/ocrLearning";
import OcrLearningDocumentView from "./OcrLearningDocumentView";
import { getCurrentUserName } from "../lib/currentUser";
import { loadLinkedDirectoryUsers } from "../lib/linkedSettingsData";
import { usePersistentState } from "../hooks/usePersistentState";
import { PageHeader } from "./PageHeader";
import OcrBreadcrumb from "./OcrBreadcrumb";
import OcrSearchField from "./OcrSearchField";
import RefreshAllButton from "./RefreshAllButton";
import SystemAddFilters, { type SystemFilterColumn } from "./SystemAddFilters";
import HorizontalTableScrollbar from "./HorizontalTableScrollbar";
import TablePagination from "./TablePagination";
import { TABLE_BATCH_SIZE } from "../lib/tablePaging";
import type { ColConfig } from "./ColumnSettingsPanel";
import ColumnSortButton, { useMultiColumnSort } from "./ColumnSortButton";
import { ResizeHandle, useColumnResize } from "./useColumnResize";
import { ProcessedDocumentsTable, type ReviewDocumentReference } from "./OcrProcessedDocumentsView";
import { WorkspaceDocumentEditor, type WorkspaceTask } from "./WorkspaceView";
import { OCR_DOCUMENT_WORK_LOG_KEY, type OcrDocumentWorkLog } from "./ocrDocumentWorkTimeStore";

export type OcrReviewSection = "approve-documents" | "analytics";

type ReviewWorkLog = OcrDocumentWorkLog;

type DirectoryUser = {
  id?: string;
  fullName?: string;
  username?: string;
  email?: string;
  status?: string;
};

type AnalyticsFilterKey = "employee" | "documents" | "needReview" | "approved" | "teamLeadReferrals" | "assignedIssues" | "workTime";

const ANALYTICS_FILTER_COLUMNS: Array<{ key: AnalyticsFilterKey; label: string }> = [
  { key: "employee", label: "Employee" },
  { key: "documents", label: "Documents" },
  { key: "needReview", label: "Need review" },
  { key: "approved", label: "Approved" },
  { key: "teamLeadReferrals", label: "Sent to TeamLead" },
  { key: "assignedIssues", label: "Assigned document issues" },
  { key: "workTime", label: "Work time" },
];

const REVIEW_WORK_LOG_KEY = OCR_DOCUMENT_WORK_LOG_KEY;

function normalized(value?: string) {
  return (value ?? "").trim().toLocaleLowerCase();
}

function formatDuration(seconds: number) {
  if (seconds <= 0) return "—";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  if (hours) return `${hours}h ${minutes}m`;
  if (minutes) return `${minutes}m ${remainingSeconds}s`;
  return `${remainingSeconds}s`;
}

function analyticsFilterValue(row: WorkerAnalytics, key: AnalyticsFilterKey) {
  if (key === "employee") return row.name;
  if (key === "documents") return String(row.documents.length);
  if (key === "needReview") return String(row.needReview);
  if (key === "approved") return String(row.approved);
  if (key === "teamLeadReferrals") return String(row.teamLeadReferrals);
  if (key === "assignedIssues") return String(row.assignedIssues);
  return formatDuration(row.totalSeconds);
}

function ApproveDocumentsView() {
  const [deliveryActionContainer, setDeliveryActionContainer] = useState<HTMLDivElement | null>(null);
  const [viewedDocument, setViewedDocument] = useState<{
    id?: string; name: string; companyId?: string; savedTask?: WorkspaceTask; position: number; total: number;
  } | null>(null);
  const [teamLeadQueue, setTeamLeadQueue] = usePersistentState<Record<string, WorkspaceTask>>('finansu-harmonija:v18:ocr:team-lead-review', {});
  const [reviewTaskId, setReviewTaskId] = useState<string | null>(null);
  const [activeDocument, setActiveDocument] = useState<ReviewDocumentReference | null>(null);
  const [documentQueue, setDocumentQueue] = useState<ReviewDocumentReference[]>([]);
  const [documentIndex, setDocumentIndex] = useState(-1);
  const [savedTasks, setSavedTasks] = usePersistentState<Record<string, WorkspaceTask>>(
    "finansu-harmonija:v12:ocr:review-tasks",
    {},
  );
  const [, setWorkLog] = usePersistentState<ReviewWorkLog>(REVIEW_WORK_LOG_KEY, {});
  const workStartedAt = useRef<number | null>(null);

  const finishWorkSession = useCallback((documentId?: string) => {
    if (!documentId || workStartedAt.current === null) return;
    const elapsedSeconds = Math.max(1, Math.round((Date.now() - workStartedAt.current) / 1000));
    setWorkLog((current) => {
      const previous = current[documentId];
      return {
        ...current,
        [documentId]: {
          seconds: (previous?.seconds ?? 0) + elapsedSeconds,
          user: getCurrentUserName(),
          updatedAt: new Date().toISOString(),
        },
      };
    });
    workStartedAt.current = null;
  }, [setWorkLog]);

  const openDocument = (document: ReviewDocumentReference, index: number, documents: ReviewDocumentReference[]) => {
    setActiveDocument(document);
    setDocumentQueue(documents);
    setDocumentIndex(index);
    workStartedAt.current = Date.now();
  };

  if (viewedDocument) return <WorkspaceDocumentEditor
    key={`view-${viewedDocument.id ?? viewedDocument.savedTask?.id}`}
    documentId={viewedDocument.id}
    documentName={viewedDocument.name}
    companyId={viewedDocument.companyId}
    savedTask={viewedDocument.savedTask}
    filePosition={viewedDocument.position}
    fileTotal={viewedDocument.total}
    readOnly
    viewNotice="Saved result · Read-only"
    onBack={() => setViewedDocument(null)}
  />;

  if (reviewTaskId && teamLeadQueue[reviewTaskId]) {
    const task = teamLeadQueue[reviewTaskId];
    return <WorkspaceDocumentEditor key={reviewTaskId} documentName={task.name} documentId={task.id} savedTask={task}
      onBack={() => setReviewTaskId(null)}
      onSave={updated => setTeamLeadQueue(current => ({ ...current, [reviewTaskId]: { ...updated,
        teamLeadReview: { ...task.teamLeadReview!, ...updated.teamLeadReview, status: updated.status === 'Completed' ? 'Approved' : 'Pending' } } }))} />;
  }

  if (activeDocument) {
    const hasNext = documentIndex >= 0 && documentIndex < documentQueue.length - 1;
    return (
      <WorkspaceDocumentEditor
        key={activeDocument.id}
        documentName={activeDocument.name}
        documentId={activeDocument.id}
        savedTask={savedTasks[activeDocument.id]}
        filePosition={documentIndex + 1}
        fileTotal={documentQueue.length}
        onSave={(task) => {
          setSavedTasks((current) => ({ ...current, [activeDocument.id]: task }));
          finishWorkSession(activeDocument.id);
          workStartedAt.current = Date.now();
        }}
        onNextFile={hasNext ? () => {
          finishWorkSession(activeDocument.id);
          const nextIndex = documentIndex + 1;
          setDocumentIndex(nextIndex);
          setActiveDocument(documentQueue[nextIndex]);
          workStartedAt.current = Date.now();
        } : undefined}
        onBack={() => {
          finishWorkSession(activeDocument.id);
          setActiveDocument(null);
          setDocumentQueue([]);
          setDocumentIndex(-1);
        }}
      />
    );
  }

  return (
    <div className="flex min-h-full min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
      <PageHeader title={uiText("Approve documents")} actions={<div ref={setDeliveryActionContainer} className="flex items-center" />} />
      <OcrBreadcrumb items={["Review", "Approve documents"]} />
      {Object.values(teamLeadQueue).some(task => task.teamLeadReview?.status === 'Pending') && <section className="rounded-lg border border-[#D3E1EC] p-4">
        <h2 className="mb-3 font-montserrat text-[14px] font-semibold text-[#10233A]">{uiText("Team lead review")}</h2>
        {Object.values(teamLeadQueue).filter(task => task.teamLeadReview?.status === 'Pending').map(task => <div key={task.id} className="flex items-center justify-between gap-4 rounded-lg bg-[#F8FDFF] px-3 py-2 text-[12px]">
          <span>{task.name}</span><span className="text-[#7288A3]">{uiText("Awaiting approval")}</span>
          <div className="flex items-center gap-2">
            <button type="button" title={uiText("VIEW")} aria-label={`View ${task.name}`}
              onClick={() => setViewedDocument({ id: task.accounting?.documentId, name: task.name,
                companyId: task.accounting?.companyId, savedTask: task, position: 1, total: 1 })}
              className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7]">
              <Eye size={15} strokeWidth={1.8} />
            </button>
            <button onClick={() => setReviewTaskId(task.id)} className="rounded-md border border-[#D3E1EC] px-3 py-1 text-[#007EA7]">{uiText("Review")}</button>
          </div>
        </div>)}
      </section>}
      <ProcessedDocumentsTable
        embedded
        reviewOnly
        selectable
        accountingDelivery
        importActionContainer={deliveryActionContainer}
        onViewDocument={(document, index, documents) => setViewedDocument({
          ...document, savedTask: loadSavedReviewDocumentTask(document, localStorage), position: index + 1, total: documents.length,
        })}
        onEditDocument={openDocument}
      />
    </div>
  );
}

function ReviewAnalyticsView() {
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [users, setUsers] = useState<DirectoryUser[]>([]);
  const [query, setQuery] = useState("");
  const [activeFilterKeys, setActiveFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const [expandedWorkers, setExpandedWorkers] = useState<Set<string>>(new Set());
  const [page, setPage] = useState(1);
  const [savedAnalyticsColumns, setAnalyticsColumns] = usePersistentState<ColConfig[]>(
    "finansu-harmonija:v12:ocr:review-analytics:columns",
    REVIEW_ANALYTICS_COLUMNS,
  );
  const analyticsColumns = useMemo(() => reviewAnalyticsColumns(savedAnalyticsColumns), [savedAnalyticsColumns]);
  const [savedReviewTasks, setSavedReviewTasks] = useState<Map<string, WorkspaceTask | undefined>>(new Map());
  const [workLog] = usePersistentState<ReviewWorkLog>(REVIEW_WORK_LOG_KEY, {});
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(analyticsColumns, setAnalyticsColumns);

  const loadData = useCallback(async () => {
    const [documentResult, companyResult] = await Promise.all([
      supabase.from("documents").select("*").order("receive_date", { ascending: false }),
      supabase.from("companies").select("*").order("name", { ascending: true }),
    ]);
    const loadedDocuments = (documentResult.data ?? []) as unknown as DbDocument[];
    setDocuments(loadedDocuments);
    setSavedReviewTasks(loadSavedReviewDocumentTasks(loadedDocuments, window.localStorage));
    setCompanies((companyResult.data ?? []) as unknown as Company[]);
    setUsers(loadLinkedDirectoryUsers("Internal users") as DirectoryUser[]);
  }, []);

  useEffect(() => {
    void loadData();
    const refresh = () => { void loadData(); };
    const events = ['storage', 'finansu-harmonija:persistent-state-changed', 'finansu-harmonija:data-changed', 'finansu-harmonija:settings-data-changed', 'document-issues-changed'];
    events.forEach(event => window.addEventListener(event, refresh));
    return () => events.forEach(event => window.removeEventListener(event, refresh));
  }, [loadData]);

  const allAnalytics = useMemo(() => buildReviewAnalytics(documents, companies, users, workLog, savedReviewTasks), [companies, documents, users, workLog, savedReviewTasks]);

  const filterColumns = useMemo<SystemFilterColumn[]>(() => ANALYTICS_FILTER_COLUMNS.map((column) => ({
    ...column,
    options: Array.from(new Set(allAnalytics.map((row) => analyticsFilterValue(row, column.key)))).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })),
  })), [allAnalytics]);

  const analytics = useMemo(() => {
    const normalizedQuery = normalized(query);
    return allAnalytics.filter((row) => {
      if (normalizedQuery && !`${row.name} ${row.email}`.toLocaleLowerCase().includes(normalizedQuery)) return false;
      return activeFilterKeys.every((key) => {
        const selectedValues = filterValues[key] ?? [];
        return selectedValues.length === 0 || selectedValues.includes(analyticsFilterValue(row, key as AnalyticsFilterKey));
      });
    });
  }, [activeFilterKeys, allAnalytics, filterValues, query]);

  const analyticsSorter = useMultiColumnSort<WorkerAnalytics, AnalyticsFilterKey>(
    analytics,
    (row, key) => {
      if (key === "employee") return row.name;
      if (key === "documents") return row.documents.length;
      if (key === "needReview") return row.needReview;
      if (key === "approved") return row.approved;
      if (key === "teamLeadReferrals") return row.teamLeadReferrals;
      if (key === "assignedIssues") return row.assignedIssues;
      return row.totalSeconds;
    },
  );
  const sortedAnalytics = analyticsSorter.sortedRows;
  const visibleAnalyticsColumns = analyticsColumns.filter((column) => column.visible);
  const analyticsGridTemplate = `42px ${visibleAnalyticsColumns.map((column) => `${column.width}px`).join(" ")}`;
  const analyticsTableWidth = 42 + visibleAnalyticsColumns.reduce((sum, column) => sum + column.width, 0);

  const pageSize = TABLE_BATCH_SIZE;
  const totalPages = Math.max(1, Math.ceil(sortedAnalytics.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const displayedWorkers = sortedAnalytics.slice(0, safePage * pageSize);

  const toggleWorker = (id: string) => setExpandedWorkers((current) => {
    const next = new Set(current);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    return next;
  });

  const exportAnalytics = () => {
    const escapeCsv = (value: string | number) => `"${String(value).replaceAll('"', '""')}"`;
    const rows: Array<Array<string | number>> = [
      ["Employee", "Documents", "Need review", "Approved", "Sent to TeamLead", "Assigned document issues", "Work time"],
      ...sortedAnalytics.map((worker) => [
        worker.name,
        worker.documents.length,
        worker.needReview,
        worker.approved,
        worker.teamLeadReferrals,
        worker.assignedIssues,
        formatDuration(worker.totalSeconds),
      ]),
    ];
    const csv = rows.map((row) => row.map(escapeCsv).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "ocr-review-analytics.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex min-h-full min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
      <PageHeader title={uiText("Review analytics")} />
      <OcrBreadcrumb items={["Review", "Analytics"]} />

      <div data-table-workspace-overview className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryCard icon={<UserRound size={18} />} label={uiText("Employees")} value={analytics.length} />
        <SummaryCard icon={<FileText size={18} />} label={uiText("Assigned documents")} value={analytics.reduce((sum, row) => sum + row.documents.length, 0)} />
        <SummaryCard icon={<CheckCircle2 size={18} />} label={uiText("Need review")} value={analytics.reduce((sum, row) => sum + row.needReview, 0)} accent />
        <SummaryCard icon={<Clock3 size={18} />} label={uiText("Recorded work time")} value={formatDuration(analytics.reduce((sum, row) => sum + row.totalSeconds, 0))} />
      </div>

      <div className="flex items-start gap-4">
        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1">
        <OcrSearchField ariaLabel={uiText("Search review analytics")} value={query} onChange={(value) => { setQuery(value); setPage(1); }} />
        <SystemAddFilters
          columns={filterColumns}
          activeKeys={activeFilterKeys}
          values={filterValues}
          onActiveKeysChange={(keys) => { setActiveFilterKeys(keys); setPage(1); }}
          onValuesChange={(values) => { setFilterValues(values); setPage(1); }}
          persistenceKey="finansu-harmonija:v12:ocr:review-analytics:filters"
        />
        </div>
        <div data-table-workspace-tools role="group" aria-label={uiText("Review analytics table tools")} className="ml-auto flex h-7 shrink-0 items-center gap-4">
          <button
            type="button"
            data-button-family="export"
            title={uiText("EXPORTDATA")}
            aria-label={uiText("EXPORTDATA review analytics")}
            onClick={exportAnalytics}
            disabled={sortedAnalytics.length === 0}
            className="flex h-4 w-4 flex-shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-35"
          >
            <Download size={16} />
          </button>
          <RefreshAllButton onRefresh={() => void loadData()} />
        </div>
      </div>

      <div ref={tableScrollRef} className="min-h-0 flex-1 overflow-x-auto scrollbar-hide">
        <div style={{ minWidth: analyticsTableWidth }}>
          <div
            style={{ gridTemplateColumns: analyticsGridTemplate }}
            className="system-table-header-row mb-3 grid min-h-6 items-center font-montserrat text-[12px] font-medium text-[#10233A]"
          >
            <span />
            {visibleAnalyticsColumns.map((column) => {
              const columnKey = column.key as AnalyticsFilterKey;
              const columnIndex = analyticsColumns.findIndex((item) => item.key === column.key);
              return (
                <div key={column.key} className="relative flex min-w-0 h-6 items-center gap-1 border-l border-[#D3E1EC] px-3">
                  <span className="min-w-0 whitespace-normal leading-[15px]">{uiText(column.label)}</span>
                  <ColumnSortButton
                    columnLabel={uiText(column.label)}
                    direction={analyticsSorter.directionFor(columnKey)}
                    onDirectionChange={(direction) => {
                      analyticsSorter.changeSort(columnKey, direction);
                      setPage(1);
                    }}
                  />
                  <ResizeHandle onMouseDown={(event) => startResize(columnIndex, event)} />
                </div>
              );
            })}
          </div>

          <div className="flex flex-col gap-0.5">
            {displayedWorkers.map((worker, index) => {
              const expanded = expandedWorkers.has(worker.id);
              return (
                <div key={worker.id} className="overflow-hidden rounded-lg">
                  <div style={{ gridTemplateColumns: analyticsGridTemplate }} className={`grid min-h-10 items-center font-montserrat text-[12px] text-[#10233A] ${index % 2 === 0 ? "bg-[#F8FDFF]" : "bg-white"} hover:bg-[#E7F4F9]`}>
                    <button type="button" aria-label={`${expanded ? "Collapse" : "Expand"} ${worker.name}`} onClick={() => toggleWorker(worker.id)} className="flex h-10 items-center justify-center text-[#7288A3] hover:text-[#007EA7]">{expanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}</button>
                    {visibleAnalyticsColumns.map((column) => (
                      <span
                        key={column.key}
                        className={`min-w-0 truncate px-3 ${column.key === "employee" ? "font-medium" : ""} ${column.key === "needReview" ? "font-semibold text-[#FF6200]" : ""} ${column.key === "approved" ? "text-[#087A55]" : ""}`}
                      >
                        {column.key === "employee" ? worker.name
                          : column.key === "documents" ? worker.documents.length
                          : column.key === "needReview" ? worker.needReview
                          : column.key === "approved" ? worker.approved
                          : column.key === "teamLeadReferrals" ? worker.teamLeadReferrals
                          : column.key === "assignedIssues" ? worker.assignedIssues
                          : formatDuration(worker.totalSeconds)}
                      </span>
                    ))}
                  </div>
                  {expanded && (
                    <div className="border-x border-b border-[#E5EDF9] bg-white px-5 py-4">
                      <div className="grid grid-cols-[170px_260px_150px_160px_140px] gap-0 border-b border-[#E5EDF9] pb-2 font-montserrat text-[11px] font-semibold text-[#7288A3]">
                        <span>{uiText("Organization")}</span><span>{uiText("Document")}</span><span>{uiText("Status")}</span><span>{uiText("Last activity")}</span><span>{uiText("Time spent")}</span>
                      </div>
                      {worker.documents.length ? worker.documents.map(({ document, organization, seconds }) => (
                        <div key={document.id} className="grid min-h-9 grid-cols-[170px_260px_150px_160px_140px] items-center gap-0 border-b border-[#F2F7FC] font-montserrat text-[12px] text-[#10233A] last:border-0">
                          <span className="truncate pr-3">{organization}</span>
                          <span className="truncate pr-3">{document.file_case || document.number || document.id}</span>
                          <span className="truncate pr-3">{translateStatus(document.status) || "—"}</span>
                          <span className="truncate pr-3 text-[#7288A3]">{workLog[document.id]?.updatedAt ? new Date(workLog[document.id].updatedAt).toLocaleString("en-GB") : "—"}</span>
                          <span>{formatDuration(seconds)}</span>
                        </div>
                      )) : <div className="py-5 text-center font-montserrat text-[12px] text-[#7288A3]">{uiText("No documents assigned")}</div>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <HorizontalTableScrollbar scrollRef={tableScrollRef} />
      <TablePagination currentPage={safePage} totalPages={totalPages} itemCount={sortedAnalytics.length} itemsPerPage={pageSize} onPageChange={setPage} scrollRef={tableScrollRef} />
    </div>
  );
}

function SummaryCard({ icon, label, value, accent = false }: { icon: ReactNode; label: string; value: string | number; accent?: boolean }) {
  return (
    <div className="rounded-xl border border-[#D3E1EC] bg-white p-4 shadow-[0_2px_8px_rgba(16,35,58,0.04)]">
      <div className="flex items-center justify-between text-[#7288A3]"><span className="font-montserrat text-[12px] font-semibold">{uiText(label)}</span>{icon}</div>
      <div className={`mt-3 font-montserrat text-[24px] font-semibold ${accent ? "text-[#FF6200]" : "text-[#10233A]"}`}>{value}</div>
    </div>
  );
}

export default function OcrReviewView({ section, learningDocument, onCloseLearningDocument }: {
  section: OcrReviewSection;
  learningDocument?: LearningEvidence | null;
  onCloseLearningDocument?: () => void;
}) {
  if (section === "approve-documents" && learningDocument && onCloseLearningDocument) {
    return <OcrLearningDocumentView key={`${learningDocument.companyId}:${learningDocument.documentId}`}
      evidence={learningDocument} onBack={onCloseLearningDocument} />;
  }
  return section === "analytics" ? <ReviewAnalyticsView /> : <ApproveDocumentsView />;
}
