import { Expand, Maximize2, Minimize2, MoveHorizontal, RotateCcw, RotateCw, ZoomIn, ZoomOut } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { MAX_PREVIEW_ZOOM, MIN_PREVIEW_ZOOM, type PreviewFit } from '../lib/documentPreview';
import { PageActionButton } from './PageHeader';

/** Shared by the OCR review canvas and the original PDF / image viewer. */
export default function DocumentPreviewControls({ scale, disabled = false, expanded, onZoom, onFit, onRotate, onExpand }: {
  scale: number; disabled?: boolean; expanded: boolean; onZoom: (scale: number) => void;
  onFit: (fit: PreviewFit) => void; onRotate: (direction: -1 | 1) => void; onExpand: () => void;
}) {
  return <div role="toolbar" aria-label={t('Document viewing controls')} className="flex flex-wrap items-center justify-center gap-1">
    <PageActionButton iconOnly icon={<ZoomOut size={16}/>} disabled={disabled || scale <= MIN_PREVIEW_ZOOM} onClick={() => onZoom(Math.round((scale - 0.1) * 100) / 100)}>Zoom out</PageActionButton>
    <button type="button" data-tooltip={t('Actual size')} aria-label={t('Actual size')} disabled={disabled} onClick={() => onZoom(1)} className="h-8 w-12 shrink-0 rounded-md font-montserrat text-xs font-semibold tabular-nums text-[#7288A3] hover:bg-[#E5EDF9] disabled:opacity-50"><span aria-live="polite">{Math.round(scale * 100)}%</span></button>
    <PageActionButton iconOnly icon={<ZoomIn size={16}/>} disabled={disabled || scale >= MAX_PREVIEW_ZOOM} onClick={() => onZoom(Math.round((scale + 0.1) * 100) / 100)}>Zoom in</PageActionButton>
    <PageActionButton iconOnly icon={<MoveHorizontal size={16}/>} disabled={disabled} onClick={() => onFit('width')}>Fit to width</PageActionButton>
    <PageActionButton iconOnly icon={<Expand size={16}/>} disabled={disabled} onClick={() => onFit('page')}>Fit whole page</PageActionButton>
    <PageActionButton iconOnly icon={<RotateCcw size={16}/>} disabled={disabled} onClick={() => onRotate(-1)}>Rotate left</PageActionButton>
    <PageActionButton iconOnly icon={<RotateCw size={16}/>} disabled={disabled} onClick={() => onRotate(1)}>Rotate right</PageActionButton>
    <PageActionButton iconOnly icon={expanded ? <Minimize2 size={16}/> : <Maximize2 size={16}/>} onClick={onExpand}>{expanded ? 'Reduce document preview' : 'Expand document preview'}</PageActionButton>
  </div>;
}
