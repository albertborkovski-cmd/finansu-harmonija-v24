import type { ReactNode } from 'react';
import { ExternalLink, Info } from 'lucide-react';
import { translateUi as t } from '../i18n/language';

export const PROFILE_INTEGRATION_LINKS = {
  drive: 'https://drive.google.com/',
  driveAbout: 'https://www.google.com/intl/lt/drive/',
  entra: 'https://entra.microsoft.com/',
} as const;

export function IntegrationHelpLink({ href, children }: { href: string; children: ReactNode }) {
  return <a href={href} target="_blank" rel="noopener noreferrer" className="inline-flex max-w-full items-center gap-1.5 text-[12px] font-medium text-[#007EA7] underline decoration-[#007EA7]/40 underline-offset-4 hover:decoration-[#007EA7] focus-visible:rounded focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]">{children}<ExternalLink size={13} aria-hidden="true" className="shrink-0" /><span className="sr-only">{t('Opens in a new tab')}</span></a>;
}

export function IntegrationInstructions({ title, steps, children }: { title: string; steps: string[]; children?: ReactNode }) {
  return <div className="rounded-lg border border-[#D3E1EC] bg-[#F7FAFC] p-4">
    <h4 className="mb-3 flex items-center gap-2 text-[13px] font-semibold text-[#10233A]"><Info size={16} aria-hidden="true" className="shrink-0 text-[#007EA7]" />{t(title)}</h4>
    <ol className="list-decimal space-y-2 pl-5 text-[12px] leading-5 text-[#526B86]">{steps.map(step => <li key={step} className="pl-1">{t(step)}</li>)}</ol>
    {children && <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-[#D3E1EC] pt-3">{children}</div>}
  </div>;
}

export function IntegrationFieldHelp({ id, children }: { id: string; children: ReactNode }) {
  return <span id={id} className="block text-[12px] font-normal leading-5 text-[#7288A3]">{children}</span>;
}
