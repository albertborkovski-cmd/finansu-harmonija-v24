import { translateUi as uiText } from '../i18n/language';
import {
  lazy,
  Suspense,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type MouseEvent as ReactMouseEvent,
  type ReactNode,
} from "react";
import Sidebar from "./Sidebar";
import WorkspaceModeSwitcher from './WorkspaceModeSwitcher';
import { normalizeWorkspaceMode, workspaceMenuVisible, workspaceModeStorageKey, type WorkspaceMode } from '../lib/workspaceMode';
import { Bell, X, ArrowRight } from 'lucide-react';
import NotificationDetailsPanel from './NotificationDetailsPanel';
import NotificationRelativeTime from './NotificationRelativeTime';
import { ensureImportantNotificationExamples, linkImportantNotificationExamples } from '../lib/importantNotificationExamples';
import { getNotificationBackgroundClassName, getNotificationModuleLabel, getNotificationRelatedObjectLabel, notificationMessage } from '../lib/notificationPresentation';
import RelatedObjectLink from './RelatedObjectLink';
import { canAccessAssignedOrganization } from '../lib/linkedSettingsData';
import { useOrganizationAccessRevision } from './useOrganizationAccessRevision';
import DashboardView from "./DashboardView";
import { GLOBAL_DOCUMENT_MENU_ITEMS } from '../lib/globalDocumentNavigation';
import type { UploadedDocumentsGroup } from "../lib/uploadedDocuments";
import { ocrChatDocumentDestination } from '../lib/ocrChatRelatedObjects';
import type { LearningEvidence } from '../lib/ocrLearning';
import type { InvoiceChatContext } from "./invoices/invoiceChat";
import type {
  OrganizationReferenceSection,
} from "./OrganizationReferenceValuesView";
import type {
  SecurityAccessTarget,
} from "./ResourceSecurityAccessView";
import type {
  AdministrationSection,
} from "./AdministrationView";
import type {
  OcrProcess,
} from "./AutomationProcessDetailView";
import OcrContextFilters from "./OcrContextFilters";
import { supabase, type Company, type DbDocument } from "../lib/supabase";
import { usePersistentState } from "../hooks/usePersistentState";
import { useOcrAutomaticRouting } from '../hooks/useOcrAutomaticRouting';
import {
  APP_MODULES,
  canEditMenu,
  canViewMenu,
  moduleForMenu,
  parseSession,
  type AppSession,
} from "../lib/accessControl";
import { userProfileStorageKey } from "../lib/currentUser";
import { useAttentionNotifications } from "../hooks/useAttentionNotifications";
import { useVisibleNotificationRecords } from '../hooks/useVisibleNotificationRecords';
import { getDashboardAttentionNotifications } from '../lib/notificationAttention';
import { getNotificationStatus, getNotificationTabCounts, getNotificationPanelRecords, isNotificationRead, type AttentionNotification, type NotificationTab, type RelatedObject } from "../lib/notifications";
import { resolveRelatedObject, loadRelatedObjectChats, loadRelatedObjects } from '../lib/relatedObjects';

const ProfileSettings = lazy(() => import("./ProfileSettings"));
const SaasAdministration = lazy(() => import('./SaasAdministration'));
const Companies = lazy(() => import("./Companies"));
const CompanyActionHistoryView = lazy(() => import('./CompanyActionHistoryView'));
const CompanyDetail = lazy(() => import("./CompanyDetail"));
const UploadedDocumentsView = lazy(() => import("./UploadedDocumentsView"));
const Documents = lazy(() => import('./Documents'));
const OcrView = lazy(() => import("./OcrView"));
const MachineLearningView = lazy(() => import("./ml"));
const OcrMachineLearningView = lazy(() => import('./OcrMachineLearningView'));
const OrganizationRequiredActionsView = lazy(() => import('./OrganizationRequiredActionsView'));
const ChatsView = lazy(() => import("./ChatsView"));
const OcrChatsView = lazy(() => import('./OcrChatsView'));
const HelpFaqView = lazy(() => import("./HelpFaqView"));
const VatClassificationsView = lazy(() => import("./VatClassificationsView"));
const GeneralLedgerView = lazy(() => import("./GeneralLedgerView"));
const SettingsIdentityManagementView = lazy(() => import("./SettingsIdentityManagementView"));
const ExchangeRatesView = lazy(() => import('./ExchangeRatesView'));
const OrganizationReferenceValuesView = lazy(() => import("./OrganizationReferenceValuesView"));
const SettingsOrganizationsView = lazy(() => import("./SettingsOrganizationsView"));
const OrganizationEmailSettingsView = lazy(() => import("./OrganizationEmailSettingsView"));
const AdministratorSettings = lazy(() => import('./AdministratorSettings'));
const OperationDateValidationView = lazy(() => import("./OperationDateValidationView"));
const AutomationSecurityAccessView = lazy(() => import("./AutomationSecurityAccessView"));
const ResourceSecurityAccessView = lazy(() => import("./ResourceSecurityAccessView"));
const AdministrationView = lazy(() => import("./AdministrationView"));
const AutomationProcessDetailView = lazy(() => import("./AutomationProcessDetailView"));
const SettingsUserAnalyticsView = lazy(() => import("./SettingsUserAnalyticsView"));
const OcrReviewView = lazy(() => import("./OcrReviewView"));
const OcrLearningDocumentView = lazy(() => import('./OcrLearningDocumentView'));
const OcrStatusSettingsView = lazy(() => import('./OcrStatusSettingsView'));
const OcrDocumentIssuesView = lazy(() => import('./OcrDocumentIssuesView'));
const OcrMyTasksView = lazy(() => import('./OcrMyTasksView'));

interface DashboardProps {
  onLogout: () => void;
  session: AppSession;
}

const MENU_FALLBACK_ORDER = [
  "global-dashboard", "uploaded-documents", "dashboard", "messages", "notifications",
  "settings-internal-roles", "settings-internal-users",
  "settings-external-roles", "settings-external-users",
  "settings-organizations", "settings-counterparties", "settings-general-ledger",
  "settings-analytics", "info", "ocr-workspace-my-tasks", "ocr-workspace-document-issues",
  "ocr-ml", "ocr-machine-learning", "ocr-review-analytics",
  "ocr-admin-document-type", "ocr-admin-activity",
];

function firstAccessibleMenu(session: AppSession, mode: WorkspaceMode = 'combined') {
  return MENU_FALLBACK_ORDER.find(menu => workspaceMenuVisible(mode, menu) && canViewMenu(session, menu)) ?? "profile";
}

function workspaceDefaultMenu(session: AppSession) {
  return ["ocr-workspace-my-tasks", "ocr-workspace-document-issues"]
    .find(menu => canViewMenu(session, menu)) ?? firstAccessibleMenu(session);
}

function administrationDefaultMenu(session: AppSession) {
  return ["ocr-admin-document-type", "ocr-admin-activity"]
    .find(menu => canViewMenu(session, menu)) ?? firstAccessibleMenu(session);
}

function ReadOnlyBoundary({
  readOnly,
  children,
}: {
  readOnly: boolean;
  children: ReactNode;
}) {
  const preventMutation = (event: ReactMouseEvent<HTMLDivElement>) => {
    if (!readOnly) return;
    const target = event.target;
    if (!(target instanceof Element)) return;
    const button = target.closest("button");
    if (!button) return;
    const action =
      `${button.textContent ?? ""} ${button.getAttribute("aria-label") ?? ""} ${button.getAttribute("title") ?? ""}`.trim();
    if (
      /\b(filters?|columns|refresh|export|view|search|cancel|back|show more)\b/i.test(
        action,
      )
    )
      return;
    if (
      /\b(create|edit|delete|save|update|upload|import|add|remove|approve|send|process|train|run|stop|restart|enable|disable|security access)\b/i.test(
        action,
      )
    ) {
      event.preventDefault();
      event.stopPropagation();
    }
  };
  return (
    <div
      className="min-h-full"
      data-access-mode={readOnly ? "read-only" : "edit"}
      onClickCapture={preventMutation}
    >
      {children}
    </div>
  );
}

export default function Dashboard({ onLogout, session }: DashboardProps) {
  useOcrAutomaticRouting(session);
  const [storedMode, setWorkspaceMode] = usePersistentState<WorkspaceMode>(workspaceModeStorageKey(session.email), 'combined');
  const workspaceMode = normalizeWorkspaceMode(storedMode);
  const [globalDocumentTarget, setGlobalDocumentTarget] = useState<{ id: string; mode: 'view' | 'edit' | 'original-view' } | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notificationsExpanded, setNotificationsExpanded] = useState(false);
  const [notificationDetails, setNotificationDetails] = useState<AttentionNotification | null>(null);
  const [notificationNavigationError, setNotificationNavigationError] = useState('');
  const [ocrNotificationTarget, setOcrNotificationTarget] = useState<{ documentId: string; issueId?: string; view: 'uploaded' | 'issue' | 'chat' | 'teamlead'; name: string; companyId: string; token: number } | null>(null);
  const organizationAccessRevision = useOrganizationAccessRevision();
  const notificationRecords = useAttentionNotifications(true);
  const visibleNotifications = useVisibleNotificationRecords(notificationRecords, session, workspaceMode);
  const demoAlertCompany = visibleNotifications.organizations.find(company => company.name === 'Alice Stone') ?? visibleNotifications.organizations[0];
  useEffect(() => {
    let cancelled = false;
    if (workspaceMode !== 'ocr' && import.meta.env.DEV && demoAlertCompany && visibleNotifications.session && canViewMenu(visibleNotifications.session, 'notifications')) {
      ensureImportantNotificationExamples(demoAlertCompany, visibleNotifications.session.email);
      const current = visibleNotifications.session;
      void loadRelatedObjects(demoAlertCompany, current).then(objects => {
        if (!cancelled) linkImportantNotificationExamples(demoAlertCompany.id, current.email, objects);
      }).catch(() => { /* Keep alerts readable if their source catalog is unavailable. */ });
    }
    return () => { cancelled = true; };
  }, [demoAlertCompany, visibleNotifications.session, workspaceMode]);
  const notificationCounts = getNotificationTabCounts(visibleNotifications.records, visibleNotifications.session ?? session);
  const activeNotificationCount = notificationCounts.notifications;
  const activeNotificationBadge = String(activeNotificationCount);
  const recentNotifications = getNotificationPanelRecords(visibleNotifications.records, visibleNotifications.session ?? session);
  useEffect(() => {
    if (!notificationsOpen) return;
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setNotificationsOpen(false); };
    document.addEventListener('keydown', close);
    return () => document.removeEventListener('keydown', close);
  }, [notificationsOpen]);
  const attentionNotifications = visibleNotifications.session
    ? getDashboardAttentionNotifications(visibleNotifications.records, visibleNotifications.session) : [];
  const [notificationTarget, setNotificationTarget] = useState<{ tab: NotificationTab; query: string; organization?: { id: string; name: string }; requiresAction?: boolean; openTasksOnly?: boolean; returnCompany?: { company: Company; menu: string } }>({ tab: "notifications", query: "" });
  const [isMenuExpanded, setIsMenuExpanded] = useState(true);
  const [activeMenu, setActiveMenu] = useState(() => firstAccessibleMenu(session, workspaceMode));
  const [ocrLearningDocument, setOcrLearningDocument] = useState<LearningEvidence | null>(null);
  const [uploadedDocumentsGroup, setUploadedDocumentsGroup] =
    useState<UploadedDocumentsGroup>("All");
  const [userProfile, setUserProfile] = usePersistentState(
    userProfileStorageKey(session.email),
    {
      fullName: session.fullName,
      email: session.email,
      phone: "",
      role: session.roleNames.join(", "),
    },
  );
  const currentUserName = userProfile.fullName.trim() || session.fullName;
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  useEffect(() => {
    if (selectedCompany && !canAccessAssignedOrganization(selectedCompany, session)) {
      setSelectedCompany(null);
      setActiveMenu('dashboard');
    }
  }, [selectedCompany, session, organizationAccessRevision]);
  const [selectedCompanyMenu, setSelectedCompanyMenu] = useState("overview");
  const [selectedCompanyDocumentId, setSelectedCompanyDocumentId] = useState<string | null>(null);
  const [selectedCompanyDocumentMode, setSelectedCompanyDocumentMode] = useState<'view' | 'edit' | 'original-view'>('view');
  const [selectedCompanyRelatedObject, setSelectedCompanyRelatedObject] = useState<RelatedObject | undefined>();
  const [relatedChat, setRelatedChat] = useState<InvoiceChatContext | null>(null);
  const displayedMenu = relatedChat ? 'messages' : activeMenu;
  const notificationsAvailable = canViewMenu(session, 'notifications');
  useEffect(() => {
    if (notificationsAvailable) return;
    setNotificationsOpen(false);
    setNotificationsExpanded(false);
    setNotificationDetails(null);
    setNotificationNavigationError('');
  }, [notificationsAvailable]);
  const mainContentRef = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    if (ocrLearningDocument && mainContentRef.current) mainContentRef.current.scrollTop = 0;
  }, [ocrLearningDocument]);
  const relatedChatReturnScroll = useRef<number | null>(null);
  const [selectedChat, setSelectedChat] = useState<InvoiceChatContext | null>(null);
  const [automationProcessFromNode, setAutomationProcessFromNode] =
    useState<OcrProcess | null>(null);
  const [automationRunIdFromNode, setAutomationRunIdFromNode] = useState<
    string | null
  >(null);
  const [automationReturnMenu, setAutomationReturnMenu] = useState("ocr-ml-documents");
  const [securityAccessTarget, setSecurityAccessTarget] =
    useState<SecurityAccessTarget | null>(null);
  const [securityAccessReturnMenu, setSecurityAccessReturnMenu] =
    useState("ocr");
  const [directoryRoleFilter, setDirectoryRoleFilter] = useState<string | undefined>();
  const [userDirectoryCreateRequest, setUserDirectoryCreateRequest] = useState<
    "Internal users" | "External users" | null
  >(null);

  useLayoutEffect(() => {
    if (relatedChatReturnScroll.current === null) return;
    if (mainContentRef.current) {
      mainContentRef.current.scrollTop = relatedChat ? 0 : relatedChatReturnScroll.current;
    }
    if (!relatedChat) relatedChatReturnScroll.current = null;
  }, [relatedChat]);

  useEffect(() => {
    const showRefreshFeedback = (event: MouseEvent) => {
      const target = event.target;
      if (!(target instanceof Element)) return;

      const button = target.closest<HTMLButtonElement>("button");
      if (!button || button.disabled) return;

      const title = button.title.trim().toUpperCase();
      const ariaLabel = (button.getAttribute("aria-label") ?? "")
        .trim()
        .toUpperCase();
      const isRefreshAll =
        button.dataset.buttonFamily === "refresh-all" ||
        title === "REFRESH ALL" ||
        ariaLabel === "REFRESH ALL" ||
        ariaLabel.startsWith("REFRESH ALL ");

      if (!isRefreshAll) return;

      // Most refresh handlers replace their row objects immediately. Apply the
      // feedback on the next frame so the animation lands on the new DOM rows,
      // rather than on elements React has just removed.
      window.requestAnimationFrame(() => {
        const appMain =
          button.closest<HTMLElement>("[data-app-main]") ??
          document.querySelector<HTMLElement>("[data-app-main]");
        if (!appMain) return;

        document
          .querySelectorAll(".refresh-all-record-text")
          .forEach((element) =>
            element.classList.remove("refresh-all-record-text"),
          );

        const recordRows = Array.from(
          appMain.querySelectorAll<HTMLElement>(
            "[data-refresh-row], tbody tr, [role='row'], [class]",
          ),
        ).filter((element) => {
          if (element.closest("nav, header") || element.contains(button))
            return false;
          const className = element.className;
          if (typeof className !== "string") return false;
          const looksLikeRecord =
            element.matches("[data-refresh-row], tbody tr, [role='row']") ||
            className.includes("hover:bg") ||
            className.includes("bg-[#F8FDFF]");
          if (!looksLikeRecord || !element.textContent?.trim()) return false;
          const bounds = element.getBoundingClientRect();
          return bounds.width > 220 && bounds.height >= 24 && bounds.height <= 96;
        });

        const textElements = new Set<HTMLElement>();
        recordRows.forEach((row) => {
          row
            .querySelectorAll<HTMLElement>("span, a, p, td, div")
            .forEach((element) => {
              if (
                !element.textContent?.trim() ||
                element.closest("button") ||
                element.querySelector("span, a, p, td, div")
              ) {
                return;
              }
              textElements.add(element);
            });
        });

        textElements.forEach(element => element.classList.remove("refresh-all-record-text"));
        // Restart the shared animation with one layout flush, not one per cell.
        if (textElements.size) void appMain.offsetWidth;
        textElements.forEach(element => element.classList.add("refresh-all-record-text"));

        window.setTimeout(() => {
          textElements.forEach((element) =>
            element.classList.remove("refresh-all-record-text"),
          );
        }, 520);
      });
    };

    document.addEventListener("click", showRefreshFeedback, true);
    return () =>
      document.removeEventListener("click", showRefreshFeedback, true);
  }, []);

  useEffect(() => {
    let interceptingMouseBack = false;
    let resetTimer: number | undefined;

    const visibleBackButton = () => {
      const candidates = Array.from(
        document.querySelectorAll<HTMLButtonElement>("button"),
      )
        .filter((button) => {
          if (button.disabled) return false;
          const action = `${button.textContent ?? ""} ${
            button.getAttribute("aria-label") ?? ""
          } ${button.title}`.trim();
          if (!/\bback\b/i.test(action)) return false;
          const bounds = button.getBoundingClientRect();
          const style = window.getComputedStyle(button);
          return (
            bounds.width > 0 &&
            bounds.height > 0 &&
            style.display !== "none" &&
            style.visibility !== "hidden"
          );
        })
        .sort((first, second) => {
          const firstBounds = first.getBoundingClientRect();
          const secondBounds = second.getBoundingClientRect();
          return secondBounds.left - firstBounds.left || firstBounds.top - secondBounds.top;
        });

      return candidates[0];
    };

    const handleMouseBack = (event: MouseEvent) => {
      if (event.button !== 3) return;

      const backButton = visibleBackButton();
      if (!backButton && !interceptingMouseBack) return;

      event.preventDefault();
      event.stopPropagation();

      if (!interceptingMouseBack && backButton) {
        interceptingMouseBack = true;
        backButton.click();
      }

      window.clearTimeout(resetTimer);
      resetTimer = window.setTimeout(() => {
        interceptingMouseBack = false;
      }, 250);
    };

    window.addEventListener("mousedown", handleMouseBack, true);
    window.addEventListener("mouseup", handleMouseBack, true);
    window.addEventListener("auxclick", handleMouseBack, true);

    return () => {
      window.clearTimeout(resetTimer);
      window.removeEventListener("mousedown", handleMouseBack, true);
      window.removeEventListener("mouseup", handleMouseBack, true);
      window.removeEventListener("auxclick", handleMouseBack, true);
    };
  }, []);

  useEffect(() => {
    if (!workspaceMenuVisible(workspaceMode, activeMenu)) {
      setActiveMenu(activeMenu === 'uploaded-documents-invoices' && workspaceMode !== 'fh' && canViewMenu(session, 'uploaded-documents-documents')
        ? 'uploaded-documents-documents' : firstAccessibleMenu(session, workspaceMode));
      setRelatedChat(null);
      setAutomationProcessFromNode(null);
      setSecurityAccessTarget(null);
      return;
    }
    if (activeMenu === 'ocr-all-documents' || activeMenu.startsWith('ocr-all-documents-') || activeMenu === 'ocr-review-approve-documents') {
      setActiveMenu(canViewMenu(session, 'uploaded-documents-documents') ? 'uploaded-documents-documents' : workspaceDefaultMenu(session));
      return;
    }
    if (activeMenu === 'ocr-review') { setActiveMenu('ocr-review-analytics'); return; }
    if (activeMenu === "ocr-admin" || activeMenu === "ocr-admin-human-task-types") {
      setActiveMenu(administrationDefaultMenu(session));
      return;
    }
    if (activeMenu === "ocr-workspace") {
      setActiveMenu(workspaceDefaultMenu(session));
      return;
    }
    if (activeMenu === "profile" || canViewMenu(session, activeMenu)) return;
    setActiveMenu(firstAccessibleMenu(session, workspaceMode));
  }, [activeMenu, session, workspaceMode]);

  const handleMenuClick = (menu: string) => {
    if (!workspaceMenuVisible(workspaceMode, menu)) return;
    setOcrNotificationTarget(null);
    setGlobalDocumentTarget(null);
    setDirectoryRoleFilter(undefined);
    if (menu === "notifications") setNotificationTarget({ tab: "reminders", query: "" });
    if (menu !== "profile" && !canViewMenu(session, menu)) return;
    setOcrLearningDocument(null);
    relatedChatReturnScroll.current = null;
    setRelatedChat(null);
    const targetMenu =
      menu === "ocr"
        ? [
            "ocr-workspace-my-tasks",
            "ocr-workspace-document-issues",
            "ocr-ml",
            "ocr-machine-learning",
            "ocr-review-analytics",
            "ocr-admin-document-type",
            "ocr-admin-activity",
          ].find((candidate) => canViewMenu(session, candidate)) ?? "profile"
        : menu === 'uploaded-documents' ? GLOBAL_DOCUMENT_MENU_ITEMS.find(item => canViewMenu(session, item.id))?.id ?? 'profile'
        : menu === "ocr-workspace" ? workspaceDefaultMenu(session)
        : menu === "ocr-admin" ? administrationDefaultMenu(session) : menu;
    if (menu === "messages") setSelectedChat(null);
    if (targetMenu === "uploaded-documents-uploaded") setUploadedDocumentsGroup("All");
    setAutomationProcessFromNode(null);
    setAutomationRunIdFromNode(null);
    setSecurityAccessTarget(null);
    setActiveMenu(targetMenu);
  };

  const openSecurityAccess = (
    target: SecurityAccessTarget,
    returnMenu: string,
  ) => {
    setSecurityAccessTarget(target);
    setSecurityAccessReturnMenu(returnMenu);
    setActiveMenu("ocr-admin-groups");
  };

  const openCompany = (company: Company, menu = "overview", documentId: string | null = null, mode: 'view' | 'edit' | 'original-view' = 'view') => {
    setSelectedCompanyRelatedObject(undefined);
    setSelectedCompanyDocumentMode(mode);
    setSelectedCompanyMenu(menu);
    setSelectedCompanyDocumentId(documentId);
    setSelectedCompany(company);
  };

  const openRelatedObject = async (object: RelatedObject, editDocument = false) => {
    let currentSession = parseSession(JSON.stringify(session));
    if (!currentSession) throw new Error('Your session is no longer valid.');
    const { data, error } = await supabase.from('companies').select('*');
    const company = !error && (data as unknown as Company[] | null)?.find(candidate => candidate.id === object.organizationId);
    if (!company || !canAccessAssignedOrganization(company, currentSession)) throw new Error('This organization is no longer accessible.');
    const resolved = await resolveRelatedObject(object, company, currentSession);
    if (!resolved) throw new Error('The related object was removed or is no longer accessible.');
    currentSession = parseSession(JSON.stringify(session));
    if (!currentSession?.access.companies.view || !canAccessAssignedOrganization(company, currentSession)) throw new Error('This organization is no longer accessible.');
    if (resolved.type === 'Chat') {
      const { data: documents, error: documentError } = await supabase.from('documents').select('*').eq('company_id', company.id);
      if (documentError) throw new Error('This chat is no longer available.');
      currentSession = parseSession(JSON.stringify(session));
      if (!currentSession || !canViewMenu(currentSession, 'messages') || !canAccessAssignedOrganization(company, currentSession)) throw new Error('This chat is no longer accessible.');
      const conversation = loadRelatedObjectChats(company, currentSession, (documents ?? []) as unknown as DbDocument[]).find(chat => chat.storageKey === resolved.recordId);
      if (!conversation) throw new Error('This chat is no longer available.');
      relatedChatReturnScroll.current = mainContentRef.current?.scrollTop ?? 0;
      setRelatedChat({ ...conversation, organizationId: company.id, companyName: company.name });
      return;
    }
    if (resolved.type === 'Document' || resolved.type === 'Invoice') {
      openCompany(company, 'documents', resolved.recordId ?? resolved.id, editDocument && canEditMenu(currentSession, 'dashboard') ? 'edit' : 'view');
      return;
    }
    openCompany(company);
    setSelectedCompanyRelatedObject(resolved);
  };

  const openOcrNotification = async (row: AttentionNotification) => {
    const target = row.ocrTarget;
    if (!target || workspaceMode === 'fh') return;
    const [{ data, error }, { data: companyRows }, access, issues, teamLead] = await Promise.all([
      supabase.from('documents').select('*').eq('id', target.documentId), supabase.from('companies').select('*'),
      import('../lib/documentEditAccess'), import('../lib/documentIssueAccess'), import('../lib/ocrTeamLeadAccess'),
    ]);
    const document = data?.[0] as unknown as DbDocument | undefined;
    const company = (companyRows as unknown as Company[] || []).find(item => item.id === document?.company_id);
    const current = parseSession(JSON.stringify(session));
    const issue = document?.digitization_issues?.find(item => item.id === target.issueId);
    const destination = { uploaded: 'uploaded-documents-uploaded', issue: 'ocr-workspace-document-issues', chat: 'messages', teamlead: 'ocr-ml' }[target.view];
    if (error || !document || document.document_deletion || !current || !canViewMenu(current, destination)
      || (company ? !canAccessAssignedOrganization(company, current) : !access.canAccessUnassignedDocuments())
      || (target.view === 'issue' && (!company || !issue || !issues.canReviewDocumentIssues() || !access.canEditCompanyDocumentIssues(company)))
      || (target.view === 'chat' && (!company || !issue || !(issues.canUseIssueConversation(company, 'worker') || issues.canUseIssueConversation(company, 'accountant'))))
      || (target.view === 'teamlead' && (!company || !teamLead.canViewTeamLeadOrganization(company))))
      throw new Error(uiText('This reported document is no longer accessible. Refresh the list.'));
    setSelectedCompany(null); setRelatedChat(null); setSelectedChat(null); setGlobalDocumentTarget(null);
    setOcrNotificationTarget({ ...target, name: document.file_case || document.number, companyId: document.company_id || '', token: Date.now() });
    setActiveMenu(destination); setNotificationsOpen(false); setNotificationDetails(null);
  };

  const openDocumentInOrganization = async (document: DbDocument, mode: 'view' | 'edit' | 'original-view' = 'view') => {
    if (workspaceMode === 'ocr') {
      if (!canViewMenu(session, 'uploaded-documents-documents')) return;
      setSelectedCompany(null);
      setGlobalDocumentTarget({ id: document.id, mode });
      setActiveMenu('uploaded-documents-documents');
      return;
    }
    if (!document.company_id) return;
    const { data } = await supabase.from("companies").select("*");
    const company = (data as unknown as Company[] | null)?.find(
      (candidate) => candidate.id === document.company_id,
    );
    if (company) openCompany(company, "documents", document.id, mode);
  };

  const openOcrChatDocument = (document: DbDocument) => {
    if (document.entry_method?.trim().toLowerCase() === 'manual') { void openDocumentInOrganization(document); return; }
    const destination = ocrChatDocumentDestination(document);
    if (!canViewMenu(session, destination)) return;
    setSelectedCompany(null); setRelatedChat(null); setSelectedChat(null);
    if (destination === 'uploaded-documents-documents') {
      setOcrNotificationTarget(null);
      setGlobalDocumentTarget({ id: document.id, mode: 'view' });
    } else {
      setGlobalDocumentTarget(null);
      setOcrNotificationTarget({ view: 'uploaded', documentId: document.id, companyId: document.company_id || '', name: document.file_case || document.number, token: Date.now() });
    }
    setActiveMenu(destination);
  };

  const companyContent = selectedCompany && canAccessAssignedOrganization(selectedCompany, session) ? (
      <ReadOnlyBoundary readOnly={!session.access.companies.edit}>
        <CompanyDetail
          key={`${selectedCompany.id}:${selectedCompanyRelatedObject?.id ?? selectedCompanyDocumentId ?? selectedCompanyMenu}`}
          company={selectedCompany}
          workspaceMode={workspaceMode}
          onOpenOcrDocument={openDocumentInOrganization}
          canEditReconciliation={session.access.companies.edit}
          initialMenu={selectedCompanyMenu}
          initialDocumentId={selectedCompanyDocumentId}
          initialDocumentMode={selectedCompanyDocumentMode}
          initialRelatedObject={selectedCompanyRelatedObject}
          notificationsContent={canViewMenu(session, 'notifications') ? <OrganizationRequiredActionsView
            organization={{ id: selectedCompany.id, name: selectedCompany.name }}
            session={session}
            workspaceMode={workspaceMode}
            onOpenOcrNotification={openOcrNotification}
            initialTab="reminders"
            initialOpenTasksOnly={selectedCompanyMenu === 'notifications' && notificationTarget.organization?.id === selectedCompany.id && notificationTarget.openTasksOnly}
            onOpenRelatedObject={openRelatedObject}
          /> : undefined}
          onLogout={onLogout}
          onOpenProfile={() => {
            relatedChatReturnScroll.current = null;
            setRelatedChat(null);
            setSelectedCompany(null);
            setSelectedCompanyMenu("overview");
            setSelectedCompanyDocumentId(null);
            setSelectedCompanyRelatedObject(undefined);
            setSelectedChat(null);
            setAutomationProcessFromNode(null);
            setAutomationRunIdFromNode(null);
            setSecurityAccessTarget(null);
            setActiveMenu("profile");
          }}
          onOpenChat={(context) => {
            relatedChatReturnScroll.current = null;
            setRelatedChat(null);
            setSelectedChat({ ...context, organizationId: selectedCompany.id });
            setSelectedCompany(null);
            setSelectedCompanyMenu("overview");
            setSelectedCompanyDocumentId(null);
            setActiveMenu("messages");
          }}
          onBack={() => {
            setSelectedCompany(null);
            setSelectedCompanyMenu("overview");
            setSelectedCompanyDocumentId(null);
            setSelectedCompanyRelatedObject(undefined);
          }}
        />
      </ReadOnlyBoundary>
    ) : null;

  const renderContent = () => {
    if (!workspaceMenuVisible(workspaceMode, activeMenu)) return null;
    const documentMenu = activeMenu === 'uploaded-documents'
      ? GLOBAL_DOCUMENT_MENU_ITEMS.find(item => canViewMenu(session, item.id))?.id
      : activeMenu;
    if (securityAccessTarget) {
      return (
        <ResourceSecurityAccessView
          target={securityAccessTarget}
          onBack={() => {
            setSecurityAccessTarget(null);
            setActiveMenu(securityAccessReturnMenu);
          }}
        />
      );
    }
    if (automationProcessFromNode) {
      return (
        <AutomationProcessDetailView
          process={automationProcessFromNode}
          initialRunId={automationRunIdFromNode ?? undefined}
          onBack={() => {
            setAutomationProcessFromNode(null);
            setAutomationRunIdFromNode(null);
            setActiveMenu(automationReturnMenu);
          }}
        />
      );
    }
    if (activeMenu === 'saas') return canViewMenu(session, 'saas') ? <SaasAdministration /> : null;
    if (activeMenu === "profile")
      return (
        <ProfileSettings
          workspaceMode={workspaceMode}
          user={{
            name: currentUserName,
            email: session.email,
            phone: userProfile.phone,
            role: session.roleNames.join(", "),
          }}
          onProfileSaved={setUserProfile}
          onCreateInternalUser={canViewMenu(session, 'settings-internal-users') && canEditMenu(session, 'settings-internal-users') ? () => {
            setUserDirectoryCreateRequest('Internal users');
            handleMenuClick('settings-internal-users');
          } : undefined}
          onOpenCompanies={() => {
            setSelectedCompany(null);
            setSelectedCompanyMenu("overview");
            setSelectedCompanyDocumentId(null);
            setActiveMenu("dashboard");
          }}
        />
      );
    if (activeMenu === "dashboard")
      return <SettingsOrganizationsView companiesMode workspaceMode={workspaceMode} onNavigateToUserDirectory={audience => {
        setUserDirectoryCreateRequest(audience);
        handleMenuClick(audience === 'Internal users' ? 'settings-internal-users' : 'settings-external-users');
      }} onViewCompany={(company) => openCompany(company)} onOpenRequiredActions={workspaceMode === 'ocr' ? undefined : company => {
        if (!canViewMenu(session, 'notifications') || !visibleNotifications.canAccessOrganization(company.id)) return;
        setNotificationTarget({ tab: 'reminders', query: '', organization: { id: company.id, name: company.name }, openTasksOnly: true });
        openCompany(company, 'notifications');
      }} />;
    if (activeMenu === 'audit-history') return <CompanyActionHistoryView company={{ id: 'all', name: 'All organizations', company_code: '', vat_code: '', client_since: 0, action_required: 0 }} global />;
    if (activeMenu === "global-dashboard")
      return (
        <DashboardView
          clientName="All companies"
          allCompanies
          workspaceMode={workspaceMode}
          attentionNotifications={canViewMenu(session, "notifications") ? attentionNotifications : undefined}
          onOpenAttention={async row => {
            if (row.ocrTarget) await openOcrNotification(row);
            else if (row.relatedObject && row.relatedObject.organizationId === row.organizationId) await openRelatedObject(row.relatedObject, true);
            else setNotificationDetails(row);
          }}
          onOpenNotifications={canViewMenu(session, "notifications") ? (tab = "reminders", query = "") => {
            if (tab === 'notifications') { setNotificationsExpanded(true); setNotificationsOpen(true); return; }
            setNotificationTarget({ tab, query, openTasksOnly: tab === 'reminders' && !query });
            setActiveMenu("notifications");
          } : undefined}
          roleNames={session.roleNames}
          access={session.access}
          onOpenDocument={openDocumentInOrganization}
          onOpenUploadedDocuments={(group) => {
            setUploadedDocumentsGroup(group);
            setActiveMenu(group === 'Processed' ? 'uploaded-documents-documents' : 'uploaded-documents-uploaded');
          }}
        />
      );
    if (documentMenu === 'uploaded-documents-documents')
      return <Documents key={`${documentMenu}:${globalDocumentTarget?.id ?? 'list'}`} allCompanies title="Documents"
        initialViewDocumentId={globalDocumentTarget?.id} initialDocumentMode={globalDocumentTarget?.mode}
        onInitialViewBack={() => setGlobalDocumentTarget(null)}
        onStartChat={canViewMenu(session, 'messages') ? context => { setRelatedChat(null); setSelectedChat(context); setActiveMenu('messages'); } : undefined} />;
    if (documentMenu === "uploaded-documents-uploaded")
      return (
        <UploadedDocumentsView
          key={ocrNotificationTarget?.view === 'uploaded' ? ocrNotificationTarget.token : 'uploads'}
          initialDocumentId={ocrNotificationTarget?.view === 'uploaded' ? ocrNotificationTarget.documentId : undefined}
          nestedNavigation
          initialGroup={uploadedDocumentsGroup}
          onOpenDocument={openDocumentInOrganization}
        />
      );
    if (activeMenu === "messages")
      return workspaceMode === 'fh' ? <ChatsView currentUserName={currentUserName} conversation={selectedChat} onOpenDocument={openDocumentInOrganization} />
        : <OcrChatsView key={ocrNotificationTarget?.view === 'chat' ? ocrNotificationTarget.token : 'chats'} session={session} currentUserName={currentUserName} conversation={selectedChat} ocrOnly={workspaceMode === 'ocr'}
          initialIssue={ocrNotificationTarget?.view === 'chat' && ocrNotificationTarget.issueId ? { documentId: ocrNotificationTarget.documentId, issueId: ocrNotificationTarget.issueId } : undefined} onOpenDocument={openOcrChatDocument} />;
    if (activeMenu === "notifications") return <OrganizationRequiredActionsView key={`${notificationTarget.organization?.id ?? 'all'}:${notificationTarget.tab}:${notificationTarget.query}:${Boolean(notificationTarget.requiresAction)}:${Boolean(notificationTarget.openTasksOnly)}`} organization={notificationTarget.organization} session={session} workspaceMode={workspaceMode} onOpenOcrNotification={openOcrNotification} initialTab="reminders" initialQuery={notificationTarget.query} initialRequiresAction={notificationTarget.requiresAction} initialOpenTasksOnly={notificationTarget.openTasksOnly} onOpenRelatedObject={openRelatedObject} onBack={notificationTarget.organization ? () => {
      setActiveMenu('dashboard');
      if (notificationTarget.returnCompany) openCompany(notificationTarget.returnCompany.company, notificationTarget.returnCompany.menu);
    } : undefined} />;
    if (activeMenu === "info") return <HelpFaqView />;
    if (activeMenu === 'settings-organizations-document-status-ocr') return <OcrStatusSettingsView />;
    const settingsSections = {
      "settings-internal-roles": {
        audience: "Internal users",
        section: "Roles",
      },
      "settings-internal-users": {
        audience: "Internal users",
        section: "Users",
      },
      "settings-external-roles": {
        audience: "External users",
        section: "Roles",
      },
      "settings-external-users": {
        audience: "External users",
        section: "Users",
      },
    } as const;
    if (activeMenu === 'settings-administrator') return <AdministratorSettings session={session} ocrOnly={workspaceMode === 'ocr'} />;
    if (workspaceMode === 'ocr' && ['settings-organizations', 'settings-organizations-document-status'].includes(activeMenu))
      return <OcrStatusSettingsView />;
    if (activeMenu === "settings-organizations")
      return <GeneralLedgerView />;
    if (activeMenu === "settings-vat-classifications")
      return <VatClassificationsView />;
    if (activeMenu === "settings-organizations-operation-date-validation")
      return <OperationDateValidationView />;
    if (activeMenu === "settings-organizations-email")
      return <OrganizationEmailSettingsView />;
    if (activeMenu === "settings-counterparties")
      return (
        <Companies
          title={uiText("Counterparties")}
          entityLabel="counterparty"
          dataSource="counterparties"
          allowCreate
          breadcrumbs={["Settings", "Counterparties"]}
        />
      );
    if (activeMenu === "settings-general-ledger") return <GeneralLedgerView />;
    if (activeMenu === "settings-organizations-exchange-rates") return <ExchangeRatesView key={activeMenu} />;
    if (activeMenu === "settings-organizations-base-currency") return <ExchangeRatesView key={activeMenu} initialTab="currency" />;
    if (activeMenu === "settings-analytics")
      return <SettingsUserAnalyticsView />;
    const organizationReferenceSections: Record<
      string,
      OrganizationReferenceSection
    > = {
      "settings-organizations-tax-country": "Tax country",
      "settings-organizations-legal-form": "Legal form",
      "settings-organizations-base-currency": "Base currency",
      "ocr-admin-document-type": "Document type",
      "settings-organizations-type": "Type",
      "settings-organizations-document-status": "Document Status",
      "settings-organizations-unit": "Unit",
    };
    if (organizationReferenceSections[activeMenu]) {
      return (
        <OrganizationReferenceValuesView
          key={activeMenu}
          section={organizationReferenceSections[activeMenu]}
          displayTitle={activeMenu === "settings-organizations-document-status" ? "Finansų harmonija" : undefined}
          breadcrumbParents={activeMenu === "settings-organizations-document-status" ? ["Settings", "General settings", "Status"] : ["Settings", "General settings"]}
        />
      );
    }
    const settingsSection =
      settingsSections[activeMenu as keyof typeof settingsSections];
    if (settingsSection) {
      if (
        settingsSection.section === "Roles" ||
        settingsSection.section === "Users"
      ) {
        return (
          <SettingsIdentityManagementView
            key={activeMenu}
            audience={settingsSection.audience}
            section={settingsSection.section}
            createOnOpen={
              settingsSection.section === "Users" &&
              userDirectoryCreateRequest === settingsSection.audience
            }
            onCreateOpened={() => setUserDirectoryCreateRequest(null)}
            initialRoleFilter={settingsSection.section === 'Users' ? directoryRoleFilter : undefined}
            onOpenRoleUsers={roleName => {
              handleMenuClick(settingsSection.audience === 'Internal users' ? 'settings-internal-users' : 'settings-external-users');
              setDirectoryRoleFilter(roleName);
            }}
          />
        );
      }
    }
    if (activeMenu === "ocr-workspace-my-tasks")
      return <OcrMyTasksView />;
    if (activeMenu === "ocr-workspace-document-issues")
      return <OcrDocumentIssuesView key={ocrNotificationTarget?.view === 'issue' ? ocrNotificationTarget.token : 'issues'} initialTarget={ocrNotificationTarget?.view === 'issue' ? ocrNotificationTarget : undefined} />;
    if (activeMenu === "ocr-review-analytics")
      return <OcrReviewView section="analytics" />;
    if (activeMenu === "ocr-machine-learning")
      return ocrLearningDocument ? <OcrLearningDocumentView evidence={ocrLearningDocument} onBack={() => setOcrLearningDocument(null)} /> : <OcrMachineLearningView
        onOpenDocument={document => {
          setOcrLearningDocument(document);
          setIsMenuExpanded(true);
        }} />;
    if (activeMenu === "ocr-ml" || activeMenu === "ocr-ml-documents" || activeMenu === "ocr-ml-models")
      return (
        <MachineLearningView
          key={ocrNotificationTarget?.view === 'teamlead' ? ocrNotificationTarget.token : 'teamlead'}
          initialDocument={ocrNotificationTarget?.view === 'teamlead' ? { id: ocrNotificationTarget.documentId, companyId: ocrNotificationTarget.companyId, name: ocrNotificationTarget.name, status: 'pending' } : undefined}
          openInvoiceProcessingDocuments={activeMenu === "ocr-ml" || activeMenu === "ocr-ml-documents"}
          onOpenAutomationProcess={(processId, processName, runId) => {
            setAutomationProcessFromNode({
              id: processId,
              name: processName,
              description: "Automation process",
              capabilities: "—",
              createdBy: "RPA platform",
              creationDate: "10.04.2026 12:22",
              modifiedBy: "RPA platform",
              modifiedDate: "10.04.2026 12:22",
            });
            setAutomationRunIdFromNode(runId ?? null);
            setAutomationReturnMenu("ocr-ml-documents");
            setActiveMenu("ocr");
          }}
        />
      );
    if (activeMenu === "ocr-admin-groups")
      return <AutomationSecurityAccessView />;
    const administrationSections: Record<string, AdministrationSection> = {
      "ocr-admin-activity": "activity",
      "ocr-admin-activity-ocr": "activity",
      "ocr-admin-activity-fh": "activity-fh",
    };
    if (administrationSections[activeMenu])
      return (
        <AdministrationView key={activeMenu} section={administrationSections[activeMenu]} />
      );
    if (activeMenu === "ocr" || activeMenu.startsWith("ocr-")) {
      return (
        <OcrView
          onNavigateToAdministration={(target) =>
            openSecurityAccess(target, "ocr")
          }
        />
      );
    }
    return (
      <div className="flex flex-1 items-center justify-center text-[#7288A3] font-montserrat font-medium text-[14px]">{uiText("Coming soon")}</div>
    );
  };

  return (
    <>
    <WorkspaceModeSwitcher value={workspaceMode} onChange={mode => {
      setWorkspaceMode(mode);
      setOcrNotificationTarget(null);
      if (mode === 'ocr') setSelectedCompany(null);
      setRelatedChat(null);
      setGlobalDocumentTarget(null);
      setOcrLearningDocument(null);
      setAutomationProcessFromNode(null);
      setSecurityAccessTarget(null);
      if (!workspaceMenuVisible(mode, activeMenu)) setActiveMenu(firstAccessibleMenu(session, mode));
    }} />
    {notificationsAvailable && <button type="button" aria-expanded={notificationsOpen} aria-label={`${uiText("Notifications")}, ${uiText("Active notifications")}: ${activeNotificationCount}`} title={uiText("Notifications")} onClick={() => { setNotificationsExpanded(false); setNotificationsOpen(value => !value); }} className="fixed right-4 top-2 z-40 flex h-9 w-9 items-center justify-center rounded-md border border-[#D3E1EC] bg-white text-[#7288A3] shadow-sm hover:text-[#007EA7]">
      <Bell size={20} />
      {activeNotificationCount > 0 && <span className="absolute -right-1 -top-1 flex min-w-4 items-center justify-center rounded-full bg-[#E65050] px-1 font-montserrat text-[10px] leading-4 text-white">{activeNotificationBadge}</span>}
    </button>}
    {notificationsAvailable && notificationDetails && <NotificationDetailsPanel notification={notificationDetails} organizationName={notificationDetails.organizationName ?? '—'} read={isNotificationRead(notificationDetails, session.email)} onClose={() => setNotificationDetails(null)} />}
    {notificationsAvailable && notificationsOpen && !notificationsExpanded && <div className="fixed inset-0 z-[100]" onClick={() => setNotificationsOpen(false)}>
      <section role="dialog" aria-label={uiText("Recent notifications")} onClick={event => event.stopPropagation()} className="absolute right-4 top-12 flex max-h-[calc(100dvh-64px)] w-[420px] max-w-[calc(100vw-32px)] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white font-montserrat shadow-xl">
        <header className="flex items-start justify-between gap-3 border-b border-[#E5EDF9] px-4 py-3">
          <div><h2 className="flex items-center gap-2 text-[16px] font-semibold text-[#10233A]">{uiText("Notifications")}{activeNotificationCount > 0 && <span className="rounded-full bg-[#E65050] px-1.5 text-[11px] leading-5 text-white">{activeNotificationBadge}</span>}</h2><p className="mt-1 text-[11px] text-[#7288A3]">{uiText("Active notifications")}</p></div>
          <button type="button" onClick={() => setNotificationsExpanded(true)} className="whitespace-nowrap pt-1 text-[12px] font-semibold text-[#007EA7] hover:underline">{uiText("View all")}</button>
        </header>
        <div className="min-h-0 overflow-y-auto p-2">
          {recentNotifications.map(row => <article key={`${row.organizationId}:${row.id}`} data-notification-status={getNotificationStatus(row)} className={`mb-2 rounded-lg border border-[#E5EDF9] p-3 last:mb-0 ${getNotificationBackgroundClassName(getNotificationStatus(row))}`}>
            <div className="flex items-start gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#E6F2F6] text-[#007EA7]"><Bell size={15} /></span><div className="min-w-0 flex-1">
              <div className="flex flex-wrap justify-between gap-x-3 gap-y-1 text-[10px] leading-4 text-[#7288A3]"><span className="font-medium">{getNotificationModuleLabel(row)}</span><span>{row.organizationName || '—'}</span></div>
              <span className={`mt-1 inline-flex rounded px-1.5 text-[10px] font-semibold leading-5 ${'severity' in row && row.severity === 'Critical' ? 'bg-[#FDEBEC] text-[#B93846]' : 'severity' in row && row.severity === 'Warning' ? 'bg-[#FFF3DE] text-[#966000]' : 'bg-[#E6F2F6] text-[#007EA7]'}`}>{'severity' in row && row.severity ? uiText(row.severity) : uiText('Info')}</span>
              <p className="mt-1 break-words text-[12px] font-semibold leading-[18px] text-[#10233A]">{uiText(row.name)}</p>
              {notificationMessage(row) !== row.name && <p className="mt-1 line-clamp-2 break-words text-[11px] leading-4 text-[#7288A3]">{notificationMessage(row)}</p>}
              {getNotificationRelatedObjectLabel(row) !== '—' && <p className="mt-1 truncate text-[11px] text-[#7288A3]" title={getNotificationRelatedObjectLabel(row)}>{uiText("Related object: ")}{getNotificationRelatedObjectLabel(row)}</p>}
              <div className="mt-2 flex items-center justify-between gap-2"><span className="text-[10px]"><NotificationRelativeTime row={row} /></span>{row.ocrTarget ? <button type="button" onClick={() => { void openOcrNotification(row).catch(error => setNotificationNavigationError(error.message)); }} className="h-7 rounded-md border border-[#D3E1EC] bg-white px-3 text-[11px] font-semibold text-[#007EA7] hover:bg-[#E6F2F6]">{uiText('Open')}</button> : row.relatedObject && row.relatedObject.organizationId === row.organizationId ? <RelatedObjectLink object={row.relatedObject} organizationId={row.organizationId} variant="button" onError={setNotificationNavigationError} onOpen={async object => { await openRelatedObject(object, true); setNotificationsOpen(false); }} /> : <button type="button" onClick={() => { setNotificationsOpen(false); setNotificationDetails(row); }} className="h-7 rounded-md border border-[#D3E1EC] bg-white px-3 text-[11px] font-semibold text-[#007EA7] hover:bg-[#E6F2F6]">{uiText("View details")}</button>}</div>
            </div></div>
          </article>)}
          {!recentNotifications.length && <p className="px-4 py-8 text-center text-[12px] text-[#7288A3]">{uiText("No active notifications.")}</p>}
          {notificationNavigationError && <p role="alert" className="px-3 py-2 text-[12px] text-[#B93846]">{notificationNavigationError}</p>}
        </div>
        <footer className="border-t border-[#E5EDF9] p-3"><button type="button" onClick={() => setNotificationsExpanded(true)} className="flex h-9 w-full items-center justify-center gap-2 rounded-md bg-[#E5EDF9] text-[12px] font-semibold text-[#007EA7] hover:bg-[#D3E1EC]">{uiText("View all notifications ")}<ArrowRight size={15} /></button></footer>
      </section>
    </div>}
    {notificationsAvailable && notificationsOpen && notificationsExpanded && <div className="fixed inset-0 z-[100] flex justify-end bg-[#10233A]/25" onClick={() => setNotificationsOpen(false)}>
      <div role="dialog" aria-modal="true" aria-label={uiText("Notifications")} className="relative h-full w-full max-w-[1400px] overflow-y-auto bg-white shadow-xl" onClick={event => event.stopPropagation()}>
        <button type="button" aria-label={uiText("Close notifications")} onClick={() => setNotificationsOpen(false)} className="absolute right-4 top-3 z-50 rounded-md p-2 text-[#7288A3] hover:bg-[#E5EDF9]"><X size={20} /></button>
        <OrganizationRequiredActionsView organization={selectedCompany ?? undefined} session={session} workspaceMode={workspaceMode} onOpenOcrNotification={openOcrNotification} initialTab="notifications" onOpenModule={async (organizationId, menu) => {
          const company = visibleNotifications.organizations.find(candidate => candidate.id === organizationId);
          const current = parseSession(JSON.stringify(session));
          if (!company || !current || !current.access.companies.view || !canAccessAssignedOrganization(company, current)) throw new Error('This organization is no longer accessible.');
          openCompany(company, menu);
          setNotificationsOpen(false);
        }} onOpenRelatedObject={async object => { await openRelatedObject(object, true); setNotificationsOpen(false); }} />
      </div>
    </div>}
    <Suspense fallback={<div role="status" className="p-6 font-montserrat text-sm text-[#7288A3]">{uiText('Loading…')}</div>}>{companyContent}</Suspense>
    <div style={{ display: selectedCompany ? 'none' : undefined }} className="flex h-screen overflow-hidden">
      <div className="flex-shrink-0 overflow-y-auto">
        <Sidebar
          notificationCount={notificationCounts.reminders}
          isExpanded={isMenuExpanded}
          onToggle={() => setIsMenuExpanded(!isMenuExpanded)}
          activeMenu={displayedMenu}
          onMenuClick={handleMenuClick}
          clientName={currentUserName}
          onLogout={onLogout}
          visibleMainMenuIds={APP_MODULES.filter(
            (module) => session.access[module.id].view,
          ).map(
            (module) =>
              ({
                companies: "dashboard",
                chats: "messages",
                notifications: "notifications",
                settings: "settings",
                faq: "info",
                ocr: "ocr",
              })[module.id],
          )}
          canViewMenu={(menu) => workspaceMenuVisible(workspaceMode, menu) && canViewMenu(session, menu)}
          workspaceMode={workspaceMode}
        />
      </div>
      <div
        ref={mainContentRef}
        data-app-main
        data-active-menu={displayedMenu}
        className="relative min-w-0 flex-1 overflow-x-hidden overflow-y-auto"
      >
        <OcrContextFilters contextKey={displayedMenu} />
        <ReadOnlyBoundary
          readOnly={
            Boolean(moduleForMenu(displayedMenu)) && !canEditMenu(session, displayedMenu)
          }
        >
          <div style={{ display: relatedChat ? 'none' : undefined }}>
            <Suspense fallback={<div role="status" className="p-6 font-montserrat text-sm text-[#7288A3]">{uiText('Loading…')}</div>}>{renderContent()}</Suspense>
          </div>
          {relatedChat && <Suspense fallback={<div role="status" className="p-6 font-montserrat text-sm text-[#7288A3]">{uiText('Loading…')}</div>}><ChatsView key={relatedChat.storageKey} preserveConversationMetadata ocrOnly={workspaceMode === 'ocr'} currentUserName={currentUserName} conversation={relatedChat} onOpenDocument={openDocumentInOrganization} onBack={() => setRelatedChat(null)} /></Suspense>}
        </ReadOnlyBoundary>
      </div>
    </div>
    </>
  );
}
