import { useMemo, useRef, useState } from 'react';
import { Check } from 'lucide-react';
import { translateUi as uiText, useLanguage } from '../i18n/language';
import { contractCountries, confirmContractDetails, readContractDetails, readContractPlanId, readConfirmedContractPlan, readContractTierId, validateContractDetails, type ContractDetails } from '../lib/contractDetails';
import { readContractPricing, hasProgressiveDocumentPricing } from '../lib/contractPricing';
import ContractPricingPanel from './ContractPricingPanel';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import ProfilePlanUsage from './ProfilePlanUsage';

const fields = [
  ['companyName', 'Company name', true], ['companyCode', 'Company code', true], ['vatCode', 'VAT code', false],
  ['representative', 'Representing person', true], ['address', 'Address', true],
] as const;

export default function ContractSettings({ email, name }: { email: string; name: string }) {
  const language = useLanguage();
  const countries = useMemo(() => contractCountries(language), [language]);
  const [details, setDetails] = useState(() => readContractDetails(window.localStorage, email, name));
  const [selectedPlanId, setSelectedPlanId] = useState(() => readContractPlanId(window.localStorage, email));
  const [currentPlanId, setCurrentPlanId] = useState(selectedPlanId);
  const [confirmedPlan, setConfirmedPlan] = useState(() => readConfirmedContractPlan(window.localStorage, email));
  const [selectedTierId, setSelectedTierId] = useState(() => readContractTierId(window.localStorage, email));
  const [currentTierId, setCurrentTierId] = useState(selectedTierId);
  const [errors, setErrors] = useState<Partial<Record<keyof ContractDetails, string>>>({});
  const [feedback, setFeedback] = useState('');
  const form = useRef<HTMLFormElement>(null);
  const update = (key: keyof ContractDetails, value: string) => {
    setDetails(current => ({ ...current, [key]: value })); setFeedback('');
    setErrors(current => ({ ...current, [key]: undefined }));
  };
  const confirm = () => {
    const next = validateContractDetails(details); setErrors(next); setFeedback('');
    if (Object.keys(next).length) {
      const key = Object.keys(next)[0];
      form.current?.querySelector<HTMLInputElement>(`[name="${key}"]`)?.focus();
      return;
    }
    try {
      const catalog = readContractPricing(window.localStorage);
      const plan = catalog.plans.find(item => item.id === selectedPlanId);
      if (!plan) { setFeedback('Select an available plan.'); return; }
      const tierId = hasProgressiveDocumentPricing(plan) ? selectedTierId : '';
      if (hasProgressiveDocumentPricing(plan) && !plan.tiers.some(tier => tier.id === tierId)) { setFeedback('Select a document range from the table.'); return; }
      confirmContractDetails(window.localStorage, email, details, { planId: plan.id, pricingRevision: catalog.revision, planSnapshot: plan, ...(tierId ? { tierId } : {}) });
      setCurrentPlanId(plan.id); setConfirmedPlan(structuredClone(plan));
      setCurrentTierId(tierId);
      setFeedback('Plan selection saved. Electronic signing and billing are not connected.');
    } catch { setFeedback('Company details could not be saved. Please try again.'); }
  };
  return <div className="flex min-w-0 flex-col gap-5 font-montserrat text-[#10233A]">
    <div><h2 className="mb-3 text-[16px] font-semibold">{uiText('Current plan')}</h2><ProfilePlanUsage email={email} selectedPlanId={currentPlanId} confirmedPlan={confirmedPlan} selectedTierId={currentTierId} /></div>
    <ContractPricingPanel selectedPlanId={selectedPlanId} currentPlanId={currentPlanId} selectedTierId={selectedTierId} onSelectTier={id => { setSelectedTierId(id); setFeedback(''); }} onSelectPlan={id => {
      if (id !== selectedPlanId) setSelectedTierId(id === currentPlanId ? currentTierId : '');
      setSelectedPlanId(id); setFeedback('');
    }} />
    <form ref={form} noValidate onSubmit={event => { event.preventDefault(); confirm(); }} className="overflow-hidden rounded-xl border border-[#D3E1EC] bg-white">
      <h3 className="border-b border-[#E5EDF9] bg-[#F4F8FC] px-5 py-3 text-[14px] font-semibold">{uiText('Company details')}</h3>
      <div className="grid gap-5 p-5 md:grid-cols-2 xl:grid-cols-3">
        {fields.map(([key, label, required]) => <label key={key} className="flex min-w-0 flex-col gap-2 text-[12px] font-medium text-[#7288A3]">
          <span>{uiText(label)}{required && <span className="ml-1 text-[#E34242]">*</span>}</span>
          <input name={key} value={details[key]} required={required} maxLength={key === 'address' ? 500 : 200} aria-invalid={Boolean(errors[key])} aria-describedby={errors[key] ? `contract-${key}-error` : undefined} onChange={event => update(key, event.target.value)} className={`h-[42px] rounded-lg border bg-white px-3.5 font-montserrat text-[14px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] ${errors[key] ? 'border-[#E34242]' : 'border-[#D3E1EC]'}`} />
          {errors[key] && <span id={`contract-${key}-error`} className="text-[11px] text-[#B42318]">{uiText(errors[key])}</span>}
        </label>)}
        <div className="flex min-w-0 flex-col gap-2"><span className="text-[12px] font-medium text-[#7288A3]">{uiText('Country')} <span className="text-[#E34242]">*</span></span><SearchableSelect value={details.country} options={countries} onChange={value => update('country', value)} ariaLabel={uiText('Country')} placeholder={uiText('Select country')} portalMenu />{errors.country && <span role="alert" className="text-[11px] text-[#B42318]">{uiText(errors.country)}</span>}</div>
      </div>
      <footer className="flex flex-wrap items-center justify-end gap-3 border-t border-[#E5EDF9] px-5 py-4">
        {feedback && <p role="status" className="mr-auto max-w-[760px] text-[12px] leading-5 text-[#7288A3]">{uiText(feedback)}</p>}
        <PageActionButton icon={<Check size={16} />} disabled={!selectedPlanId} onClick={() => form.current?.requestSubmit()}>{uiText('Update plan')}</PageActionButton>
      </footer>
    </form>
  </div>;
}
