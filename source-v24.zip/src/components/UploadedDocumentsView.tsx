import { translateStatus as statusText } from '../i18n/language';
import { ocrDocumentStatusPresentation, uploadedDocumentDisplayStatus, uploadedDocumentStatusOptions } from '../lib/ocrDocumentStatusPresentation';
import { ocrStatusLabel } from '../lib/ocrStatuses';
import useOcrStatusDescriptions from '../hooks/useOcrStatusDescriptions';
import { OcrDocumentStatusCell, OcrDocumentStatusPanel } from './OcrDocumentStatusDetails';
import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
import { AlertCircle, Check, ChevronDown, FileText, Plus, RotateCcw, ScanLine, Trash2, X } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { PageActionButton, PageHeader } from './PageHeader';
import CompactOcrUpload from './CompactOcrUpload';
import UploadedLifecycleFilter from './UploadedLifecycleFilter';
import { hasUnidentifiedOrganization, matchesUploadedLifecycle, uploadedLifecycleState, uploadedLifecycleFiltersForGroup, type UploadedLifecycleFilter as LifecycleFilter } from '../lib/uploadedLifecycleFilters';
import { toggleFilteredSelection } from '../lib/tableSelection';
import { digitizeAnywayBlocker } from '../lib/uploadedDocumentActions';
import { SystemBreadcrumb } from './SystemNavigation';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import type { ColConfig } from './ColumnSettingsPanel';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import OcrSearchField from './OcrSearchField';
import TablePagination from './TablePagination';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import DocumentOrganizationAssignment from './DocumentOrganizationAssignment';
import { RowDeleteButton } from './DeleteButtons';
import DocumentRowActionDialog from './DocumentRowActionDialog';
import GlJournalDialog from './GlJournalDialog';
import DocumentRestoreButton from './DocumentRestoreButton';
import DocumentIssueDialog from './DocumentIssueDialog';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import { useDropdownDismiss } from './useDropdownDismiss';
import { supabase, ensureOcrRegisterExamples, restoreDeletedDocument, digitizeUploadedDocuments, deleteUnconfirmedDocument, type Company, type DbDocument } from '../lib/supabase';
import { loadOcrDocumentSource } from '../lib/ocrDocumentSource';
import { canViewCompanyDocuments, canEditCompanyDocuments, canAccessUnassignedDocuments } from '../lib/documentEditAccess';
import { canAccessIssueOrganization } from '../lib/documentIssueAccess';
import { documentActionRights } from '../lib/documentRowActionAccess';
import { documentRowAction, documentRestoreBlocker, documentActionSnapshot } from '../lib/documentRowActions';
import type { StornoDocument } from '../lib/documentStorno';
import { isInactiveRecord } from '../lib/recordLifecycle';
import { getSearchSuggestions, matchesTextSearch } from '../utils/textSearch';
import { uploadedDocumentSource, withUploadedDocumentUploader } from '../lib/uploadedDocumentSource';
import { loadLinkedDirectoryUsers } from '../lib/linkedSettingsData';
import { documentTypeCatalogLabel } from '../lib/documentTypeCatalog';
import { loadOrganizationReferenceRecords } from './OrganizationReferenceValuesView';
import {
  matchesUploadedDateFilter,
  prepareUploadedDocuments,
  prepareUploadedSourceExamples,
  uploadedDocumentTimestamp as uploadedTimestamp,
  uploadedStatus,
  type UploadedDocumentsGroup,
} from '../lib/uploadedDocuments';

export type { UploadedDocumentsGroup } from '../lib/uploadedDocuments';
type UploadedFilterKey = 'uploaded' | 'organization' | 'status' | 'sourceType' | 'sourceValue';

const PAGE_SIZE = TABLE_BATCH_SIZE;

type UploadedColumnKey = 'document' | 'organization' | 'source' | 'status' | 'uploaded';

const UPLOADED_DOCUMENT_COLUMNS = [
  { key: 'document', label: 'Document', width: 230, visible: true },
  { key: 'organization', label: 'Organization', width: 170, visible: true },
  { key: 'status', label: 'Status', width: 230, visible: true },
  { key: 'source', label: 'Source', width: 280, visible: true },
  { key: 'uploaded', label: 'Uploaded', width: 150, visible: true },
] satisfies Array<{ key: UploadedColumnKey; label: string; width: number; visible: boolean }>;

const UPLOADED_FILTERS: Array<{ key: UploadedFilterKey; label: string }> = [
  { key: 'uploaded', label: 'Uploaded date' },
  { key: 'organization', label: 'Organization' },
  { key: 'status', label: 'Status' },
  { key: 'sourceType', label: 'Source type' },
  { key: 'sourceValue', label: 'Source value' },
];

function displayUploadedDate(document: DbDocument) {
  const timestamp = uploadedTimestamp(document);
  if (!timestamp) return document.receive_date || '—';
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function sourceValue(document: DbDocument) {
  return uploadedDocumentSource(document, uiText).detail;
}


function uploadedVisibleSearchCells(document: DbDocument, organizationName: string) {
  const status = uploadedDocumentDisplayStatus(document);
  return [
    document.file_case || document.number || document.id,
    document.number || '',
    uploadedDocumentSource(document).type,
    uiText(uploadedDocumentSource(document).type),
    sourceValue(document),
    organizationName,
    status,
    ocrStatusLabel(status, statusText),
    displayUploadedDate(document),
  ];
}

export default function UploadedDocumentsView({
  onOpenDocument,
  initialGroup = 'All',
  nestedNavigation = false,
  initialDocumentId,
}: {
  onOpenDocument: (document: DbDocument, mode?: 'view' | 'edit' | 'original-view') => void | Promise<void>;
  initialGroup?: UploadedDocumentsGroup;
  nestedNavigation?: boolean;
  initialDocumentId?: string;
}) {
  const initialOpened = useRef(false);
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [organizations, setOrganizations] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [lifecycleFilters, setLifecycleFilters] = useState<LifecycleFilter[]>(() => uploadedLifecycleFiltersForGroup(initialGroup));
  const [showFilters, setShowFilters] = useState(false);
  const [openFilter, setOpenFilter] = useState<UploadedFilterKey | null>(null);
  const [visibleFilterKeys, setVisibleFilterKeys] = useState<UploadedFilterKey[]>([]);
  const [pendingFilterKeys, setPendingFilterKeys] = useState<UploadedFilterKey[]>([]);
  const [selectedFilterKeys, setSelectedFilterKeys] = useState<UploadedFilterKey[]>([]);
  const [dateFilter, setDateFilter] = useState('all');
  const [documentFilter, setDocumentFilter] = useState('');
  const [searchSuggestionsOpen, setSearchSuggestionsOpen] = useState(false);
  const [highlightedSuggestion, setHighlightedSuggestion] = useState(0);
  const [organizationFilter, setOrganizationFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sourceTypeFilter, setSourceTypeFilter] = useState('');
  const [sourceValueFilter, setSourceValueFilter] = useState('');
  const [selectedDocument, setSelectedDocument] = useState<DbDocument | null>(null);
  useEffect(() => {
    if (!initialDocumentId || initialOpened.current || loading) return;
    const document = documents.find(row => row.id === initialDocumentId);
    if (document) { initialOpened.current = true; setLifecycleFilters([]); setDocumentFilter(document.file_case || document.number); setSelectedDocument(document); }
  }, [initialDocumentId, loading, documents]);
  const statusPanelId = useId();
  const statusDescriptions = useOcrStatusDescriptions();
  const [previewDocument, setPreviewDocument] = useState<DbDocument | null>(null);
  const [documentTypes, setDocumentTypes] = useState(() => loadOrganizationReferenceRecords('Document type'));
  useEffect(() => {
    const refresh = () => setDocumentTypes(loadOrganizationReferenceRecords('Document type'));
    window.addEventListener('organization-reference-updated', refresh);
    window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('organization-reference-updated', refresh); window.removeEventListener('storage', refresh); };
  }, []);
  const [assigningOrganization, setAssigningOrganization] = useState(false);
  const [issueDocument, setIssueDocument] = useState<DbDocument | null>(null);
  const [deleteDocument, setDeleteDocument] = useState<DbDocument | null>(null);
  const [notice, setNotice] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [deleteTargets, setDeleteTargets] = useState<string[] | null>(null);
  const bulkBusyRef = useRef(false);
  const [page, setPage] = useState(1);
  const [columns, setColumns] = useState<ColConfig[]>(() => UPLOADED_DOCUMENT_COLUMNS.map((column) => ({ ...column })));
  const { startResize } = useColumnResize(columns, setColumns);
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const filterMenuRef = useRef<HTMLDivElement>(null);
  const valueFilterRef = useRef<HTMLDivElement>(null);
  const searchSuggestionsRef = useRef<HTMLDivElement>(null);
  const listScrollPositionRef = useRef(0);
  useDropdownDismiss(showFilters, filterMenuRef, () => setShowFilters(false));
  useDropdownDismiss(openFilter !== null, valueFilterRef, () => setOpenFilter(null));
  useDropdownDismiss(searchSuggestionsOpen, searchSuggestionsRef, () => setSearchSuggestionsOpen(false));

  const loadData = useCallback(async () => {
    await ensureOcrRegisterExamples();
    const ocrSource = await loadOcrDocumentSource({ includeDeleted: true });
    const accessibleOrganizations = ocrSource.organizations.filter(canViewCompanyDocuments);
    const accessibleIds = new Set(accessibleOrganizations.map(company => company.id));
    const sourceExamples = prepareUploadedSourceExamples(
      ocrSource.documents.filter(document => !document.company_id || accessibleIds.has(document.company_id)),
      accessibleOrganizations,
    );
    const preparedDocuments = prepareUploadedDocuments(sourceExamples.documents);
    await Promise.all(
      [...sourceExamples.generated, ...preparedDocuments.generated].map((document) =>
        supabase.from('documents').upsert({ ...document }, { onConflict: 'id' }),
      ),
    );
    const users = [...loadLinkedDirectoryUsers('Internal users'), ...loadLinkedDirectoryUsers('External users')];
    const loadedDocuments = preparedDocuments.documents.map(document => withUploadedDocumentUploader(document, users));
    setDocuments(loadedDocuments);
    setOrganizations(accessibleOrganizations);
    setSelectedDocument((current) => current
      ? loadedDocuments.find((document) => document.id === current.id) ?? current
      : null);
    setLoading(false);
  }, []);

  useEffect(() => {
    void loadData();
    const reload = () => void loadData();
    window.addEventListener('finansu-harmonija:data-changed', reload);
    window.addEventListener('finansu-harmonija:settings-data-changed', reload);
    window.addEventListener('storage', reload);
    return () => {
      window.removeEventListener('finansu-harmonija:data-changed', reload);
      window.removeEventListener('finansu-harmonija:settings-data-changed', reload);
      window.removeEventListener('storage', reload);
    };
  }, [loadData]);

  useEffect(() => {
    setLifecycleFilters(uploadedLifecycleFiltersForGroup(initialGroup));
    setPage(1);
  }, [initialGroup]);

  const organizationNames = useMemo(
    () => new Map(organizations.map((organization) => [organization.id, organization.name])),
    [organizations],
  );
  const organizationActions = useMemo(() => new Map(organizations.map(organization => [organization.id, {
    rights: documentActionRights(organization),
    report: canAccessIssueOrganization(organization, true),
    edit: canEditCompanyDocuments(organization),
  }])), [organizations]);
  const rowActions = (document: DbDocument) => {
    const inactive = Boolean(document.document_deletion) || isInactiveRecord(document);
    const access = organizationActions.get(document.company_id || '');
    const action = documentRowAction(document as unknown as StornoDocument, access?.rights ?? { delete: false, create: false, storno: false });
    const unavailable = inactive ? 'The document is inactive. Its data and action history are retained.'
      : !access ? 'Assign an organization before using document actions.' : '';
    return {
      inactive,
      deleteReason: unavailable || (action.kind === 'delete' ? action.disabledReason : 'Confirmed documents cannot be deleted.'),
      reportReason: unavailable || (!access?.report ? 'You do not have access to report issues for this organization.' : ''),
    };
  };
  const openIssueDialog = (document: DbDocument) => {
    if (rowActions(document).reportReason) return;
    closeSidePanel();
    setIssueDocument(document);
  };

  const baseFilteredDocuments = useMemo(() => {
    const normalizedDocument = documentFilter.trim().toLowerCase();
    const normalizedOrganization = organizationFilter.trim().toLowerCase();
    const normalizedSourceValue = sourceValueFilter.trim().toLowerCase();

    return [...documents]
      .sort((left, right) => uploadedTimestamp(right) - uploadedTimestamp(left))
      .filter((document) => {
        const status = uploadedDocumentDisplayStatus(document);
        if (!matchesUploadedDateFilter(document, dateFilter)) return false;
        const organizationName = organizationNames.get(document.company_id || '') || 'Organization not identified';
        if (normalizedDocument && !matchesTextSearch(uploadedVisibleSearchCells(document, organizationName), documentFilter)) return false;
        if (normalizedOrganization && !organizationName.toLowerCase().includes(normalizedOrganization)) return false;
        if (statusFilter && status !== statusFilter) return false;
        if (sourceTypeFilter && uploadedDocumentSource(document).type.toLowerCase() !== sourceTypeFilter.toLowerCase()) return false;
        if (normalizedSourceValue && !sourceValue(document).toLowerCase().includes(normalizedSourceValue)) return false;
        return true;
      });
  }, [dateFilter, documentFilter, documents, organizationFilter, organizationNames, sourceTypeFilter, sourceValueFilter, statusFilter, statusDescriptions]);
  const filteredDocuments = useMemo(() => baseFilteredDocuments.filter(document => matchesUploadedLifecycle(document, lifecycleFilters)), [baseFilteredDocuments, lifecycleFilters]);
  const lifecycleCounts = useMemo(() => {
    const counts: Partial<Record<LifecycleFilter, number>> = {};
    for (const document of baseFilteredDocuments) {
      if (hasUnidentifiedOrganization(document)) counts['organization-not-found'] = (counts['organization-not-found'] || 0) + 1;
      const state = uploadedLifecycleState(document);
      if (state) counts[state] = (counts[state] || 0) + 1;
    }
    return counts;
  }, [baseFilteredDocuments]);

  const searchSuggestions = useMemo(() => {
    return getSearchSuggestions(
      filteredDocuments.map((document) => uploadedVisibleSearchCells(
        document,
        organizationNames.get(document.company_id || '') || 'Organization not identified',
      )),
      documentFilter,
    );
  }, [documentFilter, filteredDocuments, organizationNames]);

  const {
    sortedRows: sortedDocuments,
    changeSort,
    directionFor,
  } = useMultiColumnSort(filteredDocuments, (document, key: UploadedColumnKey) => {
    if (key === 'document') return document.file_case || document.number || document.id;
    if (key === 'organization') return organizationNames.get(document.company_id || '') || 'Organization not identified';
    if (key === 'status') return ocrStatusLabel(uploadedDocumentDisplayStatus(document), statusText);
    if (key === 'source') return uploadedDocumentSource(document).type;
    return uploadedTimestamp(document);
  });

  useEffect(() => setPage(1), [dateFilter, documentFilter, organizationFilter, statusFilter, sourceTypeFilter, sourceValueFilter, lifecycleFilters]);

  const pageCount = Math.max(1, Math.ceil(filteredDocuments.length / PAGE_SIZE));
  const selectedRows = documents.filter(document => selectedIds.has(document.id));
  const activeSelectedRows = selectedRows.filter(document => !document.document_deletion);
  const deletableRows = activeSelectedRows.filter(document => !rowActions(document).deleteReason);
  const restorableRows = selectedRows.filter(document => !documentRestoreBlocker(document as unknown as StornoDocument,
    Boolean(organizationActions.get(document.company_id || '')?.rights.delete)));
  const digitizableRows = selectedRows.filter(document => !digitizeAnywayBlocker(document,
    Boolean(organizationActions.get(document.company_id || '')?.edit)));
  const allFilteredSelected = filteredDocuments.length > 0 && filteredDocuments.every(document => selectedIds.has(document.id));
  const someFilteredSelected = filteredDocuments.some(document => selectedIds.has(document.id));
  const runBulkAction = async (kind: 'restore' | 'digitize' | 'delete') => {
    if (bulkBusyRef.current) return;
    const targets = kind === 'restore' ? restorableRows : kind === 'delete'
      ? documents.filter(document => deleteTargets?.includes(document.id)) : digitizableRows;
    if (!targets.length) return;
    bulkBusyRef.current = true; setBulkBusy(true); setNotice('');
    const completed = new Set<string>();
    const completedLabel = kind === 'restore' ? 'Documents restored' : kind === 'delete' ? 'Documents deleted' : 'Submitted for OCR processing';
    try {
      if (kind === 'delete') {
        // Read original records: displayed rows may contain presentation-only uploader fields.
        const result = await supabase.from('documents').select('*').in('id', targets.map(document => document.id));
        if (result.error) throw new Error(result.error.message);
        const current = result.data as unknown as DbDocument[];
        if (current.length !== targets.length || current.some(document => rowActions(document).deleteReason))
          throw new Error('The document state changed. Close this action and refresh the list.');
        for (const document of current) {
          await deleteUnconfirmedDocument(document.id, document.company_id || '', documentActionSnapshot(document as unknown as StornoDocument));
          completed.add(document.id);
        }
      } else if (kind === 'restore') {
        for (const document of targets) {
          await restoreDeletedDocument(document.id, document.company_id || '', JSON.stringify(document.document_deletion));
          completed.add(document.id);
        }
      } else {
        const result = await digitizeUploadedDocuments(targets.map(document => document.id));
        result.requestedIds.forEach(id => completed.add(id));
      }
      setNotice(`${uiText(completedLabel)}: ${completed.size}`);
    } catch (error) { setNotice(`${completed.size ? `${uiText(completedLabel)}: ${completed.size}. ` : ''}${uiText(error instanceof Error ? error.message : 'Could not update documents.')}`); }
    finally {
      if (kind === 'delete') setDeleteTargets(null);
      setSelectedIds(current => new Set([...current].filter(id => !completed.has(id))));
      try { await loadData(); } finally { bulkBusyRef.current = false; setBulkBusy(false); }
    }
  };
  const safePage = Math.min(page, pageCount);
  const pageDocuments = sortedDocuments.slice(0, safePage * PAGE_SIZE);
  const sourceTypes = [...new Set(documents.map(document => uploadedDocumentSource(document).type).filter(value => value !== '—'))];
  const visibleColumns = columns.filter(column => column.visible);
  const filterOptions: Record<UploadedFilterKey, Array<{ label: string; value: string }>> = {
    uploaded: [
      { label: 'Last 30 days', value: '30' },
      { label: 'Last 90 days', value: '90' },
      { label: 'Last 12 months', value: '365' },
      { label: 'All time', value: 'all' },
    ],
    organization: [
      { label: 'All', value: '' },
      ...[...new Set(organizations.map((organization) => organization.name).filter(Boolean))]
        .sort((left, right) => left.localeCompare(right))
        .map((value) => ({ label: value, value })),
    ],
    status: [
      { label: 'All', value: '' },
      ...uploadedDocumentStatusOptions(documents).map(value => ({ label: ocrStatusLabel(value, statusText), value })),
    ],
    sourceType: [
      { label: 'All', value: '' },
      ...sourceTypes.map((value) => ({ label: uiText(value), value })),
    ],
    sourceValue: [
      { label: 'All', value: '' },
      ...[...new Set(documents.map(sourceValue).filter(value => value !== '—'))]
        .sort((left, right) => left.localeCompare(right))
        .map((value) => ({ label: value, value })),
    ],
  };


  const returnToUploadedDocuments = () => {
    setAssigningOrganization(false); setSelectedDocument(null);
    window.requestAnimationFrame(() => window.scrollTo({ top: listScrollPositionRef.current }));
  };
  const openOrganizationAssignment = (document: DbDocument) => {
    if (!canAccessUnassignedDocuments(true) || document.company_id || isInactiveRecord(document)) return;
    listScrollPositionRef.current = window.scrollY;
    setSelectedDocument(document); setAssigningOrganization(true); setNotice(''); window.scrollTo({ top: 0 });
  };
  const closeSidePanel = () => { setSelectedDocument(null); setAssigningOrganization(false); };

  const openUploadedDocument = (document: DbDocument) => {
    setSelectedDocument(null);
    setNotice('');
    if (document.image_url) {
      window.open(document.image_url, '_blank', 'noopener,noreferrer');
      return;
    }

    const pdf = new jsPDF();
    const documentName = document.file_case || document.number || document.id;
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(18);
    pdf.text(documentName, 20, 28);
    pdf.setDrawColor(211, 225, 236);
    pdf.line(20, 36, 190, 36);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(11);
    const details = [
      ['Document type', documentTypeCatalogLabel(document, documentTypes) || '—'],
      ['Document Number', document.number || '—'],
      ['Client / Counterparty', document.client_counterparty || '—'],
      ['Document date', document.document_date || '—'],
      ['Uploaded', displayUploadedDate(document)],
      ['Currency', document.currency || '—'],
      ['Total amount', document.total_amount || '—'],
      ['Source', uploadedDocumentSource(document).type],
      ['Source value', sourceValue(document)],
    ];
    details.forEach(([label, value], index) => {
      const y = 50 + index * 14;
      pdf.setFont('helvetica', 'bold');
      pdf.text(String(label), 20, y);
      pdf.setFont('helvetica', 'normal');
      pdf.text(String(value), 75, y);
    });
    const pdfUrl = pdf.output('bloburl');
    window.open(String(pdfUrl), '_blank', 'noopener,noreferrer');
  };

  useEffect(() => {
    if (!previewDocument) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setPreviewDocument(null);
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [previewDocument]);

  const clearFilterValue = (key: UploadedFilterKey) => {
    if (key === 'uploaded') setDateFilter('all');
    if (key === 'organization') setOrganizationFilter('');
    if (key === 'status') setStatusFilter('');
    if (key === 'sourceType') setSourceTypeFilter('');
    if (key === 'sourceValue') setSourceValueFilter('');
    setSelectedFilterKeys((current) => current.filter((filterKey) => filterKey !== key));
    setPage(1);
  };

  const currentFilterValue = (key: UploadedFilterKey) => {
    if (key === 'uploaded') return dateFilter;
    if (key === 'organization') return organizationFilter;
    if (key === 'status') return statusFilter;
    if (key === 'sourceType') return sourceTypeFilter;
    return sourceValueFilter;
  };

  const setCurrentFilterValue = (key: UploadedFilterKey, value: string) => {
    if (key === 'uploaded') setDateFilter(value);
    if (key === 'organization') setOrganizationFilter(value);
    if (key === 'status') setStatusFilter(value);
    if (key === 'sourceType') setSourceTypeFilter(value);
    if (key === 'sourceValue') setSourceValueFilter(value);
    setSelectedFilterKeys((current) => current.includes(key) ? current : [...current, key]);
    setPage(1);
  };

  const applyPendingFilters = () => {
    const addedFilterKeys = pendingFilterKeys.filter((key) => !visibleFilterKeys.includes(key));
    visibleFilterKeys
      .filter((key) => !pendingFilterKeys.includes(key))
      .forEach(clearFilterValue);
    if (addedFilterKeys.includes('uploaded')) {
      setSelectedFilterKeys((current) => current.includes('uploaded') ? current : [...current, 'uploaded']);
    }
    setVisibleFilterKeys(pendingFilterKeys);
    setShowFilters(false);
  };

  const clearAllFilters = () => {
    setLifecycleFilters([]);
    setDocumentFilter('');
    setDateFilter('all');
    setOrganizationFilter('');
    setStatusFilter('');
    setSourceTypeFilter('');
    setSourceValueFilter('');
    setVisibleFilterKeys([]);
    setPendingFilterKeys([]);
    setSelectedFilterKeys([]);
    setShowFilters(false);
    setOpenFilter(null);
    setSearchSuggestionsOpen(false);
    setHighlightedSuggestion(0);
    setPage(1);
  };

  const originalForDuplicate = selectedDocument && uploadedStatus(selectedDocument) === 'Duplicate'
    ? documents.find((document) => document.id !== selectedDocument.id && (
        (selectedDocument.number && document.number === selectedDocument.number) ||
        (selectedDocument.file_case && document.file_case === selectedDocument.file_case)
      ))
    : undefined;

  const originalForDocument = (document: DbDocument) => uploadedStatus(document) === 'Duplicate'
    ? documents.find((candidate) => candidate.id !== document.id && (
        (document.number && candidate.number === document.number) ||
        (document.file_case && candidate.file_case === document.file_case)
      ))
    : undefined;

  if (assigningOrganization && selectedDocument) return <DocumentOrganizationAssignment key={selectedDocument.id}
    document={selectedDocument} organizations={organizations.filter(company => canEditCompanyDocuments(company) && !isInactiveRecord(company))}
    onClose={returnToUploadedDocuments} onAssigned={updated => {
      setDocuments(current => current.map(document => document.id === updated.id ? updated : document));
      returnToUploadedDocuments();
    }} />;

  return (
    <div
      className="document-register-page uploaded-documents-page relative flex min-h-full min-w-0 flex-col gap-3 bg-white pb-10"
    >
      <PageHeader title={uiText(nestedNavigation ? 'Uploaded documents' : 'All Documents')} />
      <SystemBreadcrumb items={['All Documents', nestedNavigation && 'Uploaded documents']} />
      <CompactOcrUpload documentCount={documents.length} onUploaded={loadData} />

      <div className="flex min-h-0 flex-1 flex-col gap-3">
        <div className="uploaded-documents-status-toolbar flex min-w-0 items-start gap-3 border-b border-[#E5EDF9] pb-3">
          <UploadedLifecycleFilter value={lifecycleFilters} counts={lifecycleCounts} onChange={setLifecycleFilters} />
          <div data-table-workspace-tools role="group" aria-label={uiText("Uploaded documents table tools")} className="ml-auto flex h-8 w-8 shrink-0 items-center justify-end" />
        </div>
        <div className="system-table-toolbar relative flex min-h-7 flex-shrink-0 items-start gap-4">
          <div className="uploaded-documents-toolbar-filters flex min-h-7 min-w-0 flex-1 flex-row items-center gap-1">
            <div ref={searchSuggestionsRef} data-native-system-filters className="uploaded-documents-search relative min-w-[80px] max-w-[260px] flex-1">
              <OcrSearchField
                value={documentFilter}
                onChange={(value) => {
                  setDocumentFilter(value);
                  setSearchSuggestionsOpen(Boolean(value.trim()));
                  setHighlightedSuggestion(0);
                  setPage(1);
                }}
                onFocus={() => setSearchSuggestionsOpen(Boolean(documentFilter.trim()))}
                onKeyDown={(event) => {
                  if (event.key === 'Escape') {
                    setSearchSuggestionsOpen(false);
                    return;
                  }
                  if (!searchSuggestions.length) return;
                  if (event.key === 'ArrowDown') {
                    event.preventDefault();
                    setSearchSuggestionsOpen(true);
                    setHighlightedSuggestion((current) => Math.min(current + 1, searchSuggestions.length - 1));
                  }
                  if (event.key === 'ArrowUp') {
                    event.preventDefault();
                    setHighlightedSuggestion((current) => Math.max(current - 1, 0));
                  }
                  if (event.key === 'Enter' && searchSuggestionsOpen) {
                    event.preventDefault();
                    setDocumentFilter(searchSuggestions[highlightedSuggestion] ?? documentFilter);
                    setSearchSuggestionsOpen(false);
                    setPage(1);
                  }
                }}
                ariaExpanded={searchSuggestionsOpen && searchSuggestions.length > 0}
                ariaControls="uploaded-document-search-suggestions"
                ariaLabel={uiText("Search uploaded documents")}
              />
              {searchSuggestionsOpen && searchSuggestions.length > 0 && (
                <div
                  id="uploaded-document-search-suggestions"
                  role="listbox"
                  aria-label={uiText("Uploaded document search suggestions")}
                  className="absolute left-0 top-[32px] z-50 w-[320px] overflow-hidden rounded-lg border border-[#D3E1EC] bg-white p-1.5 shadow-[0_8px_24px_rgba(16,35,58,0.14)]"
                >
                  {searchSuggestions.map((suggestion, index) => (
                    <button
                      key={suggestion}
                      type="button"
                      role="option"
                      aria-selected={documentFilter === suggestion}
                      onMouseEnter={() => setHighlightedSuggestion(index)}
                      onClick={() => {
                        setDocumentFilter(suggestion);
                        setSearchSuggestionsOpen(false);
                        setPage(1);
                      }}
                      className={`flex min-h-9 w-full items-center gap-3 rounded-md px-3 py-2 text-left font-montserrat text-[12px] font-medium leading-[18px] text-[#10233A] ${documentFilter === suggestion ? 'bg-[#E5EDF9]' : highlightedSuggestion === index ? 'bg-[#F2F7FC]' : 'hover:bg-[#F2F7FC]'}`}
                    >
                      <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${documentFilter === suggestion ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6] bg-white'}`}>
                        {documentFilter === suggestion && <Check size={12} strokeWidth={2.5} className="text-white" />}
                      </span>
                      <span className="truncate">{suggestion}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          {visibleFilterKeys.map((key) => {
            const filter = UPLOADED_FILTERS.find((item) => item.key === key);
            if (!filter) return null;
            const value = currentFilterValue(key);
            const hasSelection = selectedFilterKeys.includes(key);
            const displayValue = filterOptions[key].find((option) => option.value === value)?.label || 'All';
            const isOpen = openFilter === key;
            return (
              <div key={key} ref={isOpen ? valueFilterRef : undefined} className="relative flex-shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setOpenFilter((current) => current === key ? null : key);
                    setShowFilters(false);
                  }}
                  aria-expanded={isOpen}
                  aria-haspopup="listbox"
                  aria-label={`Filter by ${filter.label}`}
                  className="flex h-7 max-w-[240px] items-center gap-1 rounded bg-[#E5EDF9] px-2 py-[5px] font-montserrat text-[12px] font-medium leading-[18px] text-[#7288A3] hover:bg-[#DCE7F6]"
                >
                  <span className="truncate whitespace-nowrap">
                    {uiText(filter.label)}{hasSelection && <>: <span className="text-[#10233A]">{displayValue}</span></>}
                  </span>
                  {hasSelection ? (
                    <X
                      size={15}
                      className="flex-shrink-0"
                      onClick={(event) => {
                        event.stopPropagation();
                        clearFilterValue(key);
                        setOpenFilter(null);
                      }}
                    />
                  ) : (
                    <ChevronDown size={15} className={`flex-shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  )}
                </button>
                {isOpen && (
                  <div role="listbox" aria-label={`${filter.label} options`} className="absolute left-0 top-[32px] z-40 min-w-[220px] overflow-hidden rounded-lg border border-[#D3E1EC] bg-white py-1 shadow-[0_8px_24px_rgba(16,35,58,0.14)]">
                    <div className="max-h-[240px] overflow-y-auto">
                      {filterOptions[key].map((option) => {
                        const checked = hasSelection && value === option.value;
                        return (
                          <button
                            key={`${key}-${option.value}`}
                            type="button"
                            role="option"
                            aria-selected={checked}
                            onClick={() => {
                              setCurrentFilterValue(key, option.value);
                              setOpenFilter(null);
                            }}
                            className={`flex w-full items-center gap-3 px-3 py-2 text-left ${checked ? 'bg-[#E5EDF9]' : 'hover:bg-[#F2F7FC]'}`}
                          >
                            <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${checked ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6] bg-white'}`}>
                              {checked && <Check size={12} strokeWidth={2.5} className="text-white" />}
                            </span>
                            <span className="font-montserrat text-[13px] font-medium text-[#10233A]">{uiText(option.label)}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          <div ref={filterMenuRef} className="relative flex-shrink-0">
            <button
              type="button"
              onClick={() => {
                setPendingFilterKeys(visibleFilterKeys);
                setShowFilters((current) => !current);
                setOpenFilter(null);
              }}
              aria-expanded={showFilters}
              aria-haspopup="listbox"
              className="flex h-7 items-center gap-1 rounded bg-[#E5EDF9] px-2 py-[5px] font-montserrat text-[12px] font-medium leading-[18px] text-[#7288A3] hover:bg-[#DCE7F6]"
            >
              <Plus size={15} />{uiText("Add filters")}</button>
            {showFilters && (
              <div
                className="absolute left-0 top-[32px] z-40 min-w-[240px] overflow-hidden rounded-lg border border-[#D3E1EC] bg-white p-1.5 shadow-[0_8px_24px_rgba(16,35,58,0.14)]"
                onKeyDown={(event) => {
                  if (event.key === 'Enter') {
                    event.preventDefault();
                    applyPendingFilters();
                  }
                }}
              >
                <div role="listbox" aria-label={uiText("Available uploaded document filters")} aria-multiselectable="true" className="max-h-[300px] overflow-y-auto">
                  {UPLOADED_FILTERS.map((filter) => {
                    const checked = pendingFilterKeys.includes(filter.key);
                    return (
                      <button
                        key={filter.key}
                        type="button"
                        role="option"
                        aria-selected={checked}
                        onClick={() => setPendingFilterKeys((current) => checked
                          ? current.filter((key) => key !== filter.key)
                          : [...current, filter.key])}
                        className={`flex w-full items-center gap-3 rounded-md px-2 py-2 text-left ${checked ? 'bg-[#E5EDF9]' : 'hover:bg-[#F2F7FC]'}`}
                      >
                        <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${checked ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6] bg-white'}`}>
                          {checked && <Check size={12} strokeWidth={2.5} className="text-white" />}
                        </span>
                        <span className="font-montserrat text-[13px] font-medium text-[#10233A]">{uiText(filter.label)}</span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-1 flex items-center justify-between border-t border-[#E5EDF9] px-2 pt-2">
                  <span className="font-montserrat text-[11px] text-[#7288A3]">{uiText("Enter to apply")}</span>
                  <button type="button" onClick={applyPendingFilters} className="h-8 rounded-md bg-[#007EA7] px-3 font-montserrat text-[12px] font-semibold text-white hover:bg-[#006D91]">{uiText("Apply")}</button>
                </div>
              </div>
            )}
          </div>
          <button
            type="button"
            onClick={clearAllFilters}
            className="flex h-7 flex-shrink-0 items-center gap-1 rounded bg-[#E5EDF9] px-2 py-[5px] font-montserrat text-[12px] font-medium leading-[18px] text-[#7288A3] hover:bg-[#DCE7F6]"
          >
            <X size={15} />{uiText("Clear filters")}</button>
          </div>
          <div data-uploaded-selection-actions role="group" aria-label={uiText("Selected document actions")} className="ml-auto flex min-h-8 shrink-0 flex-wrap items-center justify-end gap-2">
            {restorableRows.length > 0 && <PageActionButton disabled={bulkBusy} icon={<RotateCcw size={15} />} onClick={() => void runBulkAction('restore')}>{`${uiText('Restore')} (${restorableRows.length})`}</PageActionButton>}
            {activeSelectedRows.length > 0 && <>
              <span className="inline-flex" title={!deletableRows.length ? uiText(rowActions(activeSelectedRows[0]).deleteReason) : undefined}>
                <PageActionButton disabled={bulkBusy || !deletableRows.length} icon={<Trash2 size={15} />} onClick={() => setDeleteTargets(deletableRows.map(document => document.id))}>{`${uiText('Delete')} (${deletableRows.length})`}</PageActionButton>
              </span>
              <span className="inline-flex" title={!digitizableRows.length ? uiText(digitizeAnywayBlocker(activeSelectedRows[0], Boolean(organizationActions.get(activeSelectedRows[0].company_id || '')?.edit))) : undefined}>
                <PageActionButton disabled={bulkBusy || !digitizableRows.length} icon={<ScanLine size={15} />} onClick={() => void runBulkAction('digitize')}>{`${uiText('Digitize anyway')} (${digitizableRows.length})`}</PageActionButton>
              </span>
            </>}
          </div>
        </div>

        {notice && <div className="rounded-lg bg-[#EAF8F3] px-4 py-2 font-montserrat text-[12px] font-medium text-[#008A6A]">{notice}</div>}

        <div className="uploaded-documents-layout" data-status-info-open={Boolean(selectedDocument)}>
        <section className="uploaded-documents-list flex min-h-0 min-w-0 flex-1 flex-col gap-3 bg-white">
        <div ref={tableScrollRef} className="min-h-0 flex-1 overflow-x-auto scrollbar-hide">
          <div style={{ minWidth: `${visibleColumns.reduce((sum, column) => sum + column.width + 12, 0) + 128}px` }}>
            <div className="mb-4 flex h-5 flex-row items-center gap-3 px-3">
              <div role="columnheader" className="flex w-7 shrink-0 items-center">
                <input type="checkbox" aria-label={uiText('Select all filtered documents')} checked={allFilteredSelected} ref={element => { if (element) element.indeterminate = someFilteredSelected && !allFilteredSelected; }} disabled={bulkBusy || !filteredDocuments.length} onChange={() => setSelectedIds(current => toggleFilteredSelection(current, filteredDocuments.map(document => document.id)))} className="h-[18px] w-[18px] shrink-0 rounded-[6px] accent-[#007EA7]" />
              </div>
              {visibleColumns.map((column) => (
                <div key={column.key} data-document-column={column.key} role="columnheader" className="flex flex-shrink-0 flex-row items-center">
                  <div
                    className="relative flex flex-shrink-0 flex-row items-center gap-[6px]"
                    style={{ width: column.width }}
                  >
                    <span className="min-w-0 truncate font-montserrat text-[12px] font-medium leading-[18px] text-[#10233A]">
                      {uiText(column.label)}
                    </span>
                    <ColumnSortButton
                      columnLabel={uiText(column.label)}
                      direction={directionFor(column.key as UploadedColumnKey)}
                      onDirectionChange={(direction) => {
                        changeSort(column.key as UploadedColumnKey, direction);
                        setPage(1);
                      }}
                    />
                    <ResizeHandle onMouseDown={(event) => startResize(columns.indexOf(column), event)} />
                  </div>
                </div>
              ))}
              <div role="columnheader" aria-label={uiText('Actions')} className="system-table-row-actions flex min-w-[64px] items-center" />
            </div>

          {loading ? (
            <div className="flex min-h-44 items-center justify-center font-montserrat text-[13px] text-[#7288A3]">{uiText("Loading uploaded documents…")}</div>
          ) : pageDocuments.length === 0 ? (
            <div className="flex min-h-44 flex-col items-center justify-center gap-2 text-center">
              <FileText size={28} className="text-[#A1B6C6]" />
              <span className="font-montserrat text-[13px] font-semibold text-[#10233A]">{uiText("No uploaded documents found")}</span>
            </div>
          ) : pageDocuments.map((document, index) => {
            const status = uploadedStatus(document);
            const source = uploadedDocumentSource(document, uiText);
            const organizationName = organizationNames.get(document.company_id || '');
            const duplicateOriginal = originalForDocument(document);
            const isSelected = selectedDocument?.id === document.id;
            const actions = rowActions(document);
            return (
              <div
                key={document.id}
                role="row"
                data-record-inactive={actions.inactive || undefined}
                className={`flex min-h-[44px] w-full flex-row items-center rounded-lg px-3 py-1 transition-colors ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'} ${isSelected ? '!bg-[#EAF4F8]' : 'hover:bg-[#E7F4F9]'}`}
              >
                <div className="flex min-h-9 min-w-0 flex-1 flex-row items-center gap-3 py-0.5">
                <div role="cell" className="flex w-7 shrink-0 items-center" data-record-active-control>
                  <input type="checkbox" aria-label={`${uiText('Select document')}: ${document.file_case || document.number || document.id}`} checked={selectedIds.has(document.id)} disabled={bulkBusy} onChange={() => setSelectedIds(current => { const next = new Set(current); if (next.has(document.id)) next.delete(document.id); else next.add(document.id); return next; })} className="h-[18px] w-[18px] shrink-0 rounded-[6px] accent-[#007EA7]" />
                </div>
                {visibleColumns.map(column => (
                <div key={column.key} role="cell" data-document-column={column.key} className="min-w-0 flex-shrink-0" style={{ width: column.width }}>
                {column.key === 'document' && (
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      openUploadedDocument(document);
                    }}
                    className="block max-w-full truncate text-left font-montserrat text-[12px] font-normal leading-[18px] text-[#007EA7] underline"
                    title={document.file_case || document.number || document.id}
                  >
                    {document.file_case || document.number || document.id}
                  </button>
                )}
                {column.key === 'organization' && (
                  <>
                  {organizationName ? (
                    <span className="block truncate font-montserrat text-[12px] font-normal leading-[18px] text-[#10233A]">{organizationName}</span>
                  ) : (
                    <button
                      type="button"
                      disabled={actions.inactive}
                      onClick={(event) => {
                        event.stopPropagation();
                        openOrganizationAssignment(document);
                      }}
                      className="font-montserrat text-[11px] font-semibold text-[#007EA7]"
                    >{uiText("Assign organization")}</button>
                  )}
                  </>
                )}
                {column.key === 'status' && (
                  <OcrDocumentStatusCell {...ocrDocumentStatusPresentation(document, statusDescriptions)}
                    status={uploadedDocumentDisplayStatus(document)}
                    documentName={document.file_case || document.number || document.id}
                    panelId={statusPanelId} expanded={isSelected}
                    onOpen={() => { setSelectedDocument(document); setAssigningOrganization(false); setNotice(''); }}
                    action={status === 'Duplicate' && duplicateOriginal ? (
                        <button
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            void onOpenDocument(duplicateOriginal, 'original-view');
                          }}
                          className="ml-auto shrink-0 text-left font-montserrat text-[11px] font-normal leading-[14px] text-[#007EA7] underline"
                        >{uiText("View original")}</button>
                  ) : null} />
                )}
                {column.key === 'source' && (
                <div data-document-source-cell className="flex min-w-0 flex-col items-start gap-0.5">
                  <span className="block max-w-full truncate font-montserrat text-[12px] font-medium leading-[18px] text-[#10233A]" title={uiText(source.type)}>{uiText(source.type)}</span>
                  <span data-document-source-detail className="block max-w-full truncate font-montserrat text-[11px] font-normal leading-[16px] text-[#7288A3]" title={source.detail} aria-label={`${uiText('Source details')}: ${source.detail}`}>
                    {source.detail}
                  </span>
                </div>
                )}
                {column.key === 'uploaded' && (
                <span className="font-montserrat text-[12px] font-normal leading-[18px] text-[#10233A]">{displayUploadedDate(document)}</span>
                )}
                </div>
                ))}
                <div role="cell" className="system-table-row-actions flex min-w-[64px] items-center gap-2" onClick={event => event.stopPropagation()}>
                  <button
                    type="button"
                    title={uiText(actions.reportReason || 'Report issue')}
                    aria-label={`${uiText('Report issue')}: ${document.file_case || document.number || document.id}`}
                    disabled={Boolean(actions.reportReason)}
                    onClick={() => openIssueDialog(document)}
                    className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors enabled:hover:border-[#007EA7] enabled:hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40"
                  ><AlertCircle size={14} /></button>
                  {document.document_deletion ? <DocumentRestoreButton
                    document={document}
                    allowed={Boolean(organizationActions.get(document.company_id || '')?.rights.delete)}
                    onRestored={() => { setNotice(uiText('Document restored to its previous status.')); void loadData(); }}
                    onError={setNotice}
                  /> : <RowDeleteButton
                    label={`${uiText('Delete')}: ${document.file_case || document.number || document.id}`}
                    title={uiText(actions.deleteReason || 'Delete')}
                    disabled={Boolean(actions.deleteReason)}
                    deactivationIcon="trash"
                    onDelete={() => { closeSidePanel(); setDeleteDocument(document); }}
                  />}
                </div>
                </div>
              </div>
            );
          })}
          </div>
        </div>
        <HorizontalTableScrollbar scrollRef={tableScrollRef} className="uploaded-documents-scrollbar" />
        <div className="flex flex-shrink-0 flex-row flex-wrap items-center justify-between gap-4">
          <TablePagination
            scrollRef={tableScrollRef}
            currentPage={safePage}
            totalPages={pageCount}
            itemCount={filteredDocuments.length}
            itemsPerPage={PAGE_SIZE}
            onPageChange={setPage}
          />
        </div>
        </section>
        {selectedDocument && <OcrDocumentStatusPanel document={selectedDocument} descriptions={statusDescriptions} displayDetail docked id={statusPanelId}
          organizationName={organizationNames.get(selectedDocument.company_id || '')} onClose={closeSidePanel}
          relatedAction={originalForDuplicate && <button type="button" onClick={() => void onOpenDocument(originalForDuplicate, 'original-view')}
            className="text-[12px] text-[#007EA7] underline">{uiText('View original')}</button>}
          footer={<>
            {uploadedStatus(selectedDocument) === 'Processed' && selectedDocument.company_id && (
              <PageActionButton onClick={() => void onOpenDocument(selectedDocument)}>{uiText('Open in organization')}</PageActionButton>
            )}
            {!selectedDocument.company_id && !rowActions(selectedDocument).inactive && (
              <PageActionButton onClick={() => openOrganizationAssignment(selectedDocument)}>{uiText('Assign organization')}</PageActionButton>
            )}
            <PageActionButton iconOnly icon={<AlertCircle size={16} />} ariaLabel={uiText(rowActions(selectedDocument).reportReason || 'Report issue')} disabled={Boolean(rowActions(selectedDocument).reportReason)} onClick={() => openIssueDialog(selectedDocument)}>{uiText('Report issue')}</PageActionButton>
          </>} />}
        </div>
      </div>

      {previewDocument && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-[#10233A]/25 p-4 sm:p-6"
          onMouseDown={() => setPreviewDocument(null)}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-label={`Document preview ${previewDocument.file_case || previewDocument.number || previewDocument.id}`}
            className="flex h-[min(900px,94vh)] w-[min(1180px,96vw)] flex-col overflow-hidden rounded-2xl bg-white shadow-2xl"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <header className="flex h-16 flex-shrink-0 items-center justify-between border-b border-[#E5EDF9] px-6">
              <div className="min-w-0">
                <h2 className="truncate font-montserrat text-[18px] font-semibold text-[#10233A]">
                  {previewDocument.file_case || previewDocument.number || previewDocument.id}
                </h2>
                <p className="font-montserrat text-[11px] font-normal text-[#7288A3]">{uiText("Original uploaded document · Read-only")}</p>
              </div>
              <button
                type="button"
                aria-label={uiText("Close document preview")}
                onClick={() => setPreviewDocument(null)}
                className="flex h-8 w-8 flex-shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#10233A]"
              >
                <X size={22} />
              </button>
            </header>
            <div className="min-h-0 flex-1 bg-[#EEF3F7] p-3 sm:p-5">
              {previewDocument.image_url && (previewDocument.image_url.startsWith('data:image/') || /\.(png|jpe?g|gif|webp|tiff?)($|\?)/i.test(previewDocument.image_url)) ? (
                <img
                  src={previewDocument.image_url}
                  alt={`Uploaded document ${previewDocument.file_case || previewDocument.number || previewDocument.id}`}
                  className="h-full w-full object-contain"
                />
              ) : previewDocument.image_url ? (
                <object
                  data={previewDocument.image_url}
                  type="application/pdf"
                  aria-label={`Uploaded PDF ${previewDocument.file_case || previewDocument.number || previewDocument.id}`}
                  className="h-full w-full rounded-lg bg-white"
                >
                  <div className="flex h-full flex-col items-center justify-center gap-3 rounded-lg bg-white px-8 text-center">
                    <FileText size={36} className="text-[#007EA7]" />
                    <p className="font-montserrat text-[13px] font-medium text-[#10233A]">{uiText("This browser cannot display the uploaded document.")}</p>
                    <a href={previewDocument.image_url} target="_blank" rel="noreferrer" className="font-montserrat text-[13px] font-semibold text-[#007EA7]">{uiText("Open document")}</a>
                  </div>
                </object>
              ) : (
                <div className="h-full overflow-y-auto rounded-lg bg-[#E9EFF4] p-5 sm:p-8">
                  <article className="mx-auto min-h-full w-full max-w-[760px] bg-white px-8 py-10 shadow-sm sm:px-14 sm:py-12">
                    <header className="flex items-start justify-between gap-8 border-b border-[#D3E1EC] pb-7">
                      <div className="min-w-0">
                        <p className="font-montserrat text-[11px] font-semibold uppercase tracking-[0.12em] text-[#7288A3]">{uiText("Uploaded document")}</p>
                        <h3 className="mt-2 break-words font-montserrat text-[24px] font-semibold leading-8 text-[#10233A]">
                          {previewDocument.file_case || previewDocument.number || previewDocument.id}
                        </h3>
                      </div>
                      <FileText size={42} strokeWidth={1.4} className="flex-shrink-0 text-[#007EA7]" />
                    </header>
                    <dl className="mt-8 grid grid-cols-1 gap-x-10 gap-y-6 sm:grid-cols-2">
                      {[
                        ['Document type', uiText(documentTypeCatalogLabel(previewDocument, documentTypes) || '—')],
                        ['Document Number', previewDocument.number || '—'],
                        ['Organization', organizationNames.get(previewDocument.company_id || '') || '—'],
                        ['Client / Counterparty', previewDocument.client_counterparty || '—'],
                        ['Document date', previewDocument.document_date || '—'],
                        ['Received', displayUploadedDate(previewDocument)],
                        ['Currency', previewDocument.currency || '—'],
                        ['Total amount', previewDocument.total_amount || '—'],
                        ['Source', uploadedDocumentSource(previewDocument).type],
                        ['Source value', sourceValue(previewDocument)],
                      ].map(([label, value]) => (
                        <div key={label} className="border-b border-[#E5EDF9] pb-3">
                          <dt className="font-montserrat text-[11px] font-semibold text-[#7288A3]">{uiText(label)}</dt>
                          <dd className="mt-1 break-words font-montserrat text-[13px] font-normal leading-5 text-[#10233A]">{value}</dd>
                        </div>
                      ))}
                    </dl>
                  </article>
                </div>
              )}
            </div>
          </section>
        </div>
      )}

      {issueDocument?.company_id && <DocumentIssueDialog
        documentId={issueDocument.id}
        companyId={issueDocument.company_id}
        onClose={() => { setIssueDocument(null); void loadData(); }}
      />}
      {deleteTargets && <GlJournalDialog title="Delete selected documents" subtitle={`${uiText('Selected documents')}: ${deleteTargets.length}`}
        overlayZIndex={5100} onClose={() => { if (!bulkBusyRef.current) setDeleteTargets(null); }} footer={<>
          <PageActionButton disabled={bulkBusy} onClick={() => setDeleteTargets(null)}>{uiText('Cancel')}</PageActionButton>
          <PageActionButton disabled={bulkBusy} icon={<Trash2 size={15} />} onClick={() => void runBulkAction('delete')}>{bulkBusy ? uiText('Deleting…') : `${uiText('Delete')} (${deleteTargets.length})`}</PageActionButton>
        </>}>
        <p className="text-[13px] leading-5">{uiText('Selected documents will be marked as deleted. Their data and history will be kept, and they can be restored.')}</p>
      </GlJournalDialog>}
      {deleteDocument?.company_id && <DocumentRowActionDialog
        mode="delete"
        retainedInList
        documentId={deleteDocument.id}
        companyId={deleteDocument.company_id}
        onClose={() => setDeleteDocument(null)}
        onDeleted={() => {
          setNotice(uiText('Document deleted. The inactive record remains visible in this register.'));
          void loadData();
        }}
        onCreated={() => undefined}
        onUpdated={() => undefined}
      />}
    </div>
  );
}
