import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { useState } from 'react';
import type { Company } from '../lib/supabase';
import { loadOrganizationSourceLinks } from '../lib/organizationImport';
import { MIGRATION_SCOPE, loadMigrationSetup, saveMigrationSetup, validateMigrationPackage } from '../lib/organizationMigration';
import { PageHeader, PageActionButton } from './PageHeader';
import { SystemBreadcrumb } from './SystemNavigation';
import { ClientField } from './CompanyClientInformation';
import CompanySharePointSettings from './CompanySharePointSettings';
import { saveProfileSetup } from '../lib/profileSetup';
import ProfileOcrSetup from './ProfileOcrSetup';

export default function OrganizationSetupIntegration({ company, onBack, onOpenCard, embedded = false }: { company: Company; onBack?: () => void; onOpenCard?: () => void; embedded?: boolean }) {
  return <SetupIntegrationForm target={{ kind: 'company', company }} onBack={onBack} onOpenCard={onOpenCard} embedded={embedded} />;
}

export function ProfileSetupIntegration({ email, onOpenSecurity }: { email: string; onOpenSecurity?: () => void }) {
  return <ProfileOcrSetup email={email} onOpenSecurity={onOpenSecurity} />;
}

type SetupTarget = { kind: 'company'; company: Company } | { kind: 'profile'; email: string; initial: import('../lib/organizationMigration').MigrationSetup };
function SetupIntegrationForm({ target, onBack, onOpenCard, embedded = false }: { target: SetupTarget; onBack?: () => void; onOpenCard?: () => void; embedded?: boolean }) {
  const targetId = target.kind === 'company' ? target.company.id : target.email.trim().toLowerCase();
  const identity = target.kind === 'company' ? 'organizationId' : 'profileId';
  const [setup, setSetup] = useState(() => {
    if (target.kind === 'profile') return target.initial;
    const saved = loadMigrationSetup(target.company.id);
    const link = loadOrganizationSourceLinks().find(item => item.organizationId === target.company.id);
    return { ...saved, source: saved.source || link?.source || '', portfolio: saved.portfolio || link?.environment || '' };
  });
  const [open, setOpen] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const latest = setup.results.at(-1);
  const save = (value: typeof setup) => {
    if (target.kind === 'profile') saveProfileSetup(window.localStorage, target.email, { migration: value });
    else saveMigrationSetup(target.company.id, value);
    setSetup(value);
  };
  const upload = async (file?: File) => {
    if (!file || busy) return;
    setBusy(true); setError('');
    try {
      if (file.size > 50 * 1024 * 1024) throw new Error('Maximum file size is 50 MB.');
      const raw: unknown = JSON.parse(await file.text());
      const result = validateMigrationPackage(raw, targetId, setup.asOf, file.name, identity);
      save({ ...setup, status: result.errors.length ? 'Validation failed' : 'Validated — awaiting import', results: [...setup.results, result] });
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to validate file.'); }
    finally { setBusy(false); }
  };
  return <div className={embedded ? 'flex min-w-0 flex-col gap-6 font-montserrat text-[12px] text-[#10233A]' : 'flex min-h-screen flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px] font-montserrat text-[12px] text-[#10233A]'}>
    {!embedded && target.kind === 'company' && <><PageHeader title={uiText("Setup & integration")} actions={<><PageActionButton onClick={onBack}>{uiText("Back")}</PageActionButton>{onOpenCard && <PageActionButton onClick={onOpenCard}>{uiText("Organization settings")}</PageActionButton>}</>} /><SystemBreadcrumb items={['Companies', target.company.name, 'Manage company', 'Setup & integration']} /></>}
    {target.kind === 'profile' && <p className="text-[#7288A3]">{uiText('These settings belong to your profile and do not change company settings.')}</p>}
    <section className="rounded-lg border border-[#D3E1EC] p-5">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <ClientField field={{ key: 'sourceSystem', label: uiText('Source system'), type: 'select', value: setup.source, options: ['Rivilė', 'Other ERP', 'File'], strictOptions: true }} onChange={source => setSetup(current => ({ ...current, source }))} />
        <label className="space-y-2"><span className="block font-semibold">{uiText("Portfolio / DB ID")}</span><input value={setup.portfolio} onChange={event => setSetup(current => ({ ...current, portfolio: event.target.value }))} className="h-[42px] w-full rounded-lg border border-[#D3E1EC] px-3 outline-none focus:border-[#007EA7]" /></label>
        <label className="space-y-2"><span className="block font-semibold">{uiText("Migration date")}</span><input type="date" value={setup.asOf} onChange={event => setSetup(current => ({ ...current, asOf: event.target.value }))} className="h-[42px] w-full rounded-lg border border-[#D3E1EC] px-3 outline-none focus:border-[#007EA7]" /></label>
      </div>
      <div className="mt-5 flex flex-wrap items-center justify-between gap-4"><p>{uiText("Initial setup / Migration: ")}<strong>{statusText(setup.status)}</strong></p><PageActionButton disabled={!setup.source || !setup.portfolio.trim() || !setup.asOf} onClick={() => { try { save({ ...setup, status: setup.status === 'Not started' ? 'In progress' : setup.status }); setOpen(true); setError(''); } catch { setError('Unable to save setup.'); } }}>{setup.status === 'Not started' ? uiText('Start initial setup') : uiText('Continue initial setup')}</PageActionButton></div>
      <div className="mt-5 grid gap-4 border-t border-[#D3E1EC] pt-4 md:grid-cols-2"><div><p className="font-semibold">{uiText("Last result / error")}</p><p className="mt-2 text-[#7288A3]">{latest ? latest.errors.length ? latest.errors[0] : uiText('Package validation passed. Import has not been executed.') : uiText('No migration run yet.')}</p>{latest && <p className="mt-1 text-[#7288A3]">{latest.at.slice(0, 10)} · {latest.fileName}</p>}</div><div><p className="font-semibold">{uiText("ERP synchronization status")}</p><p className="mt-2 text-[#7288A3]">{uiText("Not configured")}</p><p className="mt-1 text-[#7288A3]">{uiText("Confirmed FH payments and settlements require an ERP connector to update debt balances. No results have been transmitted.")}</p></div></div>
    </section>
    {target.kind === 'company' && <CompanySharePointSettings key={targetId} company={target.company} />}
    {error && <p role="alert" className="text-red-600">{uiText(error)}</p>}
    {open && <section className="flex flex-col gap-5 rounded-lg border border-[#D3E1EC] p-5">
      <h3 className="text-[16px] font-semibold">{uiText("Initial setup / Migration")}</h3>
      <p className="text-[#7288A3]">{uiText("Phase I includes the datasets below. Closed multi-year history does not need to be migrated in full.")}</p>
      <table className="w-full text-left"><thead><tr><th className="px-3 py-2 font-medium">{uiText("Dataset")}</th><th className="px-3 py-2 font-medium">{uiText("Validated records")}</th></tr></thead><tbody>{MIGRATION_SCOPE.map((item, index) => <tr key={item.key} className={index % 2 === 0 ? 'bg-[#F8FDFF]' : ''}><td className="h-10 px-3">{uiText(item.label)}</td><td className="px-3">{latest?.counts[item.key] ?? '—'}</td></tr>)}</tbody></table>
      <label className="cursor-pointer self-start rounded-md border-2 border-[#D3E1EC] px-3 py-2 font-semibold text-[#007EA7]">{busy ? uiText('Validating…') : uiText('Upload migration package')}<input aria-label={uiText("Upload migration package")} type="file" accept=".json,application/json" disabled={busy} className="hidden" onChange={event => { void upload(event.target.files?.[0]); event.target.value = ''; }} /></label>
      <p className="text-[#7288A3]">{uiText("JSON packages are validated only. Posting data into FH accounting modules and sending confirmed results to ERP requires configured import mappings and an ERP connector.")}</p>
      <details className="rounded-lg bg-[#F8FDFF] p-3"><summary className="cursor-pointer font-semibold">{uiText("Package format")}</summary><p className="mt-3">{target.kind === 'profile' ? uiText('Use profileId for your profile, asOf for the migration date, data for datasets and controlTotals for totals. Validation does not import company data.') : uiText("Provide organizationId, asOf, data and controlTotals. Every dataset must be an array. Records require id; financial records require currency and amount (balance for receivables/payables), counterpartyId and, for partial payments, documentId. Control totals are grouped by dataset and currency.")}</p><pre className="mt-3 overflow-auto text-[11px]">{JSON.stringify({ [identity]: targetId, asOf: setup.asOf, data: Object.fromEntries(MIGRATION_SCOPE.map(item => [item.key, []])), controlTotals: { receivables: {}, payables: {}, partialPayments: {}, advances: {}, openingBalances: {} } }, null, 2)}</pre></details>
      {latest && <><h4 className="text-[14px] font-semibold">{uiText("Validation errors (")}{latest.errors.length})</h4>{latest.errors.length ? <ul className="list-disc space-y-1 pl-5 text-red-600">{latest.errors.map((message, index) => <li key={index}>{message}</li>)}</ul> : <p className="text-[#087A55]">{uiText("No validation errors.")}</p>}<h4 className="text-[14px] font-semibold">{uiText("Control totals")}</h4><div className="overflow-auto"><table className="w-full text-left"><thead><tr>{['Dataset', 'Currency', 'Source total', 'Package total', 'Result'].map(label => <th key={label} className="p-3 font-medium">{uiText(label)}</th>)}</tr></thead><tbody>{latest.checks.map((check, index) => <tr key={index} className="odd:bg-[#F8FDFF]"><td className="p-3">{check.category}</td><td>{check.currency}</td><td>{check.expected}</td><td>{check.actual}</td><td className={check.passed ? 'text-[#087A55]' : 'text-red-600'}>{check.passed ? uiText('Matched') : uiText('Mismatch')}</td></tr>)}</tbody></table></div></>}
      {setup.results.length > 0 && <details><summary className="cursor-pointer font-semibold">{uiText("Validation history (")}{setup.results.length})</summary>{[...setup.results].reverse().map(result => <p key={result.id} className="mt-2">{result.at.slice(0, 10)} · {result.fileName} · {result.errors.length ? result.errors.length + ' errors' : uiText('Validated')}</p>)}</details>}
    </section>}
  </div>;
}
