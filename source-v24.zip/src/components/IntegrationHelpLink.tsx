import { HelpCircle } from 'lucide-react';
import { translateUi as t } from '../i18n/language';

// URL helper stays lightweight: do not load the article catalog in the main app.
export const integrationHelpHref = (integration = 'Rivilė API', topic?: string) => `./#help/integrations?${new URLSearchParams({ integration, ...(topic ? { topic } : {}) }).toString()}`;
export default function IntegrationHelpLink({ integration, label }: { integration: string; label: string }) {
  return <a href={integrationHelpHref(integration)} target="_blank" rel="noopener noreferrer"
    aria-label={`${t('Help')}: ${t(label)} · ${t('Opens in a new tab')}`} data-tooltip={`${t('Help')}: ${t(label)}`}
    onClick={event => event.stopPropagation()}
    className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#7288A3] hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#007EA7]">
    <HelpCircle size={15} aria-hidden="true" />
  </a>;
}
