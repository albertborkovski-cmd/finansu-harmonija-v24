import { useRef } from 'react';
import { Loader2, ScanLine } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { assignDocumentFields, requestDocumentsDetailedDigitization, type DbDocument } from '../lib/supabase';
import { documentAssignmentSnapshot } from '../lib/documentBulkAssignment';
import { detailedDigitizationError } from '../lib/documentDetailedDigitization';
import { hasBlockingDocumentIssue, type DocumentIssue } from '../lib/documentIssues';
import DocumentRegisterActionsMenu from './DocumentRegisterActionsMenu';
import { PageActionButton } from './PageHeader';

type Props = {
  document: DbDocument;
  issues: DocumentIssue[];
  canEdit: boolean;
  busy: boolean;
  unsavedChanges: boolean;
  onBusyChange: (busy: boolean) => void;
  onExported: (action: 'exclude' | 'exported') => void;
  onDigitized: () => void;
  onReportIssue: () => void;
  onError: (message: string) => void;
};

/** The global OCR register's editor reuses its row menu and guarded commands.
 * Actions never silently discard or auto-save unfinished document edits. */
export default function DocumentRegisterEditorActions({ document, issues, canEdit, busy, unsavedChanges, onBusyChange, onExported, onDigitized, onReportIssue, onError }: Props) {
  const pending = useRef(false);
  const saveFirst = unsavedChanges ? 'Save document changes before using this action.' : '';
  const digitizationError = saveFirst || detailedDigitizationError({ ...document, digitization_issues: issues }, canEdit);
  const exportAction = async (action: 'exclude' | 'exported') => {
    if (pending.current || busy || !canEdit || unsavedChanges) return;
    pending.current = true; onBusyChange(true);
    try {
      await assignDocumentFields([document.id], { other: action }, { [document.id]: documentAssignmentSnapshot({ ...document }) });
      onExported(action);
    } finally { pending.current = false; onBusyChange(false); }
  };
  const digitize = async () => {
    if (pending.current || busy || digitizationError) return;
    pending.current = true; onBusyChange(true); onError('');
    try {
      await requestDocumentsDetailedDigitization([document.id]);
      onDigitized();
    } catch (error) {
      onError(error instanceof Error ? error.message : 'The documents could not be returned to OCR.');
    } finally { pending.current = false; onBusyChange(false); }
  };
  return <div data-document-register-editor-actions className="ml-auto flex flex-wrap items-center justify-end gap-2">
    <span title={digitizationError ? t(digitizationError) : undefined} className="inline-flex">
      <PageActionButton disabled={busy || Boolean(digitizationError)} onClick={() => void digitize()}
        icon={busy ? <Loader2 size={15} className="animate-spin" /> : <ScanLine size={15} />}>
        {t('Digitize in detail')}
      </PageActionButton>
    </span>
    <span title={saveFirst ? t(saveFirst) : undefined} className="inline-flex [&>button]:h-8 [&>button]:w-8 [&>button]:rounded-md">
      <DocumentRegisterActionsMenu documentLabel={document.file_case || document.number || document.id}
        disabled={busy || Boolean(document.document_deletion)} canEdit={canEdit && !unsavedChanges}
        excluded={Boolean(document.excluded_from_export)} exported={document.manual_export_status === 'Exported'}
        issueBlocksExport={hasBlockingDocumentIssue({ status: document.status, digitization_issues: issues })} onExportAction={exportAction}
        onReportIssue={onReportIssue} onError={onError} />
    </span>
  </div>;
}
