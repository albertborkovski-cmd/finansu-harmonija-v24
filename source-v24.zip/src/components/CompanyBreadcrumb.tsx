import { translateUi as uiText } from '../i18n/language';
export default function CompanyBreadcrumb({
  companyName,
  items = [],
  singleLine = false,
}: {
  companyName: string;
  items?: string[];
  singleLine?: boolean;
}) {
  const path = ["Companies", companyName, ...items].filter(Boolean);

  return (
    <nav
      data-system-breadcrumb
      aria-label={uiText("Breadcrumb")}
      className={`flex min-h-4 items-center gap-1.5 font-montserrat text-[11px] font-medium leading-4 text-[#7288A3] ${singleLine ? "flex-nowrap overflow-hidden whitespace-nowrap" : "flex-wrap"}`}
    >
      {path.map((item, index) => (
        <span key={`${item}-${index}`} className="contents">
          {index > 0 && <span className="text-[#A1B6C6]">/</span>}
          <span
            className={
              index === path.length - 1 ? "text-[#A1B6C6]" : undefined
            }
          >
            {index === 1 ? item : uiText(item)}
          </span>
        </span>
      ))}
    </nav>
  );
}
