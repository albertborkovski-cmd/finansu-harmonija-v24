import { useEffect, useMemo, useRef, useState } from 'react';
import { Eye, PencilLine, Plus, RefreshCw } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { supabase, type Company } from '../lib/supabase';
import { canManageContractPricing, contractPlanSaas, CONTRACT_PRICING_CHANGED, CONTRACT_PRICING_KEY, DEFAULT_CONTRACT_PLAN_ID, readContractPricing, type ContractPricingCatalog } from '../lib/contractPricing';
import { companySaasUsage, parseCompanySaasPlan, SAAS_PRODUCTS, type SaasUsageDocument } from '../lib/companySaas';
import { readSaasSubscriptions, saveSaasSubscription, SAAS_SUBSCRIPTIONS_CHANGED, SAAS_SUBSCRIPTIONS_KEY, type SaasSubscription, type SaasSubscriptionCatalog } from '../lib/saasAdministration';
import { PageActionButton, PageHeader } from './PageHeader';
import { SystemBreadcrumb } from './SystemNavigation';
import SearchableSelect from './SearchableSelect';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import GlJournalDialog from './GlJournalDialog';
import ContractPricingPanel from './ContractPricingPanel';
import { ContractPlanOptionsSummary } from './ContractPlanOptions';
import OcrSearchField from './OcrSearchField';
import RefreshAllButton from './RefreshAllButton';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import ColumnSortButton from './ColumnSortButton';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import { usePersistentState } from '../hooks/usePersistentState';
import SaasPlanUsageCard from './SaasPlanUsageCard';

const COMPANY_COLUMNS: ColConfig[] = [
  { key: 'company', label: 'Company', width: 180, visible: true },
  { key: 'code', label: 'Company code', width: 160, visible: true },
  { key: 'plan', label: 'Pricing plan', width: 230, visible: true },
  { key: 'product', label: 'Product', width: 210, visible: true },
  { key: 'status', label: 'Subscription status', width: 185, visible: true },
  { key: 'start', label: 'Subscription start', width: 180, visible: true },
  { key: 'used', label: 'Documents this month', width: 200, visible: true },
];
const rowActionClass = 'flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors enabled:hover:border-[#007EA7] enabled:hover:text-[#007EA7] disabled:opacity-40';

const fieldClass = 'h-[42px] w-full rounded-lg border border-[#D3E1EC] bg-white px-3.5 font-montserrat text-[14px] text-[#10233A] outline-none focus:border-[#007EA7]';
type Editor = { companyId: string; subscription?: SaasSubscription; revision: number };

function SubscriptionEditor({ editor, companies, pricing, onClose, onSaved }: { editor: Editor; companies: Company[]; pricing: ContractPricingCatalog; onClose: () => void; onSaved: (value: SaasSubscriptionCatalog) => void }) {
  const [companyId, setCompanyId] = useState(editor.companyId);
  const [planId, setPlanId] = useState(editor.subscription?.planId || pricing.plans[0]?.id || '');
  const [status, setStatus] = useState<SaasSubscription['status']>(editor.subscription?.status || 'Active');
  const [startsOn, setStartsOn] = useState(editor.subscription?.startsOn || new Date().toLocaleDateString('en-CA'));
  const [error, setError] = useState(''), [saving, setSaving] = useState(false);
  const form = useRef<HTMLFormElement>(null);
  const selectedPlan = pricing.plans.find(plan => plan.id === planId);
  const save = async () => {
    if (saving) return;
    setSaving(true); setError('');
    try {
      if (!canManageContractPricing(localStorage)) throw new Error('Only an administrator can manage SaaS subscriptions.');
      const { data, error: loadError } = await supabase.from('companies').select('id');
      if (loadError) throw new Error(loadError.message);
      const next = saveSaasSubscription(localStorage, editor.revision, { companyId, planId, status, startsOn }, (data || []).map(row => String(row.id)));
      window.dispatchEvent(new Event(SAAS_SUBSCRIPTIONS_CHANGED)); onSaved(next);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to save SaaS settings.'); }
    finally { setSaving(false); }
  };
  return <GlJournalDialog title={editor.companyId ? 'Edit subscription' : 'Assign SaaS plan'} onClose={onClose}
    footer={<><PageActionButton disabled={saving} onClick={onClose}>{t('Cancel')}</PageActionButton><PageActionButton disabled={saving || !companyId || !planId} onClick={() => form.current?.requestSubmit()}>{t(saving ? 'Saving…' : 'Save changes')}</PageActionButton></>}>
    <form ref={form} onSubmit={event => { event.preventDefault(); void save(); }} className="grid gap-4 sm:grid-cols-2">
      <div className="col-span-full"><div className="mb-2 text-[12px] font-medium text-[#7288A3]">{t('Company')} *</div><SearchableSelect ariaLabel={t('Company')} value={companyId} disabled={Boolean(editor.companyId) || saving} options={companies.map(company => ({ value: company.id, label: `${company.name}${company.company_code ? ` · ${company.company_code}` : ''}` }))} onChange={setCompanyId} portalMenu /></div>
      <div className="col-span-full"><div className="mb-2 text-[12px] font-medium text-[#7288A3]">{t('Pricing plan')} *</div><SearchableSelect ariaLabel={t('Pricing plan')} value={planId} disabled={saving} options={pricing.plans.map(plan => ({ value: plan.id, label: t(plan.name) }))} onChange={setPlanId} portalMenu /></div>
      <label className="flex flex-col gap-2 text-[12px] font-medium text-[#7288A3]">{t('Subscription start')} *<input type="date" required disabled={saving} value={startsOn} onChange={event => setStartsOn(event.target.value)} className={fieldClass} /></label>
      <div><div className="mb-2 text-[12px] font-medium text-[#7288A3]">{t('Subscription status')} *</div><SearchableSelect ariaLabel={t('Subscription status')} value={status} disabled={saving} options={['Active', 'Paused', 'Cancelled'].map(value => ({ value, label: t(value) }))} onChange={value => setStatus(value as SaasSubscription['status'])} portalMenu /></div>
      {selectedPlan && <div className="col-span-full"><ContractPlanOptionsSummary plan={selectedPlan} showModules={false} /></div>}
      <p className="col-span-full text-[12px] leading-5 text-[#7288A3]">{t('Assignment changes SaaS configuration only. Existing contracts, invoices and user access are not changed.')}</p>
      {error && <p role="alert" className="col-span-full text-[12px] text-[#B42318]">{t(error)}</p>}
    </form>
  </GlJournalDialog>;
}

export default function SaasAdministration() {
  const language = useLanguage();
  const [tab, setTab] = useState<'companies' | 'pricing' | 'history'>('companies');
  const [companies, setCompanies] = useState<Company[]>([]), [documents, setDocuments] = useState<SaasUsageDocument[]>([]);
  const [pricing, setPricing] = useState<ContractPricingCatalog | null>(null), [subscriptions, setSubscriptions] = useState<SaasSubscriptionCatalog | null>(null);
  const [loading, setLoading] = useState(true), [error, setError] = useState(''), [feedback, setFeedback] = useState('');
  const [refresh, setRefresh] = useState(0), [query, setQuery] = useState(''), [statusFilter, setStatusFilter] = useState('');
  const [selectedPlan, setSelectedPlan] = useState(DEFAULT_CONTRACT_PLAN_ID), [editor, setEditor] = useState<Editor | null>(null);
  const [viewCompanyId, setViewCompanyId] = useState<string | null>(null);
  const [columns, setColumns] = usePersistentState<ColConfig[]>('finansu-harmonija-v24:saas-companies:columns', COMPANY_COLUMNS);
  const [showColumns, setShowColumns] = useState(false);
  const { startResize } = useColumnResize(columns, setColumns);
  const [sort, setSort] = useState<{ key: 'company' | 'plan' | 'status'; descending: boolean }>({ key: 'company', descending: false });
  const scrollRef = useRef<HTMLDivElement>(null);
  const admin = canManageContractPricing(localStorage);
  useEffect(() => {
    if (!admin) return;
    let cancelled = false;
    setLoading(true); setError('');
    void Promise.all([supabase.from('companies').select('*'), supabase.from('documents').select('id, company_id, receive_date, created_at')]).then(([companyResult, documentResult]) => {
      if (cancelled) return;
      if (companyResult.error || documentResult.error) throw new Error('SaaS companies could not be loaded.');
      setCompanies(companyResult.data as unknown as Company[] || []); setDocuments(documentResult.data || []);
    }).catch(reason => { if (!cancelled) setError(reason instanceof Error ? reason.message : 'SaaS companies could not be loaded.'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [admin, refresh]);
  useEffect(() => {
    const reload = (event?: Event) => {
      if (event instanceof StorageEvent && event.key && ![CONTRACT_PRICING_KEY, SAAS_SUBSCRIPTIONS_KEY].includes(event.key)) return;
      try { setPricing(readContractPricing(localStorage)); setSubscriptions(readSaasSubscriptions(localStorage)); }
      catch (reason) { setError(reason instanceof Error ? reason.message : 'SaaS companies could not be loaded.'); setPricing(null); setSubscriptions(null); }
    };
    reload(); window.addEventListener('storage', reload); window.addEventListener(CONTRACT_PRICING_CHANGED, reload); window.addEventListener(SAAS_SUBSCRIPTIONS_CHANGED, reload);
    return () => { window.removeEventListener('storage', reload); window.removeEventListener(CONTRACT_PRICING_CHANGED, reload); window.removeEventListener(SAAS_SUBSCRIPTIONS_CHANGED, reload); };
  }, [refresh]);
  const rows = useMemo(() => {
    const grouped = new Map<string, SaasUsageDocument[]>();
    for (const document of documents) { const id = String(document.company_id); if (!grouped.has(id)) grouped.set(id, []); grouped.get(id)!.push(document); }
    return companies.filter(company => Boolean(company.saas_settings) || subscriptions?.subscriptions.some(row => row.companyId === company.id)).map(company => {
      const subscription = subscriptions?.subscriptions.find(row => row.companyId === company.id);
      const plan = pricing?.plans.find(item => item.id === subscription?.planId);
      const settings = plan ? contractPlanSaas(plan) : parseCompanySaasPlan(company.saas_settings);
      return { company, subscription, settings, plan, planName: plan?.name || 'Individual company pricing', status: subscription?.status || 'Active', usage: companySaasUsage(company.id, grouped.get(company.id) || [], settings), used: companySaasUsage(company.id, grouped.get(company.id) || [], { ...settings, periodas: 'month' }).used };
    });
  }, [companies, documents, subscriptions, pricing]);
  const filtered = rows.filter(row => (!statusFilter || row.status === statusFilter) && `${row.company.name} ${row.company.company_code} ${t(row.planName)}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()))
    .sort((a, b) => (sort.key === 'company' ? a.company.name.localeCompare(b.company.name, language) : sort.key === 'plan' ? t(a.planName).localeCompare(t(b.planName), language) : t(a.status).localeCompare(t(b.status), language)) * (sort.descending ? -1 : 1));
  const companyNames = new Map(companies.map(company => [company.id, company.name]));
  const history = [...(subscriptions?.history || []).map(event => ({ at: event.at, by: event.by, entity: companyNames.get(event.companyId) || event.companyId, action: event.previous ? 'Subscription updated' : 'Plan assigned', detail: `${t(pricing?.plans.find(plan => plan.id === event.next.planId)?.name || 'Pricing plan')} · ${t(event.next.status)}` })),
    ...(pricing?.history || []).map(event => ({ at: event.at, by: event.by, entity: t(pricing?.plans.find(plan => plan.id === event.planId)?.name || 'Pricing plan'), action: event.area === 'plan' ? 'Plan created' : 'Pricing updated', detail: t(event.area === 'configuration' ? 'Plan settings' : event.area === 'lines' ? 'Digitization pricing' : event.area === 'name' ? 'Plan name' : event.area) }))].sort((a, b) => b.at.localeCompare(a.at));
  if (!admin) return <div role="alert" className="p-8 font-montserrat text-sm">{t('Only an administrator can manage SaaS subscriptions.')}</div>;
  const visibleColumns = columns.filter(column => column.visible);
  const gridTemplateColumns = `${visibleColumns.map(column => `${column.width}px`).join(' ')} minmax(88px,1fr)`;
  const minWidth = visibleColumns.reduce((sum, column) => sum + column.width, 88);
  const viewed = rows.find(row => row.company.id === viewCompanyId);
  return <div className="flex min-w-0 flex-col gap-6 px-4 py-10 font-montserrat text-[#10233A] sm:px-8 lg:px-[72px]">
    <PageHeader title="SaaS" actions={<>{tab === 'companies' && <PageActionButton icon={<Plus size={16} />} disabled={loading || !pricing || !subscriptions} onClick={() => setEditor({ companyId: '', revision: subscriptions!.revision })}>{t('Assign SaaS plan')}</PageActionButton>}{tab !== 'companies' && <PageActionButton icon={<RefreshCw size={16} />} disabled={loading} onClick={() => setRefresh(value => value + 1)}>{t('Refresh')}</PageActionButton>}</>} />
    <SystemBreadcrumb items={['SaaS', tab === 'companies' ? 'Companies' : tab === 'pricing' ? 'Plans & pricing' : 'Change history']} />
    <div className="flex gap-6 overflow-x-auto border-b border-[#D3E1EC]" role="tablist" aria-label={t('SaaS administration')}>{([{ id: 'companies', label: 'Companies' }, { id: 'pricing', label: 'Plans & pricing' }, { id: 'history', label: 'Change history' }] as const).map(item => <button key={item.id} role="tab" aria-selected={tab === item.id} onClick={() => { setTab(item.id); setFeedback(''); }} className={`whitespace-nowrap border-b-2 pb-3 text-[14px] font-semibold ${tab === item.id ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3] hover:text-[#007EA7]'}`}>{t(item.label)}</button>)}</div>
    {error && <p role="alert" className="text-[12px] text-[#B42318]">{t(error)}</p>}{feedback && <p role="status" className="text-[12px] text-[#087A55]">{t(feedback)}</p>}
    {tab === 'pricing' && <ContractPricingPanel administration selectedPlanId={selectedPlan} onSelectPlan={setSelectedPlan} />}
    {tab === 'companies' && <>
      <div className="grid gap-3 sm:grid-cols-3" data-table-workspace-overview>{[{ label: 'SaaS companies', value: rows.length }, { label: 'Active subscriptions', value: rows.filter(row => row.status === 'Active').length }, { label: 'Pricing plans', value: pricing?.plans.length || 0 }].map(item => <div key={item.label} className="flex min-h-[64px] items-center justify-between gap-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3"><span className="text-[12px] text-[#7288A3]">{t(item.label)}</span><strong className="text-[22px] font-semibold tabular-nums">{item.value}</strong></div>)}</div>
      <section className="flex min-h-0 min-w-0 flex-1 flex-col gap-3" aria-label={t('SaaS companies')}>
        <div className="flex min-h-8 shrink-0 flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2"><OcrSearchField ariaLabel="Search SaaS companies" value={query} onChange={setQuery} /><div className="w-[200px]"><SearchableSelect ariaLabel="Subscription status" value={statusFilter} options={[{ value: '', label: t('All statuses') }, ...['Active', 'Paused', 'Cancelled'].map(value => ({ value, label: t(value) }))]} onChange={setStatusFilter} className="h-7 rounded border border-transparent bg-[#E5EDF9] px-2 pr-8 font-montserrat text-[12px] font-medium text-[#7288A3]" portalMenu /></div></div>
          <div data-table-workspace-tools role="group" aria-label={t('Table tools')} className="ml-auto flex h-7 shrink-0 items-center gap-4"><ColumnSettingsButton onClick={() => setShowColumns(true)} /><RefreshAllButton disabled={loading} onRefresh={() => setRefresh(value => value + 1)} /></div>
        </div>
        <div ref={scrollRef} role="region" tabIndex={0} aria-label={t('SaaS companies')} className="min-h-[200px] max-h-[60vh] flex-1 overflow-auto overscroll-contain scrollbar-hide">
          <div role="table" aria-label={t('SaaS companies')} style={{ minWidth }} className="w-full text-[12px] leading-[18px]">
            <div role="row" style={{ gridTemplateColumns }} className="system-table-header-row sticky top-0 z-10 mb-1 grid min-h-9 border-b border-[#E5EDF9] bg-white font-medium">
              {visibleColumns.map(column => { const sortable = ['company', 'plan', 'status'].includes(column.key); return <div key={column.key} role="columnheader" aria-sort={sortable && sort.key === column.key ? sort.descending ? 'descending' : 'ascending' : undefined} className="relative flex min-w-0 items-start gap-1.5 px-3 py-2"><span className="min-w-0 truncate">{t(column.label)}</span>{sortable && <ColumnSortButton columnLabel={t(column.label)} direction={sort.key === column.key ? sort.descending ? 'desc' : 'asc' : null} onDirectionChange={direction => setSort({ key: column.key as typeof sort.key, descending: direction === 'desc' })} />}<ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} /></div>; })}
              <div role="columnheader" className="system-table-row-actions"><span className="sr-only">{t('Actions')}</span></div>
            </div>
            {loading ? <p className="p-8 text-center text-[#7288A3]">{t('Loading…')}</p> : filtered.map((row, index) => <div key={row.company.id} role="row" style={{ gridTemplateColumns }} className={`mb-0.5 grid h-10 items-center rounded-lg font-normal transition-colors hover:bg-[#E7F4F9] ${index % 2 ? 'bg-white' : 'bg-[#F8FDFF]'}`}>
              {visibleColumns.map(column => <div key={column.key} role="cell" className={`min-w-0 truncate px-3 ${column.key === 'used' ? 'text-right tabular-nums' : ''}`}>
                {column.key === 'company' ? row.company.name : column.key === 'code' ? row.company.company_code || '—' : column.key === 'plan' ? t(row.planName) : column.key === 'product' ? t(SAAS_PRODUCTS.find(product => product.value === row.settings.produktas)?.label || 'OCR + Panel') : column.key === 'status' ? <span className={`inline-flex rounded px-2 py-0.5 font-medium ${row.status === 'Active' ? 'bg-[#E6F5EE] text-[#087A55]' : row.status === 'Paused' ? 'bg-[#FFF4DB] text-[#9A6700]' : 'bg-[#EAF0F5] text-[#7288A3]'}`}>{t(row.status)}</span> : column.key === 'start' ? row.subscription?.startsOn || '—' : row.used.toLocaleString(language)}
              </div>)}
              <div role="cell" className="system-table-row-actions flex items-center justify-end gap-2 px-3"><button type="button" className={rowActionClass} title={t('View subscription')} aria-label={`${t('View subscription')}: ${row.company.name}`} onClick={() => setViewCompanyId(row.company.id)}><Eye size={14} /></button><button type="button" className={rowActionClass} title={t('Edit subscription')} aria-label={`${t('Edit subscription')}: ${row.company.name}`} disabled={!subscriptions || !pricing} onClick={() => setEditor({ companyId: row.company.id, subscription: row.subscription, revision: subscriptions!.revision })}><PencilLine size={14} /></button></div>
            </div>)}
            {!loading && !filtered.length && <p className="p-8 text-center text-[#7288A3]">{t('No SaaS companies found. Assign a plan to add a company.')}</p>}
          </div>
        </div>
        <HorizontalTableScrollbar scrollRef={scrollRef} />
        <div role="status" className="text-right text-[12px] text-[#7288A3]">{filtered.length.toLocaleString(language)} / {rows.length.toLocaleString(language)} · {t('Companies')}</div>
      </section>
    </>}
    {tab === 'history' && <div className="max-h-[65vh] overflow-auto rounded-lg border border-[#D3E1EC]"><table className="w-full text-left text-[12px]"><thead className="sticky top-0 bg-[#F4F8FC] text-[#7288A3]"><tr>{['Date', 'Company / Plan', 'Action', 'Details', 'User'].map(label => <th key={label} className="px-4 py-3 font-semibold">{t(label)}</th>)}</tr></thead><tbody>{history.map((event, index) => <tr key={`${event.at}:${index}`} className="border-t border-[#E5EDF9] odd:bg-[#F8FDFF]"><td className="whitespace-nowrap px-4 py-3">{new Date(event.at).toLocaleString(language)}</td><td className="px-4 py-3">{event.entity}</td><td className="px-4 py-3">{t(event.action)}</td><td className="px-4 py-3">{event.detail}</td><td className="px-4 py-3">{event.by}</td></tr>)}{!history.length && <tr><td colSpan={5} className="p-8 text-center text-[#7288A3]">{t('No changes yet.')}</td></tr>}</tbody></table></div>}
    {editor && pricing && <SubscriptionEditor editor={editor} companies={companies} pricing={pricing} onClose={() => setEditor(null)} onSaved={next => { setSubscriptions(next); setEditor(null); setFeedback('SaaS subscription saved.'); }} />}
    {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={COMPANY_COLUMNS} onSave={next => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
    {viewed && <GlJournalDialog title="Subscription overview" subtitle={viewed.company.name} onClose={() => setViewCompanyId(null)} footer={<><PageActionButton onClick={() => setViewCompanyId(null)}>{t('Close')}</PageActionButton><PageActionButton icon={<PencilLine size={16} />} disabled={!subscriptions || !pricing} onClick={() => { setEditor({ companyId: viewed.company.id, subscription: viewed.subscription, revision: subscriptions!.revision }); setViewCompanyId(null); }}>{t('Edit subscription')}</PageActionButton></>}><SaasPlanUsageCard name={viewed.company.name} settings={viewed.settings} plan={viewed.plan} planName={viewed.planName} usage={viewed.usage} loading={loading} onRefresh={() => setRefresh(value => value + 1)} /></GlJournalDialog>}
  </div>;
}
