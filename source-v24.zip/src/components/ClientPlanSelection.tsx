import { useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { SAAS_PRODUCTS, SAAS_PRICING, SAAS_PERIODS } from '../lib/companySaas';
import { contractPlanSaas, hasProgressiveDocumentPricing, discountedDocumentPrice, contractTierRange, readContractPricing, CONTRACT_PRICING_CHANGED, CONTRACT_PRICING_KEY, type ContractPlan, type ContractPricingCatalog } from '../lib/contractPricing';
import SearchableSelect from './SearchableSelect';

type Props = { selectedPlanId: string; currentPlanId: string; selectedTierId?: string; onSelectPlan: (id: string) => void; onSelectTier?: (id: string) => void };
const optionLabel = (options: readonly { value: string; label: string }[], value: string) => t(options.find(option => option.value === value)?.label || value);

function PlanPrice({ plan }: { plan: ContractPlan }) {
  const language = useLanguage(), settings = contractPlanSaas(plan);
  const format = (value: number) => new Intl.NumberFormat(language, { maximumFractionDigits: 4 }).format(value);
  const prices = plan.tiers.map(discountedDocumentPrice);
  return <div className="mt-4 flex flex-wrap items-baseline gap-x-2 gap-y-1">
    <strong className="text-[22px] font-semibold tabular-nums leading-7">{hasProgressiveDocumentPricing(plan) ? `${format(Math.min(...prices))}–${format(Math.max(...prices))} ct` : `${format(Number(settings.kaina))} EUR`}</strong>
    <span className="text-[11px] text-[#7288A3]">{t(settings.kainodara === 'docs' ? 'Per document' : settings.kainodara === 'users' ? 'Per active user' : 'Per company / period')}</span>
  </div>;
}

export default function ClientPlanSelection({ selectedPlanId, currentPlanId, selectedTierId = '', onSelectPlan, onSelectTier }: Props) {
  const language = useLanguage();
  const [loaded, setLoaded] = useState<{ catalog: ContractPricingCatalog | null; error: string }>(() => {
    try { return { catalog: readContractPricing(localStorage), error: '' }; }
    catch { return { catalog: null, error: 'Pricing could not be loaded. Saved data has not been changed.' }; }
  });
  const [product, setProduct] = useState(() => {
    const plan = loaded.catalog?.plans.find(item => item.id === selectedPlanId);
    return plan ? contractPlanSaas(plan).produktas : 'both';
  });
  const [pricing, setPricing] = useState('all');
  useEffect(() => {
    const reload = (event: Event) => {
      if (event instanceof StorageEvent && event.key && event.key !== CONTRACT_PRICING_KEY) return;
      try { setLoaded({ catalog: readContractPricing(localStorage), error: '' }); }
      catch { setLoaded({ catalog: null, error: 'Pricing could not be loaded. Saved data has not been changed.' }); }
    };
    window.addEventListener('storage', reload); window.addEventListener(CONTRACT_PRICING_CHANGED, reload);
    return () => { window.removeEventListener('storage', reload); window.removeEventListener(CONTRACT_PRICING_CHANGED, reload); };
  }, []);
  const matchingPlans = (nextProduct: string, nextPricing: string) => loaded.catalog?.plans.filter(plan => {
    const options = contractPlanSaas(plan);
    return options.produktas === nextProduct && (nextPricing === 'all' || options.kainodara === nextPricing);
  }) || [];
  const changeFilters = (nextProduct: typeof product, nextPricing: string) => {
    setProduct(nextProduct);
    setPricing(nextPricing);
    const available = matchingPlans(nextProduct, nextPricing);
    onSelectPlan(available.find(plan => plan.id === selectedPlanId)?.id || available[0]?.id || '');
  };
  const plans = matchingPlans(product, pricing);
  const selected = plans.find(plan => plan.id === selectedPlanId);
  const selectedTier = selected?.tiers.find(tier => tier.id === selectedTierId);
  const format = (value: number) => new Intl.NumberFormat(language, { maximumFractionDigits: 4 }).format(value);
  return <section aria-label={t('Change plan')} className="min-w-0 overflow-hidden rounded-lg border border-[#D3E1EC] bg-white">
    <header className="border-b border-[#E5EDF9] bg-[#F4F8FC] px-5 py-4">
      <h2 className="text-[16px] font-semibold">{t('Change plan')}</h2>
      <p className="mt-1 text-[12px] leading-5 text-[#7288A3]">{t('Choose an available plan. Your current plan stays unchanged until you confirm the update.')}</p>
    </header>
    <div className="space-y-4 p-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <div><p className="mb-2 text-[12px] font-medium text-[#7288A3]">{t('Product')}</p><SearchableSelect ariaLabel={t('SaaS product')} value={product} onChange={value => changeFilters(value as typeof product, pricing)} options={SAAS_PRODUCTS.map(item => ({ ...item, label: t(item.label) }))} portalMenu /></div>
        <div><p className="mb-2 text-[12px] font-medium text-[#7288A3]">{t('Pricing model')}</p><SearchableSelect ariaLabel={t('SaaS pricing model')} value={pricing} onChange={value => changeFilters(product, value)} options={[{ value: 'all', label: t('All pricing models') }, ...SAAS_PRICING.map(item => ({ ...item, label: t(item.label) }))]} portalMenu /></div>
      </div>
      {loaded.error ? <p role="alert" className="text-[12px] text-[#B42318]">{t(loaded.error)}</p> : plans.length ? <div className="grid items-stretch gap-3 md:grid-cols-2 2xl:grid-cols-3" role="group" aria-label={t('Available plans')}>
        {plans.map(plan => {
          const settings = contractPlanSaas(plan), checked = selectedPlanId === plan.id, current = currentPlanId === plan.id;
          return <button key={plan.id} type="button" aria-pressed={checked} aria-label={`${t('Select plan')}: ${t(plan.name)}`} data-static-selection onClick={() => onSelectPlan(plan.id)} className={`flex min-w-0 flex-col rounded-lg border-2 p-4 text-left outline-none focus-visible:ring-2 focus-visible:ring-[#007EA7] focus-visible:ring-offset-2 ${checked ? 'border-[#007EA7] bg-[#F3FAFD]' : 'border-[#D3E1EC] bg-white hover:border-[#9EBACD]'}`}>
            <div className="flex w-full items-start gap-3"><span className={`mt-0.5 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${checked ? 'border-[#007EA7] bg-[#007EA7] text-white' : 'border-[#9EBACD]'}`}>{checked && <Check size={12} strokeWidth={2.5} />}</span><div className="min-w-0 flex-1"><span className="block text-[14px] font-semibold leading-5">{t(plan.name)}</span><span className="mt-1 block text-[11px] text-[#7288A3]">{optionLabel(SAAS_PRODUCTS, settings.produktas)}</span></div><span className={`shrink-0 rounded px-2 py-1 text-[10px] font-semibold ${current ? 'bg-[#E5EDF9] text-[#007EA7]' : checked ? 'bg-[#E4F3EB] text-[#087A55]' : 'invisible'}`}>{t(current ? 'Current plan' : 'Selected')}</span></div>
            <PlanPrice plan={plan} />
            <dl className="mt-4 grid w-full grid-cols-2 gap-3 border-t border-[#E3ECF3] pt-3 text-[12px]"><div><dt className="text-[#7288A3]">{t('Document limit')}</dt><dd className="mt-1 font-semibold tabular-nums">{format(Number(settings.kiekis))}</dd></div><div><dt className="text-[#7288A3]">{t('Period')}</dt><dd className="mt-1 font-semibold">{optionLabel(SAAS_PERIODS, settings.periodas)}</dd></div></dl>
          </button>;
        })}
      </div> : <p role="status" className="rounded-lg border border-dashed border-[#D3E1EC] p-5 text-[13px] text-[#7288A3]">{t('No available plans for this selection. Choose another product or pricing model.')}</p>}
      {selected && <section aria-label={t('Pricing details')} className="overflow-hidden rounded-lg border border-[#D3E1EC]">
        <h3 className="bg-[#F8FAFC] px-4 py-3 text-[13px] font-semibold">{t('Pricing details')}: {t(selected.name)}</h3>
        {hasProgressiveDocumentPricing(selected) && <>
          <p className="px-4 pb-3 text-[12px] text-[#7288A3]">{t('Select one document range to include in your plan request.')}</p>
          <div className="overflow-x-auto"><table className="w-full min-w-[420px] text-left text-[12px]">
            <thead className="bg-[#F8FAFC] text-[#7288A3]"><tr><th className="w-12 px-4 py-2"><span className="sr-only">{t('Select')}</span></th>{['Document count', 'Document discount', 'Document price'].map(label => <th key={label} className="px-4 py-2 font-medium">{t(label)}</th>)}</tr></thead>
            <tbody>{selected.tiers.map(tier => {
              const checked = tier.id === selectedTierId;
              return <tr key={tier.id} data-static-selection onClick={() => onSelectTier?.(tier.id)} className={`cursor-pointer border-t border-[#E5EDF9] ${checked ? 'bg-[#E5EDF9]' : 'hover:bg-[#F3FAFD]'}`}>
                <td className="px-4 py-3"><label className="flex h-[18px] w-[18px] cursor-pointer items-center justify-center">
                  <input type="radio" name="contract-price-tier" aria-label={`${t('Select document range')}: ${contractTierRange(tier)}`} checked={checked} onChange={() => onSelectTier?.(tier.id)} className="peer sr-only" />
                  <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border peer-focus-visible:ring-2 peer-focus-visible:ring-[#007EA7] peer-focus-visible:ring-offset-2 ${checked ? 'border-[#007EA7] bg-[#007EA7] text-white' : 'border-[#9EBACD]'}`}>{checked && <Check size={12} strokeWidth={2.5} />}</span>
                </label></td>
                <td className="px-4 py-3">{contractTierRange(tier)}</td><td className="px-4 py-3 tabular-nums">{format(tier.discountPercent)}%</td><td className="px-4 py-3 tabular-nums">{format(discountedDocumentPrice(tier))} ct</td>
              </tr>;
            })}</tbody>
          </table></div>
          <div aria-live="polite" className="min-h-[44px] border-t border-[#D3E1EC] bg-[#F3FAFD] px-4 py-3 text-[12px] text-[#007EA7]">
            {selectedTier ? <><span className="font-semibold">{t('Selected document range')}: </span>{contractTierRange(selectedTier)} {t('documents')} · {format(discountedDocumentPrice(selectedTier))} ct / {t('document')}</> : t('Select a document range from the table.')}
          </div>
        </>}
        {!hasProgressiveDocumentPricing(selected) && <div className="border-t border-[#E5EDF9] px-4 pb-4"><PlanPrice plan={selected} /></div>}
        {contractPlanSaas(selected).produktas !== 'panel' && <div className="flex flex-wrap gap-x-6 gap-y-2 border-t border-[#E5EDF9] px-4 py-3 text-[12px]"><span>{t('Price per detailed digitization line')}: <strong>{format(selected.linePriceCents)} ct</strong></span><span>{t('Minimum billable lines per document')}: <strong>{format(selected.minimumLines)}</strong></span></div>}
      </section>}
    </div>
  </section>;
}
