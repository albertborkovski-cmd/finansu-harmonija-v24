import { useEffect, useState, type ReactNode } from 'react';
import { PencilLine, Plus, Save } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import {
  addContractTier, canManageContractPricing, contractDocumentPricing, contractPlanSaas, contractTierRange,
  CONTRACT_PRICING_CHANGED, CONTRACT_PRICING_KEY, discountedDocumentPrice, readContractPricing, removeContractTier,
  saveContractPricing, updateContractTier, type ContractPlan, type ContractPriceTier, type ContractPricingCatalog,
} from '../lib/contractPricing';
import { SAAS_MODULES, SAAS_OVERAGE, SAAS_PERIODS, SAAS_PRICING, SAAS_PRODUCTS } from '../lib/companySaas';
import GlJournalDialog from './GlJournalDialog';
import { PageActionButton } from './PageHeader';
import SearchableSelect from './SearchableSelect';
import MultiSelectField from './MultiSelectField';
import { RowDeleteButton } from './DeleteButtons';

const inputClass = 'h-[42px] w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3.5 font-montserrat text-[14px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] disabled:bg-[#F4F8FC] disabled:text-[#7288A3]';
const number = (value: string) => value.trim() ? Number(value.replace(',', '.')) : NaN;
const options = (items: readonly { value: string; label: string }[]) => items.map(item => ({ ...item, label: t(item.label) }));
const normalize = (plan: ContractPlan): ContractPlan => ({ ...structuredClone(plan), saas: contractPlanSaas(plan), documentPricing: contractDocumentPricing(plan) });
function Field({ label, children }: { label: string; children: ReactNode }) { return <div className="flex min-w-0 flex-col gap-2"><span className="text-[12px] font-medium text-[#7288A3]">{t(label)}</span>{children}</div>; }

function TierEditor({ tier, adding, onClose, onApply }: { tier: ContractPriceTier; adding: boolean; onClose: () => void; onApply: (patch: Pick<ContractPriceTier, 'to' | 'basePriceCents' | 'discountPercent'>) => void }) {
  const [to, setTo] = useState(tier.to === null ? '' : String(tier.to));
  const [price, setPrice] = useState(String(tier.basePriceCents)), [discount, setDiscount] = useState(String(tier.discountPercent)), [error, setError] = useState('');
  const unlimited = !adding && tier.to === null;
  const apply = () => { try { onApply({ to: unlimited ? null : number(to), basePriceCents: number(price), discountPercent: number(discount) }); } catch (reason) { setError(reason instanceof Error ? reason.message : 'The document pricing tiers are invalid.'); } };
  return <GlJournalDialog title={adding ? 'Add pricing tier' : 'Edit document pricing'} onClose={onClose} footer={<><PageActionButton onClick={onClose}>{t('Cancel')}</PageActionButton><PageActionButton onClick={apply}>{t('Apply')}</PageActionButton></>}>
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Documents from"><input aria-label={t('Documents from')} value={tier.from} readOnly className={`${inputClass} bg-[#F4F8FC]`} /></Field>
      <Field label="Documents to"><input aria-label={t('Documents to')} inputMode="numeric" value={unlimited ? t('Unlimited') : to} disabled={unlimited} onChange={event => setTo(event.target.value)} className={inputClass} /></Field>
      <Field label="Base document price (ct)"><input aria-label={t('Base document price (ct)')} inputMode="decimal" value={price} onChange={event => setPrice(event.target.value)} className={inputClass} /></Field>
      <Field label="Discount (%)"><input aria-label={t('Discount (%)')} inputMode="decimal" value={discount} onChange={event => setDiscount(event.target.value)} className={inputClass} /></Field>
      <p className="col-span-full text-[12px] leading-5 text-[#7288A3]">{t('The next range starts automatically after this one. Changes are applied when you save the plan.')}</p>
      {error && <p role="alert" className="col-span-full text-[12px] text-[#B42318]">{t(error)}</p>}
    </div>
  </GlJournalDialog>;
}

function PlanForm({ plan, revision, onSaved, onDirty }: { plan: ContractPlan; revision: number; onSaved: (catalog: ContractPricingCatalog) => void; onDirty: (dirty: boolean) => void }) {
  const language = useLanguage();
  const [draft, setDraft] = useState(() => normalize(plan));
  const [baseline, setBaseline] = useState(() => normalize(plan));
  const [baseRevision, setBaseRevision] = useState(revision);
  const [tierEditor, setTierEditor] = useState<{ tier: ContractPriceTier; adding: boolean } | null>(null), [deleteId, setDeleteId] = useState('');
  const [error, setError] = useState(''), [feedback, setFeedback] = useState('');
  const dirty = JSON.stringify(draft) !== JSON.stringify(baseline);
  useEffect(() => { onDirty(dirty); }, [dirty, onDirty]);
  const saas = contractPlanSaas(draft), progressive = saas.kainodara === 'docs' && contractDocumentPricing(draft) === 'progressive';
  const patch = (value: Partial<ContractPlan>) => { setDraft(current => ({ ...current, ...value })); setFeedback(''); setError(''); };
  const patchSaas = (value: Partial<typeof saas>) => patch({ saas: { ...saas, ...value } });
  const format = (value: number) => new Intl.NumberFormat(language, { maximumFractionDigits: 4 }).format(value);
  const reset = () => { const next = normalize(plan); setDraft(next); setBaseline(next); setBaseRevision(revision); setError(''); setFeedback(''); };
  const save = () => {
    try {
      const next = saveContractPricing(localStorage, baseRevision, { kind: 'details', planId: draft.id, name: draft.name, saas, documentPricing: contractDocumentPricing(draft), tiers: draft.tiers, linePriceCents: draft.linePriceCents, minimumLines: draft.minimumLines });
      const saved = normalize(next.plans.find(item => item.id === draft.id)!);
      setDraft(saved); setBaseline(saved); setBaseRevision(next.revision); setError(''); setFeedback('Pricing saved.');
      onSaved(next); window.dispatchEvent(new Event(CONTRACT_PRICING_CHANGED));
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Pricing could not be saved. Please try again.'); }
  };
  return <div className="flex min-w-0 flex-col gap-4">
    <section className="rounded-lg border border-[#D3E1EC] bg-white">
      <h3 className="rounded-t-lg border-b border-[#E5EDF9] bg-[#F4F8FC] px-5 py-3 text-[14px] font-semibold">{t('1. Plan settings')}</h3>
      <div className="grid gap-4 p-5 md:grid-cols-3">
        <div className="md:col-span-3"><Field label="Plan name"><input aria-label={t('Plan name')} value={draft.name} maxLength={120} onChange={event => patch({ name: event.target.value })} className={inputClass} /></Field></div>
        <Field label="Product"><SearchableSelect ariaLabel="SaaS product" value={saas.produktas} options={options(SAAS_PRODUCTS)} onChange={value => patchSaas({ produktas: value as typeof saas.produktas })} portalMenu /></Field>
        <Field label="Pricing model"><SearchableSelect ariaLabel="SaaS pricing model" value={saas.kainodara} options={options(SAAS_PRICING)} onChange={value => patchSaas({ kainodara: value as typeof saas.kainodara })} portalMenu /></Field>
        <Field label="Period"><SearchableSelect ariaLabel="SaaS period" value={saas.periodas} options={options(SAAS_PERIODS)} onChange={value => patchSaas({ periodas: value as typeof saas.periodas })} portalMenu /></Field>
      </div>
    </section>
    <section className="min-w-0 rounded-lg border border-[#D3E1EC] bg-white">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-t-lg border-b border-[#E5EDF9] bg-[#F4F8FC] px-5 py-3"><h3 className="text-[14px] font-semibold">{t('2. Pricing')}</h3>{progressive && <PageActionButton icon={<Plus size={15} />} onClick={() => setTierEditor({ tier: { ...draft.tiers[draft.tiers.length - 1], to: null }, adding: true })}>{t('Add pricing tier')}</PageActionButton>}</div>
      <div className="space-y-4 p-5">
        {saas.kainodara === 'docs' && <div className="max-w-[380px]"><Field label="Document pricing"><SearchableSelect ariaLabel="Document pricing" value={contractDocumentPricing(draft)} options={options([{ value: 'progressive', label: 'Progressive pricing tiers' }, { value: 'flat', label: 'Fixed price per document' }])} onChange={value => patch({ documentPricing: value as 'progressive' | 'flat' })} portalMenu /></Field></div>}
        {progressive ? <>
          <p className="text-[12px] leading-5 text-[#7288A3]">{t('Each price applies only to the documents within its range. Prices exclude VAT.')}</p>
          <div className="overflow-x-auto"><table className="w-full min-w-[640px] border-separate border-spacing-y-0.5 text-left text-[12px] leading-[18px]">
            <thead><tr className="text-[#7288A3]">{['Document count', 'Base document price (ct)', 'Discount (%)', 'Document price after discount'].map(label => <th key={label} className="border-b border-[#E5EDF9] px-3 py-3 font-medium">{t(label)}</th>)}<th className="system-table-row-actions w-[88px] border-b border-[#E5EDF9]"><span className="sr-only">{t('Actions')}</span></th></tr></thead>
            <tbody>{draft.tiers.map((tier, index) => <tr key={tier.id} className={`h-10 ${index % 2 ? 'bg-white' : 'bg-[#F8FDFF]'} hover:bg-[#E7F4F9]`}><td className="rounded-l-lg px-3">{contractTierRange(tier)}</td><td className="px-3 tabular-nums">{format(tier.basePriceCents)} ct</td><td className="px-3 tabular-nums">{format(tier.discountPercent)}%</td><td className="px-3 tabular-nums">{format(discountedDocumentPrice(tier))} ct</td><td className="system-table-row-actions rounded-r-lg px-3"><div className="flex justify-end gap-2"><button type="button" title={t('Edit')} aria-label={`${t('Edit pricing tier')}: ${contractTierRange(tier)}`} onClick={() => setTierEditor({ tier, adding: false })} className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><PencilLine size={14} /></button><RowDeleteButton label={`${t('Delete pricing tier')}: ${contractTierRange(tier)}`} disabled={draft.tiers.length === 1} onDelete={() => setDeleteId(tier.id)} /></div></td></tr>)}</tbody>
          </table></div>
        </> : <div className="max-w-[380px]"><Field label={saas.kainodara === 'docs' ? 'Price per document (EUR)' : saas.kainodara === 'users' ? 'Price per active user (EUR)' : 'Company fee per period (EUR)'}><input aria-label={t('SaaS price (EUR)')} inputMode="decimal" value={saas.kaina} onChange={event => patchSaas({ kaina: event.target.value.replace(',', '.') })} className={inputClass} /></Field><p className="mt-2 text-[12px] text-[#7288A3]">{t('Prices exclude VAT.')}</p></div>}
        {saas.produktas !== 'panel' && <div className="grid gap-4 border-t border-[#E5EDF9] pt-4 sm:grid-cols-2"><Field label="Detailed line price (ct)"><input aria-label={t('Detailed line price (ct)')} inputMode="decimal" value={Number.isFinite(draft.linePriceCents) ? draft.linePriceCents : ''} onChange={event => patch({ linePriceCents: number(event.target.value) })} className={inputClass} /></Field><Field label="Minimum billable lines per document"><input aria-label={t('Minimum billable lines per document')} inputMode="numeric" value={Number.isFinite(draft.minimumLines) ? draft.minimumLines : ''} onChange={event => patch({ minimumLines: number(event.target.value) })} className={inputClass} /></Field></div>}
      </div>
    </section>
    <details className="rounded-lg border border-[#D3E1EC] bg-white"><summary className="cursor-pointer rounded-lg bg-[#F4F8FC] px-5 py-3 text-[14px] font-semibold">{t('3. Limits & modules')}</summary><div className="grid gap-4 p-5 sm:grid-cols-2"><Field label="Document limit"><input aria-label={t('SaaS document limit')} inputMode="numeric" value={saas.kiekis} onChange={event => patchSaas({ kiekis: event.target.value })} className={inputClass} /></Field><Field label="When the limit is reached"><SearchableSelect ariaLabel="SaaS overage policy" value={saas.virsijimas} options={options(SAAS_OVERAGE)} onChange={value => patchSaas({ virsijimas: value as typeof saas.virsijimas })} portalMenu /></Field><div className="sm:col-span-2"><MultiSelectField label={t('Modules')} options={SAAS_MODULES.map(item => t(item.label))} value={SAAS_MODULES.filter(item => saas.moduliai.includes(item.value)).map(item => t(item.label))} onChange={values => patchSaas({ moduliai: SAAS_MODULES.filter(item => values.includes(t(item.label))).map(item => item.value) })} portalMenu /></div></div></details>
    <footer className="sticky bottom-0 z-20 flex flex-wrap items-center justify-between gap-3 border-t border-[#E5EDF9] bg-white py-4">
      <div className="max-w-[650px] text-[12px] leading-5 text-[#7288A3]"><p>{t('Changes apply to this plan. Previously confirmed contracts are not changed.')}</p>{error && <p role="alert" className="text-[#B42318]">{t(error)}</p>}{feedback && <p role="status" className="text-[#087A55]">{t(feedback)}</p>}</div>
      <div className="ml-auto flex gap-2"><PageActionButton disabled={!dirty && revision === baseRevision} onClick={reset}>{t('Reset changes')}</PageActionButton><PageActionButton disabled={!dirty} icon={<Save size={15} />} onClick={save}>{t('Save changes')}</PageActionButton></div>
    </footer>
    {tierEditor && <TierEditor tier={tierEditor.tier} adding={tierEditor.adding} onClose={() => setTierEditor(null)} onApply={value => { const tiers = tierEditor.adding ? addContractTier(draft.tiers, { ...value, to: Number(value.to) }) : updateContractTier(draft.tiers, tierEditor.tier.id, value); patch({ tiers }); setTierEditor(null); }} />}
    {deleteId && <GlJournalDialog title="Delete pricing tier" onClose={() => setDeleteId('')} footer={<><PageActionButton onClick={() => setDeleteId('')}>{t('Cancel')}</PageActionButton><PageActionButton onClick={() => { patch({ tiers: removeContractTier(draft.tiers, deleteId) }); setDeleteId(''); }}>{t('Delete')}</PageActionButton></>}><p className="text-[14px] leading-6">{t('The adjacent tier will cover this document range. Its price will apply after the plan is saved.')}</p></GlJournalDialog>}
  </div>;
}

export default function SaasPlansPricing({ selectedPlanId, onSelectPlan }: { selectedPlanId: string; onSelectPlan: (id: string) => void }) {
  const [catalog, setCatalog] = useState<ContractPricingCatalog | null>(null), [error, setError] = useState('');
  const [dirty, setDirty] = useState(false), [pendingPlan, setPendingPlan] = useState('');
  const [creating, setCreating] = useState(false), [name, setName] = useState(''), [createError, setCreateError] = useState('');
  useEffect(() => {
    const reload = (event?: Event) => { if (event instanceof StorageEvent && event.key && event.key !== CONTRACT_PRICING_KEY) return; try { setCatalog(readContractPricing(localStorage)); setError(''); } catch (reason) { setError(reason instanceof Error ? reason.message : 'Pricing could not be loaded. Saved data has not been changed.'); } };
    reload(); window.addEventListener(CONTRACT_PRICING_CHANGED, reload); window.addEventListener('storage', reload);
    return () => { window.removeEventListener(CONTRACT_PRICING_CHANGED, reload); window.removeEventListener('storage', reload); };
  }, []);
  const plan = catalog?.plans.find(item => item.id === selectedPlanId) || catalog?.plans[0];
  const changePlan = (id: string) => { if (dirty && id !== plan?.id) { setPendingPlan(id); return; } onSelectPlan(id); setDirty(false); };
  const create = () => {
    if (!plan || !catalog) return;
    try { const next = saveContractPricing(localStorage, catalog.revision, { kind: 'create', sourcePlanId: plan.id, name }); setCatalog(next); onSelectPlan(next.plans[next.plans.length - 1].id); setDirty(false); setCreating(false); window.dispatchEvent(new Event(CONTRACT_PRICING_CHANGED)); }
    catch (reason) { setCreateError(reason instanceof Error ? reason.message : 'Pricing could not be saved. Please try again.'); }
  };
  if (!canManageContractPricing(localStorage)) return <p role="alert">{t('Only an administrator can edit contract pricing.')}</p>;
  return <section className="flex min-w-0 flex-col gap-5">
    <div className="flex flex-wrap items-end justify-between gap-3"><div className="w-full max-w-[420px]"><Field label="Pricing plan"><SearchableSelect ariaLabel="Pricing plan" value={plan?.id || ''} options={(catalog?.plans || []).map(item => ({ value: item.id, label: t(item.name) }))} onChange={changePlan} portalMenu /></Field></div><PageActionButton disabled={!plan || dirty} icon={<Plus size={16} />} onClick={() => { setName(''); setCreateError(''); setCreating(true); }}>{t('New pricing plan')}</PageActionButton></div>
    {error && <p role="alert" className="text-[12px] text-[#B42318]">{t(error)}</p>}
    {plan && catalog && <PlanForm key={plan.id} plan={plan} revision={catalog.revision} onSaved={setCatalog} onDirty={setDirty} />}
    {pendingPlan && <GlJournalDialog title="Discard unsaved changes?" onClose={() => setPendingPlan('')} footer={<><PageActionButton onClick={() => setPendingPlan('')}>{t('Cancel')}</PageActionButton><PageActionButton onClick={() => { onSelectPlan(pendingPlan); setPendingPlan(''); setDirty(false); }}>{t('Discard changes')}</PageActionButton></>}><p className="text-[14px]">{t('Save this plan before switching, or discard its unsaved changes.')}</p></GlJournalDialog>}
    {creating && <GlJournalDialog title="New pricing plan" onClose={() => setCreating(false)} footer={<><PageActionButton onClick={() => setCreating(false)}>{t('Cancel')}</PageActionButton><PageActionButton onClick={create}>{t('Create new')}</PageActionButton></>}><Field label="Plan name"><input autoFocus aria-label={t('Plan name')} value={name} maxLength={120} onChange={event => setName(event.target.value)} className={inputClass} /></Field><p className="mt-3 text-[12px] leading-5 text-[#7288A3]">{t('The selected plan is copied. Edit its pricing without changing the original plan.')}</p>{createError && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{t(createError)}</p>}</GlJournalDialog>}
  </section>;
}
