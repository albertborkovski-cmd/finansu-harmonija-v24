import { translateUi as uiText } from '../../i18n/language';
import { createContext, useContext, useEffect, useId, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, ChevronUp, Eye, Loader2, Paperclip, X } from 'lucide-react';
import { createInvoiceDocument, updateInvoiceDocument, createInvoiceLineType, supabase, type Company, type DbDocument } from '../../lib/supabase';
import DocumentActionHistory from '../DocumentActionHistory';
import { accountingToday, type StornoDocument } from '../../lib/documentStorno';
import { canCreateCompanyDocument, documentActionRights } from '../../lib/documentRowActionAccess';
import { isInactiveRecord } from '../../lib/recordLifecycle';
import { loadLinkedDirectoryUsers, SETTINGS_DATA_CHANGED_EVENT } from '../../lib/linkedSettingsData';
import { documentResponsibleOptions } from '../../lib/documentResponsibleUsers';
import { loadCompanyAdvanceEmployees } from '../../lib/companyAdvanceEmployees';
import { advanceEmployeeName, selectInvoiceAdvanceEmployee } from '../../lib/invoiceAdvanceEmployee';
import { invoiceAmountDue, invoiceDueDate, invoiceTypeOptions, loadInvoiceCounterparties, newInvoiceDraft, updateInvoiceAccountingDefaults, invoiceCreditSources, invoiceCreditCounterparty, isCreditInvoiceKind, updateInvoiceClassification, type InvoiceCreditSource, type InvoiceAccountingDefaultKey, type InvoiceDraft, type InvoiceAttachment } from '../../lib/invoiceCreation';
import { initialInvoiceStatusOptions, documentStatusOptions } from '../../lib/documentProcessingStatus';
import { canEditCompanyDocuments, canViewCompanyDocuments } from '../../lib/documentEditAccess';
import { documentEditStateError, documentWasApproved, type InlineDocumentSource } from '../../lib/documentInlineEditing';
import { ApprovedDocumentEditWarning } from '../ApprovedDocumentEditWarning';
import { invoiceDocumentSnapshot, invoiceFormFromDocument, invoiceFormCounterparties, invoiceSourceAttachment, usesManualInvoiceForm, type InvoiceRecord } from '../../lib/invoiceDocumentForm';
import { invoiceCopyFromDocument } from '../../lib/invoiceCopy';
import { creditNoteSourceError, invoiceCreditNoteFromDocument } from '../../lib/invoiceCreditNote';
import { documentActionSnapshot } from '../../lib/documentRowActions';
import DocumentStornoAction from '../DocumentStornoAction';
import DocumentIssueDialog, { DocumentIssueBadge } from '../DocumentIssueDialog';
import { documentIssueStatus, hasBlockingDocumentIssue } from '../../lib/documentIssues';
import { loadCompanyGeneralLedgerAccountHierarchy } from '../GeneralLedgerView';
import { loadOrganizationReferenceRecords, loadOrganizationReferenceValues } from '../OrganizationReferenceValuesView';
import { loadVatClassifications } from '../VatClassificationsView';
import SearchableSelect, { type SearchableSelectOption } from '../SearchableSelect';
import { PageActionButton } from '../PageHeader';
import BackNavigationButton from '../BackNavigationButton';
import { SaveButton, CancelButton } from '../ScopedActionButtons';
import InvoiceLinesEditor from './InvoiceLinesEditor';
import { invoiceLineTypeOptions } from '../../lib/invoiceLineTypes';
import { loadInvoiceWarehouse } from '../../lib/invoiceLineExtras';
import { WAREHOUSE_CHANGED } from '../../lib/warehouseStore';
import type { WarehouseStore } from '../../lib/warehouse';
import InvoiceTotalsSummary from './InvoiceTotalsSummary';
import InvoiceAttachmentPreview from './InvoiceAttachmentPreview';

const control = 'h-9 w-full min-w-0 rounded-md border border-[#D3E1EC] bg-white px-3 text-[12px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10 disabled:bg-[#F2F5F9] disabled:text-[#7288A3]';
const ReadOnlyContext = createContext(false);

function Field({ label, required, children }: { label: string; required?: boolean; children: ReactNode }) {
  const readOnly = useContext(ReadOnlyContext);
  return <div className="flex min-w-0 flex-col gap-1.5 text-[11px] font-medium text-[#7288A3]"><span>{uiText(label)}{required && <span className="ml-1 text-[#DC2626]">*</span>}</span><fieldset disabled={readOnly} className="m-0 min-w-0 border-0 p-0">{children}</fieldset></div>;
}
function Select({ label, value, options, onChange, placeholder = 'Select', disabled = false }: { label: string; value: string; options: string[] | SearchableSelectOption[]; onChange: (value: string) => void; placeholder?: string; disabled?: boolean }) {
  const choices = options.map(option => typeof option === 'string' ? { value: option, label: option } : option);
  if (value && !choices.some(option => option.value === value)) choices.unshift({ value, label: value, disabled: true });
  return <SearchableSelect ariaLabel={uiText(label)} value={value} options={choices} onChange={onChange} placeholder={uiText(placeholder)} disabled={disabled} className={`${control} !pr-8`} portalMenu menuClassName="!z-[5200]" />;
}
function Section({ number, title, open, onToggle, summary, children }: { number: number; title: string; open: boolean; onToggle: () => void; summary?: string; children: ReactNode }) {
  const id = useId();
  return <section className="rounded-lg border border-[#D3E1EC] bg-white"><button type="button" aria-expanded={open} aria-controls={id} onClick={onToggle} className="flex w-full items-center gap-3 rounded-t-lg bg-[#F2F5F9] px-4 py-2.5 text-left text-[12px] font-semibold text-[#10233A]"><span className="whitespace-nowrap">{number}. {uiText(title)}</span>{!open && summary && <span className="truncate text-[11px] font-normal text-[#7288A3]">{summary}</span>}{open ? <ChevronUp size={15} className="ml-auto shrink-0 text-[#7288A3]" /> : <ChevronDown size={15} className="ml-auto shrink-0 text-[#7288A3]" />}</button><div id={id} hidden={!open} className="p-4">{children}</div></section>;
}
function Party({ company }: { company?: Company }) {
  return <dl className="mt-2 grid grid-cols-[100px_minmax(0,1fr)] gap-x-3 gap-y-1 rounded-md bg-[#F2F5F9] px-3 py-2 text-[11px] leading-5">
    {([['Company code', company?.company_code], ['VAT code', company?.vat_code], ['Address', company?.address], ['Country', company?.country || company?.tax_country]]).map(([label, value]) => <div key={label} className="contents"><dt className="text-[#7288A3]">{uiText(label)}</dt><dd className="m-0 break-words font-medium">{value || '—'}</dd></div>)}
  </dl>;
}
const format = (minor: number, currency: string) => `${((minor || 0) / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;
function readAttachment(file: File): Promise<InvoiceAttachment> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.onload = () => resolve({ name: file.name, type: file.type, size: file.size, url: String(reader.result) });
    reader.readAsDataURL(file);
  });
}

function loadInvoiceOptions(companyId: string, company: Company) {
  return {
    invoiceOptions: invoiceTypeOptions(loadOrganizationReferenceRecords('Document type')),
    unitOptions: loadOrganizationReferenceRecords('Unit').filter(row => row.status.toLowerCase() === 'active').map(row => ({ value: row.code, label: `${row.code} · ${row.fullName}` })),
    glOptions: loadCompanyGeneralLedgerAccountHierarchy(companyId, company.general_ledger).map(row => ({ value: row.code, label: `${row.code} · ${row.name}` })),
    vatOptions: loadVatClassifications().filter(row => row.active),
    users: documentResponsibleOptions(loadLinkedDirectoryUsers('Internal users')),
    advanceEmployees: loadCompanyAdvanceEmployees(company),
    currencies: [...new Set([company.base_currency || 'EUR', ...loadOrganizationReferenceValues('Base currency')].filter(code => /^[A-Z]{3}$/.test(code)))],
  };
}

type Props = { companyId: string; companyName: string; onClose: () => void; onCreated: () => void;
  onOpenRelatedDocument?: (document: DbDocument) => void;
  documentId?: string; copySourceDocumentId?: string; creditNoteSourceDocumentId?: string; mode?: 'create' | 'edit' | 'view'; sectionName?: string; documentActions?: ReactNode;
  documentManagementActions?: (state: { unsavedChanges: boolean; busy: boolean }) => ReactNode };

export default function CreateInvoiceForm({ companyId, companyName, onClose, onCreated, documentId, copySourceDocumentId, creditNoteSourceDocumentId, mode = 'create', sectionName = 'Invoices', documentActions, documentManagementActions, onOpenRelatedDocument }: Props) {
  const titleId = useId(), root = useRef<HTMLDivElement>(null), errorRef = useRef<HTMLParagraphElement>(null), fileInput = useRef<HTMLInputElement>(null);
  const [draft, setDraft] = useState(() => newInvoiceDraft(accountingToday(new Date())));
  const [record, setRecord] = useState<InvoiceRecord>();
  const [copySourceName, setCopySourceName] = useState('');
  const creditSourceSnapshot = useRef('');
  const [creditNoteReason, setCreditNoteReason] = useState('');
  const [showIssue, setShowIssue] = useState(false);
  const expectedSnapshot = useRef(''), originalForm = useRef('');
  const [company, setCompany] = useState<Company>();
  const [warehouse, setWarehouse] = useState<WarehouseStore | null>(null);
  const [counterparties, setCounterparties] = useState<Company[]>([]);
  const [documents, setDocuments] = useState<InvoiceCreditSource[]>([]);
  const [options, setOptions] = useState<ReturnType<typeof loadInvoiceOptions>>({ invoiceOptions: [], unitOptions: [], glOptions: [], vatOptions: [], users: [], advanceEmployees: [], currencies: ['EUR'] });
  const [lookups, setLookups] = useState<Array<{ type: string; value: string }>>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [attachments, setAttachments] = useState<InvoiceAttachment[]>([]);
  const [previewAttachment, setPreviewAttachment] = useState<InvoiceAttachment | null>(null);
  const [open, setOpen] = useState(new Set(['basic', 'parties', 'dates', 'defaults', 'lines', 'totals']));
  const requestId = useRef(crypto.randomUUID()), pending = useRef(false), initialized = useRef(false);
  const stateError = record ? documentEditStateError(record as InlineDocumentSource) : '';
  const readOnly = mode === 'view' || Boolean(documentId && (!canEditCompanyDocuments(company) || stateError));
  const hasChanges = initialized.current && originalForm.current !== JSON.stringify({ draft, attachments });
  const heading = documentId ? `${readOnly ? 'View' : 'Edit'} invoice ${String(record?.number || '')}` : creditNoteSourceDocumentId ? 'Create credit note' : 'Create new invoice';
  useEffect(() => { if (error) { errorRef.current?.scrollIntoView({ block: 'nearest' }); errorRef.current?.focus(); } }, [error]);
  useEffect(() => {
    let current = true;
    const previous = document.activeElement as HTMLElement | null;
    root.current?.focus();
    const refresh = async () => {
      try {
        const [companyResult, lookupResult, documentResult] = await Promise.all([supabase.from('companies').select('*').eq('id', companyId), supabase.from('lookup_values').select('*'), supabase.from('documents').select('*').eq('company_id', companyId)]);
        if (companyResult.error || lookupResult.error || documentResult.error) throw new Error('Could not load the company settings and documents.');
        const activeCompany = companyResult.data?.[0] as unknown as Company | undefined;
        if (!activeCompany || (documentId ? !canViewCompanyDocuments(activeCompany) : !canCreateCompanyDocument(activeCompany)) || isInactiveRecord(activeCompany)) throw new Error('You do not have access to this company’s documents.');
        const savedDocument = documentId ? documentResult.data?.find(row => row.id === documentId) : undefined;
        if (documentId && (!savedDocument || !usesManualInvoiceForm(savedDocument))) throw new Error('This manual invoice has moved or is no longer available.');
        const copySource = copySourceDocumentId ? documentResult.data?.find(row => row.id === copySourceDocumentId && row.company_id === companyId) : undefined;
        if (copySourceDocumentId && (documentId || !copySource)) throw new Error('The source document has moved or is no longer available.');
        const creditSource = creditNoteSourceDocumentId ? documentResult.data?.find(row => row.id === creditNoteSourceDocumentId) : undefined;
        if (creditNoteSourceDocumentId) {
          if (documentId || copySourceDocumentId) throw new Error('Open credit note creation as a new document.');
          const sourceError = creditNoteSourceError(creditSource, companyId, documentActionRights(activeCompany).create);
          if (sourceError) throw new Error(sourceError);
        }
        const parties = invoiceFormCounterparties(savedDocument || creditSource, loadInvoiceCounterparties(companyId)).filter(row => !isInactiveRecord(row));
        const currentOptions = loadInvoiceOptions(companyId, activeCompany);
        if (!current) return;
        setCompany(activeCompany); setWarehouse(loadInvoiceWarehouse(activeCompany)); setCounterparties(parties); setLookups((lookupResult.data ?? []) as unknown as Array<{ type: string; value: string }>); setOptions(currentOptions);
        setDocuments((documentResult.data ?? []) as unknown as InvoiceCreditSource[]);
        setRecord(savedDocument);
        setCopySourceName(String(copySource?.number || copySource?.file_case || ''));
        if (!initialized.current) {
          if (savedDocument) {
            const form = invoiceFormFromDocument(savedDocument, parties, activeCompany.base_currency || 'EUR');
            setDraft(form.draft); setAttachments(form.attachments);
            expectedSnapshot.current = invoiceDocumentSnapshot(savedDocument);
            originalForm.current = JSON.stringify(form);
          } else if (creditSource) {
            setDraft(invoiceCreditNoteFromDocument(creditSource, { companyId, baseCurrency: activeCompany.base_currency || 'EUR',
              today: accountingToday(), counterparties: parties, invoiceOptions: currentOptions.invoiceOptions, users: currentOptions.users,
              allowed: documentActionRights(activeCompany).create }));
            creditSourceSnapshot.current = documentActionSnapshot(creditSource as StornoDocument);
            setAttachments([]);
          } else if (copySource) {
            setDraft(invoiceCopyFromDocument(copySource, { companyId, baseCurrency: activeCompany.base_currency || 'EUR',
              today: accountingToday(), counterparties: parties, invoiceOptions: currentOptions.invoiceOptions, users: currentOptions.users }));
            setAttachments([]);
          } else setDraft(value => ({ ...value, currency: activeCompany.base_currency || 'EUR', kind: currentOptions.invoiceOptions.some(option => option.value === value.kind) ? value.kind : currentOptions.invoiceOptions[0]?.value || '' }));
          initialized.current = true;
        } else if (!documentId) {
          setDraft(value => currentOptions.invoiceOptions.some(option => option.value === value.kind) ? value : { ...value, kind: '', creditSourceDocumentId: '' });
        }
      } catch (cause) { if (current) { setCompany(undefined); setError(cause instanceof Error ? cause.message : 'Could not load invoice settings.'); } }
      finally { if (current) setLoading(false); }
    };
    void refresh();
    const onDataChanged = (event: Event) => { if (['documents', 'companies'].includes((event as CustomEvent).detail?.table)) void refresh(); };
    window.addEventListener('finansu-harmonija:data-changed', onDataChanged);
    window.addEventListener(WAREHOUSE_CHANGED, refresh);
    window.addEventListener('counterparties-updated', refresh); window.addEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh); window.addEventListener('organization-reference-updated', refresh); window.addEventListener('storage', refresh);
    return () => { current = false; previous?.focus(); window.removeEventListener('finansu-harmonija:data-changed', onDataChanged); window.removeEventListener(WAREHOUSE_CHANGED, refresh); window.removeEventListener('counterparties-updated', refresh); window.removeEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh); window.removeEventListener('organization-reference-updated', refresh); window.removeEventListener('storage', refresh); };
  }, [companyId, documentId, copySourceDocumentId, creditNoteSourceDocumentId]);
  const { invoiceOptions, unitOptions, glOptions, vatOptions, users, currencies } = options;
  const invoiceLabel = invoiceOptions.find(option => option.value === draft.kind)?.label || '—';
  const creditDocuments = useMemo(() => invoiceCreditSources(documents, companyId, draft.purpose), [documents, companyId, draft.purpose]);
  const creditDocument = (documentId || creditNoteSourceDocumentId ? documents : creditDocuments).find(row => row.id === draft.creditSourceDocumentId);
  const creditOptions = documentId && creditDocument && !creditDocuments.some(row => row.id === creditDocument.id)
    ? [creditDocument, ...creditDocuments] : creditDocuments;
  const selectCreditDocument = (id: string) => {
    const source = creditDocuments.find(row => row.id === id);
    const party = source && invoiceCreditCounterparty(source, counterparties);
    setDraft(previous => ({ ...previous, creditSourceDocumentId: id, ...(party ? { counterpartyId: party.id } : {}) }));
  };
  const references = (type: string) => [{ value: '', label: '—' }, ...lookups.filter(row => row.type === `${type}::company::${companyId}`).map(row => ({ value: row.value, label: row.value }))];
  const lineTypeOptions = invoiceLineTypeOptions(companyId, lookups);
  const activeStatuses = documentId ? documentStatusOptions() : initialInvoiceStatusOptions();
  const statusOptions = activeStatuses.some(option => option.value === draft.status) ? activeStatuses : [{ value: draft.status, label: draft.status, disabled: true }, ...activeStatuses];
  const addLineType = async (name: string) => {
    const saved = await createInvoiceLineType(companyId, name);
    setLookups(previous => previous.some(row => row.type === saved.type && row.value === saved.value) ? previous : [...previous, saved]);
    return saved.value;
  };
  const series = useMemo(() => {
    let configured: string[] = [];
    try { const values = JSON.parse(company?.document_series || '{}'); configured = (Array.isArray(values.items) ? values.items : []).map((item: { code: string }) => item.code); }
    catch { configured = (company?.document_series || '').split(',').map(value => value.trim()); }
    return [...new Set([...configured, ...lookups.filter(row => row.type === `series::company::${companyId}`).map(row => row.value)].filter(Boolean))];
  }, [company?.document_series, lookups, companyId]);
  const selectedParty = counterparties.find(row => row.id === draft.counterpartyId);
  const sourceAttachment = invoiceSourceAttachment(record);
  const savedUserOptions = (value: string, savedName: unknown, savedId: unknown): SearchableSelectOption[] => {
    if (savedName && value === String(savedId || '') && (!value || !users.some(user => user.value === value))) {
      return [{ value, label: String(savedName), disabled: true }, ...users.filter(user => user.value !== value)];
    }
    return users;
  };
  const responsibleChoices = savedUserOptions(draft.responsibleId, record?.accountable_responsible, record?.accountable_responsible_id);
  const managerChoices = savedUserOptions(draft.customerManagerId || '', record?.invoice_customer_manager, record?.invoice_customer_manager_id);
  const baseCurrency = company?.base_currency || 'EUR', amountDue = invoiceAmountDue(draft);
  const additionalSummary = [
    `Accountable / Responsible person ${responsibleChoices.find(row => row.value === draft.responsibleId)?.label || '—'}`,
    ...(draft.purpose === 'Sale' ? [`Customer manager ${managerChoices.find(row => row.value === (draft.customerManagerId || ''))?.label || '—'}`, `Invoice language ${draft.language}`] : []),
  ].join(' · ');
  const update = <K extends keyof InvoiceDraft>(key: K, value: InvoiceDraft[K]) => setDraft(previous => ({ ...previous, [key]: value }));
  const updateDefault = <K extends InvoiceAccountingDefaultKey>(key: K, value: InvoiceDraft[K]) =>
    setDraft(previous => updateInvoiceAccountingDefaults(previous, { [key]: value }, vatOptions));
  const toggle = (name: string) => setOpen(previous => { const next = new Set(previous); if (next.has(name)) next.delete(name); else next.add(name); return next; });
  const onFiles = async (files: FileList | null) => {
    if (!files || pending.current) return;
    pending.current = true; setBusy(true); setError('');
    try {
      const added = Array.from(files);
      if (attachments.length + added.length > 10 || added.some(file => !['application/pdf', 'image/png', 'image/jpeg'].includes(file.type) || !file.size || file.size > 10 * 1024 * 1024)) throw new Error('Choose up to 10 PDF, PNG or JPG files, each up to 10 MB.');
      const uploaded = await Promise.all(added.map(readAttachment));
      setAttachments(previous => [...previous, ...uploaded]);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to attach files.'); }
    finally { pending.current = false; setBusy(false); if (fileInput.current) fileInput.current.value = ''; }
  };
  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    if (readOnly || pending.current || loading || !company) return;
    pending.current = true; setBusy(true); setError('');
    try {
      const command = { requestId: requestId.current, draft, attachments, ...(copySourceDocumentId ? { copySourceDocumentId } : {}),
        ...(creditNoteSourceDocumentId ? { creditNoteSource: { documentId: creditNoteSourceDocumentId, expectedSnapshot: creditSourceSnapshot.current, reason: creditNoteReason } } : {}) };
      if (documentId) await updateInvoiceDocument(documentId, companyId, command, expectedSnapshot.current);
      else await createInvoiceDocument(companyId, command);
      onCreated(); onClose();
    }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'The invoice could not be saved.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return createPortal(<ReadOnlyContext.Provider value={readOnly}><div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} data-document-form="manual-invoice" data-form-mode={readOnly ? 'view' : mode} className="fixed inset-0 z-[5000] flex flex-col bg-[#F8FAFC] font-montserrat text-[#10233A] outline-none" onKeyDown={event => {
    if (event.key === 'Escape' && !busy) { event.stopPropagation(); if ((event.target as Element).closest('[role="combobox"], [role="listbox"]') || document.querySelector('[role="combobox"][aria-expanded="true"]')) return; onClose(); }
    if (event.key === 'Tab') { const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),textarea:not(:disabled),[tabindex="0"]')].filter(node => node.getClientRects().length); const first = controls[0], last = controls.at(-1); if (event.shiftKey && (document.activeElement === first || document.activeElement === root.current)) { event.preventDefault(); last?.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); } }
  }}>
    <header className="flex shrink-0 flex-wrap items-center justify-between gap-4 border-b border-[#D3E1EC] bg-white px-6 py-3"><div className="min-w-0"><div className="flex items-center gap-4"><BackNavigationButton label={uiText("Back")} disabled={busy} onClick={onClose} /><h1 id={titleId} className="text-[22px] font-semibold">{uiText(heading)}</h1></div><p className="mt-2 text-[11px] text-[#7288A3]">{uiText("Companies / ")}{companyName} / {sectionName} / {uiText(heading)}</p></div><div className="flex flex-wrap items-center gap-3">
      {documentActions}
      {record && documentManagementActions?.({ unsavedChanges: !readOnly && hasChanges, busy: busy || loading })}
      {record && documentId && <><DocumentStornoAction documentId={documentId} companyId={companyId} status={String(record.status || '')} unsavedChanges={!readOnly && hasChanges} /><PageActionButton onClick={() => setShowIssue(true)}>{uiText("Report issue")}</PageActionButton><DocumentIssueBadge status={documentIssueStatus(record)} /></>}
      <div className="w-[190px] shrink-0"><Field label={uiText("Status")}><SearchableSelect localizeOptions="status" ariaLabel={uiText("Invoice status")} value={draft.status} options={statusOptions} onChange={value => update('status', value)} disabled={readOnly || busy || loading || !company} className={`${control} !pr-8`} portalMenu menuClassName="!z-[5200]" /></Field></div></div></header>
    <form noValidate onSubmit={event => void save(event)} className="flex min-h-0 flex-1 flex-col">
      <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4 sm:px-6">
        {loading && <p role="status" className="flex items-center gap-2 text-[12px]"><Loader2 size={15} className="animate-spin" />{uiText("Loading company settings…")}</p>}
        {error && <p ref={errorRef} tabIndex={-1} role="alert" className="rounded-lg bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{error}</p>}
        {record && hasBlockingDocumentIssue(record) && <p role="status" className="rounded-lg border border-[#EEB648] bg-[#FFF4DC] px-4 py-2 text-[12px] text-[#926317]">{uiText("Reported issue · Approval and transfer to accounting are blocked until correction, OCR reprocessing and validation are completed.")}</p>}
        {documentId && mode === 'edit' && stateError && <p role="status" className="text-[12px] text-[#7288A3]">{stateError}</p>}
        {record && !readOnly && documentWasApproved(record) && <ApprovedDocumentEditWarning />}
        {copySourceName && <p className="text-[12px] text-[#7288A3]">{uiText("Copy of ")}{copySourceName}{uiText(" · New invoice")}</p>}
        <fieldset disabled={busy || loading || !company} className="m-0 min-w-0 space-y-3 border-0 p-0">
          <Section number={1} title={uiText("Basic information")} open={open.has('basic')} onToggle={() => toggle('basic')} summary={`${draft.purpose} · ${invoiceLabel} · ${draft.number || 'New invoice'}`}>
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-6">
              <Field label={uiText("Document purpose")} required><div role="group" aria-label={uiText("Document purpose")} className="flex h-9 rounded-md border border-[#D3E1EC] bg-[#F2F5F9] p-0.5">{(['Purchase', 'Sale'] as const).map(value => <button type="button" key={value} aria-label={value} disabled={Boolean(creditNoteSourceDocumentId)} data-static-selection="true" aria-pressed={draft.purpose === value} onClick={() => setDraft(previous => updateInvoiceClassification(previous, { purpose: value }))} className={`flex-1 rounded text-[12px] font-semibold ${draft.purpose === value ? 'bg-[#007EA7] text-white' : 'text-[#7288A3] hover:text-[#007EA7]'}`}>{value}</button>)}</div></Field>
              <Field label={uiText("Invoice")} required><Select label={uiText("Invoice")} value={draft.kind} options={invoiceOptions} disabled={Boolean(creditNoteSourceDocumentId || (draft.purpose === 'Purchase' && draft.advanceEmployeeId))} placeholder={uiText("Select invoice type")} onChange={value => setDraft(previous => updateInvoiceClassification(previous, { kind: value }))} /></Field>
              <Field label={uiText("Series")}><Select label={uiText("Series")} value={draft.series} options={[{ value: '', label: '—' }, ...series.map(value => ({ value, label: value }))]} onChange={value => update('series', value)} /></Field>
              <Field label={uiText("Invoice No.")} required><input aria-label={uiText("Invoice No.")} className={control} value={draft.number} onChange={event => update('number', event.target.value)} required maxLength={100} /></Field>
              <Field label={uiText("Order No.")}><input aria-label={uiText("Order No.")} className={control} value={draft.orderNo} onChange={event => update('orderNo', event.target.value)} /></Field>
              <Field label={uiText("Currency")} required><Select label={uiText("Currency")} value={draft.currency} options={currencies} onChange={value => setDraft(previous => ({ ...previous, currency: value, exchangeRate: value === baseCurrency ? '1' : '' }))} /></Field>
            </div>
            {draft.purpose === 'Purchase' && !creditNoteSourceDocumentId && !draft.creditSourceDocumentId && <div className="mt-4 grid grid-cols-1 gap-2 lg:grid-cols-3">
              <Field label={uiText('Advance employee')}><Select label={uiText('Advance employee')} value={draft.advanceEmployeeId || ''}
                options={[{ value: '', label: '—' }, ...options.advanceEmployees.map(user => ({ value: user.id, label: advanceEmployeeName(user), description: user.email }))]}
                onChange={value => setDraft(previous => selectInvoiceAdvanceEmployee(previous, value))} /></Field>
              {draft.advanceEmployeeId && <p className="self-end text-[11px] leading-5 text-[#7288A3] lg:col-span-2">{uiText('Advance invoice is selected automatically. GL transfers are created on reconciliation only when the accounts differ.')}</p>}
            </div>}
            {isCreditInvoiceKind(draft.kind) && <div className="mt-4 grid grid-cols-1 gap-2 lg:grid-cols-2">
              <Field label={creditNoteSourceDocumentId ? uiText('Original invoice') : uiText('Document to reconcile')}><SearchableSelect ariaLabel={creditNoteSourceDocumentId ? uiText('Original invoice') : uiText('Document to reconcile')} value={draft.creditSourceDocumentId || ''}
                options={[{ value: '', label: '—' }, ...creditOptions.map(row => ({ value: row.id, label: row.number || row.id,
                  description: [row.client_counterparty, row.document_date, row.total_amount && `${row.total_amount} ${row.currency || ''}`].filter(Boolean).join(' · ') }))]}
                onChange={selectCreditDocument} placeholder={`Select ${draft.purpose === 'Sale' ? 'sales' : 'purchase'} document`}
                className={`${control} !pr-8`} portalMenu menuClassName="!z-[5200]" disabled={Boolean(documentId || creditNoteSourceDocumentId) || busy || loading || !company} /></Field>
              <div className="flex min-w-0 items-end pb-1 text-[11px] leading-5 text-[#7288A3]">
                {draft.creditSourceDocumentId && !creditDocument ? <span role="alert" className="text-[#B42318]">{documentId ? uiText('The original document is no longer available. Its audit link is retained.') : uiText('The selected document is no longer available. Select another document.')}</span>
                  : creditDocument ? <span>{[creditDocument.client_counterparty, creditDocument.document_date, `${creditDocument.total_amount} ${creditDocument.currency || ''}`].filter(Boolean).join(' · ')}</span>
                    : <span>{creditDocuments.length ? `${creditDocuments.length} ${draft.purpose === 'Sale' ? 'sales' : 'purchase'} documents available for ${companyName}.` : `No ${draft.purpose === 'Sale' ? 'sales' : 'purchase'} documents available for ${companyName}.`}</span>}
              </div>
            </div>}
            {creditNoteSourceDocumentId && <div className="mt-4"><Field label={uiText("Credit note reason")} required><textarea aria-label={uiText("Credit note reason")} className={`${control} h-auto min-h-[72px] py-2`} rows={2} maxLength={2000} value={creditNoteReason} onChange={event => setCreditNoteReason(event.target.value)} required /></Field></div>}
            {draft.currency !== baseCurrency && <div className="mt-4 max-w-xs"><Field label={`Exchange rate · 1 ${draft.currency} in ${baseCurrency}`} required><input aria-label={uiText("Exchange rate")} className={control} inputMode="decimal" value={draft.exchangeRate} onChange={event => update('exchangeRate', event.target.value)} required /></Field></div>}
          </Section>
          <Section number={2} title={uiText("Seller / Buyer information")} open={open.has('parties')} onToggle={() => toggle('parties')} summary={selectedParty?.name}>
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">{[true, false].map(seller => {
              const external = seller ? draft.purpose === 'Purchase' : draft.purpose === 'Sale';
              return <div key={String(seller)}><Field label={seller ? external ? uiText('Seller (Supplier)') : uiText('Seller (Our company)') : external ? uiText('Buyer (Customer)') : uiText('Buyer (Our company)')} required={external}>{external ? <Select label={uiText("Counterparty")} value={draft.counterpartyId} options={counterparties.map(row => ({ value: row.id, label: row.name, description: row.company_code }))} onChange={value => update('counterpartyId', value)} placeholder={uiText("Select counterparty")} /> : <input aria-label={seller ? uiText('Seller company') : uiText('Buyer company')} className={control} disabled value={company?.name || companyName} />}</Field><Party company={external ? selectedParty : company} />{external && !counterparties.length && <p className="mt-2 text-[11px] text-[#7288A3]">{uiText("Add a counterparty in Companies / ")}{companyName}{uiText(" / Counterparties.")}</p>}</div>;
            })}</div>
          </Section>
          <Section number={3} title={uiText("Dates")} open={open.has('dates')} onToggle={() => toggle('dates')} summary={`${draft.invoiceDate} · Due ${draft.dueDate}`}><div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <Field label={uiText("Invoice date")} required><input aria-label={uiText("Invoice date")} className={control} type="date" value={draft.invoiceDate} onChange={event => setDraft(previous => ({ ...previous, invoiceDate: event.target.value, operationDate: previous.operationDate === previous.invoiceDate ? event.target.value : previous.operationDate, dueDate: previous.paymentTerms === 'custom' ? previous.dueDate : invoiceDueDate(event.target.value, previous.paymentTerms) }))} required /></Field>
            <Field label={uiText("Operation date")} required><input aria-label={uiText("Operation date")} className={control} type="date" value={draft.operationDate} onChange={event => update('operationDate', event.target.value)} required /></Field>
            <Field label={uiText("Payment terms")}><Select label={uiText("Payment terms")} value={draft.paymentTerms} options={[{ value: '0', label: 'Due on receipt' }, ...['7', '14', '30', '60', '90'].map(value => ({ value, label: `${value} days` })), { value: 'custom', label: 'Custom' }]} onChange={value => setDraft(previous => ({ ...previous, paymentTerms: value, dueDate: value === 'custom' ? previous.dueDate : invoiceDueDate(previous.invoiceDate, value) }))} /></Field>
            <Field label={uiText("Due date")} required><input aria-label={uiText("Due date")} className={control} type="date" value={draft.dueDate} onChange={event => setDraft(previous => ({ ...previous, dueDate: event.target.value, paymentTerms: 'custom' }))} required /></Field>
          </div></Section>
          <Section number={4} title={uiText("Accounting defaults")} open={open.has('defaults')} onToggle={() => toggle('defaults')} summary={`VAT classifier ${draft.vatClassifier || '—'} · Department ${draft.department || '—'} · Cost center ${draft.costCenter || '—'} · Include VAT in debt ${draft.includeVatInDebt ? 'Yes' : 'No'}`}><div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Field label={uiText("VAT classifier")}><Select label={uiText("Default VAT classifier")} value={draft.vatClassifier} options={[{ value: '', label: '—' }, ...vatOptions.map(row => ({ value: row.code, label: `${row.code} · ${row.rate}%` }))]} onChange={value => updateDefault('vatClassifier', value)} /></Field>
            <Field label={uiText("Department")}><Select label={uiText("Department")} value={draft.department} options={references('department_code')} onChange={value => updateDefault('department', value)} /></Field>
            <Field label={uiText("Cost center")}><Select label={uiText("Cost center")} value={draft.costCenter} options={references('cost_center')} onChange={value => updateDefault('costCenter', value)} /></Field>
            <Field label={uiText("Include VAT in debt")}><Select label={uiText("Include VAT in debt")} value={String(draft.includeVatInDebt)} options={[{ value: 'true', label: 'Yes' }, { value: 'false', label: 'No' }]} onChange={value => updateDefault('includeVatInDebt', value === 'true')} /></Field>
          </div></Section>
          <Section number={5} title={uiText("Invoice lines")} open={open.has('lines')} onToggle={() => toggle('lines')} summary={`${draft.lines.length} lines`}>
            <InvoiceLinesEditor readOnly={readOnly} draft={draft} setDraft={setDraft} glOptions={glOptions} vatOptions={vatOptions} unitOptions={unitOptions} referenceOptions={references} seriesOptions={series} responsibleOptions={users} lineTypeOptions={lineTypeOptions} onCreateLineType={addLineType} companyId={companyId} baseCurrency={baseCurrency} warehouse={warehouse} />
            {draft.allocations && <div className="mt-5"><InvoiceLinesEditor allocation readOnly={readOnly} draft={draft} setDraft={setDraft} glOptions={glOptions} vatOptions={vatOptions} unitOptions={unitOptions} referenceOptions={references} seriesOptions={series} responsibleOptions={users} lineTypeOptions={lineTypeOptions} onCreateLineType={addLineType} companyId={companyId} baseCurrency={baseCurrency} warehouse={warehouse} /></div>}
          </Section>
          <Section number={6} title={uiText("Document totals")} open={open.has('totals')} onToggle={() => toggle('totals')} summary={format(amountDue, draft.currency)}>
            <InvoiceTotalsSummary draft={draft} baseCurrency={baseCurrency} />
          </Section>
          <Section number={7} title={uiText("Additional information")} open={open.has('additional')} onToggle={() => toggle('additional')} summary={additionalSummary}>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Field label={uiText("Accountable / Responsible person")}><Select label={uiText("Accountable / Responsible person")} value={draft.responsibleId} options={responsibleChoices} onChange={value => update('responsibleId', value)} /></Field>
              {draft.purpose === 'Sale' && <>
                <Field label={uiText("Customer manager")}><Select label={uiText("Customer manager")} value={draft.customerManagerId || ''} options={managerChoices} onChange={value => update('customerManagerId', value)} /></Field>
                <Field label={uiText("Invoice language")}><Select label={uiText("Invoice language")} value={draft.language} options={['EN', 'LT']} onChange={value => update('language', value)} /></Field>
              </>}
            </div>
          </Section>
          <Section number={8} title={uiText("Attachments and notes")} open={open.has('attachments')} onToggle={() => toggle('attachments')} summary={`${attachments.length + (sourceAttachment ? 1 : 0)} files · ${draft.notes ? 'Notes added' : 'No notes'}`}>
            <div className="grid gap-4 md:grid-cols-2"><div>
              <input ref={fileInput} type="file" multiple accept=".pdf,.png,.jpg,.jpeg" className="hidden" onChange={event => void onFiles(event.target.files)} />
              {!readOnly && <PageActionButton onClick={() => fileInput.current?.click()} icon={<Paperclip size={14} />}>{uiText("Upload attachment")}</PageActionButton>}
              <p className="my-2 text-[11px] text-[#7288A3]">{uiText("PDF, PNG, JPG · up to 10 MB per file")}</p>
              {sourceAttachment && <button type="button" onClick={() => setPreviewAttachment(sourceAttachment)} className="mb-2 flex w-full items-center gap-2 rounded-md border border-[#E5EDF9] px-3 py-2 text-left text-[12px] text-[#007EA7] hover:bg-[#F0F7FA]"><Eye size={14} className="shrink-0" /><span className="truncate">{sourceAttachment.name}</span><span className="ml-auto shrink-0 text-[10px] text-[#7288A3]">{uiText("Original document")}</span></button>}
              <ul aria-label={uiText("Invoice attachments")} className="space-y-2">{attachments.map((file, index) => <li key={`${file.name}-${index}`} className="flex items-center justify-between gap-3 rounded-md border border-[#E5EDF9] px-3 py-2 text-[12px]">
                <button type="button" onClick={() => setPreviewAttachment(file)} className="min-w-0 truncate text-left font-medium text-[#007EA7] hover:underline" title={file.name}>{file.name}</button>
                <div className="flex shrink-0 items-center gap-2"><button type="button" aria-label={`Preview attachment ${file.name}`} onClick={() => setPreviewAttachment(file)} className="flex h-7 w-7 items-center justify-center rounded-md border border-[#D3E1EC] text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><Eye size={14} /></button>{!readOnly && <button type="button" aria-label={`Remove attachment ${file.name}`} onClick={() => setAttachments(previous => previous.filter((_, i) => i !== index))} className="flex h-7 w-7 items-center justify-center rounded-md border border-[#D3E1EC] text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><X size={14} /></button>}</div>
              </li>)}</ul>
            </div><Field label={uiText("Notes")}><textarea aria-label={uiText("Notes")} className={`${control} !h-24 resize-y py-2`} maxLength={10000} value={draft.notes} onChange={event => update('notes', event.target.value)} /></Field></div>
          </Section>
        </fieldset>
        {documentId && <DocumentActionHistory documentId={documentId} companyId={companyId} onOpenRelatedDocument={onOpenRelatedDocument} unsavedChanges={!readOnly && hasChanges} busy={busy} />}
      </div>
      <footer className="flex shrink-0 justify-end gap-3 border-t border-[#D3E1EC] bg-white px-6 py-3"><CancelButton onClick={() => { if (!busy) onClose(); }}>{readOnly ? uiText('Close') : uiText('Cancel')}</CancelButton>{!readOnly && <SaveButton type="submit" disabled={busy || loading || !company || Boolean(documentId && !hasChanges)}>{busy ? uiText('Saving…') : documentId ? uiText('Save changes') : draft.status === 'Draft' ? uiText('Save draft') : uiText('Save invoice')}</SaveButton>}</footer>
    </form>
    {previewAttachment && <InvoiceAttachmentPreview file={previewAttachment} onClose={() => setPreviewAttachment(null)} />}
    {showIssue && documentId && <DocumentIssueDialog documentId={documentId} companyId={companyId} onClose={() => setShowIssue(false)} />}
  </div></ReadOnlyContext.Provider>, document.body);
}
