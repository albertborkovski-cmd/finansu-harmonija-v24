import { translateUi as uiText } from '../../i18n/language';
import { invoiceTotalsPresentation, type InvoiceDraft } from '../../lib/invoiceCreation';

const format = (minor: number, currency: string) => `${(minor / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;

export default function InvoiceTotalsSummary({ draft, baseCurrency }: { draft: InvoiceDraft; baseCurrency: string }) {
  const totals = invoiceTotalsPresentation(draft, baseCurrency);
  return <div className={`grid items-start gap-4 ${totals.accounting ? 'md:grid-cols-2' : ''}`}>
    <dl aria-label={uiText("Invoice totals")} className="m-0 space-y-2 rounded-lg border border-[#E5EDF9] p-3 text-[12px]">
      {totals.rows.map(row => <div key={row.label} className="flex justify-between gap-4"><dt className="text-[#7288A3]">{row.label}</dt><dd className="m-0 tabular-nums">{format(row.amount, draft.currency)}</dd></div>)}
      <div className="flex justify-between gap-4 rounded-md bg-[#E5EDF9] px-3 py-2 text-[14px] font-semibold"><dt>{uiText("Amount due")}</dt><dd className="m-0 tabular-nums">{format(totals.amountDue, draft.currency)}</dd></div>
    </dl>
    {totals.accounting && <dl aria-label={uiText("Accounting currency total")} className="m-0 rounded-lg bg-[#F2F5F9] p-4 text-[12px]"><dt className="mb-2 text-[#7288A3]">{uiText("Total in accounting currency (")}{totals.accounting.currency})</dt><dd className="m-0 text-[16px] font-semibold tabular-nums">{totals.accounting.total === null ? '—' : format(totals.accounting.total, totals.accounting.currency)}</dd></dl>}
  </div>;
}
