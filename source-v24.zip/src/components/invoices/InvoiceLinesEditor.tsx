import { translateUi as uiText } from '../../i18n/language';
import { useId, useMemo, useRef, useState, type Dispatch, type SetStateAction } from 'react';
import { Columns2, Plus, Scissors, Trash2, X } from 'lucide-react';
import SearchableSelect, { type SearchableSelectOption } from '../SearchableSelect';
import HorizontalTableScrollbar from '../HorizontalTableScrollbar';
import ColumnSettingsPanel, { type ColConfig } from '../ColumnSettingsPanel';
import { PageActionButton } from '../PageHeader';
import { appendInvoiceLine, invoiceAllocationError, invoiceLineAmounts, invoiceLinePricing, invoiceLineIncludesVatInDebt, invoiceLineVatClassifier, isCreditInvoiceKind, splitInvoiceLines, updateInvoiceLine, type InvoiceDraft, type InvoiceLineDraft } from '../../lib/invoiceCreation';
import { documentLineRowClass, documentLineHeaderClass, documentLineInputClass, documentQuantityColumns } from '../documentLineDesign';
import InvoiceLineTypeSelect from './InvoiceLineTypeSelect';
import { invoiceAccountingCurrency, invoiceLineStock, invoiceLineUsesWarehouse, invoiceWarehouseColumnAvailable, invoiceWarehouseSnapshot } from '../../lib/invoiceLineExtras';
import type { WarehouseStore } from '../../lib/warehouse';

type Props = {
  readOnly?: boolean;
  allocation?: boolean;
  draft: InvoiceDraft;
  setDraft: Dispatch<SetStateAction<InvoiceDraft>>;
  glOptions: SearchableSelectOption[];
  vatOptions: Array<{ code: string; rate: string }>;
  unitOptions: SearchableSelectOption[];
  referenceOptions: (type: string) => SearchableSelectOption[];
  seriesOptions: string[];
  responsibleOptions: SearchableSelectOption[];
  lineTypeOptions: SearchableSelectOption[];
  onCreateLineType: (name: string) => Promise<string>;
  companyId: string;
  baseCurrency: string;
  warehouse: WarehouseStore | null;
};
const inputClass = `${documentLineInputClass} w-full`;
const iconClass = 'flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:bg-[#F0F7FA] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40';
const invoiceKeys: Record<string, string> = { qty: 'quantity', subtotal: 'net', vat: 'vatAmount', vatPct: 'vatRate', product: 'name', discount: 'discountAmount', object: 'project', center: 'costCenter', expense: 'glAccount', vatClass: 'vatClassifier' };
const optionalPricingColumns: ColConfig[] = [
  { key: 'unitPriceInclVat', label: 'Unit price incl. VAT', width: 155, visible: false },
  { key: 'discount', label: 'Discount %', width: 100, visible: false },
  { key: 'discountAmount', label: 'Discount amount', width: 140, visible: false },
  { key: 'discountedUnitPrice', label: 'Discounted unit price', width: 165, visible: false },
  { key: 'amountAfterDiscountExclVat', label: 'Amount after discount excl. VAT', width: 230, visible: false },
];
const invoiceQuantityColumns = documentQuantityColumns.filter(column => column.key !== 'product');
const defaults = (): ColConfig[] => {
  const optional: ColConfig[] = [
    ...[
      ['lineNo', 'Line No.', 85], ['itemCode', 'Item / Service code', 160], ['unit', 'Unit of measure', 130],
      ['barcode', 'Barcode', 140], ['productGroup', 'Product group', 150],
    ].map(([key, label, width]) => ({ key: String(key), label: String(label), width: Number(width), visible: false, group: 'Items / Services' })),
    ...optionalPricingColumns.map(column => ({ ...column, group: 'Prices / Discounts' })),
    ...[
      ['lineNote', 'Line note / Comment', 220], ['analyticalSeries', 'Analytical series', 160],
      ['mainAnalyticalAccount', 'Main analytical account', 200], ['responsibleId', 'Employee / Responsible person', 250],
      ['costCenter', 'Center', 130], ['relatedContract', 'Related contract', 190],
    ].map(([key, label, width]) => ({ key: String(key), label: String(label), width: Number(width), visible: false, group: 'Accounting / Analytics' })),
    ...[
      ['accountingAmount', 'Amount in accounting currency', 230], ['accountingUnitPrice', 'Unit price in accounting currency', 240],
    ].map(([key, label, width]) => ({ key: String(key), label: String(label), width: Number(width), visible: false, group: 'Currency' })),
    ...[
      ['warehouseId', 'Warehouse', 180], ['stockQuantity', 'Stock quantity', 130], ['costPrice', 'Cost price', 140],
      ['costAmount', 'Cost amount', 150], ['profit', 'Profit', 140],
    ].map(([key, label, width]) => ({ key: String(key), label: String(label), width: Number(width), visible: false, group: 'Warehouse / Cost' })),
  ];
  const optionalKeys = new Set(optional.map(column => column.key));
  const base = invoiceQuantityColumns.filter(column => !['discount', 'systemId', 'code'].includes(column.key) && !optionalKeys.has(invoiceKeys[column.key] || column.key));
  return [{ key: 'systemId', label: 'System ID', width: 110, visible: true },
    { key: 'type', label: 'Type', width: 170, visible: true },
    { key: 'name', label: 'Code / Name', width: 190, visible: true },
    { key: 'description', label: 'Description', width: 170, visible: true },
    ...base.flatMap(column => [
      { key: invoiceKeys[column.key] || column.key, label: column.label, width: column.w, visible: true },
      ...(column.key === 'vatPct' ? [{ key: 'includeVatInDebt', label: 'Include VAT in debt', width: 150, visible: true }] : []),
    ]),
    ...optional];
};
const decimal = (cents: number) => (cents / 100).toFixed(2);
const precisePrice = (value: number) => value.toLocaleString('en-GB', { useGrouping: false, minimumFractionDigits: 2, maximumFractionDigits: 4 });

function LineSelect({ label, value, options, onChange }: { label: string; value: string; options: SearchableSelectOption[] | string[]; onChange: (value: string) => void }) {
  const choices = options.map(option => typeof option === 'string' ? { value: option, label: option } : option);
  if (value && !choices.some(option => option.value === value)) choices.unshift({ value, label: value, disabled: true });
  return <SearchableSelect ariaLabel={uiText(label)} value={value} options={choices} onChange={onChange} placeholder={uiText("—")} className={`${inputClass} !pr-7`} portalMenu menuClassName="!z-[5200]" />;
}

export default function InvoiceLinesEditor({ draft, setDraft, glOptions, vatOptions, unitOptions, referenceOptions, seriesOptions, responsibleOptions, lineTypeOptions, onCreateLineType, companyId, baseCurrency, warehouse, readOnly = false, allocation = false }: Props) {
  const [columns, setColumns] = useState(defaults);
  const [showColumns, setShowColumns] = useState(false), [showSplit, setShowSplit] = useState(false);
  const [splitMode, setSplitMode] = useState<'equal' | 'percent' | 'amount'>('equal');
  const [splitValues, setSplitValues] = useState<Record<string, string>>({}), [splitError, setSplitError] = useState('');
  const table = useRef<HTMLDivElement>(null), splitTable = useRef<HTMLDivElement>(null), id = useId();
  const rows = allocation ? draft.allocations || draft.lines : draft.lines;
  const stock = useMemo(() => invoiceWarehouseSnapshot(warehouse, companyId, draft.operationDate, baseCurrency), [warehouse, companyId, draft.operationDate, baseCurrency]);
  const availableColumns = columns.filter(column => invoiceWarehouseColumnAvailable(column.key, stock, rows));
  const visible = availableColumns.filter(column => column.visible);
  const requiredKeys = new Set(invoiceQuantityColumns.filter(column => column.required).map(column => invoiceKeys[column.key] || column.key));
  requiredKeys.delete('discountAmount');
  requiredKeys.add('type');
  requiredKeys.add('name');
  const sign = isCreditInvoiceKind(draft.kind) ? -1 : 1;
  const allocationError = invoiceAllocationError(draft);
  const updateRows = (updater: (rows: InvoiceLineDraft[]) => InvoiceLineDraft[]) => {
    if (readOnly) return;
    setDraft(current => ({ ...current, [allocation ? 'allocations' : 'lines']: updater(allocation ? current.allocations || current.lines : current.lines) }));
  };
  const change = (lineId: string, patch: Partial<InvoiceLineDraft>) => updateRows(current => current.map(line => line.id === lineId ? updateInvoiceLine(line, patch) : line));
  const addLine = () => {
    const lineId = crypto.randomUUID();
    if (readOnly) return;
    setDraft(current => appendInvoiceLine(current, allocation ? 'summary' : 'quantity', vatOptions, lineId));
    setShowSplit(false);
  };
  const startSplit = (nextMode: typeof splitMode = splitMode) => {
    const total = draft.lines.reduce((sum, row) => sum + invoiceLineAmounts(row).net, 0);
    const values: Record<string, string> = {};
    let remainder = nextMode === 'percent' ? 10000 : total;
    rows.forEach((row, index) => { const amount = index === rows.length - 1 ? remainder : Math.floor((nextMode === 'percent' ? 10000 : total) / rows.length); remainder -= amount; values[row.id] = decimal(amount); });
    setSplitMode(nextMode); setSplitValues(values); setSplitError(''); setShowSplit(true);
  };
  const applySplit = () => {
    try { const result = splitInvoiceLines(draft.lines, rows, splitMode, splitValues, { allowUnpricedTargets: true }); updateRows(() => result); setShowSplit(false); setSplitError(''); }
    catch (cause) { setSplitError(cause instanceof Error ? cause.message : 'Could not split lines.'); }
  };
  const cell = (line: InvoiceLineDraft, key: string, index: number) => {
    const label = `Invoice line ${index + 1} ${columns.find(column => column.key === key)?.label || key}`;
    const amounts = invoiceLineAmounts(line);
    const pricing = invoiceLinePricing(line);
    const output = (value: string, title?: string) => <output aria-label={uiText(label)} title={uiText(title)} className={`${inputClass} block !bg-[#F7F7F7] !text-[#828588] tabular-nums`}>{value}</output>;
    if (key === 'lineNo') return output(String(index + 1));
    if (key === 'accountingAmount' || key === 'accountingUnitPrice') {
      const converted = invoiceAccountingCurrency(line, draft, baseCurrency);
      return output(converted ? `${key === 'accountingAmount' ? decimal(converted.amount) : precisePrice(converted.unitPrice)} ${baseCurrency}` : '—', key === 'accountingAmount' ? 'Line amount after discount, excluding VAT, converted at the document exchange rate' : 'Unit price before discount, excluding VAT, converted at the document exchange rate');
    }
    if (['stockQuantity', 'costPrice', 'costAmount', 'profit'].includes(key)) {
      const values = invoiceLineStock(line, draft, stock, baseCurrency);
      const value = values?.[key as 'stockQuantity' | 'costPrice' | 'costAmount' | 'profit'];
      return output(value == null ? '—' : key === 'stockQuantity' ? String(value) : `${key === 'costPrice' ? precisePrice(value) : decimal(value)} ${baseCurrency}`, `Warehouse data at ${draft.operationDate}. Match an Item / Service code and select a Warehouse. Profit applies to sales.`);
    }
    if (key === 'net' || key === 'total') return <output aria-label={uiText(label)} className={`${inputClass} block !bg-[#F7F7F7] !text-[#828588] tabular-nums`}>{decimal(sign * amounts[key])}{key === 'total' ? ` ${draft.currency}` : ''}</output>;
    if (key === 'unitPriceInclVat' || key === 'discountedUnitPrice' || key === 'amountAfterDiscountExclVat') return <output aria-label={uiText(label)} title={key === 'unitPriceInclVat' ? uiText('Unit price before discount, including VAT at the line VAT rate') : key === 'discountedUnitPrice' ? uiText('Unit price after discount, excluding VAT') : uiText('Line amount after discount, excluding VAT')} className={`${inputClass} block !bg-[#F7F7F7] !text-[#828588] tabular-nums`}>{pricing ? key === 'amountAfterDiscountExclVat' ? decimal(sign * amounts.net) : precisePrice(pricing[key]) : '—'}</output>;
    if (key === 'systemId') return <output aria-label={uiText(label)} title={line.id} className={`${inputClass} block truncate !bg-[#F7F7F7] !text-[#828588]`}>{line.id.includes(':') ? line.id : '—'}</output>;
    const select = (value: string, options: SearchableSelectOption[] | string[], onChange: (value: string) => void) => <LineSelect label={uiText(label)} value={value} options={options} onChange={onChange} />;
    if (key === 'warehouseId') return invoiceLineUsesWarehouse(line, stock) ? select(line.warehouseId || '', [{ value: '', label: '—' }, ...stock.locations.map(row => ({ value: row.id, label: `${row.code} · ${row.name}` }))], value => change(line.id, { warehouseId: value })) : output('—', 'Warehouse applies only to stocked product lines');
    if (key === 'itemCode') return <input aria-label={uiText(label)} type="text" className={inputClass} value={line.itemCode || ''} maxLength={100} onChange={event => change(line.id, { itemCode: event.target.value })} />;
    if (key === 'type') return <InvoiceLineTypeSelect label={uiText(label)} value={line.type} options={lineTypeOptions} onChange={value => change(line.id, { type: value, catalogId: '', ...(value !== 'Product' ? { warehouseId: '' } : {}) })} onCreate={onCreateLineType} />;
    if (key === 'name') return <input aria-label={uiText(label)} type="text" className={inputClass} value={line.name} placeholder={uiText("Enter code or name")} onChange={event => change(line.id, { name: event.target.value, catalogId: '' })} />;
    if (key === 'includeVatInDebt') return <div className="flex h-[26px] items-center px-2"><input type="checkbox" aria-label={uiText(label)} checked={invoiceLineIncludesVatInDebt(line, draft.includeVatInDebt)} onChange={event => change(line.id, { includeVatInDebt: event.target.checked })} /></div>;
    if (key === 'glAccount') return select(line.glAccount || draft.glAccount, [{ value: '', label: '—' }, ...glOptions.map(option => ({ ...option, label: option.value, description: option.label }))], value => change(line.id, { glAccount: value }));
    if (key === 'mainAnalyticalAccount') return select(line.mainAnalyticalAccount || '', [{ value: '', label: '—' }, ...glOptions], value => change(line.id, { mainAnalyticalAccount: value }));
    if (key === 'responsibleId') return select(line.responsibleId ?? draft.responsibleId, responsibleOptions, value => change(line.id, { responsibleId: value }));
    if (key === 'lineNote' || key === 'analyticalSeries' || key === 'relatedContract') return <input aria-label={uiText(label)} type="text" className={inputClass} value={line[key] || ''} maxLength={key === 'lineNote' ? 2000 : key === 'analyticalSeries' ? 100 : 200} onChange={event => change(line.id, { [key]: event.target.value })} />;
    if (key === 'vatClassifier') return select(invoiceLineVatClassifier(line, draft.vatClassifier), [{ value: '', label: '—' }, ...vatOptions.map(option => ({ value: option.code, label: option.code, description: `${option.rate}%` }))], value => { const vat = vatOptions.find(option => option.code === value); change(line.id, { vatClassifier: value, ...(vat ? { vatRate: vat.rate.replace('%', '').trim() } : {}) }); });
    if (key === 'unit') return select(line.unit, unitOptions.map(option => ({ ...option, label: option.value, description: option.label })), value => change(line.id, { unit: value }));
    if (key === 'series') return select(line.series ?? draft.series, [{ value: '', label: '—' }, ...seriesOptions.map(value => ({ value, label: value }))], value => change(line.id, { series: value }));
    const lookup: Record<string, string> = { productGroup: 'product_group', department: 'department_code', project: 'object_project', costCenter: 'cost_center' };
    if (lookup[key]) {
      const field = key as 'productGroup' | 'department' | 'project' | 'costCenter';
      const value = line[field] ?? (field === 'productGroup' ? '' : draft[field]);
      return select(value, referenceOptions(lookup[key]), value => change(line.id, { [key]: value }));
    }
    if (key === 'vatRate' || key === 'discount') return <div className={`${inputClass} flex items-center gap-1 focus-within:border-[#007EA7]`}><input aria-label={uiText(label)} inputMode="decimal" className="min-w-0 flex-1 bg-transparent outline-none" value={key === 'vatRate' ? line.vatRate : line.discountAmount === undefined ? line.discount : pricing ? precisePrice(pricing.discountPercent) : ''} onChange={event => change(line.id, { [key]: event.target.value })} /><span aria-hidden="true">%</span></div>;
    const value = key === 'discountAmount' ? line.discountAmount ?? decimal(amounts.discount) : key === 'vatAmount' ? line.vatAmount ?? decimal(amounts.vat) : String(line[key as keyof InvoiceLineDraft] ?? '');
    return <input aria-label={uiText(label)} className={inputClass} value={value} inputMode={['quantity', 'price', 'discountAmount', 'vatAmount'].includes(key) ? 'decimal' : 'text'} onChange={event => change(line.id, { [key]: event.target.value })} />;
  };

  return <div className="flex min-w-0 flex-col gap-2" onKeyDown={event => {
    if (event.key !== 'Escape' || (event.target as Element).closest('[role="combobox"], [role="listbox"]')) return;
    if (showColumns) { event.stopPropagation(); setShowColumns(false); }
    else if (showSplit) { event.stopPropagation(); setShowSplit(false); }
  }}>
    <div className="flex flex-wrap items-center gap-3">
      {!readOnly && <><button type="button" title={uiText("Split")} aria-label={uiText("Split")} disabled={!rows.length} className={iconClass} onClick={() => startSplit()}><Scissors size={14} strokeWidth={1.8} /></button>
      <button type="button" title={uiText("Add line")} aria-label={uiText("Add line")} disabled={rows.length >= 500} className={iconClass} onClick={addLine}><Plus size={14} strokeWidth={1.8} /></button></>}
      <button type="button" title={uiText("Column settings")} aria-label={uiText("Column settings")} className={`${iconClass} ml-auto`} onClick={() => setShowColumns(true)}><Columns2 size={14} strokeWidth={1.8} /></button>
    </div>
    <div className="border-b border-[#D3E1EC] pb-2 text-[12px] font-semibold text-[#10233A]">{allocation ? uiText('Accounting allocations') : uiText('Document lines')}</div>
    <fieldset disabled={readOnly} className={`m-0 min-w-0 border-0 p-0 ${readOnly ? '[&_input]:bg-[#F7F7F7] [&_input]:text-[#7288A3]' : ''}`}>
    <div ref={table} className="max-h-[360px] w-full min-w-0 overflow-auto scrollbar-hide">
      <div role="table" aria-label={uiText("Invoice lines")} data-document-lines-appearance="edit" className="min-w-full font-montserrat text-[12px]" style={{ width: visible.reduce((sum, column) => sum + column.width + 2, 36) }}>
        <div role="row" className={`${documentLineHeaderClass} sticky top-0 z-10 bg-white`}>
          {visible.map(column => <div role="columnheader" key={column.key} className="shrink-0 px-2 text-left text-[12px] font-medium leading-[18px] text-[#7288A3]" style={{ width: column.width }}>{uiText(column.label)}{requiredKeys.has(column.key) && <span className="ml-0.5 text-[#D64545]">*</span>}</div>)}
          <div role="columnheader" aria-label={uiText("Actions")} className="system-table-row-actions w-6" />
        </div>
        <div role="rowgroup">{rows.map((line, index) => <div role="row" key={line.id} className={`${documentLineRowClass} ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'}`}>
          {visible.map(column => <div role="cell" key={column.key} className="shrink-0" style={{ width: column.width }}>{cell(line, column.key, index)}</div>)}
          <div role="cell" className="system-table-row-actions flex w-6 items-center">{!readOnly && <button type="button" title={uiText("Remove line")} aria-label={`Remove invoice line ${index + 1}`} disabled={rows.length === 1} onClick={() => { updateRows(current => current.filter(item => item.id !== line.id)); setShowSplit(false); }} className="flex h-[26px] w-6 shrink-0 items-center justify-center px-1 disabled:cursor-not-allowed"><Trash2 size={14} className={rows.length === 1 ? 'text-[#D3E1EC]' : 'text-[#FF6200] opacity-60 transition-opacity hover:opacity-100'} /></button>}</div>
        </div>)}</div>
      </div>
    </div>
    </fieldset>
    <HorizontalTableScrollbar scrollRef={table} fixed={false} expandable={false} />
    {allocationError && <p role="status" className="text-[11px] text-[#B45309]">{allocationError}</p>}
    {showSplit && <section aria-labelledby={`${id}-split`} className="overflow-hidden rounded-lg border border-[#D3E1EC] bg-white">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-[#D3E1EC] bg-[#F2F5F9] px-4 py-3">
        <h3 id={`${id}-split`} className="flex items-center gap-2 text-[12px] font-semibold text-[#10233A]"><Scissors size={14} className="text-[#7288A3]" />{uiText("Split")}<span className="rounded border border-[#D3E1EC] bg-white px-2 py-0.5 text-[11px] font-medium text-[#7288A3]">{rows.length}{uiText(" lines")}</span></h3>
        <span className="text-[12px] font-semibold tabular-nums text-[#007EA7]">{decimal(draft.lines.reduce((sum, row) => sum + invoiceLineAmounts(row).net, 0))} {draft.currency}</span>
        <div role="group" aria-label={uiText("Split method")} className="ml-auto flex gap-0.5 rounded-md border border-[#D3E1EC] bg-white p-0.5">{(['equal', 'percent', 'amount'] as const).map(value => <button type="button" key={value} aria-pressed={splitMode === value} data-static-selection="true" onClick={() => startSplit(value)} className={`h-7 min-w-[72px] rounded px-3 text-[11px] font-semibold transition-colors ${splitMode === value ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#7288A3] hover:bg-[#F2F5F9] hover:text-[#10233A]'}`}>{value === 'equal' ? uiText('Equal') : value === 'percent' ? uiText('By %') : uiText('By amount')}</button>)}</div>
        <button type="button" className={iconClass} aria-label={uiText("Close split")} onClick={() => setShowSplit(false)}><X size={14} /></button>
      </div>
      <div className="px-4 pt-2">
        <div ref={splitTable} className="!max-h-[280px] overflow-auto">
          <div role="table" aria-label={uiText("Split allocations")} className="w-full min-w-[480px] text-[12px]">
            <div role="row" className="sticky top-0 z-10 grid grid-cols-[64px_minmax(0,1fr)_192px] border-b border-[#D3E1EC] bg-white text-left text-[11px] font-medium text-[#7288A3]">
              <div role="columnheader" className="px-2 py-2">{uiText("Line")}</div>
              <div role="columnheader" className="px-2 py-2">{uiText("Code / Name")}</div>
              <div role="columnheader" className="px-2 py-2">{splitMode === 'percent' ? uiText('Allocation (%)') : `Amount excl. VAT (${draft.currency})`}</div>
            </div>
            <div role="rowgroup">{rows.map((row, index) => <div role="row" key={row.id} className="grid grid-cols-[64px_minmax(0,1fr)_192px] items-center border-b border-[#EDF1F5] last:border-b-0 hover:bg-[#F8FDFF]">
              <div role="cell" className="px-2 py-2 tabular-nums text-[#7288A3]">{index + 1}</div>
              <div role="cell" className="min-w-0 px-2 py-2 text-[#10233A]"><span className="block truncate" title={row.name || row.description || undefined}>{row.name || row.description || '—'}</span></div>
              <div role="cell" className="px-2 py-2"><input aria-label={`Split line ${index + 1}`} className={`${inputClass} !h-8 tabular-nums disabled:bg-[#F7F7F7] disabled:text-[#7288A3]`} inputMode="decimal" disabled={splitMode === 'equal'} value={splitValues[row.id] ?? ''} onChange={event => setSplitValues(current => ({ ...current, [row.id]: event.target.value }))} /></div>
            </div>)}</div>
          </div>
        </div>
        <HorizontalTableScrollbar scrollRef={splitTable} fixed={false} expandable={false} />
      </div>
      {splitError && <p role="alert" className="px-4 pb-3 text-[12px] text-[#B42318]">{splitError}</p>}
      <div className="flex justify-end gap-2 border-t border-[#D3E1EC] px-4 py-3"><PageActionButton onClick={() => setShowSplit(false)}>{uiText("Cancel")}</PageActionButton><PageActionButton onClick={applySplit}>{uiText("Apply")}</PageActionButton></div>
    </section>}
    {showColumns && <div className="fixed inset-0 z-[5300]"><button type="button" aria-label={uiText("Close column settings")} className="absolute inset-0 bg-[#10233A]/20" onClick={() => setShowColumns(false)} /><ColumnSettingsPanel columns={availableColumns} defaultColumns={defaults().filter(column => invoiceWarehouseColumnAvailable(column.key, stock, rows))} onSave={value => setColumns(current => [...value, ...current.filter(column => !invoiceWarehouseColumnAvailable(column.key, stock, rows))])} onClose={() => setShowColumns(false)} /></div>}
  </div>;
}
