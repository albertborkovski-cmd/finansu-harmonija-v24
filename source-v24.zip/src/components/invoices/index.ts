export { default } from './InvoicesView';
