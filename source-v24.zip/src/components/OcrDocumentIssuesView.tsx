import { translateUi as uiText } from '../i18n/language';
import DocumentIssueQueue from './DocumentIssueQueue';
import OcrBreadcrumb from './OcrBreadcrumb';
import { PageHeader } from './PageHeader';
import { useState } from 'react';

export default function OcrDocumentIssuesView({ initialTarget }: { initialTarget?: { documentId: string; issueId?: string } }) {
  const [editing, setEditing] = useState(false);
  return (
    <div className={editing ? 'min-h-full min-w-0 bg-white' : 'flex min-h-full min-w-0 flex-col gap-3 bg-white px-4 py-14 sm:px-8 lg:px-[72px]'}>
      {!editing && <>
      <PageHeader title={uiText("Document issues")} />
      <OcrBreadcrumb items={['Workspace', 'Document issues']} />
      </>}
      <DocumentIssueQueue initialTarget={initialTarget} onEditingChange={setEditing} />
    </div>
  );
}
