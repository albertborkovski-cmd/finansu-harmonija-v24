import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, ChevronUp, ExternalLink, Eye, Landmark, Loader2, Paperclip, Pencil, Plus, Trash2 } from 'lucide-react';
import { createBankTransaction, saveBankTransaction, supabase, type Company, type DbDocument } from '../lib/supabase';
import { bankAllocationTotals, bankReconciliation, bankReconciliationKey, bankTransactionFromDocument, bankTransactionSnapshot, companyBankAccounts, type BankAllocation, type BankTransaction } from '../lib/bankTransaction';
import { canEditCompanyBankEntries } from '../lib/companyBankEditing';
import { documentEditStateError } from '../lib/documentInlineEditing';
import { loadInvoiceCounterparties, type InvoiceAttachment } from '../lib/invoiceCreation';
import { SETTINGS_DATA_CHANGED_EVENT } from '../lib/linkedSettingsData';
import { invoiceSourceAttachment } from '../lib/invoiceDocumentForm';
import SearchableSelect, { type SearchableSelectOption } from './SearchableSelect';
import { loadCompanyGeneralLedgerAccountHierarchy } from './GeneralLedgerView';
import BackNavigationButton from './BackNavigationButton';
import { SaveButton, CancelButton } from './ScopedActionButtons';
import { PageActionButton } from './PageHeader';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import InvoiceAttachmentPreview from './invoices/InvoiceAttachmentPreview';
import DocumentActionHistory from './DocumentActionHistory';
import { bankProcessingStatus, bankProcessingStatusEditError } from '../lib/bankProcessingStatus';
import { readBankMatchingDemo, type BankMatchingDemo } from '../lib/bankMatchingDemo';
import { companyBankAccountLabel } from '../lib/companyBankAccountDisplay';
import BankMatchingDataDialog from './BankMatchingDataDialog';
import { canCreateCompanyBankTransaction } from '../lib/bankTransactionCreation';
import { loadOrganizationReferenceValues } from './OrganizationReferenceValuesView';

const control = 'h-9 w-full min-w-0 rounded-md border border-[#D3E1EC] bg-white px-3 text-[12px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10 disabled:bg-[#F2F5F9] disabled:text-[#7288A3]';
const rowAction = 'flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:text-[#B4B6B8]';
const descriptions = ['Received payment (customer debt)', 'Supplier payment', 'Bank fee / commission', 'Advance payment', 'Cash deposit', 'Cash withdrawal', 'Other transaction'];
const format = (minor: number, currency: string) => Number.isFinite(minor) ? `${(minor / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}` : '—';
function Field({ label, required, children, className = '' }: { label: string; required?: boolean; children: ReactNode; className?: string }) {
  return <div className={`min-w-0 space-y-1.5 ${className}`}><div className="text-[11px] font-medium text-[#7288A3]">{uiText(label)}{required && <span className="ml-1 text-[#DC2626]">*</span>}</div>{children}</div>;
}
function Section({ number, title, open, onToggle, summary, children }: { number: number; title: string; open: boolean; onToggle: () => void; summary?: string; children: ReactNode }) {
  const id = useId();
  return <section className="min-w-0 rounded-lg border border-[#D3E1EC] bg-white"><button type="button" aria-expanded={open} aria-controls={id} onClick={onToggle} className="flex w-full items-center gap-3 rounded-t-lg bg-[#F2F5F9] px-4 py-2.5 text-left text-[12px] font-semibold text-[#10233A]"><span className="shrink-0">{number}. {uiText(title)}</span>{!open && <span className="hidden truncate text-[11px] font-normal text-[#7288A3] sm:block">{summary}</span>}{open ? <ChevronUp size={15} className="ml-auto shrink-0 text-[#7288A3]" /> : <ChevronDown size={15} className="ml-auto shrink-0 text-[#7288A3]" />}</button><div id={id} hidden={!open} className="min-w-0 p-4">{children}</div></section>;
}
function Select({ label, value, options, onChange, disabled = false }: { label: string; value: string; options: SearchableSelectOption[] | string[]; onChange: (value: string) => void; disabled?: boolean }) {
  const choices = options.map(option => typeof option === 'string' ? { value: option, label: option } : option);
  if (value && !choices.some(option => option.value === value)) choices.unshift({ value, label: value, disabled: true });
  return <SearchableSelect ariaLabel={uiText(label)} value={value} options={choices} onChange={onChange} disabled={disabled} className={`${control} !pr-8`} portalMenu menuClassName="!z-[5200]" />;
}
type Props = { document: DbDocument; company: Company; mode?: 'create' | 'edit'; onClose: () => void; onSaved: (document: DbDocument) => void; onOpenReconciliation?: () => void };
export default function BankTransactionEditor({ document: record, company, mode = 'edit', onClose, onSaved, onOpenReconciliation }: Props) {
  const isCreate = mode === 'create';
  const titleId = useId(), root = useRef<HTMLDivElement>(null), table = useRef<HTMLDivElement>(null), fileInput = useRef<HTMLInputElement>(null), pending = useRef(false), errorRef = useRef<HTMLParagraphElement>(null);
  const escapeFromDropdown = useRef(false);
  const matchingResults = useRef<HTMLElement>(null);
  const [draft, setDraft] = useState(() => bankTransactionFromDocument(record, company));
  const baseline = useRef(JSON.stringify(draft)), expected = useRef(bankTransactionSnapshot(record));
  const [open, setOpen] = useState(new Set([1, 2]));
  const [parties, setParties] = useState<Company[]>([]), [lookups, setLookups] = useState<{ type: string; value: string }[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState(''), [discard, setDiscard] = useState(false);
  const [access, setAccess] = useState(() => isCreate ? canCreateCompanyBankTransaction(company) : canEditCompanyBankEntries(company));
  const [reconciliation, setReconciliation] = useState(() => bankReconciliation(record.id, company.id, localStorage.getItem(bankReconciliationKey(company.id))));
  const [preview, setPreview] = useState<InvoiceAttachment>();
  const [matchingOpen, setMatchingOpen] = useState(false);
  const [matchingDemo, setMatchingDemo] = useState(() => readBankMatchingDemo(company.id, record.id));
  const [matchingSaved, setMatchingSaved] = useState(false);
  const stateError = documentEditStateError(record as unknown as Parameters<typeof documentEditStateError>[0]);
  const readOnly = !access || Boolean(stateError), disabled = readOnly || busy || loading;
  const dirty = baseline.current !== JSON.stringify(draft);
  const accounts = useMemo(() => companyBankAccounts(company), [company]);
  const currencies = useMemo(() => [...new Set([company.base_currency || 'EUR', ...loadOrganizationReferenceValues('Base currency')])], [company.base_currency]);
  const glOptions = useMemo(() => loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger).map(row => ({ value: row.code, label: `${row.code} · ${row.name}` })), [company.id, company.general_ledger]);
  const matchingDisabled = isCreate || busy || loading || Boolean(bankProcessingStatusEditError(record, access));
  const totals = bankAllocationTotals(draft);
  const originalFile = invoiceSourceAttachment(record as unknown as Parameters<typeof invoiceSourceAttachment>[0]);
  const sourceAttachment = originalFile ? [originalFile] : [];
  const files = [...sourceAttachment, ...draft.attachments];
  useEffect(() => {
    let current = true;
    const previous = window.document.activeElement as HTMLElement | null;
    const rememberDropdown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') escapeFromDropdown.current = Boolean(root.current?.querySelector('[role="combobox"][aria-expanded="true"]'));
    };
    window.addEventListener('keydown', rememberDropdown, true);
    root.current?.focus();
    const refresh = () => {
      if (!current) return;
      setAccess(isCreate ? canCreateCompanyBankTransaction(company) : canEditCompanyBankEntries(company));
      try { setReconciliation(bankReconciliation(record.id, company.id, localStorage.getItem(bankReconciliationKey(company.id)))); }
      catch { setError('Reconciliation data could not be loaded.'); }
    };
    Promise.all([supabase.from('lookup_values').select('*'), Promise.resolve().then(() => loadInvoiceCounterparties(company.id))]).then(([result, counterparties]) => {
      if (!current) return;
      if (result.error) throw new Error(result.error.message);
      setLookups((result.data || []) as unknown as { type: string; value: string }[]);
      setParties(counterparties.filter(row => !(row as unknown as Record<string, unknown>).inactive && (row as unknown as Record<string, unknown>).active !== false));
    }).catch(cause => { if (current) setError(cause instanceof Error ? cause.message : 'Could not load company settings.'); }).finally(() => { if (current) setLoading(false); });
    window.addEventListener('storage', refresh); window.addEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh);
    return () => { current = false; previous?.focus(); window.removeEventListener('keydown', rememberDropdown, true); window.removeEventListener('storage', refresh); window.removeEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh); };
  }, [company, record.id, isCreate]);
  useEffect(() => { if (error) { errorRef.current?.scrollIntoView({ block: 'nearest' }); errorRef.current?.focus(); } }, [error]);
  useEffect(() => { if (matchingSaved) matchingResults.current?.scrollIntoView({ block: 'nearest' }); }, [matchingSaved, matchingDemo?.revision]);
  const update = <K extends keyof BankTransaction>(key: K, value: BankTransaction[K]) => setDraft(previous => ({ ...previous, [key]: value }));
  const updateLine = (id: string, patch: Partial<BankAllocation>) => setDraft(previous => ({ ...previous, allocations: previous.allocations.map(row => row.id === id ? { ...row, ...patch } : row) }));
  const references = (type: string) => [{ value: '', label: '—' }, ...lookups.filter(row => row.type === `${type}::company::${company.id}`).map(row => ({ value: row.value, label: row.value }))];
  const close = () => { if (!pending.current) dirty && !readOnly ? setDiscard(true) : onClose(); };
  const navigateReconciliation = () => {
    if (dirty && !readOnly) { setError('Save or cancel your changes before opening Reconciliation.'); return; }
    onOpenReconciliation?.();
  };
  const matchingUpdated = (value: BankMatchingDemo) => {
    setMatchingDemo(value); setMatchingSaved(true); setMatchingOpen(false);
    setOpen(previous => new Set([...previous, 3]));
  };
  async function save(event: React.FormEvent) {
    event.preventDefault(); if (disabled || pending.current || !dirty) return;
    pending.current = true; setBusy(true); setError('');
    try {
      const saved = isCreate ? await createBankTransaction(company.id, record.id, draft) : await saveBankTransaction(record.id, company.id, draft, expected.current);
      baseline.current = JSON.stringify(draft); onSaved(saved); onClose();
    }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'The bank transaction could not be saved.'); }
    finally { pending.current = false; setBusy(false); }
  }
  async function attach(files: File[]) {
    if (disabled || pending.current || !files.length) return;
    pending.current = true; setBusy(true); setError('');
    try {
      if (draft.attachments.length + files.length > 20 || files.some(file => !['application/pdf', 'image/png', 'image/jpeg'].includes(file.type) || file.size > 2 * 1024 * 1024 || file.size === 0)) throw new Error('Select up to 20 PDF, PNG or JPG files, no larger than 2 MB each.');
      if ([...draft.attachments, ...files].reduce((sum, file) => sum + file.size, 0) > 8 * 1024 * 1024) throw new Error('Attachments must not exceed 8 MB in total.');
      const added = await Promise.all(files.map(file => new Promise<InvoiceAttachment>((resolve, reject) => {
        const reader = new FileReader(); reader.onerror = () => reject(new Error('Could not read attachment.'));
        reader.onload = () => resolve({ name: file.name, size: file.size, type: file.type, url: String(reader.result) }); reader.readAsDataURL(file);
      })));
      setDraft(previous => ({ ...previous, attachments: [...previous.attachments, ...added] }));
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not add attachments.'); }
    finally { pending.current = false; setBusy(false); if (fileInput.current) fileInput.current.value = ''; }
  }
  return createPortal(<div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} data-bank-transaction-editor className="fixed inset-0 z-[5000] flex flex-col bg-[#F8FAFC] font-montserrat text-[#10233A] outline-none" onKeyDown={event => {
    if (matchingOpen) return;
    if (event.key === 'Escape') { event.stopPropagation(); if (preview || escapeFromDropdown.current) { root.current?.focus(); return; } event.preventDefault(); if (discard) setDiscard(false); else close(); }
    if (event.key === 'Tab' && !preview && !window.document.querySelector('[role="listbox"]')) { const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),textarea:not(:disabled),[tabindex="0"]')].filter(node => node.getClientRects().length); const first = controls[0], last = controls.at(-1); if (event.shiftKey && (window.document.activeElement === first || window.document.activeElement === root.current)) { event.preventDefault(); last?.focus(); } else if (!event.shiftKey && window.document.activeElement === last) { event.preventDefault(); first?.focus(); } }
  }}>
    <header className="shrink-0 border-b border-[#D3E1EC] bg-white px-4 py-3 sm:px-6"><BackNavigationButton label={uiText("Back to Bank")} onClick={close} disabled={busy} /><div className="mt-2 flex flex-wrap items-center justify-between gap-3"><h1 id={titleId} className="flex items-center gap-2 text-[20px] font-semibold"><Landmark size={21} className="text-[#007EA7]" />{isCreate ? uiText('New bank transaction') : uiText('Bank transaction details')}</h1><div className="flex items-center gap-2 text-[11px] font-semibold"><span className="rounded-full bg-[#E5EDF9] px-3 py-1 text-[#007EA7]">{statusText(bankProcessingStatus(record))}</span><span className={`rounded-full px-3 py-1 ${reconciliation.matched ? 'bg-[#E4F4EF] text-[#21866A]' : 'bg-[#FFF4DC] text-[#926317]'}`}>{statusText(reconciliation.status)}</span></div></div><p className="mt-1.5 text-[11px] text-[#7288A3]">{uiText("Companies / ")}{company.name}{uiText(" / Bank / ")}{isCreate ? uiText('New bank transaction') : draft.transferNo || draft.referenceNo || uiText('Transaction')}</p></header>
    <form noValidate onSubmit={event => void save(event)} className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-4 sm:px-6">
        {loading && <p role="status" className="flex items-center gap-2 text-[12px] text-[#7288A3]"><Loader2 size={14} className="animate-spin" />{uiText("Loading company settings…")}</p>}
        {error && <p ref={errorRef} tabIndex={-1} role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{error}</p>}
        {readOnly && <p role="status" className="rounded-md border border-[#D3E1EC] bg-white px-3 py-2 text-[12px] text-[#7288A3]">{stateError || uiText('You do not have permission to edit this bank entry.')}</p>}
        {([1, 2, 3, 4, 5] as const).map(number => <Section key={number} number={number} title={['Bank details', 'Accounting allocation', 'Reconciliation', 'Additional information', 'Attachments and notes'][number - 1]} open={open.has(number)} onToggle={() => setOpen(previous => { const next = new Set(previous); next.has(number) ? next.delete(number) : next.add(number); return next; })} summary={number === 4 ? `Source: ${record.source || '—'} · ${draft.transferNo || '—'}` : number === 5 ? `${files.length} file(s)${draft.notes ? ' · Notes added' : ''}` : undefined}>
          {number === 1 && isCreate && <fieldset className="m-0 min-w-0 space-y-4 border-0 p-0" aria-label={uiText("New bank transaction details")} disabled={disabled}>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <Field label={uiText("Date")} required><input aria-label={uiText("Transaction date")} type="date" value={draft.date} onChange={event => update('date', event.target.value)} className={control} /></Field>
              <Field label={uiText("Bank account")} required><Select label={uiText("Bank account")} value={draft.bankAccount} options={accounts.map(account => ({ value: account.iban, label: `${account.bank || 'Bank'} · ${account.iban}` }))} onChange={value => update('bankAccount', value)} disabled={disabled} />{!accounts.length && <p className="text-[10px] text-[#926317]">{uiText("Add a bank account in this company’s Bank accounts settings.")}</p>}</Field>
              <Field label={uiText("Counterparty name")} required><input aria-label={uiText("Counterparty name")} value={draft.counterpartyName} maxLength={500} onChange={event => update('counterpartyName', event.target.value)} className={control} /></Field>
              <Field label={uiText("Counterparty IBAN")}><input aria-label={uiText("Counterparty IBAN")} value={draft.counterpartyIban} maxLength={34} onChange={event => update('counterpartyIban', event.target.value)} className={control} /></Field>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-6">
              <Field label={uiText("Purpose of payment")} required className="sm:col-span-2"><input aria-label={uiText("Purpose of payment")} value={draft.paymentPurpose} maxLength={5000} onChange={event => update('paymentPurpose', event.target.value)} className={control} /></Field>
              <Field label={uiText("Amount")} required><input aria-label={uiText("Transaction amount")} inputMode="decimal" placeholder={uiText("0.00")} value={draft.amount} onChange={event => { const amount = event.target.value; setDraft(previous => ({ ...previous, amount, allocations: previous.allocations.length === 1 && (!previous.allocations[0].amount || previous.allocations[0].amount === previous.amount) ? [{ ...previous.allocations[0], amount }] : previous.allocations })); }} className={`${control} tabular-nums`} /><p className="text-[10px] text-[#7288A3]">{uiText("Positive: incoming · Negative: outgoing")}</p></Field>
              <Field label={uiText("Currency")} required><Select label={uiText("Transaction currency")} value={draft.currency} options={currencies} onChange={value => update('currency', value)} disabled={disabled} /></Field>
              <Field label={uiText("Exchange rate date")}><input aria-label={uiText("Exchange rate date")} type="date" value={draft.exchangeRateDate} onChange={event => update('exchangeRateDate', event.target.value)} className={control} /></Field>
              <Field label={uiText("Reference No.")}><input aria-label={uiText("Reference No.")} value={draft.referenceNo} maxLength={200} onChange={event => update('referenceNo', event.target.value)} className={control} /></Field>
            </div>
          </fieldset>}
          {number === 1 && !isCreate && <fieldset className="m-0 min-w-0 space-y-4 border-0 p-0" aria-label={uiText("Imported bank details")}>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <Field label={uiText("Date")}><input aria-label={uiText("Transaction date")} readOnly value={draft.date || '—'} className={`${control} !bg-[#F2F5F9]`} /></Field>
              <Field label={uiText("Bank account")}><input aria-label={uiText("Bank account")} readOnly value={companyBankAccountLabel(record.id, company.id, { ...accounts.find(row => row.iban === draft.bankAccount), iban: draft.bankAccount })} title={draft.bankAccount} className={`${control} !bg-[#F2F5F9]`} /></Field>
              <Field label={uiText("Counterparty name")}><input aria-label={uiText("Counterparty name")} readOnly value={draft.counterpartyName || '—'} className={`${control} !bg-[#F2F5F9]`} /></Field>
              <Field label={uiText("Counterparty IBAN")}><input aria-label={uiText("Counterparty IBAN")} readOnly value={draft.counterpartyIban || '—'} className={`${control} !bg-[#F2F5F9]`} /></Field>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-6">
              <Field label={uiText("Purpose of payment")} className="sm:col-span-2"><input aria-label={uiText("Purpose of payment")} readOnly value={draft.paymentPurpose || '—'} title={draft.paymentPurpose} className={`${control} !bg-[#F2F5F9]`} /></Field>
              <Field label={uiText("Amount")}><input aria-label={uiText("Transaction amount")} readOnly value={draft.amount} className={`${control} !bg-[#F2F5F9] tabular-nums`} /></Field>
              <Field label={uiText("Currency")}><input aria-label={uiText("Transaction currency")} readOnly value={draft.currency} className={`${control} !bg-[#F2F5F9]`} /></Field>
              <Field label={uiText("Exchange rate date")}><input aria-label={uiText("Exchange rate date")} readOnly value={draft.exchangeRateDate || '—'} className={`${control} !bg-[#F2F5F9]`} /></Field>
              <Field label={uiText("Reference No.")}><input aria-label={uiText("Reference No.")} readOnly value={draft.referenceNo || '—'} className={`${control} !bg-[#F2F5F9]`} /></Field>
            </div>
            <Field label={uiText("Original bank payment description / statement text")}><p className="m-0 min-h-[48px] whitespace-pre-wrap rounded-md bg-[#F2F5F9] px-3 py-2.5 text-[12px] leading-5">{draft.originalStatement || '—'}</p></Field>
          </fieldset>}
          {number === 2 && <div className="min-w-0 space-y-3"><div ref={table} className="max-h-[360px] overflow-auto rounded-md border border-[#D3E1EC]" tabIndex={0} aria-label={uiText("Accounting allocation table")}><table className="w-full min-w-[1040px] border-collapse text-left text-[11px]"><thead className="sticky top-0 z-10 bg-[#F2F5F9] text-[#7288A3]"><tr>{['#', 'Description *', 'GL account *', 'Department', 'Object / Project', 'Cost center', 'Amount *', ''].map((label, i) => <th key={i} className="border-b border-[#D3E1EC] px-2 py-2.5 font-medium" scope="col">{uiText(label)}</th>)}</tr></thead><tbody>{draft.allocations.map((row, index) => <tr key={row.id} className="border-b border-[#E5EDF9] last:border-0 odd:bg-[#F8FDFF]">
            <td className="w-9 px-2 py-2 text-center text-[#7288A3]">{index + 1}</td><td className="min-w-[240px] p-2"><Select label={`Allocation ${index + 1} Description`} value={row.description} options={descriptions} onChange={value => updateLine(row.id, { description: value })} disabled={disabled} /></td>
            <td className="min-w-[205px] p-2"><Select label={`Allocation ${index + 1} GL account`} value={row.glAccount} options={glOptions} onChange={value => updateLine(row.id, { glAccount: value })} disabled={disabled} /></td>
            <td className="min-w-[145px] p-2"><Select label={`Allocation ${index + 1} Department`} value={row.department} options={references('department_code')} onChange={value => updateLine(row.id, { department: value })} disabled={disabled} /></td>
            <td className="min-w-[150px] p-2"><Select label={`Allocation ${index + 1} Object / Project`} value={row.project} options={references('object_project')} onChange={value => updateLine(row.id, { project: value })} disabled={disabled} /></td>
            <td className="min-w-[130px] p-2"><Select label={`Allocation ${index + 1} Cost center`} value={row.costCenter} options={references('cost_center')} onChange={value => updateLine(row.id, { costCenter: value })} disabled={disabled} /></td>
            <td className="min-w-[130px] p-2"><input aria-label={`Allocation ${index + 1} Amount`} inputMode="decimal" disabled={disabled} value={row.amount} onChange={event => updateLine(row.id, { amount: event.target.value })} className={`${control} text-right tabular-nums`} /></td>
            <td className="system-table-row-actions p-2"><button type="button" disabled={disabled || draft.allocations.length === 1} aria-label={`Remove allocation ${index + 1}`} title={uiText("Remove allocation")} onClick={() => setDraft(previous => ({ ...previous, allocations: previous.allocations.filter(line => line.id !== row.id) }))} className={rowAction}><Trash2 size={14} /></button></td>
          </tr>)}</tbody></table></div><HorizontalTableScrollbar scrollRef={table} fixed={false} expandable={false} className="!static !min-h-6 !py-0" />
            {!readOnly && <button type="button" disabled={disabled} onClick={() => setDraft(previous => ({ ...previous, allocations: [...previous.allocations, { id: crypto.randomUUID(), description: '', glAccount: '', department: '', project: '', costCenter: '', amount: '' }] }))} className="flex items-center gap-1.5 text-[12px] font-semibold text-[#007EA7] hover:underline disabled:opacity-50"><Plus size={15} />{uiText("Add line")}</button>}
            <dl className="grid grid-cols-1 gap-3 rounded-md bg-[#F2F5F9] p-3 text-[11px] sm:grid-cols-3"><div><dt className="text-[#7288A3]">{uiText("Transaction amount")}</dt><dd className="m-0 mt-1 text-[14px] font-semibold tabular-nums">{format(totals.amount, draft.currency)}</dd></div><div><dt className="text-[#7288A3]">{uiText("Allocated amount")}</dt><dd className="m-0 mt-1 text-[14px] font-semibold tabular-nums">{format(totals.allocated, draft.currency)}</dd></div><div><dt className="text-[#7288A3]">{uiText("Remaining amount")}</dt><dd className={`m-0 mt-1 text-[14px] font-semibold tabular-nums ${totals.valid && totals.remaining === 0 ? 'text-[#21866A]' : 'text-[#B45309]'}`}>{format(totals.remaining, draft.currency)}</dd></div></dl>
          </div>}
          {number === 3 && <div className="space-y-4"><div className="grid items-end gap-4 sm:grid-cols-2 xl:grid-cols-[1fr_2fr_auto]"><Field label={uiText("Reconciliation status")}><p className="m-0 flex h-9 items-center gap-2 text-[12px] font-medium"><span className={`h-1.5 w-1.5 rounded-full ${reconciliation.matched ? 'bg-[#21866A]' : 'bg-[#E3A008]'}`} />{statusText(reconciliation.status)}</p></Field><Field label={uiText("Settled documents")}><div className="flex min-h-9 flex-wrap items-center gap-2 text-[12px]">{reconciliation.documents.length ? reconciliation.documents.map(item => <span key={item.id} className="rounded-md border border-[#D3E1EC] px-2 py-1">{item.number}</span>) : <span className="text-[#7288A3]">—</span>}</div></Field><div className="flex flex-wrap gap-2"><PageActionButton icon={<Pencil size={14} />} onClick={() => { setMatchingSaved(false); setMatchingOpen(true); }} disabled={matchingDisabled}>{uiText("Edit matching data")}</PageActionButton><PageActionButton icon={<ExternalLink size={14} />} onClick={navigateReconciliation} disabled={!onOpenReconciliation || busy}>{uiText("Open reconciliation")}</PageActionButton></div></div>
            {matchingSaved && <p role="status" className="rounded-md bg-[#E4F4EF] px-3 py-2 text-[12px] text-[#21866A]">{uiText("Matching data saved. Suggested matches preview updated.")}</p>}
            {matchingDemo && <section ref={matchingResults} aria-label={uiText("Suggested matches")} className="overflow-hidden rounded-lg border border-[#D3E1EC]"><div className="flex flex-wrap items-center justify-between gap-2 bg-[#F2F5F9] px-3 py-2.5"><h3 className="text-[12px] font-semibold">{uiText("Suggested matches")}</h3><span className="rounded bg-[#E5EDF9] px-2 py-1 text-[10px] font-semibold text-[#007EA7]">{uiText("Demo preview · ")}{matchingDemo.revision}</span></div><div className="space-y-3 p-3"><p className="text-[11px] text-[#7288A3]">{uiText("No matching algorithm has run. This example is not an actual match and cannot change confirmed reconciliations.")}</p><div className="text-[11px]"><span className="text-[#7288A3]">{uiText("Matching purpose: ")}</span><span className="whitespace-pre-wrap break-words">{matchingDemo.input.matchingPurpose || '—'}</span></div><div className="overflow-x-auto"><table className="w-full min-w-[500px] text-left text-[12px]"><thead className="text-[11px] text-[#7288A3]"><tr>{['Document No.', 'Counterparty', 'Amount', 'Currency'].map(label => <th key={label} scope="col" className="border-b border-[#D3E1EC] px-2 py-2 font-medium">{uiText(label)}</th>)}</tr></thead><tbody><tr className="bg-[#F8FDFF]"><td className="px-2 py-3">{matchingDemo.suggestion.documentNo}</td><td className="px-2 py-3">{matchingDemo.suggestion.counterpartyName}</td><td className="px-2 py-3 tabular-nums">{matchingDemo.suggestion.amount}</td><td className="px-2 py-3">{matchingDemo.suggestion.currency}</td></tr></tbody></table></div></div></section>}
          </div>}
          {number === 4 && <div className="space-y-4"><div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4"><Field label={uiText("Transfer no.")}><input aria-label={uiText("Transfer no.")} readOnly value={draft.transferNo || '—'} className={`${control} !bg-[#F2F5F9]`} /></Field>{[['Source', record.source], ['Counterparty code', draft.counterpartyCode], ['System ID', record.id], ['Created by', record.created_by || ''], ['Created at', record.created_at], ['Import batch', String((record as unknown as Record<string, unknown>).import_batch || '')]].map(([label, value]) => <Field key={label} label={uiText(label)}><p className="m-0 break-words py-2 text-[12px]">{value || '—'}</p></Field>)}</div><DocumentActionHistory documentId={record.id} companyId={company.id} unsavedChanges={dirty} busy={busy} /></div>}
          {number === 5 && <div className="space-y-4"><input ref={fileInput} type="file" multiple accept="application/pdf,image/png,image/jpeg" className="hidden" onChange={event => void attach(Array.from(event.target.files || []))} />{!readOnly && <PageActionButton icon={<Paperclip size={14} />} onClick={() => fileInput.current?.click()} disabled={disabled}>{uiText("Upload attachment")}</PageActionButton>}<ul className="m-0 space-y-2 p-0">{files.map((file, index) => <li key={`${index}:${file.name}`} className="flex items-center gap-2 rounded-md border border-[#D3E1EC] px-3 py-2 text-[12px]"><Paperclip size={14} className="shrink-0 text-[#7288A3]" /><span className="min-w-0 flex-1 truncate">{file.name}</span><button type="button" aria-label={`View attachment ${file.name}`} onClick={() => setPreview(file)} className={rowAction}><Eye size={14} /></button>{index >= sourceAttachment.length && !readOnly && <button type="button" disabled={disabled} aria-label={`Remove attachment ${file.name}`} onClick={() => update('attachments', draft.attachments.filter((_, i) => i !== index - sourceAttachment.length))} className={rowAction}><Trash2 size={14} /></button>}</li>)}</ul><Field label={uiText("Notes")}><textarea aria-label={uiText("Notes")} rows={3} disabled={disabled} value={draft.notes} onChange={event => update('notes', event.target.value)} className={`${control} !h-auto py-2`} /></Field></div>}
        </Section>)}
      </div>
      <footer className="flex shrink-0 flex-wrap items-center justify-end gap-3 border-t border-[#D3E1EC] bg-white px-4 py-3 sm:px-6">{discard ? <><p className="mr-auto text-[12px]">{uiText("Discard unsaved changes?")}</p><CancelButton onClick={() => setDiscard(false)}>{uiText("Keep editing")}</CancelButton><SaveButton onClick={onClose}>{uiText("Discard changes")}</SaveButton></> : <><CancelButton onClick={close}>{readOnly ? uiText('Close') : uiText('Cancel')}</CancelButton>{!readOnly && <SaveButton type="submit" disabled={disabled || !dirty}>{busy ? uiText('Saving…') : isCreate ? uiText('Save') : uiText('Save changes')}</SaveButton>}</>}</footer>
    </form>
    {preview && <InvoiceAttachmentPreview file={preview} onClose={() => setPreview(undefined)} />}
    {matchingOpen && <BankMatchingDataDialog record={record} company={company} parties={parties} onClose={() => setMatchingOpen(false)} onSaved={matchingUpdated} />}
  </div>, window.document.body);
}
