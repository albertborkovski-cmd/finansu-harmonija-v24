import { ArrowLeft, Eye, EyeOff, Pencil, Settings2 } from 'lucide-react';
import type { ReactNode } from 'react';
import { useLanguage } from '../i18n/language';
import { editorialArticle } from '../lib/helpEditorialCatalog';
import { helpArticleKey, isHelpVisible } from '../lib/helpContent';
import { useHelpContent } from './HelpContentProvider';
import HelpArticleBody from './HelpArticleBody';

export default function HelpContentBoundary({ route, children }: { route: string; children: ReactNode }) {
  const { state, admin, error } = useHelpContent(), lt = useLanguage() === 'lt', lang = lt ? 1 : 0;
  const entry = editorialArticle(route, state), visible = isHelpVisible(route, state);
  const preview = admin && new URLSearchParams(route.split('?')[1] || '').get('preview') === '1';
  const editHref = './#help/admin?' + new URLSearchParams({ edit: helpArticleKey(route) });
  return <>
    {admin && <div className="flex min-h-12 flex-wrap items-center gap-3 border-b border-[#D3E1EC] bg-[#EEF6FA] px-5 py-3 pr-32 font-montserrat text-[12px] text-[#526B86]">
      <a href="./#help/admin" className="inline-flex items-center gap-2 rounded-md border border-[#C4D8E6] bg-white px-3 py-2 font-semibold text-[#007EA7]"><Settings2 size={15} />{lt ? 'Tvarkyti pagalbą' : 'Manage help'}</a>
      {entry && <a href={editHref} className="inline-flex items-center gap-2 rounded-md border border-[#C4D8E6] bg-white px-3 py-2 font-semibold text-[#007EA7]"><Pencil size={14} />{lt ? 'Redaguoti aprašymą' : 'Edit article'}</a>}
      {!visible && <span className="inline-flex items-center gap-2"><EyeOff size={15} />{lt ? 'Paslėpta nuo naudotojų' : 'Hidden from users'}</span>}
    </div>}
    {error ? <div role="alert" className="m-6 rounded-lg border border-red-200 bg-red-50 p-6 font-montserrat">{lt ? 'Nepavyko perskaityti išsaugotos pagalbos. Duomenys nepakeisti. Atnaujinkite puslapį arba kreipkitės į administratorių.' : 'Saved help content could not be loaded. Data was not changed. Reload or contact an administrator.'}</div>
      : !visible && !preview ? <main className="min-h-screen bg-[#F7FAFC] p-8 font-montserrat text-[#10233A]"><div className="mx-auto max-w-3xl rounded-xl border border-[#D3E1EC] bg-white p-8"><EyeOff size={28} className="mb-4 text-[#7288A3]" /><h1 className="text-xl font-semibold">{lt ? 'Šis aprašymas šiuo metu nerodomas' : 'This article is currently hidden'}</h1><p className="my-4 text-sm text-[#7288A3]">{lt ? 'Aprašymas neištrintas. Administratorius gali vėl įjungti jo matomumą.' : 'The article has not been deleted. An administrator can make it visible again.'}</p><a href="./#help" className="inline-flex items-center gap-2 text-sm text-[#007EA7]"><ArrowLeft size={16} />{lt ? 'Pagalbos centras' : 'Help centre'}</a>{admin && entry && <a className="ml-6 inline-flex items-center gap-2 text-sm text-[#007EA7]" href={entry.href + (entry.href.includes('?') ? '&' : '?') + 'preview=1'}><Eye size={16} />{lt ? 'Administratoriaus peržiūra' : 'Administrator preview'}</a>}</div></main>
        : entry && state.articles[entry.key] ? <main className="min-h-screen bg-[#F7FAFC] px-5 py-8 font-montserrat text-[#10233A]"><article className="mx-auto max-w-5xl rounded-xl border border-[#D3E1EC] bg-white p-6 sm:p-9"><a href="./#help" className="mb-5 inline-flex items-center gap-2 text-sm text-[#007EA7]"><ArrowLeft size={16} />{lt ? 'Pagalbos centras' : 'Help centre'}</a><h1 className="text-[26px] font-semibold">{entry.title[lang] || entry.title[1 - lang]}</h1><p className="mb-7 mt-3 text-sm leading-6 text-[#7288A3]">{entry.description[lang] || entry.description[1 - lang]}</p><HelpArticleBody body={entry.body[lang] || entry.body[1 - lang]} /></article></main> : children}
  </>;
}
