import { BookOpen, HelpCircle } from 'lucide-react';
import { useLanguage, translateUi as t } from '../i18n/language';
import { COMPANY_EXPORT_FORMATS } from '../lib/companyDigitizationSettings';
import { exportSchema } from '../lib/exportFormatSchemas';
import { exportFieldHelp, exportHelpFields } from '../lib/exportSettingsHelp';
import SearchableSelect from './SearchableSelect';
import { useEffect, useState } from 'react';

export default function ExportSettingsHelpPage() {
  const language = useLanguage(), lt = language === 'lt';
  const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
  const [format, setFormat] = useState(() => COMPANY_EXPORT_FORMATS.includes(params.get('format') as typeof COMPANY_EXPORT_FORMATS[number]) ? params.get('format')! : 'Rivilė');
  const [topic, setTopic] = useState(params.get('topic') || 'overview');
  const fields = exportHelpFields(format, topic);
  useEffect(() => { document.title = `Finansų harmonija · ${lt ? 'Pagalba' : 'Help'} · ${format}`; }, [lt, format]);
  const columnsOnly = ['Additional column settings', 'Required', 'Assign automatically', 'Default value'].includes(topic);
  return <main className="min-h-screen bg-[#F5F8FB] px-4 py-8 font-montserrat text-[#10233A] sm:px-8">
    <div className="mx-auto max-w-5xl space-y-5">
      <header className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7">
        <div className="mb-3 flex items-center gap-2 text-[13px] font-semibold text-[#007EA7]"><BookOpen size={19} />Finansų harmonija · {t('Help')}</div>
        <h1 className="text-[24px] font-semibold">{t('Export settings')} · {format}</h1>
        <p className="mt-3 max-w-3xl text-[13px] leading-6 text-[#526B86]">{lt ? 'Čia paaiškinami pasirinkto eksporto formato laukai. Pagalbos atidarymas nekeičia nustatymų ir nesiunčia dokumentų. Formos nustatymai išsaugomi tik paspaudus „Išsaugoti pakeitimus“.' : 'This guide explains the selected export format. Opening help does not change settings or send documents. Form settings are saved only when you choose Save changes.'}</p>
        <div className="mt-5 flex flex-wrap items-center gap-3"><div className="w-full sm:w-72"><SearchableSelect ariaLabel={t('Export format')} value={format} options={[...COMPANY_EXPORT_FORMATS]} onChange={value => { setFormat(value); setTopic('overview'); }} portalMenu /></div><button onClick={() => setTopic('overview')} className="rounded-md border border-[#D3E1EC] bg-white px-3 py-2 text-[12px] font-medium text-[#007EA7]">{lt ? 'Visa formato pagalba' : 'All help for this format'}</button></div>
      </header>
      {!columnsOnly && <section className="divide-y divide-[#E5EDF9] rounded-xl border border-[#D3E1EC] bg-white px-5 sm:px-7">{fields.map(field => <article key={field.key} className="py-5"><h2 className="flex items-center gap-2 text-[14px] font-semibold"><HelpCircle size={16} className="shrink-0 text-[#007EA7]" />{t(field.label)}</h2><p className="mt-2 text-[13px] leading-6 text-[#526B86]">{exportFieldHelp(field, lt)}</p></article>)}</section>}
      {(columnsOnly || topic === 'overview') && <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7"><h2 className="mb-4 text-[16px] font-semibold">{t('Additional column settings')}</h2>
        <dl className="space-y-4 text-[13px] leading-6">{[
          [t('Required'), lt ? 'Jei privalomas dokumento laukas tuščias, dokumentų registre rodomas įspėjimas. Taikomi šios organizacijos nustatymai.' : 'A missing required document field displays a warning in the document register. Rules belong to this organization.'],
          [t('Assign automatically'), lt ? 'Numatytoji reikšmė priskiriama tik tuščiam laukui pasirinktu etapu. Rankiniu būdu įvesta reikšmė nepakeičiama.' : 'The default value fills an empty field at the selected stage. A manually entered value is retained.'],
          [t('Default value'), lt ? 'Pasirinkite reikšmę iš organizacijos kodų sąrašo arba įveskite apskaitos sistemos kodą. Vien numatytoji reikšmė be automatinio priskyrimo dokumento nekeičia.' : 'Select an organization code or enter the accounting-system code. A default value alone does not change a document unless automatic assignment is enabled.'],
        ].map(([label, value]) => <div key={label}><dt className="font-semibold">{label}</dt><dd className="text-[#526B86]">{value}</dd></div>)}</dl>
        <p className="mt-5 border-t border-[#E5EDF9] pt-4 text-[12px] leading-6 text-[#7288A3]">{exportSchema(format).columns.map(column => t(column.label)).join(' · ')}</p>
      </section>}
      <footer className="pb-6 text-center text-[11px] text-[#7288A3]">Finansų harmonija · {lt ? 'Eksporto nustatymų pagalba' : 'Export settings help'}</footer>
    </div>
  </main>;
}
