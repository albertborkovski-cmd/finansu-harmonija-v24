import { ArrowLeft, BookOpen, Info, ExternalLink } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLanguage, translateUi as t } from '../i18n/language';
import { COMPANY_EXPORT_FORMATS } from '../lib/companyDigitizationSettings';
import { exportSchema } from '../lib/exportFormatSchemas';
import { exportFieldHelp, exportHelpFields } from '../lib/exportSettingsHelp';
import { API_EXPORT_FORMATS, API_EXPORT_STEPS, CURRENT_INTEGRATION_NOTICE, EXPORT_TUTORIALS, FILE_EXPORT_STEPS, RIVILE_API_ERRORS, RIVILE_GUIDE_SOURCES, exportSetupSteps } from '../lib/exportHelpGuide';
import SearchableSelect from './SearchableSelect';
import { HelpScreenshot, HelpVideo } from './HelpMedia';
import ExportDateConflictHelp from './ExportDateConflictHelp';
import { integrationHelpHref } from './IntegrationHelpLink';

export default function ExportSettingsHelpPage() {
  const lt = useLanguage() === 'lt', lang = lt ? 1 : 0;
  const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
  const [format, setFormat] = useState(() => COMPANY_EXPORT_FORMATS.includes(params.get('format') as typeof COMPANY_EXPORT_FORMATS[number]) ? params.get('format')! : 'Rivilė');
  const [topic, setTopic] = useState(params.get('topic') || 'overview');
  const fields = exportHelpFields(format, topic), api = API_EXPORT_FORMATS.includes(format);
  const [view, setView] = useState(topic === 'date-conflict' ? 'errors' : topic === 'overview' ? 'setup' : ['Additional column settings', 'Required', 'Assign automatically', 'Default value'].includes(topic) ? 'columns' : 'fields');
  useEffect(() => { document.title = 'Finansų harmonija · ' + (lt ? 'Pagalba' : 'Help') + ' · ' + format; }, [lt, format]);
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'auto' }); }, [format, topic, view]);
  const sections = [
    ['setup', lt ? '1. Nustatymas' : '1. Setup'], ['transfer', lt ? '2. Failas ar API?' : '2. File or API?'],
    ['fields', lt ? '3. Ką įrašyti į laukus' : '3. What to enter'], ['columns', lt ? '4. Papildomi stulpeliai' : '4. Additional columns'],
    ['errors', lt ? '5. Jei nepavyksta' : '5. Troubleshooting'], ['videos', lt ? '6. Vaizdo instrukcijos' : '6. Video tutorials'],
  ];
  return <main className="min-h-screen bg-[#F5F8FB] p-4 font-montserrat text-[#10233A] sm:p-8">
    <div className="mx-auto max-w-6xl">
      <a href="./#help/organization" className="mb-5 inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]"><ArrowLeft size={15} />{lt ? 'Pagalbos centras' : 'Help centre'}</a>
      <header className="mb-5 rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7">
        <p className="mb-2 flex items-center gap-2 text-[12px] font-semibold text-[#007EA7]"><BookOpen size={18} />Finansų harmonija · {t('Help')}</p>
        <h1 className="text-[24px] font-semibold">{t('Export settings')} · {format}</h1>
        <p className="mt-2 text-[13px] leading-6 text-[#526B86]">{lt ? 'Nuo organizacijos nustatymų iki rezultato apskaitos programoje: veiksmai, laukų reikšmės, klaidos ir mokomieji įrašai.' : 'From organization setup to the accounting-system result: steps, field meanings, error checks and tutorials.'}</p>
        <div className="mt-4 max-w-sm"><SearchableSelect ariaLabel={t('Export format')} value={format} options={[...COMPANY_EXPORT_FORMATS]} onChange={value => { setFormat(value); setTopic('overview'); setView('setup'); }} portalMenu /></div>
      </header>
      <div className="grid items-start gap-5 md:grid-cols-[235px_minmax(0,1fr)]">
        <nav aria-label={lt ? 'Šiame straipsnyje' : 'In this guide'} className="space-y-1 rounded-xl border border-[#D3E1EC] bg-white p-3 md:sticky md:top-5">
          <a href={integrationHelpHref(format)} className="mb-2 block rounded-md border border-[#D3E1EC] px-3 py-2.5 text-[13px] font-semibold text-[#007EA7] hover:bg-[#E5EDF9]">{lt ? 'Integracijos aprašymas' : 'Integration guide'}</a>
          {sections.map(([id, label]) => <button key={id} type="button" aria-current={view === id ? 'page' : undefined} onClick={() => setView(id)} className={'w-full rounded-md px-3 py-2.5 text-left text-[13px] font-medium leading-5 ' + (view === id ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#526B86] hover:bg-[#F2F6FA]')}>{label}</button>)}
        </nav>
        <div className="min-w-0 space-y-5">
          <aside className="flex gap-3 rounded-lg border border-[#D3E1EC] bg-[#EBF5FA] p-4 text-[12px] leading-6 text-[#526B86]"><Info size={18} className="mt-1 shrink-0 text-[#007EA7]" /><p>{CURRENT_INTEGRATION_NOTICE[lang]}</p></aside>
          <section className="rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7">
            {view === 'setup' && <><h2 className="mb-5 text-[19px] font-semibold">{lt ? 'Kaip nustatyti eksportą' : 'How to set up export'} · {format}</h2>
              <ol className="space-y-5">{exportSetupSteps(format).map((step, index) => <li key={index} className="flex gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#E5EDF9] text-[12px] font-semibold text-[#007EA7]">{index + 1}</span><div><h3 className="text-[14px] font-semibold">{step.title[lang]}</h3><p className="mt-1 text-[13px] leading-6 text-[#526B86]">{step.body[lang]}</p></div></li>)}</ol>
              <HelpScreenshot file="export-settings.jpg" lt={lt} caption={lt ? 'FH: organizacijos eksporto nustatymai. Rakto laukas paliktas tuščias.' : 'FH: organization export settings. The key field is intentionally empty.'} />
              {format === 'Rivilė ERP' && <p className="text-[13px] leading-6 text-[#526B86]">{lt ? 'ERP raktas kuriamas Rivilė ERP skiltyje Nustatymai → Bendrieji → API raktai. Kuriant nurodoma įmonė ir galiojimas. Raktas parodomas vieną kartą; jį saugokite saugiai. Pergeneravus senasis raktas jungtyse nebeveiks.' : 'In Rivilė ERP, use Settings → General → API keys, selecting the company and expiry. The key is displayed once; store it securely. Regenerating it invalidates the old key in existing connections.'}</p>}
            </>}
            {view === 'transfer' && <><h2 className="text-[19px] font-semibold">{lt ? 'Eksporto failas ir API – kuo skiriasi?' : 'Export file and API — what is different?'}</h2><div className="mt-5 space-y-6">{[{ title: lt ? 'Failas: atsisiunčiate ir importuojate' : 'File: download and import', steps: FILE_EXPORT_STEPS }, { title: lt ? 'API: tiesioginis sistemos ryšys' : 'API: a direct system connection', steps: API_EXPORT_STEPS }].map(item => <article key={item.title}><h3 className="mb-3 text-[15px] font-semibold text-[#007EA7]">{item.title}</h3><ol className="list-decimal space-y-2 pl-5 text-[13px] leading-6 text-[#526B86]">{item.steps.map((step, index) => <li key={index}>{step[lang]}</li>)}</ol></article>)}</div><p className="mt-5 rounded-lg bg-[#F5F8FB] p-4 text-[13px] leading-6">{lt ? 'API raktas = leidimas veikti. „Gateway“ = ryšys su GAMA baze. Kodų atitikmenys = kur ir kaip registruoti sąskaitą. Šie trys dalykai vienas kito nepakeičia.' : 'API key = authorization. Gateway = connection to the GAMA database. Code mappings = how the invoice is recorded. These three elements do not replace each other.'}</p></>}
            {view === 'fields' && <><h2 className="text-[19px] font-semibold">{lt ? 'Ką įrašyti ir ką pakeičia nustatymas' : 'What to enter and what the setting controls'}</h2>{topic !== 'overview' && <button type="button" onClick={() => setTopic('overview')} className="mt-3 text-[12px] font-semibold text-[#007EA7] underline">{lt ? 'Rodyti visus šio formato laukus' : 'Show every field for this format'}</button>}<div className="mt-2 divide-y divide-[#E5EDF9]">{fields.map(field => <article key={field.key} className="py-5"><h3 className="text-[14px] font-semibold">{t(field.label)}</h3><p className="mt-2 text-[13px] leading-6 text-[#526B86]">{exportFieldHelp(field, lt)}</p></article>)}</div></>}
            {view === 'columns' && <><h2 className="text-[19px] font-semibold">{t('Additional column settings')}</h2><p className="mt-3 text-[13px] leading-6 text-[#526B86]">{lt ? 'Kiekviena eilutė valdo vieną dokumento lauką. Pvz., Padalinys: Privalomas ✓, Priskirti automatiškai ✓, Numatytoji reikšmė ADMIN.' : 'Each row controls one document field. Example: Department — Required ✓, Assign automatically ✓, Default value ADMIN.'}</p>
              <dl className="mt-5 space-y-4 text-[13px] leading-6">{[
                [t('Required'), lt ? 'Tuščias laukas registre pažymimas raudonu šauktuku. Tai reikalavimas užpildyti lauką, o ne automatinis reikšmės sukūrimas.' : 'An empty field shows a red warning in the register. This is a requirement to fill it, not a value generator.'],
                [t('Assign automatically'), lt ? 'Tuščiam laukui pritaikoma parinkta numatytoji reikšmė. Rankinė reikšmė nepakeičiama. Jei formatas leidžia, pasirinkite etapą – skaitmeninimo ar eksportavimo metu.' : 'An empty field receives the selected default; manual values are retained. Where supported, choose the digitization or export stage.'],
                [t('Default value'), lt ? 'Pasirinkite kodą iš šios organizacijos sąrašo. Vien numatytoji reikšmė be automatinio priskyrimo nepildo dokumentų. Jei kodo nėra, pirma pridėkite jį atitinkamoje kairiojo meniu skiltyje.' : 'Select a code from this organization’s list. A default alone does not fill documents without automatic assignment. Add a missing code in the corresponding left-hand section first.'],
              ].map(([title, body]) => <div key={title}><dt className="font-semibold">{title}</dt><dd className="text-[#526B86]">{body}</dd></div>)}</dl>
              <HelpScreenshot file="additional-columns.jpg" lt={lt} caption={lt ? 'FH: privalomi laukai, automatinis priskyrimas ir numatytosios reikšmės.' : 'FH: required fields, automatic assignment and defaults.'} /><p className="text-[12px] leading-6 text-[#7288A3]">{exportSchema(format).columns.map(column => t(column.label)).join(' · ')}</p>
            </>}
            {view === 'errors' && <><h2 className="text-[19px] font-semibold">{lt ? 'Ką tikrinti, jei dokumentas neperduotas' : 'What to check when a document is not delivered'}</h2><ul className="my-4 list-disc space-y-2 pl-5 text-[13px] leading-6 text-[#526B86]">
              <li>{lt ? 'Teisinga organizacija ir gavėjo duomenų bazė; pasirinktas tinkamas formatas.' : 'Correct organization and destination database; the intended format is selected.'}</li>
              <li>{lt ? 'Užpildyti privalomi laukai; atpažįstami kontrahentų, išlaidų ir PVM kodai.' : 'Required fields are filled; counterparty, expense and VAT codes are recognized.'}</li>
              <li>{lt ? 'Nėra neišspręsto dokumento klaidos pranešimo. Apskaitos sistemoje leidžiamas dokumento laikotarpis.' : 'No unresolved document issue; the accounting system allows the document period.'}</li>
              <li>{lt ? 'Jei siuntimo rezultatas neaiškus, prieš kartojant ieškokite dokumento gavėjo sistemoje.' : 'If the result is uncertain, search for the document in the destination before retrying.'}</li></ul>
              {format === 'Rivilė API' && <div className="overflow-x-auto"><table className="w-full text-left text-[12px] leading-5"><thead className="bg-[#F2F6FA]"><tr>{[lt ? 'Atsakymas' : 'Response', lt ? 'Reikšmė' : 'Meaning', lt ? 'Ką daryti' : 'What to do'].map(label => <th key={label} className="p-3 font-semibold">{label}</th>)}</tr></thead><tbody>{RIVILE_API_ERRORS.map(error => <tr key={error.code} className="border-b border-[#E5EDF9]"><td className="p-3 font-semibold">{error.code}</td><td className="p-3">{error.meaning[lang]}</td><td className="p-3 text-[#526B86]">{error.action[lang]}</td></tr>)}</tbody></table></div>}
              {!api && <p className="mt-3 text-[13px] leading-6 text-[#526B86]">{lt ? 'Failo importo klaidą pateikia gavėjo apskaitos programa. Išsaugokite jos klaidos tekstą ir patikrinkite, kuri failo eilutė atmesta.' : 'For a file import, the receiving program reports the error. Keep its error text and identify the rejected file row.'}</p>}
              {format === 'Site.pro' ? <ExportDateConflictHelp lt={lt} /> : <a href="./#help/export?format=Site.pro&topic=date-conflict" className="mt-5 inline-flex text-[13px] font-medium text-[#007EA7] underline">{lt ? 'Site.pro: Datos konfliktas prekei' : 'Site.pro: Item date conflict'}</a>}
            </>}
            {view === 'videos' && <><h2 className="text-[19px] font-semibold">{lt ? 'Importas apskaitos programoje' : 'Import in the accounting program'}</h2><p className="my-3 text-[13px] leading-6 text-[#526B86]">{lt ? 'Originalūs kitų sistemų mokomieji vaizdo įrašai nekeisti. Jie nėra FH sąsajos demonstracija. YouTube turinys įkeliamas tik paspaudus įrašo mygtuką.' : 'Original tutorials for other systems are unchanged. They are not FH interface demonstrations. YouTube content loads only when you choose a video.'}</p><div className="grid gap-4 sm:grid-cols-2">{[...EXPORT_TUTORIALS].sort((a, b) => Number(format.startsWith(b.format)) - Number(format.startsWith(a.format))).map(video => <HelpVideo key={video.id} {...video} lt={lt} />)}</div></>}
          </section>
          {format.startsWith('Rivilė') && <footer className="rounded-lg border border-[#D3E1EC] bg-white p-4"><p className="mb-2 text-[12px] font-semibold">{lt ? 'Oficiali Rivilės dokumentacija' : 'Official Rivilė documentation'}</p><div className="flex flex-wrap gap-x-5 gap-y-2">{RIVILE_GUIDE_SOURCES.filter(item => format === 'Rivilė ERP' ? item.title.includes('ERP') : !item.title.includes('ERP')).map(source => <a key={source.url} href={source.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[11px] text-[#007EA7] underline">{source.title}<ExternalLink size={12} /></a>)}</div></footer>}
          {format === 'Business Central' && <a href="https://learn.microsoft.com/en-us/dynamics365/business-central/finance-posting-groups" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[12px] text-[#007EA7] underline">Microsoft Learn · Posting groups<ExternalLink size={12} /></a>}
        </div>
      </div>
    </div>
  </main>;
}
