import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { supabase, ensureOcrMyTaskExamples, type Company, type DbDocument } from '../lib/supabase';
import { canViewTeamLeadOrganization, canViewTeamLeadWork } from '../lib/ocrTeamLeadAccess';
import { loadSavedReviewDocumentTasks } from '../lib/ocrReviewDocuments';
import { loadLinkedDirectoryUsers } from '../lib/linkedSettingsData';
import { matchesIssueWorker, teamLeadWorkerDirectory, teamLeadWorkerDocumentIds, type OcrWorker } from '../lib/ocrTeamLeadWorkers';
import { OCR_DOCUMENT_WORK_LOG_KEY, type OcrDocumentWorkLog } from './ocrDocumentWorkTimeStore';
import { WorkspaceDocumentEditor, type WorkspaceTask } from './WorkspaceView';
import { ProcessedDocumentsTable, type ReviewDocumentReference } from './OcrProcessedDocumentsView';
import DocumentIssueQueue from './DocumentIssueQueue';
import OcrBreadcrumb from './OcrBreadcrumb';
import { PageHeader } from './PageHeader';
import SearchableSelect from './SearchableSelect';

export default function OcrTeamLeadWorkersView({ initialWorkerEmail = '', onBack }: {
  initialWorkerEmail?: string; onBack: () => void;
}) {
  const [workerEmail, setWorkerEmail] = useState(initialWorkerEmail);
  const [tab, setTab] = useState<'tasks' | 'issues'>('tasks');
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [tasks, setTasks] = useState<Map<string, WorkspaceTask | undefined>>(new Map());
  const [workLog, setWorkLog] = useState<OcrDocumentWorkLog>({});
  const [workers, setWorkers] = useState<OcrWorker[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [editingIssue, setEditingIssue] = useState(false);
  const [viewed, setViewed] = useState<{ reference: ReviewDocumentReference; position: number; total: number; task?: WorkspaceTask } | null>(null);
  const load = useCallback(async () => {
    try {
      if (!canViewTeamLeadWork()) throw new Error('You no longer have access to TeamLead.');
      await ensureOcrMyTaskExamples();
      const [companyResult, documentResult] = await Promise.all([
        supabase.from('companies').select('*'), supabase.from('documents').select('*'),
      ]);
      if (companyResult.error || documentResult.error) throw new Error('Unable to load worker tasks.');
      const companyIds = new Set((companyResult.data as unknown as Company[]).filter(canViewTeamLeadOrganization).map(company => company.id));
      const nextDocuments = (documentResult.data as unknown as DbDocument[]).filter(document => companyIds.has(document.company_id ?? ''));
      const nextTasks = loadSavedReviewDocumentTasks(nextDocuments, localStorage);
      let nextLog: OcrDocumentWorkLog = {};
      try {
        const stored = JSON.parse(localStorage.getItem(OCR_DOCUMENT_WORK_LOG_KEY) || '{}');
        if (stored && typeof stored === 'object' && !Array.isArray(stored)) nextLog = stored;
      } catch { /* Saved explicit assignments remain available without a legacy work log. */ }
      setDocuments(nextDocuments); setTasks(nextTasks); setWorkLog(nextLog);
      setWorkers(teamLeadWorkerDirectory(nextDocuments, nextTasks, nextLog, loadLinkedDirectoryUsers('Internal users')));
      setError('');
      return { documents: nextDocuments, tasks: nextTasks, workLog: nextLog };
    } catch (reason) {
      setDocuments([]); setTasks(new Map()); setWorkers([]);
      setError(reason instanceof Error ? reason.message : 'Unable to load worker tasks.');
      return null;
    } finally { setLoading(false); }
  }, []);
  useEffect(() => {
    void load();
    const refresh = () => { void load(); };
    const events = ['storage', 'finansu-harmonija:persistent-state-changed', 'finansu-harmonija:data-changed', 'finansu-harmonija:settings-data-changed', 'document-issues-changed'];
    events.forEach(event => window.addEventListener(event, refresh));
    return () => events.forEach(event => window.removeEventListener(event, refresh));
  }, [load]);
  const documentIds = useMemo(() => teamLeadWorkerDocumentIds(documents, tasks, workLog, workerEmail), [documents, tasks, workLog, workerEmail]);
  const issueCount = documents.reduce((count, document) => count + (document.digitization_issues ?? []).filter(issue => matchesIssueWorker(issue, workerEmail)).length, 0);
  const selectedWorker = workers.find(worker => worker.email === workerEmail);
  const options = [{ value: '', label: 'All workers' }, ...workers.map(worker => ({ value: worker.email, label: worker.name, description: worker.email }))];
  if (workerEmail && !selectedWorker) options.push({ value: workerEmail, label: workerEmail });
  const viewDocument = async (reference: ReviewDocumentReference, index: number, queue: ReviewDocumentReference[]) => {
    const current = await load();
    if (!current) return;
    if (!teamLeadWorkerDocumentIds(current.documents, current.tasks, current.workLog, workerEmail).has(reference.id)
      || !current.documents.some(document => document.id === reference.id && document.company_id === reference.companyId)) {
      setError('This document is no longer available for the selected worker.'); return;
    }
    setViewed({ reference, position: index + 1, total: queue.length, task: current.tasks.get(reference.id) });
  };
  return <>
    <div hidden={Boolean(viewed)}>
      <div className={editingIssue ? 'relative min-h-full min-w-0 bg-white' : 'relative flex min-h-full min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]'}>
        {!editingIssue && <>
        <PageHeader title={uiText("Worker tasks")} leading={<button type="button" aria-label={uiText("Back to TeamLead")} onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-md border-2 border-[#D3E1EC] text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><ArrowLeft size={17} /></button>} />
        <OcrBreadcrumb items={['TeamLead', 'Workers', selectedWorker?.name || (workerEmail ? workerEmail : 'All workers')]} />
        <div className="flex flex-wrap items-end gap-5">
          <div className="w-full max-w-[320px] space-y-2"><label className="font-montserrat text-[12px] font-medium text-[#7288A3]">{uiText("Worker")}</label>
            <SearchableSelect value={workerEmail} options={options} onChange={setWorkerEmail} ariaLabel={uiText("Worker")} portalMenu />
          </div>
          <div className="flex min-w-0 gap-5 border-b border-[#D3E1EC]" role="tablist" aria-label={uiText("Worker work")}>
            {([{ key: 'tasks', label: 'Tasks', count: documentIds.size }, { key: 'issues', label: 'Document issues', count: issueCount }] as const).map(item =>
              <button key={item.key} type="button" role="tab" aria-selected={tab === item.key} onClick={() => setTab(item.key)}
                className={`border-b-2 px-1 py-3 font-montserrat text-[13px] font-semibold ${tab === item.key ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3] hover:text-[#007EA7]'}`}>
                {uiText(item.label)}<span className="ml-2 text-[11px] tabular-nums">{item.count}</span>
              </button>)}
          </div>
        </div>
        {error && <p role="alert" className="rounded-lg bg-[#FFF0F0] px-3 py-2 font-montserrat text-[12px] text-[#B42318]">{error}</p>}
        </>}
        <div hidden={tab !== 'tasks'} role="tabpanel" aria-label={uiText("Tasks")}>
          <ProcessedDocumentsTable embedded showAllDocuments teamLead documentIds={documentIds}
            onOpenWorker={worker => setWorkerEmail(worker.email)} onViewDocument={(...args) => void viewDocument(...args)} onRefreshDocuments={load}
            emptyMessage={loading ? uiText('Loading worker tasks…') : uiText('No tasks for the selected worker.')} />
        </div>
        <div hidden={tab !== 'issues'} role="tabpanel" aria-label={uiText("Document issues")}>
          <DocumentIssueQueue teamLeadOverview workerEmail={workerEmail} onOpenWorker={worker => setWorkerEmail(worker.email)} onEditingChange={setEditingIssue} />
        </div>
      </div>
    </div>
    {viewed && <WorkspaceDocumentEditor teamLead key={viewed.reference.id} documentId={viewed.reference.id} companyId={viewed.reference.companyId}
      documentName={viewed.reference.name} savedTask={viewed.task} filePosition={viewed.position} fileTotal={viewed.total}
      readOnly viewNotice="Worker task · Read-only" onBack={() => setViewed(null)} />}
  </>;
}
