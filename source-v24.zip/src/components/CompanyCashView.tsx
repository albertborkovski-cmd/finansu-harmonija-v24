import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Copy, Eye, FilePlus2, Pencil, Plus, Printer } from 'lucide-react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { getCurrentUserName } from '../lib/currentUser';
import { loadLinkedDirectoryUsers } from '../lib/linkedSettingsData';
import { isInactiveRecord } from '../lib/recordLifecycle';
import { loadInvoiceCounterparties } from '../lib/invoiceCreation';
import { loadStornoPeriodPolicy } from '../lib/documentStornoAccess';
import { stornoPeriodError } from '../lib/documentStorno';
import { blankCashDocument, cashAmount, cashBook, cashDocumentLinked, cashId, cashMasterLinked, cashToday, cashTotal, CASH_SECTIONS, copyCashDocument, emptyCash, removeCashRecord, saveCashDocument, saveCashMaster, type CashDocument, type CashKind, type CashMaster, type CashMasterCollection, type CashSection, type CashStore, type CashValidation } from '../lib/cash';
import { CASH_CHANGED, cashHasExternalLinks, cashPermissions, loadCash, updateCash } from '../lib/cashStore';
import { canExtendCashExamples, createCashExamples, extendCashExamples, prepareAliceCashExamples, shouldPrepareAliceCashExamples } from '../lib/cashExamples';
import { cashBookReport, type CashPrintReport } from '../lib/cashPrint';
import { addCompanyGeneralLedgerAccount, loadCompanyGeneralLedgerAccountHierarchy } from './GeneralLedgerView';
import { loadOrganizationReferenceValues } from './OrganizationReferenceValuesView';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import { PageActionButton, PageHeader } from './PageHeader';
import { RowDeleteButton } from './DeleteButtons';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import SearchableSelect from './SearchableSelect';
import GlJournalDialog from './GlJournalDialog';
import WarehouseTable, { type WarehouseTableRow } from './WarehouseTable';
import type { ColConfig } from './ColumnSettingsPanel';
import CashDocumentEditor, { type CashRelatedDocument } from './cash/CashDocumentEditor';
import CashSettingsEditor from './cash/CashSettingsEditor';
import CashPrintPreview from './cash/CashPrintPreview';
import { CashField, CashRowAction, CashStatus, cashInput } from './cash/CashControls';

const col = (key: string, label: string, width = 150, visible = true): ColConfig => ({ key, label, width, visible });
const DOCUMENT_COLUMNS = [col('date', 'Date', 110), col('number', 'Document No.', 165), col('kind', 'Operation type', 180), col('cashAccount', 'Cash account', 170), col('counterparty', 'Counterparty', 190), col('purpose', 'Purpose of payment', 240), col('amount', 'Amount', 120), col('currency', 'Currency', 90), col('status', 'Status', 120), col('glAccount', 'Cash GL account', 135, false), col('cashier', 'Cashier', 160, false), col('accountant', 'Accountant', 160, false), col('createdBy', 'Created by', 170, false), col('createdAt', 'Creation date', 160, false), col('notes', 'Notes', 240, false)];
const ACCOUNT_COLUMNS = [col('code', 'Code', 120), col('name', 'Cash account', 240), col('glAccount', 'GL account', 170), col('currency', 'Currency', 100), col('status', 'Status', 120)];
const PEOPLE_COLUMNS = [col('name', 'Full name', 230), col('role', 'Responsibility', 160), col('cashAccount', 'Cash account', 230), col('validFrom', 'Valid from', 125), col('validTo', 'Valid to', 125), col('status', 'Status', 120)];
const SERIES_COLUMNS = [col('prefix', 'Series', 150), col('kind', 'Operation type', 220), col('nextNumber', 'Next number', 130), col('digits', 'Number length', 130), col('preview', 'Next document No.', 210), col('status', 'Status', 120)];
const BOOK_COLUMNS = [col('date', 'Date', 110), col('number', 'Document No.', 170), col('counterparty', 'Counterparty', 210), col('purpose', 'Purpose of payment', 250), col('income', 'Income', 120), col('expense', 'Expense', 120), col('balance', 'Balance', 130), col('currency', 'Currency', 90)];
const monthStart = () => cashToday().slice(0, 7) + '-01';
const activeUsers = () => loadLinkedDirectoryUsers('Internal users').filter(row => !isInactiveRecord(row) && !['Blocked', 'Unactivated'].includes(row.status || '')).map(row => ({ id: row.id, name: row.fullName || row.email || row.username || row.id }));

export default function CompanyCashView({ company, section, onSectionChange }: { company: Company; section: CashSection; onSectionChange: (section: CashSection) => void }) {
  const [store, setStore] = useState<CashStore>(() => emptyCash(company.id));
  const [loadError, setLoadError] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [editor, setEditor] = useState<{ record: CashDocument; readOnly: boolean; revision: number } | null>(null);
  const [master, setMaster] = useState<{ collection: CashMasterCollection; record: CashMaster; revision: number } | null>(null);
  const [confirm, setConfirm] = useState<{ collection: CashMasterCollection | 'documents'; id: string; label: string; linked: boolean; revision: number } | null>(null);
  const [seedConfirm, setSeedConfirm] = useState(false);
  const [printPreview, setPrintPreview] = useState<CashPrintReport | null>(null);
  const [accountId, setAccountId] = useState('');
  const [from, setFrom] = useState(monthStart);
  const [to, setTo] = useState(cashToday);
  const [relatedDocuments, setRelatedDocuments] = useState<CashRelatedDocument[]>([]);
  const permissions = cashPermissions(company);
  const title = CASH_SECTIONS.find(row => row.id === section)!.label;
  const actor = getCurrentUserName();
  const refresh = useCallback(() => {
    try { setStore(loadCash(company.id)); setLoadError(''); } catch (cause) { setLoadError((cause as Error).message); }
  }, [company.id]);
  useEffect(() => { refresh(); window.addEventListener(CASH_CHANGED, refresh); window.addEventListener('storage', refresh); return () => { window.removeEventListener(CASH_CHANGED, refresh); window.removeEventListener('storage', refresh); }; }, [refresh]);
  useEffect(() => {
    if (!permissions.view) return;
    let cancelled = false;
    void (async () => {
      const result = await supabase.from('documents').select('*').eq('company_id', company.id);
      if (cancelled) return;
      if (result.error) { setError('Related documents could not be loaded. Cash records remain available.'); return; }
      setRelatedDocuments(((result.data || []) as unknown as DbDocument[]).filter(row => row.company_id === company.id && !isInactiveRecord(row) && !!row.number).map(row => ({ id: row.id, number: row.number || '', label: `${row.number} · ${row.client_counterparty || '—'}`, currency: row.currency || '', counterparty: row.client_counterparty || '' })));
    })().catch(() => { if (!cancelled) setError('Related documents could not be loaded.'); });
    return () => { cancelled = true; };
  }, [company.id, permissions.view]);
  const chart = useMemo(() => loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger || ''), [company.id, company.general_ledger, store.revision]);
  const users = activeUsers();
  const currencies = loadOrganizationReferenceValues('Base currency');
  const glOptions = chart.map(row => ({ value: row.code, label: `${row.code} · ${row.name}` }));
  const validation = (period = true): CashValidation => ({ activeGlAccounts: loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger || '').map(row => row.code), activeUserIds: activeUsers().map(row => row.id), currencies: loadOrganizationReferenceValues('Base currency'), relatedDocuments, ...(period ? { periodError: (date: string) => stornoPeriodError(date, date, cashToday(), loadStornoPeriodPolicy(company.id)).replace('reversal date', 'cash document date') || null } : {}) });
  const selectedAccount = store.accounts.find(row => row.id === accountId) || store.accounts.find(row => !row.inactive) || store.accounts[0];
  const book = useMemo(() => {
    if (!selectedAccount) return { result: null, error: '' };
    try { return { result: cashBook(store, selectedAccount.id, from, to), error: '' }; } catch (cause) { return { result: null, error: (cause as Error).message }; }
  }, [store, selectedAccount, from, to]);
  const rows = useMemo<WarehouseTableRow[]>(() => {
    const accountName = (id: string) => store.accounts.find(row => row.id === id)?.name || '—';
    if (section === 'accounts') return store.accounts.map(row => ({ ...row, status: row.inactive ? 'Inactive' : 'Active' }));
    if (section === 'people') return store.people.map(row => ({ ...row, cashAccount: accountName(row.accountId), validTo: row.validTo || '—', status: row.inactive ? 'Inactive' : 'Active' }));
    if (section === 'series') return store.series.map(row => ({ ...row, preview: `${row.prefix}-${String(row.nextNumber).padStart(row.digits, '0')}`, status: row.inactive ? 'Inactive' : 'Active' }));
    if (section === 'book') return (book.result?.rows || []).map(row => ({ id: row.document.id, date: row.document.date, number: row.document.number, counterparty: row.document.counterparty, purpose: row.document.purpose, income: row.income / 100, expense: row.expense / 100, balance: row.balance / 100, currency: row.document.currency }));
    return store.documents.filter(row => section === 'receipts' ? row.kind === 'Money receipt' : row.kind !== 'Money receipt').sort((a, b) => b.date.localeCompare(a.date) || b.number.localeCompare(a.number)).map(row => ({ id: row.id, number: row.number, date: row.date, kind: row.kind, cashAccount: accountName(row.accountId), counterparty: row.counterparty, purpose: row.purpose, amount: cashTotal(row) / 100 * (row.kind === 'Cash expense order' ? -1 : 1), currency: row.currency, status: row.inactive ? 'Inactive' : row.status, inactive: row.inactive, glAccount: row.cashGlAccount, cashier: row.cashier, accountant: row.accountant, createdBy: row.createdBy, createdAt: row.createdAt, notes: row.notes }));
  }, [section, store, book]);
  const columns = section === 'accounts' ? ACCOUNT_COLUMNS : section === 'people' ? PEOPLE_COLUMNS : section === 'series' ? SERIES_COLUMNS : section === 'book' ? BOOK_COLUMNS : DOCUMENT_COLUMNS;
  const collection: CashMasterCollection | null = ['accounts', 'people', 'series'].includes(section) ? section as CashMasterCollection : null;
  const newDocument = (kind: CashKind) => setEditor({ record: blankCashDocument(store, kind, actor), readOnly: false, revision: store.revision });
  const newMaster = () => {
    if (!collection) return;
    const base = { id: cashId(), companyId: company.id, revision: 0, inactive: false };
    const record: CashMaster = collection === 'accounts' ? { ...base, code: '', name: '', glAccount: '', currency: company.base_currency || 'EUR' } : collection === 'people' ? { ...base, accountId: selectedAccount?.id || '', userId: '', name: '', role: 'Cashier', validFrom: cashToday(), validTo: '' } : { ...base, prefix: '', kind: 'Cash income order', nextNumber: 1, digits: 6 };
    setMaster({ collection, record, revision: store.revision });
  };
  const mutate = (revision: number, action: 'edit' | 'create' | 'delete', change: (current: CashStore) => CashStore, success: string) => {
    const next = updateCash(company, revision, action, change); setStore(next); setMessage(success); setError(''); return next;
  };
  const loadExamples = useCallback((automatic = false) => {
    const chartKey = `finansu-harmonija:v12:company-general-ledger:${company.id}`;
    const previousChart = localStorage.getItem(chartKey);
    let writtenChart: string | null = null;
    try {
      const latest = loadCash(company.id);
      if (automatic && !shouldPrepareAliceCashExamples(company, latest)) return;
      // Only the company's copy is extended, never the shared Settings template.
      if (previousChart) JSON.parse(previousChart);
      const next = updateCash(company, latest.revision, 'create', current => {
        const currentValidation: CashValidation = { activeGlAccounts: loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger || '').map(row => row.code), activeUserIds: activeUsers().map(row => row.id), currencies: loadOrganizationReferenceValues('Base currency') };
        if (!automatic && canExtendCashExamples(current)) return extendCashExamples(current, currentValidation, actor, cashToday());
        if (!automatic && (current.accounts.length || current.documents.length || current.people.length || current.series.length)) throw new Error('Cash records can only be added to an empty or previously initialized cash workspace.');
        const planned = [
          ...(!currentValidation.activeGlAccounts.some(code => /^27/.test(code)) ? [{ code: '2720', name: 'Cash on hand', parentCode: '2' }] : []),
          ...(!currentValidation.activeGlAccounts.some(code => /^24/.test(code)) ? [{ code: '2411', name: 'Trade receivables', parentCode: '2' }] : []),
          ...(!currentValidation.activeGlAccounts.some(code => /^6\d/.test(code)) ? [{ code: '6300', name: 'Operating expenses', parentCode: '6' }] : []),
        ];
        const preparedValidation = { ...currentValidation, activeGlAccounts: [...currentValidation.activeGlAccounts, ...planned.map(row => row.code)] };
        const sample = automatic ? prepareAliceCashExamples(current, preparedValidation, activeUsers(), cashToday()) : createCashExamples(company.id, preparedValidation, activeUsers(), cashToday());
        for (const account of planned.filter(account => sample.accounts.some(row => row.glAccount === account.code) || sample.documents.some(row => row.lines.some(line => line.account === account.code)))) {
          if (!addCompanyGeneralLedgerAccount(company.id, company.general_ledger || '', account)) throw new Error(`GL account ${account.code} could not be added. Check the company chart of accounts.`);
          writtenChart = localStorage.getItem(chartKey);
        }
        return sample;
      });
      setStore(next); setError('');
      if (!automatic) setMessage('Cash records added.');
      setSeedConfirm(false);
    } catch (cause) {
      if (writtenChart && localStorage.getItem(chartKey) === writtenChart) {
        if (previousChart === null) localStorage.removeItem(chartKey); else localStorage.setItem(chartKey, previousChart);
        window.dispatchEvent(new CustomEvent('company-general-ledger-updated', { detail: { companyId: company.id } }));
      }
      setError((cause as Error).message);
    }
  }, [company, actor]);
  useEffect(() => {
    if (permissions.create) loadExamples(true);
  }, [company.id, permissions.create, loadExamples]);
  const askRemove = (collection: CashMasterCollection | 'documents', record: CashDocument | CashMaster, label: string) => {
    setError(''); setConfirm({ collection, id: record.id, label, revision: store.revision, linked: (collection === 'documents' ? cashDocumentLinked(store, record.id) : cashMasterLinked(store, collection, record.id)) || cashHasExternalLinks(record) });
  };
  const renderActions = (row: WarehouseTableRow) => {
    const document = store.documents.find(item => item.id === row.id);
    if (document) return <>
      <CashRowAction label={`View ${document.number}`} onClick={() => setEditor({ record: document, readOnly: true, revision: store.revision })}><Eye size={14} /></CashRowAction>
      {section !== 'book' && <>
        <CashRowAction label={`${uiText('Edit')} ${document.number}`} disabled={!permissions.edit || document.status !== 'Draft' || document.inactive} onClick={() => {
          if (!permissions.edit || document.status !== 'Draft' || document.inactive) return;
          setEditor({ record: document, readOnly: false, revision: store.revision });
        }}><Pencil size={14} /></CashRowAction>
        {permissions.create && <CashRowAction label={`Copy ${document.number}`} onClick={() => setEditor({ record: copyCashDocument(store, document, actor), readOnly: false, revision: store.revision })}><Copy size={14} /></CashRowAction>}{permissions.create && document.kind === 'Money receipt' && document.status === 'Approved' && !document.inactive && !store.documents.some(item => item.receiptId === document.id) && <CashRowAction label={`Create income order from ${document.number}`} onClick={() => setEditor({ record: copyCashDocument(store, document, actor, true), readOnly: false, revision: store.revision })}><FilePlus2 size={14} /></CashRowAction>}{permissions.delete && <RowDeleteButton label={`Delete ${document.number}`} linked={cashDocumentLinked(store, document.id) || cashHasExternalLinks(document)} inactive={document.inactive} onDelete={() => askRemove('documents', document, document.number)} />}
      </>}
    </>;
    if (!collection) return null;
    const record = store[collection].find(item => item.id === row.id)!;
    return <>{permissions.edit && !record.inactive && <CashRowAction label={`Edit ${row.name || row.prefix}`} onClick={() => setMaster({ collection, record, revision: store.revision })}><Pencil size={14} /></CashRowAction>}{permissions.delete && <RowDeleteButton label={`Delete ${row.name || row.prefix}`} linked={cashMasterLinked(store, collection, row.id) || cashHasExternalLinks(record)} inactive={record.inactive} onDelete={() => askRemove(collection, record, String(row.name || row.prefix))} />}</>;
  };
  if (!permissions.view) return <p role="alert" className="p-10 text-[13px]">{uiText("You do not have access to this company’s cash workspace.")}</p>;
  return <div className="flex h-full min-h-0 min-w-0 flex-col gap-4 bg-white px-4 py-10 font-montserrat text-[#10233A] sm:px-8 lg:px-[56px]">
    <PageHeader title={uiText(title)} className="!h-auto !flex-wrap [&>div:first-child]:min-w-[min(100%,260px)] [&>div:last-child]:max-w-full [&>div:last-child]:flex-wrap" actions={<>
      {permissions.create && !loadError && <>{(!store.accounts.length || canExtendCashExamples(store)) && <PageActionButton onClick={() => setSeedConfirm(true)}>{uiText("Add records")}</PageActionButton>}{collection ? <PageActionButton icon={<Plus size={15} />} onClick={newMaster}>{section === 'accounts' ? uiText('New cash account') : section === 'people' ? uiText('Assign person') : uiText('New series')}</PageActionButton> : section === 'transactions' ? <><PageActionButton icon={<Plus size={15} />} onClick={() => newDocument('Cash income order')}>{uiText("Income order")}</PageActionButton><PageActionButton icon={<Plus size={15} />} onClick={() => newDocument('Cash expense order')}>{uiText("Expense order")}</PageActionButton></> : section === 'receipts' ? <PageActionButton icon={<Plus size={15} />} onClick={() => newDocument('Money receipt')}>{uiText("New receipt")}</PageActionButton> : null}</>}
      {section === 'book' && <PageActionButton icon={<Printer size={15} />} disabled={!book.result || !!loadError} onClick={() => { try { setPrintPreview(cashBookReport(store, selectedAccount!.id, from, to, company.name)); } catch (cause) { setError((cause as Error).message); } }}>{uiText("Print cash book")}</PageActionButton>}
    </>} />
    <CompanyBreadcrumb companyName={company.name} items={['Cash', title]} />
    {(loadError || error) && <p role="alert" className="rounded-lg bg-red-50 p-3 text-[12px] text-red-700">{loadError || error}</p>}
    {message && <p role="status" className="text-[12px] text-[#23744F]">{message}</p>}
    {!store.accounts.length && !loadError && <div data-table-workspace-overview className="flex flex-wrap items-center gap-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3 text-[12px]"><span>{uiText("Start with a cash account, responsible persons and document series.")}</span>{(['accounts', 'people', 'series'] as const).map(key => <button key={key} type="button" onClick={() => onSectionChange(key)} className="text-[#007EA7] hover:underline">{CASH_SECTIONS.find(row => row.id === key)?.label}</button>)}</div>}
    {section === 'book' && <>
      <div className="grid shrink-0 gap-3 sm:grid-cols-[minmax(220px,1fr)_180px_180px]"><CashField label={uiText("Cash account")}><SearchableSelect portalMenu ariaLabel={uiText("Cash book account")} className={cashInput} value={selectedAccount?.id || ''} options={store.accounts.map(row => ({ value: row.id, label: `${row.code} · ${row.name} · ${row.currency}${row.inactive ? ' (Inactive)' : ''}` }))} onChange={setAccountId} /></CashField><CashField label={uiText("From")}><input aria-label={uiText("Cash book from")} className={cashInput} type="date" value={from} onChange={event => setFrom(event.target.value)} /></CashField><CashField label={uiText("To")}><input aria-label={uiText("Cash book to")} className={cashInput} type="date" value={to} onChange={event => setTo(event.target.value)} /></CashField></div>
      {book.error && <p role="alert" className="text-[12px] text-red-700">{book.error}</p>}
      {book.result && <div data-table-workspace-overview className="grid shrink-0 grid-cols-2 gap-4 rounded-xl border border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3 lg:grid-cols-4">{([['Opening balance', book.result.opening], ['Income', book.result.income], ['Expense', book.result.expense], ['Closing balance', book.result.closing]] as const).map(([label, amount]) => <div key={label}><span className="text-[11px] text-[#7288A3]">{uiText(label)}</span><p className="mt-1 text-[16px] font-semibold tabular-nums">{cashAmount(amount)} <span className="text-[11px] font-medium text-[#7288A3]">{selectedAccount?.currency}</span></p></div>)}</div>}
    </>}
    <WarehouseTable scope={`finansu-harmonija:v22:cash-table:${company.id}:${section}`} title={uiText(title)} rows={loadError ? [] : rows} defaults={columns} selected={selected} onSelectedChange={setSelected} onRefresh={refresh} actions={renderActions} renderCell={(row, key) => key === 'status' ? <CashStatus status={String(row.status)} /> : key === 'number' ? <button type="button" className="text-[#007EA7] hover:underline" onClick={() => { const record = store.documents.find(item => item.id === row.id); if (record) setEditor({ record, readOnly: true, revision: store.revision }); }}>{row.number}</button> : ['amount', 'income', 'expense', 'balance'].includes(key) ? <span className="tabular-nums">{key === 'amount' && Number(row[key]) > 0 ? '+' : ''}{Number(row[key]).toFixed(2)}</span> : undefined} />
    {editor && <CashDocumentEditor initial={editor.record} store={store} companyName={company.name} readOnly={editor.readOnly || !permissions.edit} glAccounts={glOptions} counterparties={[company.name, ...loadInvoiceCounterparties(company.id).filter(row => !isInactiveRecord(row)).map(row => row.name), ...relatedDocuments.map(row => row.counterparty), ...store.documents.map(row => row.counterparty)]} relatedDocuments={relatedDocuments} onClose={() => setEditor(null)} onSave={(draft, approve) => { mutate(editor.revision, draft.revision ? 'edit' : 'create', current => saveCashDocument(current, draft, approve, actor, validation()), approve ? 'Cash document approved.' : 'Cash draft saved.'); setEditor(null); }} />}
    {master && <CashSettingsEditor collection={master.collection} initial={master.record} store={store} glAccounts={glOptions} users={users.map(row => ({ value: row.id, label: row.name }))} currencies={currencies} onClose={() => setMaster(null)} onSave={record => { mutate(master.revision, record.revision ? 'edit' : 'create', current => saveCashMaster(current, master.collection, record, actor, validation(false)), 'Cash settings saved.'); setMaster(null); }} />}
    {confirm && <GlJournalDialog title={`${confirm.linked ? 'Deactivate' : 'Delete'} record`} onClose={() => setConfirm(null)} footer={<><CancelButton onClick={() => setConfirm(null)}>{uiText("Cancel")}</CancelButton><SaveButton onClick={() => { try { mutate(confirm.revision, 'delete', current => { const record = current[confirm.collection].find(row => row.id === confirm.id); if (!record) throw new Error('This record no longer exists.'); return removeCashRecord(current, confirm.collection, confirm.id, actor, cashHasExternalLinks(record)); }, confirm.linked ? 'Record deactivated. History retained.' : 'Unused record deleted.'); setConfirm(null); } catch (cause) { setError((cause as Error).message); } }}>{confirm.linked ? uiText('Deactivate') : uiText('Delete')}</SaveButton></>}><p className="text-[13px] leading-6">{confirm.label}{confirm.linked ? uiText(' will remain visible as inactive. Approved accounting movements and cash book balances remain unchanged.') : uiText(' is unused and will be deleted. Its action history and number reservation are retained.')}</p>{error && <p role="alert" className="mt-3 text-[12px] text-red-700">{error}</p>}</GlJournalDialog>}
    {seedConfirm && <GlJournalDialog title={uiText("Add cash records")} onClose={() => setSeedConfirm(false)} footer={<><CancelButton onClick={() => setSeedConfirm(false)}>{uiText("Cancel")}</CancelButton><SaveButton onClick={() => loadExamples()}>{uiText("Add records")}</SaveButton></>}><div className="space-y-3 text-[13px] leading-6"><p>{uiText("Add cash income and expense orders with different counterparties, amounts and statuses for ")}{company.name}{uiText(". Existing amounts and document numbers are retained.")}</p>{!store.accounts.length && <p>{uiText("Cash accounts, responsible persons and KPO / KIO / PPK series will also be prepared. If required, accounts 2720, 2411 and 6300 will be added to this company’s chart. The shared GL template remains unchanged.")}</p>}</div>{error && <p role="alert" className="mt-3 text-[12px] text-red-700">{error}</p>}</GlJournalDialog>}
    {printPreview && <CashPrintPreview report={printPreview} onClose={() => setPrintPreview(null)} />}
  </div>;
}
