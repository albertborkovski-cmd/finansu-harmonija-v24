import { useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, ClipboardPaste, Loader2, Save } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { EXPENSE_CODE_TYPES, expenseCodeRowErrors, parseExpenseCodePaste, type ExpenseCodeDraft, type ExpenseCodeType } from '../lib/companyExpenseImport';
import { importCompanyExpenseCodes, type LedgerAccount } from './GeneralLedgerView';
import { PageActionButton } from './PageHeader';
import SearchableSelect from './SearchableSelect';

const emptyRow = (): ExpenseCodeDraft => ({ code: '', name: '', alternativeCodes: '' });
const inputClass = 'h-[42px] w-full rounded-lg border border-[#D3E1EC] bg-white px-3 font-montserrat text-[13px] text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-1 focus:ring-[#007EA7]/20 disabled:bg-[#F5F8FB]';
const pageSize = 20;

/** Inline in the fixed organization workspace, so entering/pasting codes never resizes the dialog. */
export default function CompanyExpenseCodeEditor({ companyId, templateName, accounts, mode, canEdit, onCancel, onSaved }: {
  companyId: string; templateName: string; accounts: LedgerAccount[]; mode: 'manual' | 'excel'; canEdit: boolean;
  onCancel: () => void; onSaved: (count: number) => void;
}) {
  const language = useLanguage();
  const [type, setType] = useState<ExpenseCodeType>('Code');
  const [text, setText] = useState(''), [rows, setRows] = useState<ExpenseCodeDraft[]>(mode === 'manual' ? [emptyRow()] : []);
  const [parseError, setParseError] = useState(''), [saveError, setSaveError] = useState('');
  const [busy, setBusy] = useState(false), [page, setPage] = useState(0);
  const pending = useRef(false);
  const initialTemplateName = useRef(templateName);
  const errors = useMemo(() => expenseCodeRowErrors(rows, accounts), [rows, accounts]);
  const invalidCount = errors.filter(row => row.length).length;
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const options = EXPENSE_CODE_TYPES.map(value => ({ value, label: value === 'Product' && language === 'lt' ? 'Prekė' : t(value) }));
  const updateRow = (index: number, field: keyof ExpenseCodeDraft, value: string) => {
    setRows(previous => previous.map((row, current) => current === index ? { ...row, [field]: value } : row)); setSaveError('');
  };
  const paste = (value: string) => {
    setText(value); setPage(0); setSaveError('');
    try { setRows(parseExpenseCodePaste(value)); setParseError(''); }
    catch (error) { setRows([]); setParseError(error instanceof Error ? error.message : 'Could not read the pasted codes.'); }
  };
  const save = async () => {
    if (pending.current || !canEdit || parseError || invalidCount || !rows.length) return;
    pending.current = true; setBusy(true); setSaveError('');
    try { const created = await importCompanyExpenseCodes(companyId, initialTemplateName.current, rows, type); onSaved(created.length); }
    catch (error) { setSaveError(error instanceof Error ? error.message : 'Could not save the codes.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return <section className="flex h-full min-h-0 flex-col gap-4 font-montserrat" aria-label={t(mode === 'manual' ? 'New expense' : 'Import from Excel')}>
    <div className="flex shrink-0 items-center gap-3 border-b border-[#E5EDF9] pb-3">
      <PageActionButton onClick={onCancel} disabled={busy} iconOnly className="!p-0" icon={<ChevronLeft size={16} className="shrink-0" />} ariaLabel={t('Back to chart of accounts')}>{t('Back')}</PageActionButton>
      <div><h3 className="text-[15px] font-semibold text-[#10233A]">{t(mode === 'manual' ? 'New expense' : 'Import from Excel')}</h3>
        <p className="mt-1 text-[11px] leading-4 text-[#7288A3]">{t('Codes are saved only for this organization. The shared template stays unchanged.')}</p></div>
    </div>
    <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-3 [scrollbar-gutter:stable]">
      <fieldset disabled={busy || !canEdit} className="min-w-0 space-y-4">
        {mode === 'manual' ? <div className="grid grid-cols-1 gap-4 md:grid-cols-[minmax(160px,1fr)_minmax(220px,2fr)]">
          {(['code', 'name'] as const).map(field => <label key={field} className="space-y-1.5 text-[12px] font-medium text-[#7288A3]">
            <span>{t(field === 'code' ? 'Code' : 'Name')} <span className="text-[#B42318]">*</span></span>
            <input autoFocus={field === 'code'} required aria-label={t(field === 'code' ? 'Code' : 'Name')} className={inputClass} value={rows[0][field]} maxLength={field === 'code' ? 100 : 1000} onChange={event => updateRow(0, field, event.target.value)} />
          </label>)}
          <div className="space-y-1.5"><p className="text-[12px] font-medium text-[#7288A3]">{t('Type')} <span className="text-[#B42318]">*</span></p>
            <SearchableSelect ariaLabel={t('Type')} value={type} options={options} onChange={value => setType(value as ExpenseCodeType)} disabled={busy || !canEdit} portalMenu />
          </div>
          <label className="space-y-1.5 text-[12px] font-medium text-[#7288A3]"><span>{t('Alternative codes')}</span>
            <input aria-label={t('Alternative codes')} className={inputClass} value={rows[0].alternativeCodes} maxLength={2000} onChange={event => updateRow(0, 'alternativeCodes', event.target.value)} placeholder={t('Separate codes with commas or semicolons')} />
          </label>
          {(rows[0].code || rows[0].name) && errors[0].length > 0 && <p role="alert" className="text-[12px] text-[#B42318] md:col-span-2">{errors[0].map(error => t(error)).join(' ')}</p>}
        </div> : <>
          <p className="text-[12px] leading-5 text-[#7288A3]">{t('Column A: Code. Column B: Name or description. Copy both columns and paste here.')}</p>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-[minmax(0,1fr)_220px]">
            <label className="space-y-2 text-[12px] font-medium text-[#7288A3]"><span>{t('Paste codes from Excel')}</span>
              <textarea autoFocus rows={3} spellCheck={false} aria-label={t('Paste codes from Excel')} value={text} onChange={event => paste(event.target.value)}
                placeholder={t('Code\tName\n001\tAccounting services\n002\tOffice supplies')} className={`${inputClass} h-[84px] resize-none py-2 leading-5`} />
            </label>
            <div className="space-y-2"><p className="text-[12px] font-medium text-[#7288A3]">{t('Type for imported codes')} <span className="text-[#B42318]">*</span></p>
              <SearchableSelect ariaLabel={t('Type for imported codes')} value={type} options={options} onChange={value => setType(value as ExpenseCodeType)} disabled={busy || !canEdit} portalMenu />
            </div>
          </div>
          {parseError && <p role="alert" className="text-[12px] text-[#B42318]">{t(parseError)}</p>}
          {rows.length > 0 && <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-[12px]"><h4 className="font-semibold">{t('Import preview')} · {rows.length}</h4>
              <span role="status" className={invalidCount ? 'text-[#B42318]' : 'text-[#7288A3]'}>{invalidCount ? `${t('Rows to correct')}: ${invalidCount}` : t('Ready to import')}</span></div>
            <div className="max-h-[310px] overflow-auto rounded-lg border border-[#D3E1EC]">
              <table className="w-full min-w-[550px] border-collapse text-left text-[12px]"><thead className="sticky top-0 z-10 bg-[#F2F6FA] text-[#7288A3]"><tr>
                <th className="w-12 px-3 py-2">#</th><th className="w-[28%] px-3 py-2">{t('Code')}</th><th className="px-3 py-2">{t('Name')}</th>
              </tr></thead><tbody>{rows.slice(page * pageSize, (page + 1) * pageSize).map((row, offset) => {
                const index = page * pageSize + offset;
                return <tr key={index} className={`border-t border-[#E5EDF9] ${errors[index].length ? 'bg-[#FFF9F5]' : 'bg-white'}`}>
                  <td className="px-3 py-2 align-top text-[#7288A3]">{index + 1}</td>
                  {(['code', 'name'] as const).map(field => <td key={field} className="px-2 py-1.5 align-top"><input className={`${inputClass} !h-9`} aria-label={`${t(field === 'code' ? 'Code' : 'Name')} ${index + 1}`} aria-invalid={errors[index].length > 0} value={row[field]} onChange={event => updateRow(index, field, event.target.value)} />
                    {field === 'code' && errors[index].length > 0 && <p className="mt-1 text-[10px] leading-4 text-[#B42318]">{errors[index].map(error => t(error)).join(' ')}</p>}</td>)}
                </tr>;
              })}</tbody></table>
            </div>
            {pageCount > 1 && <div className="flex items-center justify-end gap-2 text-[12px] text-[#7288A3]">
              <PageActionButton iconOnly className="!p-0" ariaLabel={t('Previous page')} icon={<ChevronLeft size={15} className="shrink-0" />} disabled={page === 0 || busy} onClick={() => setPage(previous => previous - 1)}>{t('Previous')}</PageActionButton>
              <span>{page + 1} / {pageCount}</span>
              <PageActionButton iconOnly className="!p-0" ariaLabel={t('Next page')} icon={<ChevronRight size={15} className="shrink-0" />} disabled={page + 1 === pageCount || busy} onClick={() => setPage(previous => previous + 1)}>{t('Next')}</PageActionButton>
            </div>}
          </div>}
        </>}
      </fieldset>
      {saveError && <p role="alert" className="rounded-lg border border-[#E8D3AC] bg-[#FFF9EE] px-3 py-2 text-[12px] text-[#926317]">{t(saveError)}</p>}
    </div>
    <footer className="flex shrink-0 items-center justify-end gap-2 border-t border-[#E5EDF9] pt-3">
      <PageActionButton disabled={busy} onClick={onCancel}>{t('Cancel')}</PageActionButton>
      <PageActionButton disabled={busy || !canEdit || !rows.length || Boolean(parseError) || invalidCount > 0} onClick={() => void save()}
        icon={busy ? <Loader2 size={15} className="animate-spin" /> : mode === 'excel' ? <ClipboardPaste size={15} /> : <Save size={15} />}>
        {t(busy ? 'Saving…' : mode === 'excel' ? 'Import' : 'Save')}
      </PageActionButton>
    </footer>
  </section>;
}
