import { useEffect, useState } from 'react';
import { translateUi as t } from '../i18n/language';
import { supabase, type Company } from '../lib/supabase';
import { ADDITIONAL_DOCUMENT_COLUMNS, type AdditionalColumnRule } from '../lib/documentAdditionalColumns';
import type { ExportColumn } from '../lib/exportFormatSchemas';
import { documentAssignmentOptions, type DocumentAssignmentOptions } from '../lib/documentBulkAssignment';
import { loadLinkedDirectoryUsers } from '../lib/linkedSettingsData';
import SearchableSelect from './SearchableSelect';
import ExportSettingsHelpLink from './ExportSettingsHelpLink';

export default function AdditionalColumnSettings({ company, value, disabled, onChange, helpFormat, columns = ADDITIONAL_DOCUMENT_COLUMNS.map(column => ({ ...column, sourceKey: column.key })) }: {
  company: Company; value: Record<string, AdditionalColumnRule>; disabled: boolean; onChange: (value: Record<string, AdditionalColumnRule>) => void; columns?: readonly ExportColumn[]; helpFormat?: string;
}) {
  const [options, setOptions] = useState<DocumentAssignmentOptions | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let cancelled = false;
    void Promise.all([supabase.from('lookup_values').select('*'), import('./GeneralLedgerView'), import('./VatClassificationsView')]).then(([result, ledger, vat]) => {
      if (result.error) throw new Error(result.error.message);
      const next = documentAssignmentOptions(company, result.data || [], ledger.loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger), vat.loadVatClassifications(), [], loadLinkedDirectoryUsers('Internal users'));
      if (!cancelled) { setOptions(next); setError(''); }
    }).catch(() => { if (!cancelled) setError('Could not load default value options.'); });
    return () => { cancelled = true; };
  }, [company]);
  const update = (key: string, patch: Partial<AdditionalColumnRule>) => onChange({ ...value, [key]: { ...value[key], ...patch } });
  return <div data-additional-column-settings>
    <p className="mb-3 text-[12px] leading-5 text-[#7288A3]">{t('Required fields show a warning when empty. Automatic assignment fills empty fields only, at the selected assignment stage.')}</p>
    <div className="overflow-x-auto rounded-md border border-[#D3E1EC]">
      <table className="w-full min-w-[580px] table-fixed text-left text-[12px] text-[#10233A]">
        <colgroup><col className="w-[25%]" /><col className="w-[14%]" /><col className="w-[23%]" /><col className="w-[38%]" /></colgroup>
        <thead className="bg-[#F2F6FA] text-[#7288A3]"><tr><th className="px-3 py-3 font-medium">{t('Field')}</th>{['Required', 'Assign automatically', 'Default value'].map(label => <th key={label} className={`px-2 py-3 font-medium ${label === 'Default value' ? 'text-left' : 'text-center'}`}><span className="inline-flex items-center gap-1.5">{t(label)}{helpFormat && <ExportSettingsHelpLink format={helpFormat} topic={label} label={label} />}</span></th>)}</tr></thead>
        <tbody>{columns.map(column => {
          const rule = value[column.key] || { required: false, automatic: false, defaultValue: '', defaultLabel: '' };
          const choices = column.sourceKey ? options?.[column.sourceKey] || [] : [];
          const existing = rule.defaultValue && !choices.some(option => option.value === rule.defaultValue)
            ? [{ value: rule.defaultValue, label: rule.defaultLabel || rule.defaultValue, disabled: true }] : [];
          return <tr key={column.key} className="border-t border-[#E5EDF9] hover:bg-[#F7FBFD]">
            <th scope="row" className="px-3 py-2.5 font-medium">{t(column.label)}</th>
            <td className="px-2 text-center"><input type="checkbox" aria-label={`${t(column.label)} · ${t('Required')}`} checked={rule.required} disabled={disabled} onChange={event => update(column.key, { required: event.target.checked })} /></td>
            <td className="px-2 text-center"><input type="checkbox" aria-label={`${t(column.label)} · ${t('Assign automatically')}`} checked={rule.automatic} disabled={disabled} onChange={event => update(column.key, { automatic: event.target.checked })} /></td>
            <td className="px-3 py-2">{column.key === 'note' || !column.sourceKey
              ? <input aria-label={`${t(column.label)} · ${t('Default value')}`} maxLength={500} value={rule.defaultValue} disabled={disabled} placeholder="—" onChange={event => update(column.key, { defaultValue: event.target.value, defaultLabel: '' })} className="h-8 w-full rounded border border-[#D3E1EC] bg-transparent px-2 font-montserrat text-[12px] outline-none focus:border-[#007EA7]" />
              : <SearchableSelect value={rule.defaultValue} options={[{ value: '', label: '—' }, ...existing, ...choices]} disabled={disabled || !options} ariaLabel={`${t(column.label)} · ${t('Default value')}`} onChange={next => update(column.key, { defaultValue: next, defaultLabel: choices.find(option => option.value === next)?.label || '' })} portalMenu menuClassName="!z-[1300]" className="h-8 rounded border border-[#D3E1EC] bg-transparent px-2 pr-8 font-montserrat text-[12px] text-[#10233A]" />}</td>
          </tr>;
        })}</tbody>
      </table>
    </div>
    {error && <p role="alert" className="mt-2 text-[12px] text-[#B42318]">{t(error)}</p>}
  </div>;
}
