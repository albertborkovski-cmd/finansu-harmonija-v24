import { translateUi as uiText } from '../i18n/language';
import { useEffect, useState } from 'react';
import { supabase, type Company } from '../lib/supabase';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import { readProfileSetup, saveProfileSetup } from '../lib/profileSetup';
import { IntegrationFieldHelp, IntegrationHelpLink, IntegrationInstructions, PROFILE_INTEGRATION_LINKS as helpLinks } from './ProfileIntegrationHelp';
import IntegrationGuideLink from './IntegrationHelpLink';

export default function CompanySharePointSettings({ company, profileEmail }: { company: Company; profileEmail?: never } | { profileEmail: string; company?: never }) {
  const [values, setValues] = useState(() => profileEmail ? { ...readProfileSetup(window.localStorage, profileEmail).sharepoint, sharepoint_client_secret: '' } : {
    sharepoint_client_id: company?.sharepoint_client_id || '',
    sharepoint_client_secret: company?.sharepoint_client_secret || '',
    sharepoint_tenant_id: company?.sharepoint_tenant_id || '',
    sharepoint_urls: company?.sharepoint_urls || '',
    sharepoint_sync_schedule: company?.sharepoint_sync_schedule || 'Manual synchronization',
    sharepoint_sync_time: company?.sharepoint_sync_time || '09:00',
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const companyId = company?.id;
  useEffect(() => {
    if (!companyId) return;
    let cancelled = false;
    void (async () => {
      const { data, error: loadError } = await supabase.from('companies').select('*').eq('id', companyId);
      const stored = data?.[0];
      if (!cancelled && !loadError && stored) setValues(current => Object.fromEntries(Object.entries(current).map(([key, value]) => [key, typeof stored[key] === 'string' ? stored[key] : value])) as typeof current);
    })();
    return () => { cancelled = true; };
  }, [companyId]);
  const change = (key: keyof typeof values, value: string) => { setValues(current => ({ ...current, [key]: value })); setMessage(''); setError(''); };
  const save = async () => {
    if (saving) return;
    setSaving(true); setError(''); setMessage('');
    try {
      if (profileEmail) saveProfileSetup(window.localStorage, profileEmail, { sharepoint: values });
      else if (company) {
        const { error: saveError } = await supabase.from('companies').update(values).eq('id', company.id);
        if (saveError) throw new Error(saveError.message);
      }
      setMessage('SharePoint settings saved.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save SharePoint settings.'); }
    finally { setSaving(false); }
  };
  const inputClass = 'h-[42px] w-full rounded-lg border border-[#D3E1EC] bg-white px-[14px] font-montserrat text-[14px] font-medium leading-5 text-[#10233A] outline-none focus:border-[#007EA7]';
  return <section className={`rounded-lg border border-[#D3E1EC] bg-white p-5 ${profileEmail ? 'text-[13px]' : ''}`}>
    <div className="flex flex-wrap items-center justify-between gap-3"><h3 className="flex items-center gap-2 font-montserrat text-[16px] font-semibold leading-6 text-[#10233A]">{uiText(profileEmail ? 'Read documents from SharePoint' : 'SharePoint settings')}<IntegrationGuideLink integration="sharepoint" label="SharePoint" /></h3>{profileEmail && <span className="rounded-md bg-[#F4F8FC] px-3 py-1 text-[12px] text-[#7288A3]">{uiText('Not connected')}</span>}</div>
    {profileEmail && <p className="mt-3 text-[12px] leading-5 text-[#7288A3]">{uiText('Prepare access to files at the specified SharePoint locations. Connection and scheduled reading require a secure FH connector.')}</p>}
    {profileEmail && <div className="mt-4"><IntegrationInstructions title="How to prepare SharePoint access" steps={[
      'Open Microsoft Entra admin center → App registrations and select the application intended for your FH integration.',
      'In Overview, find Application (client) ID and Directory (tenant) ID. Enter these identifiers in the matching fields below.',
      'Certificates & secrets contains client credentials. An administrator must configure the secret on the secure FH server, not in this browser form.',
      'Ask your Microsoft administrator to review the application’s access to the required SharePoint sites. Save the folder addresses below; saving preferences does not grant permissions or start reading files.',
    ]}><IntegrationHelpLink href={helpLinks.entra}>{uiText('Open Microsoft Entra')}</IntegrationHelpLink></IntegrationInstructions></div>}
    <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
      {([
        { key: 'sharepoint_client_id', label: 'SharePoint Client ID', shortLabel: 'Client ID', help: 'Application (client) ID identifies the registered integration application. It is not your Microsoft sign-in name.' },
        { key: 'sharepoint_client_secret', label: 'SharePoint Client secret', shortLabel: 'Client secret', help: 'The secret value is shown when created in Entra. Do not paste it here or send it in chat; secure server configuration is required.' },
        { key: 'sharepoint_tenant_id', label: 'SharePoint Tenant ID', shortLabel: 'Tenant ID', help: 'Directory (tenant) ID identifies the Microsoft organization that owns the SharePoint site.' },
      ] as const).map(field => <label key={field.key} className="flex flex-col gap-2"><span className="font-semibold">{uiText(profileEmail ? field.shortLabel : field.label)}</span><input aria-describedby={profileEmail ? `${field.key}-help` : undefined} disabled={Boolean(profileEmail) && field.key === 'sharepoint_client_secret'} type={field.key === 'sharepoint_client_secret' ? 'password' : 'text'} autoComplete="off" value={values[field.key]} onChange={event => change(field.key, event.target.value)} className={`${inputClass} disabled:bg-[#F4F8FC] disabled:text-[#7288A3]`} />{profileEmail && <IntegrationFieldHelp id={`${field.key}-help`}>{uiText(field.help)}</IntegrationFieldHelp>}</label>)}
      <div className="flex flex-col gap-2"><span className="font-semibold">{uiText("Synchronization schedule")}</span><SearchableSelect ariaLabel={uiText("Synchronization schedule")} value={values.sharepoint_sync_schedule} options={['Every 5 minutes', 'Every hour', 'Every day', 'Synchronization disabled', 'Manual synchronization'].map(value => ({ value, label: uiText(value) }))} onChange={value => change('sharepoint_sync_schedule', value)} portalMenu />{profileEmail && <IntegrationFieldHelp id="sharepoint-schedule-help">{uiText('Choose how often the connected service should check for new files. Manual synchronization does not schedule automatic runs.')}</IntegrationFieldHelp>}</div>
      {values.sharepoint_sync_schedule === 'Every day' && <label className="flex flex-col gap-2"><span className="font-semibold">{uiText("Synchronization time")}</span><input aria-describedby={profileEmail ? 'sharepoint-time-help' : undefined} type="time" value={values.sharepoint_sync_time} onChange={event => change('sharepoint_sync_time', event.target.value)} className={inputClass} />{profileEmail && <IntegrationFieldHelp id="sharepoint-time-help">{uiText('Preferred time for the daily run. The connected service must confirm the timezone before scheduling.')}</IntegrationFieldHelp>}</label>}
      <label className="flex flex-col gap-2 md:col-span-2"><span className="font-semibold">{uiText("SharePoint URLs")}</span><textarea rows={3} value={values.sharepoint_urls} placeholder={profileEmail ? 'https://example.sharepoint.com/sites/Company/Shared%20Documents/**/documents' : undefined} onChange={event => change('sharepoint_urls', event.target.value)} className="w-full resize-y rounded-lg border border-[#D3E1EC] px-[14px] py-3 font-montserrat text-[14px] font-medium leading-5 text-[#10233A] outline-none focus:border-[#007EA7]" />{profileEmail && <span className="text-[12px] font-normal leading-5 text-[#7288A3]">{uiText('Enter each SharePoint URL on a separate line.')}</span>}</label>
    </div>
    {profileEmail && <div className="mt-4 space-y-4">
      <IntegrationInstructions title="Which SharePoint address should I enter?" steps={[
        'Use the document library or folder address, not a link to a single file. Enter each location on a new line.',
        'Add a folder name to restrict reading to that folder. The /**/ pattern in the source guide selects matching nested folder names; support must be configured in the FH connector.',
      ]}><div className="w-full min-w-0 space-y-2 text-[12px] text-[#526B86]"><p>{uiText('Document library example')}:</p><code className="block break-all rounded border border-[#D3E1EC] bg-white p-2">https://example.sharepoint.com/sites/Company/Shared%20Documents</code><p>{uiText('Specific folder example')}:</p><code className="block break-all rounded border border-[#D3E1EC] bg-white p-2">https://example.sharepoint.com/sites/Company/Shared%20Documents/Invoices</code><p>{uiText('Nested folder pattern example')}:</p><code className="block break-all rounded border border-[#D3E1EC] bg-white p-2">https://example.sharepoint.com/sites/Company/Shared%20Documents/**/Invoices</code></div></IntegrationInstructions>
      <p className="text-[12px] leading-5 text-[#7288A3]">{uiText('If access fails, check the client and tenant identifiers, secret expiry, application permissions and folder path with your Microsoft administrator.')}</p>
      <p className="text-[12px] leading-5 text-[#7288A3]">{uiText('Finansų harmonija uses its own integration, permissions and service accounts. Ask your administrator for the correct connection details.')}</p>
      <p className="text-[12px] leading-5 text-[#7288A3]">{uiText('Connection is not configured. Secrets require a secure server and are not stored in this browser.')}</p>
    </div>}
    <div className="mt-5 flex flex-wrap items-center justify-end gap-3"><span role="status" className="text-[12px] text-[#087A55]">{uiText(message)}</span>{error && <span role="alert" className="text-[12px] text-red-600">{uiText(error)}</span>}{profileEmail && <PageActionButton disabled>{uiText('Connect SharePoint')}</PageActionButton>}<PageActionButton disabled={saving} onClick={() => void save()}>{saving ? uiText('Saving…') : uiText('Save')}</PageActionButton></div>
  </section>;
}
