import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import type { Company, DbDocument } from '../../lib/supabase';
import { ASSET_METHODS, assetBalance, assetMinor, assetMoney, assetToday, type AssetCommand, type AssetGroup, type AssetInventory, type AssetStore, type FixedAsset } from '../../lib/fixedAssets';
import { translateUi as t, useLanguage } from '../../i18n/language';
import { loadCompanyAdvanceEmployees } from '../../lib/companyAdvanceEmployees';
import SearchableSelect from '../SearchableSelect';
import GeneralLedgerAccountSelect from '../GeneralLedgerAccountSelect';
import GlJournalDialog from '../GlJournalDialog';
import { CancelButton, SaveButton } from '../ScopedActionButtons';
import { PageActionButton } from '../PageHeader';
import { WarehouseCheck } from '../WarehouseTable';
import { CashField as Field, CashSection as Section, CashRowAction as RowAction, cashInput as input } from '../cash/CashControls';

type Common = { company: Company; store: AssetStore; busy: boolean; error: string; onClose: () => void; onSave: (command: AssetCommand) => void };
function Footer({ busy, onClose, onSave, readOnly = false }: Pick<Common, 'busy' | 'onClose'> & { onSave: () => void; readOnly?: boolean }) {
  return <><CancelButton onClick={onClose}>{t(readOnly ? 'Close' : 'Cancel')}</CancelButton>{!readOnly && <SaveButton disabled={busy} onClick={onSave}>{t('Save')}</SaveButton>}</>;
}
function ErrorMessage({ error }: { error: string }) { return error ? <p role="alert" className="mb-4 rounded-lg bg-red-50 p-3 text-[13px] text-red-700">{t(error)}</p> : null; }
export function AssetCardEditor({ company, store, record, documents, readOnly, busy, error, onClose, onSave }: Common & { record: FixedAsset; documents: DbDocument[]; readOnly: boolean }) {
  useLanguage();
  const [a, setA] = useState(() => structuredClone(record));
  const posted = store.operations.some(o => o.assetId === a.id), financialDisabled = readOnly || posted;
  const set = <K extends keyof FixedAsset>(key: K, value: FixedAsset[K]) => setA(prev => ({ ...prev, [key]: value }));
  const employees = loadCompanyAdvanceEmployees(company);
  const number = (key: 'cost' | 'residual' | 'openingDepreciation', label: string) => <Field label={label}><input className={input} type="number" min="0" step="0.01" value={a[key] / 100} disabled={financialDisabled} onChange={e => set(key, assetMinor(e.target.value))} /></Field>;
  const operations = store.operations.filter(o => o.assetId === a.id);
  return <GlJournalDialog wide title={readOnly ? 'Fixed asset card' : store.assets.some(asset => asset.id === a.id) ? 'Edit fixed asset' : 'New asset'} subtitle={`${company.name} · ${a.number || t('New asset')}`} onClose={onClose} footer={<Footer busy={busy} onClose={onClose} onSave={() => onSave({ type: 'save-asset', asset: a })} readOnly={readOnly} />}>
    <ErrorMessage error={error} />
    <div className="space-y-4">
      <Section title="Asset information"><div className="grid gap-4 md:grid-cols-3">
        <Field label="Inventory No. *"><input className={input} value={a.number} disabled={financialDisabled} onChange={e => set('number', e.target.value)} /></Field>
        <Field label="Asset name *"><input className={input} value={a.name} disabled={readOnly} onChange={e => set('name', e.target.value)} /></Field>
        <Field label="Asset group *"><SearchableSelect portalMenu ariaLabel="Asset group" value={a.groupId} disabled={financialDisabled} options={store.groups.filter(g => !g.inactive || g.id === a.groupId).map(g => ({ value: g.id, label: `${g.code} · ${g.name}` }))} onChange={id => { const g = store.groups.find(x => x.id === id)!; setA(p => ({ ...p, groupId: id, method: g.method, lifeMonths: g.lifeMonths })); }} /></Field>
        <Field label="Acquisition date *"><input type="date" className={input} value={a.acquisitionDate} disabled={financialDisabled} onChange={e => set('acquisitionDate', e.target.value)} /></Field>
        <Field label="Quantity"><input type="number" min="0.001" step="0.001" className={input} value={a.quantity} disabled={financialDisabled} onChange={e => set('quantity', Number(e.target.value))} /></Field>
        <Field label="Location"><input className={input} value={a.location} disabled={readOnly} onChange={e => set('location', e.target.value)} /></Field>
        <Field label="Department"><input className={input} value={a.department} disabled={readOnly} onChange={e => set('department', e.target.value)} /></Field>
        <Field label="Responsible person"><SearchableSelect portalMenu ariaLabel="Responsible person" value={a.responsible} disabled={readOnly} options={[{ value: '', label: '—' }, ...employees.map(e => ({ value: e.id, label: e.fullName || e.email || e.id }))]} onChange={v => set('responsible', v)} /></Field>
        <Field label="Currency"><input className={input} disabled value={store.currency} /></Field>
      </div></Section>
      <Section title="Acquisition and depreciation"><div className="grid gap-4 md:grid-cols-3">
        {number('cost', 'Acquisition cost *')}{number('residual', 'Residual value')}{number('openingDepreciation', 'Opening accumulated depreciation')}
        <Field label="Depreciation method"><SearchableSelect portalMenu localizeOptions ariaLabel="Depreciation method" value={a.method} options={[...ASSET_METHODS]} disabled={financialDisabled} onChange={v => set('method', v as FixedAsset['method'])} /></Field>
        <Field label="Remaining useful life (months)"><input type="number" min="1" max="1200" className={input} disabled={financialDisabled} value={a.lifeMonths} onChange={e => set('lifeMonths', Number(e.target.value))} /></Field>
        <Field label="Depreciable"><fieldset disabled={financialDisabled} className="flex h-10 items-center disabled:opacity-50"><WarehouseCheck checked={a.depreciable} label={t('Depreciable')} onChange={() => set('depreciable', !a.depreciable)} /></fieldset></Field>
        {a.method === 'Units of production' && <Field label="Expected production units"><input type="number" min="1" className={input} disabled={financialDisabled} value={a.totalUnits} onChange={e => set('totalUnits', Number(e.target.value))} /></Field>}
      </div><p className="mt-3 text-[12px] text-[#7288A3]">{t(posted ? 'Posted asset values can only be changed through asset operations.' : 'Depreciation starts in the next month after commissioning.')}</p></Section>
      <Section title="Acquisition documents"><div className="space-y-2">{a.sources.map((source, index) => <div key={index} className="grid grid-cols-[minmax(0,1fr)_180px_32px] items-end gap-3">
        <Field label="Document No."><SearchableSelect portalMenu ariaLabel="Acquisition document" value={source.id} disabled={financialDisabled} options={documents.map(d => ({ value: d.id, label: `${d.number} · ${d.client_counterparty || ''} · ${d.amount_without_vat} ${d.currency}` }))} onChange={id => { const d = documents.find(x => x.id === id)!; set('sources', a.sources.map((s, i) => i === index ? { id, number: d.number, amount: assetMinor(d.amount_without_vat) } : s)); }} /></Field>
        <Field label="Allocated acquisition cost"><input className={input} type="number" step="0.01" min="0" disabled={financialDisabled} value={source.amount / 100} onChange={e => set('sources', a.sources.map((s, i) => i === index ? { ...s, amount: assetMinor(e.target.value) } : s))} /></Field>
        <RowAction label="Remove" disabled={financialDisabled} onClick={() => set('sources', a.sources.filter((_, i) => i !== index))}><Trash2 size={14} /></RowAction>
      </div>)}<PageActionButton icon={<Plus size={14} />} disabled={financialDisabled || !documents.length} onClick={() => set('sources', [...a.sources, { id: '', number: '', amount: 0 }])}>Link acquisition document</PageActionButton>
      <p className="text-[12px] text-[#7288A3]">{t('Only approved purchase documents in the company accounting currency are available. Existing assets may be entered using Opening balance.')}</p></div></Section>
      <Field label="Notes"><textarea className={`${input} h-20 py-2`} disabled={readOnly} value={a.note} onChange={e => set('note', e.target.value)} /></Field>
      {!!operations.length && <Section title="Asset operations"><div className="overflow-auto"><table className="w-full text-left text-[12px]"><thead className="text-[#7288A3]"><tr>{['Date', 'Document No.', 'Operation type', 'Cost change', 'Depreciation change', 'Created by'].map(h => <th className="p-2" key={h}>{t(h)}</th>)}</tr></thead><tbody>{operations.map(o => <tr key={o.id} className="border-t border-[#E5EDF9]"><td className="p-2">{o.date}</td><td>{o.number}</td><td>{t(o.kind)}</td><td>{assetMoney(o.costChange)}</td><td>{assetMoney(o.depreciationChange)}</td><td>{o.by}</td></tr>)}</tbody></table></div></Section>}
      <Section title="Action history"><div className="space-y-2 text-[12px]">{store.audit.filter(e => e.subjectId === a.id).slice().reverse().map(e => <div key={e.id} className="flex justify-between gap-4 border-b border-[#E5EDF9] pb-2"><span>{t(e.action)}</span><span className="text-[#7288A3]">{e.by} · {new Date(e.at).toLocaleString()}</span></div>)}</div></Section>
    </div>
  </GlJournalDialog>;
}
export function AssetGroupEditor({ company, store, record, busy, error, onClose, onSave }: Common & { record: AssetGroup }) {
  useLanguage(); const [g, setG] = useState({ ...record });
  const accountsLocked = store.assets.some(a => a.groupId === g.id && store.operations.some(o => o.assetId === a.id));
  return <GlJournalDialog title="Asset group" onClose={onClose} footer={<Footer busy={busy} onClose={onClose} onSave={() => onSave({ type: 'save-group', group: g })} />}><ErrorMessage error={error} /><div className="grid gap-4 sm:grid-cols-2">
    <Field label="Code *"><input className={input} value={g.code} onChange={e => setG({ ...g, code: e.target.value })} /></Field><Field label="Name *"><input className={input} value={g.name} onChange={e => setG({ ...g, name: e.target.value })} /></Field>
    {([['assetAccount', 'Asset GL account'], ['depreciationAccount', 'Accumulated depreciation account'], ['expenseAccount', 'Depreciation expense account']] as const).map(([key, label]) => <Field key={key} label={label}><GeneralLedgerAccountSelect formField disabled={accountsLocked} companyId={company.id} generalLedgerName={company.general_ledger} ariaLabel={label} value={g[key]} onChange={value => setG({ ...g, [key]: value })} /></Field>)}
    <Field label="Useful life (months)"><input className={input} type="number" min="1" value={g.lifeMonths} onChange={e => setG({ ...g, lifeMonths: Number(e.target.value) })} /></Field>
    <Field label="Depreciation method"><SearchableSelect portalMenu localizeOptions ariaLabel="Depreciation method" value={g.method} options={[...ASSET_METHODS]} onChange={v => setG({ ...g, method: v as AssetGroup['method'] })} /></Field>
  </div></GlJournalDialog>;
}
export function AssetOperationEditor({ company, store, record, busy, error, onClose, onSave }: Common & { record: FixedAsset }) {
  useLanguage(); const b = assetBalance(store, record);
  const options = b.start ? ['Modernization', 'Revaluation', 'Transfer between groups', 'Write-off', 'Withdrawal for sale'] : ['Commissioning', 'Opening balance'];
  const [c, setC] = useState<Extract<AssetCommand, { type: 'post' }>>({ type: 'post', assetId: record.id, kind: b.start ? 'Modernization' : record.openingDepreciation ? 'Opening balance' : 'Commissioning', date: assetToday(), account: '', amount: 0, lifeExtension: 0, reason: '' });
  return <GlJournalDialog title="Asset operation" subtitle={`${record.number} · ${record.name}`} onClose={onClose} footer={<Footer busy={busy} onClose={onClose} onSave={() => onSave(c)} />}><ErrorMessage error={error} /><div className="grid gap-4 sm:grid-cols-2">
    <Field label="Operation type"><SearchableSelect portalMenu localizeOptions ariaLabel="Operation type" value={c.kind} options={options} onChange={kind => setC({ ...c, kind: kind as typeof c.kind })} /></Field>
    <Field label="Operation date *"><input type="date" className={input} value={c.date} onChange={e => setC({ ...c, date: e.target.value })} /></Field>
    <div className="sm:col-span-2">{c.kind === 'Transfer between groups' ? <Field label="Target asset group *"><SearchableSelect portalMenu ariaLabel="Target asset group" value={c.targetGroupId || ''} options={store.groups.filter(g => !g.inactive && g.id !== record.groupId).map(g => ({ value: g.id, label: `${g.code} · ${g.name}` }))} onChange={targetGroupId => setC({ ...c, targetGroupId })} /></Field> : <Field label="Correspondence account *"><GeneralLedgerAccountSelect formField ariaLabel="Correspondence account" companyId={company.id} generalLedgerName={company.general_ledger} value={c.account} onChange={account => setC({ ...c, account })} /></Field>}</div>
    {['Modernization', 'Revaluation'].includes(c.kind) && <><Field label="Adjustment amount *"><input className={input} type="number" step="0.01" value={c.amount / 100} onChange={e => setC({ ...c, amount: assetMinor(e.target.value) })} /></Field><Field label="Useful life extension (months)"><input className={input} type="number" min="0" value={c.lifeExtension} onChange={e => setC({ ...c, lifeExtension: Number(e.target.value) })} /></Field></>}
    <div className="sm:col-span-2"><Field label="Reason *"><textarea className={`${input} h-20 py-2`} value={c.reason} onChange={e => setC({ ...c, reason: e.target.value })} /></Field></div>
    <p className="sm:col-span-2 rounded-lg bg-[#F3F7FB] p-3 text-[12px]">{t('Book value')}: {assetMoney(b.book)} {store.currency}. {t('Saving posts balanced entries to the GL journal. Original operations are retained.')}</p>
    {c.kind === 'Withdrawal for sale' && <p className="sm:col-span-2 text-[12px] text-[#7288A3]">{t('Choose the stock account for withdrawal. Create the sales invoice separately in Invoices.')}</p>}
  </div></GlJournalDialog>;
}
export function AssetInventoryEditor({ store, record, busy, error, onClose, onSave }: Common & { record: AssetInventory }) {
  useLanguage(); const [i, setI] = useState(() => structuredClone(record));
  const fill = (date: string) => store.assets.filter(a => { const b = assetBalance(store, a, date); return b.start && !b.disposed; }).map(a => { const b = assetBalance(store, a, date); return { assetId: a.id, number: a.number, name: a.name, bookQuantity: a.quantity, actualQuantity: a.quantity, bookValue: b.book, note: '' }; });
  return <GlJournalDialog wide title="Asset inventory" onClose={onClose} footer={<><CancelButton onClick={onClose}>{t('Close')}</CancelButton>{!i.locked && <><PageActionButton disabled={busy} onClick={() => onSave({ type: 'save-inventory', inventory: { ...i, locked: true } })}>Save & lock</PageActionButton><SaveButton disabled={busy} onClick={() => onSave({ type: 'save-inventory', inventory: i })}>{t('Save')}</SaveButton></>}</>}><ErrorMessage error={error} />
    <div className="mb-4 grid max-w-2xl gap-4 sm:grid-cols-2"><Field label="Inventory No. *"><input className={input} disabled={i.locked} value={i.number} onChange={e => setI({ ...i, number: e.target.value })} /></Field><Field label="Date"><input className={input} type="date" disabled={i.locked} value={i.date} onChange={e => setI({ ...i, date: e.target.value, lines: fill(e.target.value) })} /></Field></div>
    <div className="overflow-auto"><table className="w-full min-w-[750px] text-left text-[12px]"><thead className="bg-[#F3F7FB] text-[#7288A3]"><tr>{['Inventory No.', 'Asset name', 'Book quantity', 'Actual quantity', 'Difference', 'Notes'].map(h => <th className="p-3" key={h}>{t(h)}</th>)}</tr></thead><tbody>{i.lines.map((l, index) => <tr className="border-b border-[#E5EDF9]" key={l.assetId}><td className="p-3">{l.number}</td><td>{l.name}</td><td>{l.bookQuantity}</td><td className="w-36 p-2"><input className={input} aria-label={`${t('Actual quantity')} ${l.number}`} type="number" min="0" step="0.001" disabled={i.locked} value={l.actualQuantity} onChange={e => setI({ ...i, lines: i.lines.map((r, n) => n === index ? { ...r, actualQuantity: Number(e.target.value) } : r) })} /></td><td>{Number((l.actualQuantity - l.bookQuantity).toFixed(3))}</td><td className="p-2"><input className={input} aria-label={`${t('Notes')} ${l.number}`} disabled={i.locked} value={l.note} onChange={e => setI({ ...i, lines: i.lines.map((r, n) => n === index ? { ...r, note: e.target.value } : r) })} /></td></tr>)}</tbody></table></div>
    {!i.lines.length && <p className="p-4 text-[13px] text-[#7288A3]">{t('There are no commissioned assets for this date.')}</p>}
    <p className="mt-4 text-[12px] text-[#7288A3]">{t('Inventory differences do not change accounting automatically. Review them before posting a separate asset operation.')}</p>
  </GlJournalDialog>;
}
