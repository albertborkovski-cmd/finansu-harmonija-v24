import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { translateUi, useLanguage } from '../i18n/language';
import { SYSTEM_TOOLTIP_ID, TOOLTIP_TARGETS, systemTooltipPosition, systemTooltipText, suppressNativeTooltipTitles } from '../lib/systemTooltip';

/** One delegated tooltip for every list, modal and dynamically created control. */
export default function SystemTooltip() {
  const language = useLanguage();
  const [tip, setTip] = useState<{ target: Element; text: string } | null>(null);
  const [position, setPosition] = useState<{ left: number; top: number } | null>(null);
  const bubble = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    suppressNativeTooltipTitles(document.body);
    const nativeTitles = new MutationObserver(records => {
      for (const record of records) {
        if (record.type === 'attributes' && record.target instanceof Element) suppressNativeTooltipTitles(record.target);
        else for (const node of record.addedNodes) if (node instanceof Element) suppressNativeTooltipTitles(node);
      }
    });
    nativeTitles.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['title'] });
    return () => nativeTitles.disconnect();
  }, []);

  useEffect(() => {
    let target: Element | null = null;
    let restore: (() => void) | undefined;
    let observer: MutationObserver | undefined;
    const hide = () => {
      observer?.disconnect(); observer = undefined;
      restore?.(); restore = undefined; target = null;
      setTip(null); setPosition(null);
    };
    const show = (node: EventTarget | null) => {
      const element = node instanceof Element ? node.closest(TOOLTIP_TARGETS) : null;
      if (element === target) return;
      hide();
      if (!element || element.closest('[data-tooltip-disabled="true"], [role="tooltip"]')) return;
      const text = systemTooltipText(element);
      target = element;
      // Keep title-only icons discoverable while their native title is suppressed.
      // Moving between an SVG and its paths must not restore a browser tooltip.
      element.setAttribute('data-system-tooltip-target', 'true');
      // Also normalize synchronously for a control mounted immediately before pointerover.
      for (let item: Element | null = element; item; item = item.parentElement) {
        if (item.hasAttribute('title')) {
          item.setAttribute('data-system-tooltip-native', item.getAttribute('title') || '');
          item.removeAttribute('title');
        }
      }
      const describedBy = element.getAttribute('aria-describedby');
      if (text) element.setAttribute('aria-describedby', [describedBy, SYSTEM_TOOLTIP_ID].filter(Boolean).join(' '));
      restore = () => {
        element.removeAttribute('data-system-tooltip-target');
        const descriptions = (element.getAttribute('aria-describedby') || '').split(/\s+/).filter(id => id !== SYSTEM_TOOLTIP_ID).join(' ');
        if (descriptions) element.setAttribute('aria-describedby', descriptions); else element.removeAttribute('aria-describedby');
      };
      if (text) setTip({ target: element, text: translateUi(text, language) });
      observer = new MutationObserver(() => { if (!element.isConnected) hide(); });
      observer.observe(document.body, { childList: true, subtree: true });
    };
    const over = (event: PointerEvent) => { if (event.pointerType !== 'touch') show(event.target); };
    const out = (event: PointerEvent) => {
      if (target && (!(event.relatedTarget instanceof Node) || !target.contains(event.relatedTarget))) hide();
    };
    const focus = (event: FocusEvent) => { if (event.target instanceof Element && event.target.matches(':focus-visible')) show(event.target); };
    const key = (event: KeyboardEvent) => { if (event.key === 'Escape') hide(); };
    document.addEventListener('pointerover', over, true);
    document.addEventListener('pointerout', out, true);
    document.addEventListener('focusin', focus, true);
    document.addEventListener('focusout', hide, true);
    document.addEventListener('pointerdown', hide, true);
    document.addEventListener('keydown', key, true);
    document.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    window.addEventListener('blur', hide);
    return () => {
      hide();
      document.removeEventListener('pointerover', over, true);
      document.removeEventListener('pointerout', out, true);
      document.removeEventListener('focusin', focus, true);
      document.removeEventListener('focusout', hide, true);
      document.removeEventListener('pointerdown', hide, true);
      document.removeEventListener('keydown', key, true);
      document.removeEventListener('scroll', hide, true);
      window.removeEventListener('resize', hide);
      window.removeEventListener('blur', hide);
    };
  }, [language]);

  useLayoutEffect(() => {
    if (!tip || !bubble.current) return;
    const bounds = bubble.current.getBoundingClientRect();
    setPosition(systemTooltipPosition(tip.target.getBoundingClientRect(), bounds, { width: window.innerWidth, height: window.innerHeight }, tip.target.getAttribute('data-tooltip-side') || 'bottom'));
  }, [tip]);

  return tip ? createPortal(<div ref={bubble} id={SYSTEM_TOOLTIP_ID} role="tooltip" className="system-tooltip"
    style={{ left: position?.left ?? 0, top: position?.top ?? 0, visibility: position ? 'visible' : 'hidden' }}>{tip.text}</div>, document.body) : null;
}
