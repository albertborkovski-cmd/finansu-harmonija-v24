import { ArrowDown, ArrowUp, Bold, Check, Eye, EyeOff, Heading2, ImagePlus, Italic, Link2, ListOrdered, Save, Trash2, Video, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useLanguage } from '../i18n/language';
import { editorialArticles, helpCategories } from '../lib/helpEditorialCatalog';
import { isHelpGroupVisible, safeHelpUrl, type EditableHelpArticle, type EditableHelpCategory } from '../lib/helpContent';
import { helpDescendants, helpLinkMarkdown, helpParent, replaceHelpSelection } from '../lib/helpEditing';
import { saveHelpMedia } from '../lib/helpMediaStore';
import { useHelpContent } from './HelpContentProvider';
import HelpArticleBody from './HelpArticleBody';
import SearchableSelect from './SearchableSelect';

export const helpEditorButton = 'inline-flex min-h-9 items-center justify-center gap-2 rounded-lg border border-[#C4D8E6] bg-white px-3 py-2 text-[11px] font-semibold text-[#007EA7] hover:bg-[#EAF4F9] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40';
const field = 'mt-1.5 w-full rounded-lg border border-[#D3E1EC] bg-white px-3 py-2.5 text-[13px] font-normal text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10';
const label = 'block text-[11px] font-semibold text-[#7288A3]';
const primary = helpEditorButton + ' !border-[#007EA7] !bg-[#007EA7] !text-white';
function errorText(error: unknown, lt: boolean) {
  const message = error instanceof Error ? error.message : String(error);
  if (!lt) return message;
  if (message.includes('another window')) return 'Pagalba pakeista kitame lange. Nukopijuokite savo pakeitimus, tada atverkite temą iš naujo.';
  if (message.includes('administrator')) return 'Aprašymus gali tvarkyti tik aktyvus administratorius.';
  if (message.includes('title')) return 'Įrašykite pavadinimą ir temos turinį. Pavadinimas – iki 250 simbolių.';
  if (message.includes('parent')) return 'Tema negali būti perkelta į savo pačios potemę.';
  if (message.includes('Supported media')) return 'Galimi formatai: PNG, JPG, WebP, GIF, MP4 ir WebM.';
  if (message.includes('Media limit')) return 'Nuotrauka gali būti iki 10 MB, vaizdo įrašas – iki 50 MB.';
  return 'Nepavyko išsaugoti. Ankstesni duomenys nepakeisti. Patikrinkite naršyklės saugyklą.';
}
function useUnsavedChanges(dirty: boolean, onDirty: (dirty: boolean) => void) {
  useEffect(() => { onDirty(dirty); }, [dirty, onDirty]);
  useEffect(() => {
    const warn = (event: BeforeUnloadEvent) => { if (dirty) { event.preventDefault(); event.returnValue = ''; } };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);
}

export default function HelpArticleEditor({ original, onDirty }: { original: EditableHelpArticle; onDirty: (dirty: boolean) => void }) {
  const { state, save } = useHelpContent(), lt = useLanguage() === 'lt';
  const [draft, setDraft] = useState(() => structuredClone(original));
  const [revision, setRevision] = useState(state.revision);
  const [lang, setLang] = useState<0 | 1>(lt ? 1 : 0);
  const initialVisible = !(original.custom && !state.articles[original.key]) && state.visibility[original.key] !== false;
  const [visible, setVisible] = useState(initialVisible);
  const [baseline, setBaseline] = useState(() => JSON.stringify({ draft: original, visible: initialVisible }));
  const [mode, setMode] = useState<'split' | 'edit' | 'preview'>('split');
  const [notice, setNotice] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const [panel, setPanel] = useState<'link' | 'image' | 'video' | null>(null);
  const [linkLabel, setLinkLabel] = useState(''), [linkUrl, setLinkUrl] = useState(''), [caption, setCaption] = useState(''), [image, setImage] = useState('');
  const textarea = useRef<HTMLTextAreaElement>(null), fileInput = useRef<HTMLInputElement>(null);
  const selection = useRef({ start: 0, end: 0 });
  const mounted = useRef(true);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  const entries = useMemo(() => editorialArticles(state), [state]);
  const categories = useMemo(() => helpCategories(state), [state]);
  const descendants = useMemo(() => helpDescendants(draft.key, entries), [draft.key, entries]);
  const availableImages = useMemo(() => Array.from(new Set(entries.flatMap(item => [...item.body[0].matchAll(/\]\((help\/[a-zA-Z0-9._/-]+)\)/g)].map(match => match[1])))).sort(), [entries]);
  const dirty = busy || JSON.stringify({ draft, visible }) !== baseline;
  useUnsavedChanges(dirty, onDirty);
  const update = (key: 'title' | 'description' | 'body', value: string) => { setNotice(''); setDraft(current => ({ ...current, [key]: current[key].map((text, i) => i === lang ? value : text) as [string, string] })); };
  const insert = (text: string, block = false) => {
    const result = replaceHelpSelection(draft.body[lang], selection.current.start, selection.current.end, block ? `\n\n${text}\n\n` : text);
    update('body', result.body);
    selection.current = { start: result.cursor, end: result.cursor };
    requestAnimationFrame(() => { textarea.current?.focus(); textarea.current?.setSelectionRange(result.cursor, result.cursor); });
  };
  const selectedText = () => draft.body[lang].slice(selection.current.start, selection.current.end);
  const format = (before: string, after = '', placeholder = lt ? 'Tekstas' : 'Text') => insert(before + (selectedText() || placeholder) + after);
  const addLink = () => {
    const href = safeHelpUrl(linkUrl.trim());
    if (!href || href.startsWith('help-media:') || href.startsWith('help/')) { setError(lt ? 'Įveskite saugią https:// arba pasirinkite pagalbos temos nuorodą.' : 'Enter an https:// URL or choose a help topic.'); return; }
    insert(helpLinkMarkdown(linkLabel.trim() || href, href)); setPanel(null); setError('');
  };
  const upload = async (file: File) => {
    setBusy(true); setError('');
    try {
      const media = await saveHelpMedia(file);
      if (!mounted.current) return;
      insert(`${media.kind === 'video' ? '@' : '!'}[${(caption || file.name).replace(/[\[\]\r\n]/g, ' ')}](${media.url})`, true);
      setPanel(null); setCaption('');
    } catch (error) { if (mounted.current) setError(errorText(error, lt)); }
    finally { if (mounted.current) setBusy(false); }
  };
  const move = (direction: -1 | 1) => {
    const index = new Map(entries.map((entry, i) => [entry.key, i]));
    const siblings = [...entries.filter(item => item.key !== draft.key && item.category === draft.category && helpParent(item) === helpParent(draft)), draft].sort((a, b) => (a.order ?? index.get(a.key) ?? entries.length) - (b.order ?? index.get(b.key) ?? entries.length));
    const at = siblings.findIndex(item => item.key === draft.key), neighbor = siblings[at + direction];
    if (!neighbor) return;
    const nextNeighbor = siblings[at + direction * 2];
    const order = neighbor.order ?? index.get(neighbor.key) ?? entries.length;
    const other = nextNeighbor ? nextNeighbor.order ?? index.get(nextNeighbor.key) ?? entries.length : order + direction * 2;
    setDraft(current => ({ ...current, order: (order + other) / 2 }));
  };
  const submit = () => {
    setError('');
    try {
      const movedChildren = entries.filter(item => descendants.has(item.key) && item.category !== draft.category).map(item => ({ ...item, category: draft.category }));
      save(revision, { article: draft, articles: movedChildren, visibility: { key: draft.key, visible } });
      setRevision(value => value + 1); setBaseline(JSON.stringify({ draft, visible }));
      setNotice(lt ? 'Tema išsaugota.' : 'Topic saved.'); onDirty(false);
    } catch (error) { setError(errorText(error, lt)); }
  };
  const toolbar = (name: string, icon: ReactNode, action: () => void) => <button type="button" className={helpEditorButton + ' !px-2.5'} data-tooltip={name} aria-label={name} onMouseDown={event => event.preventDefault()} disabled={busy} onClick={action}>{icon}</button>;
  return <section className="overflow-hidden rounded-xl border border-[#D3E1EC] bg-white">
    <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[#D3E1EC] bg-[#F3F8FB] px-5 py-4"><div><h2 className="text-sm font-semibold">{lt ? 'Temos redaktorius' : 'Topic editor'}</h2><p className="mt-1 text-[11px] text-[#7288A3]">{lt ? 'Pažymėkite tekstą ir naudokite įrankių juostą. Vaizdai įterpiami ties žymekliu.' : 'Select text and use the toolbar. Media is inserted at the cursor.'}</p></div><div className="flex gap-2"><button type="button" className={helpEditorButton} disabled={busy} onClick={() => setVisible(value => !value)}>{visible ? <Eye size={15} /> : <EyeOff size={15} />}{visible ? (lt ? 'Matoma' : 'Visible') : (lt ? 'Paslėpta' : 'Hidden')}</button><button type="button" className={primary} disabled={busy || !dirty} onClick={submit}><Save size={15} />{lt ? 'Išsaugoti' : 'Save'}</button></div></header>
    <div className="space-y-4 p-5">
      <div className="grid gap-4 lg:grid-cols-3"><div><span className={label}>{lt ? 'Turinio kalba' : 'Content language'}</span><SearchableSelect ariaLabel={lt ? 'Turinio kalba' : 'Content language'} disabled={busy} value={String(lang)} options={[{ value: '1', label: 'Lietuvių' }, { value: '0', label: 'English' }]} onChange={value => { setLang(value === '1' ? 1 : 0); selection.current = { start: 0, end: 0 }; setPanel(null); }} portalMenu className={field} /></div>
        <div><span className={label}>{lt ? 'Skiltis' : 'Category'}</span><SearchableSelect ariaLabel={lt ? 'Skiltis' : 'Category'} value={draft.category} options={categories.map(item => ({ value: item.id, label: item.title[lt ? 1 : 0] || item.title[lt ? 0 : 1] }))} onChange={category => setDraft(current => ({ ...current, category, parentKey: '' }))} portalMenu className={field} /></div>
        <div><span className={label}>{lt ? 'Tėvinė tema' : 'Parent topic'}</span><SearchableSelect ariaLabel={lt ? 'Tėvinė tema' : 'Parent topic'} value={helpParent(draft)} options={[{ value: '', label: lt ? 'Skilties pradžioje' : 'At category root' }, ...entries.filter(item => item.category === draft.category && item.key !== draft.key && !descendants.has(item.key)).map(item => ({ value: item.key, label: item.title[lt ? 1 : 0] || item.title[lt ? 0 : 1] }))]} onChange={parentKey => setDraft(current => ({ ...current, parentKey }))} portalMenu className={field} /></div>
      </div>
      {!isHelpGroupVisible(draft.category, state) && <p className="rounded-lg bg-amber-50 p-3 text-xs text-amber-800">{lt ? 'Skiltis paslėpta. Kad tema būtų matoma naudotojams, įjunkite ir skilties matomumą.' : 'This category is hidden. Show the category as well to make the topic visible.'}</p>}
      <label className={label}>{lt ? 'Pavadinimas' : 'Title'}<input className={field} maxLength={250} value={draft.title[lang]} onChange={event => update('title', event.target.value)} /></label>
      <label className={label}>{lt ? 'Trumpas aprašymas' : 'Summary'}<textarea className={field} rows={2} maxLength={2000} value={draft.description[lang]} onChange={event => update('description', event.target.value)} /></label>
      <div className="flex flex-wrap items-center justify-between gap-2 border-y border-[#E5EDF9] py-2"><div className="flex flex-wrap gap-1.5">
        {toolbar(lt ? 'Paryškinti' : 'Bold', <Bold size={15} />, () => format('**', '**'))}
        {toolbar(lt ? 'Kursyvas' : 'Italic', <Italic size={15} />, () => format('*', '*'))}
        {toolbar(lt ? 'Antraštė' : 'Heading', <Heading2 size={16} />, () => insert('## ' + (selectedText() || (lt ? 'Antraštė' : 'Heading')), true))}
        {toolbar(lt ? 'Žingsniai' : 'Steps', <ListOrdered size={16} />, () => insert((selectedText() || (lt ? 'Pirmas žingsnis\nAntras žingsnis' : 'First step\nSecond step')).split('\n').map((line, i) => `${i + 1}. ${line}`).join('\n'), true))}
        {toolbar(lt ? 'Įterpti nuorodą' : 'Insert link', <Link2 size={16} />, () => { setLinkLabel(selectedText()); setLinkUrl(''); setPanel('link'); })}
        {toolbar(lt ? 'Įterpti nuotrauką' : 'Insert image', <ImagePlus size={16} />, () => { setCaption(''); setPanel('image'); })}
        {toolbar(lt ? 'Įterpti vaizdo įrašą' : 'Insert video', <Video size={16} />, () => { setCaption(''); setPanel('video'); })}
      </div><div className="flex rounded-lg bg-[#F3F8FB] p-1">{(['edit', 'split', 'preview'] as const).map(value => <button key={value} className={`rounded-md px-3 py-1.5 text-[11px] ${mode === value ? 'bg-white font-semibold text-[#007EA7] shadow-sm' : 'text-[#7288A3]'}`} aria-pressed={mode === value} onClick={() => setMode(value)}>{value === 'edit' ? (lt ? 'Tekstas' : 'Text') : value === 'preview' ? (lt ? 'Peržiūra' : 'Preview') : (lt ? 'Tekstas + vaizdas' : 'Text + preview')}</button>)}</div></div>
      {panel && <div className="rounded-lg border border-[#C4D8E6] bg-[#F3F8FB] p-4"><div className="mb-3 flex items-center justify-between"><h3 className="text-xs font-semibold">{panel === 'link' ? (lt ? 'Nuoroda pažymėtam tekstui' : 'Link selected text') : panel === 'image' ? (lt ? 'Nuotrauka pasirinktoje vietoje' : 'Image at cursor') : (lt ? 'Vaizdo įrašas pasirinktoje vietoje' : 'Video at cursor')}</h3><button disabled={busy} aria-label={lt ? 'Uždaryti įterpimą' : 'Close insert panel'} onClick={() => setPanel(null)}><X size={16} /></button></div>
        {panel === 'link' ? <div className="grid gap-3 lg:grid-cols-2"><label className={label}>{lt ? 'Nuorodos tekstas' : 'Link text'}<input value={linkLabel} onChange={event => setLinkLabel(event.target.value)} className={field} /></label><label className={label}>{lt ? 'Nuorodos adresas' : 'Link URL'}<input placeholder="https://…" value={linkUrl} onChange={event => setLinkUrl(event.target.value)} className={field} /></label><div><span className={label}>{lt ? 'Arba nuoroda į pagalbos temą' : 'Or link to a help topic'}</span><SearchableSelect ariaLabel={lt ? 'Pagalbos temos nuoroda' : 'Help topic link'} value={entries.some(item => item.href === linkUrl) ? linkUrl : ''} options={entries.map(item => ({ value: item.href, label: item.title[lang] || item.title[1 - lang] }))} onChange={href => { setLinkUrl(href); if (!linkLabel) setLinkLabel(entries.find(item => item.href === href)?.title[lang] || ''); }} portalMenu /></div><div className="flex items-end justify-end"><button className={helpEditorButton} onClick={addLink}><Link2 size={15} />{lt ? 'Įterpti nuorodą' : 'Insert link'}</button></div></div>
          : <div className="space-y-3"><label className={label}>{lt ? 'Vaizdo aprašas' : 'Media caption'}<input value={caption} onChange={event => setCaption(event.target.value)} className={field} disabled={busy} /></label>{panel === 'image' && <div className="flex items-center gap-2"><div className="min-w-0 flex-1"><SearchableSelect ariaLabel={lt ? 'Esama FH ekrano nuotrauka' : 'Existing FH screenshot'} value={image} options={availableImages.map(value => ({ value, label: value.slice(5) }))} onChange={setImage} portalMenu /></div><button className={helpEditorButton} disabled={!image || busy} onClick={() => { insert(`![${caption.replace(/[\[\]\r\n]/g, ' ') || (lt ? 'FH ekrano nuotrauka' : 'FH screenshot')}](${image})`, true); setPanel(null); }}>{lt ? 'Įterpti' : 'Insert'}</button></div>}<div className="flex flex-wrap items-center gap-3"><input ref={fileInput} type="file" className="hidden" aria-label={lt ? 'Įkelti medijos failą' : 'Upload media file'} accept={panel === 'video' ? 'video/mp4,video/webm' : 'image/png,image/jpeg,image/webp,image/gif'} onChange={event => { const file = event.target.files?.[0]; event.target.value = ''; if (file) void upload(file); }} /><button className={helpEditorButton} disabled={busy} onClick={() => fileInput.current?.click()}>{panel === 'video' ? <Video size={15} /> : <ImagePlus size={15} />}{busy ? (lt ? 'Įkeliama…' : 'Uploading…') : (lt ? 'Įkelti iš kompiuterio' : 'Upload from computer')}</button><p className="text-[11px] text-[#7288A3]">{panel === 'video' ? 'MP4 / WebM · ≤ 50 MB' : 'PNG / JPG / WebP / GIF · ≤ 10 MB'}</p></div></div>}
      </div>}
      <div className={mode === 'split' ? 'grid gap-4 xl:grid-cols-2' : ''}>
        {mode !== 'preview' && <label className={label}>{lt ? 'Aprašymo turinys' : 'Article content'}<textarea ref={textarea} className={field + ' min-h-[440px] resize-y leading-7'} aria-label={lt ? 'Aprašymo turinys' : 'Article content'} maxLength={250000} disabled={busy} value={draft.body[lang]} onSelect={event => { selection.current = { start: event.currentTarget.selectionStart, end: event.currentTarget.selectionEnd }; }} onChange={event => update('body', event.target.value)} /></label>}
        {mode !== 'edit' && <div><p className={label + ' mb-1.5'}>{lt ? 'Taip matys naudotojas' : 'User preview'}</p><div className="h-[440px] overflow-auto rounded-lg border border-[#D3E1EC] bg-[#FAFCFE] p-5"><h3 className="mb-2 text-lg font-semibold">{draft.title[lang] || draft.title[1 - lang]}</h3><p className="mb-5 text-xs leading-6 text-[#7288A3]">{draft.description[lang] || draft.description[1 - lang]}</p><HelpArticleBody body={draft.body[lang]} /></div></div>}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 text-[11px] text-[#7288A3]"><span>{lt ? 'Kalbos redaguojamos atskirai. Teksto žymos: **paryškinta**, *kursyvas*, ## antraštė.' : 'Languages are edited separately. Text marks: **bold**, *italic*, ## heading.'}</span><span>{draft.body[lang].length.toLocaleString()} / 250 000</span></div>
      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
      {notice && <p role="status" className="flex items-center gap-2 text-xs text-[#2B8269]"><Check size={15} />{notice}</p>}
      <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5EDF9] pt-4"><div className="flex flex-wrap gap-2"><button className={helpEditorButton} disabled={busy} onClick={() => move(-1)}><ArrowUp size={14} />{lt ? 'Aukščiau' : 'Move up'}</button><button className={helpEditorButton} disabled={busy} onClick={() => move(1)}><ArrowDown size={14} />{lt ? 'Žemiau' : 'Move down'}</button><button className={helpEditorButton} disabled={busy || !visible} onClick={() => { setVisible(false); setNotice(lt ? 'Išsaugojus tema bus pašalinta iš naudotojų meniu. Turinys liks šiame medyje ir galės būti grąžintas.' : 'Save to remove this topic from the user menu. Content is retained and can be restored.'); }}><Trash2 size={14} />{lt ? 'Pašalinti iš meniu' : 'Remove from menu'}</button></div><button className={primary} disabled={busy || !dirty} onClick={submit}><Save size={15} />{lt ? 'Išsaugoti' : 'Save'}</button></footer>
      {state.history.some(item => item.key === draft.key) && <details className="text-xs text-[#7288A3]"><summary className="cursor-pointer py-2">{lt ? 'Pakeitimų istorija' : 'Change history'}</summary>{state.history.filter(item => item.key === draft.key).slice(-5).reverse().map((item, index) => <p key={index} className="py-1">{new Date(item.at).toLocaleString(lt ? 'lt-LT' : 'en-GB')} · {item.by} · {item.action === 'save' ? (lt ? 'Išsaugota' : 'Saved') : item.action === 'show' ? (lt ? 'Parodyta' : 'Shown') : (lt ? 'Paslėpta' : 'Hidden')}</p>)}</details>}
    </div>
  </section>;
}

export function HelpCategoryEditor({ original, onDirty }: { original: EditableHelpCategory; onDirty: (dirty: boolean) => void }) {
  const { state, save } = useHelpContent(), lt = useLanguage() === 'lt';
  const [draft, setDraft] = useState(() => structuredClone(original));
  const [visible, setVisible] = useState(isHelpGroupVisible(original.id, state)), [revision, setRevision] = useState(state.revision);
  const [baseline, setBaseline] = useState(() => JSON.stringify({ draft: original, visible: isHelpGroupVisible(original.id, state) }));
  const [lang, setLang] = useState<0 | 1>(lt ? 1 : 0), [error, setError] = useState(''), [notice, setNotice] = useState('');
  const dirty = JSON.stringify({ draft, visible }) !== baseline;
  useUnsavedChanges(dirty, onDirty);
  const update = (key: 'title' | 'description', value: string) => setDraft(current => ({ ...current, [key]: current[key].map((text, i) => i === lang ? value : text) as [string, string] }));
  const submit = () => { try { save(revision, { category: draft, visibility: { key: `category:${draft.id}`, visible } }); setRevision(value => value + 1); setBaseline(JSON.stringify({ draft, visible })); setError(''); setNotice(lt ? 'Skiltis išsaugota.' : 'Category saved.'); onDirty(false); } catch (error) { setError(errorText(error, lt)); } };
  return <section className="rounded-xl border border-[#D3E1EC] bg-white p-5"><h2 className="mb-5 text-lg font-semibold">{lt ? 'Skilties nustatymai' : 'Category settings'}</h2><div className="max-w-3xl space-y-5"><SearchableSelect ariaLabel={lt ? 'Turinio kalba' : 'Content language'} value={String(lang)} options={[{ value: '1', label: 'Lietuvių' }, { value: '0', label: 'English' }]} onChange={value => setLang(value === '1' ? 1 : 0)} portalMenu /><label className={label}>{lt ? 'Skilties pavadinimas' : 'Category title'}<input className={field} value={draft.title[lang]} maxLength={250} onChange={event => update('title', event.target.value)} /></label><label className={label}>{lt ? 'Skilties aprašymas' : 'Category description'}<textarea className={field} rows={5} maxLength={2000} value={draft.description[lang]} onChange={event => update('description', event.target.value)} /></label><label className="flex items-center gap-3 text-sm"><input type="checkbox" className="h-[18px] w-[18px] accent-[#007EA7]" checked={visible} onChange={event => setVisible(event.target.checked)} />{lt ? 'Rodyti skiltį naudotojams' : 'Show category to users'}</label><p className="text-xs leading-6 text-[#7288A3]">{lt ? 'Paslėpus skiltį, naudotojams nerodomos ir jos temos. Temos neištrinamos. Pasirinkite „Pridėti potemę“, kad šioje skiltyje sukurtumėte aprašymą.' : 'Hiding a category also hides its topics without deleting them. Choose Add subtopic to create an article in this category.'}</p>{error && <p role="alert" className="text-sm text-red-700">{error}</p>}{notice && <p role="status" className="text-sm text-[#2B8269]">{notice}</p>}<div className="flex justify-end gap-2"><button className={helpEditorButton} disabled={!visible} onClick={() => setVisible(false)}><Trash2 size={15} />{lt ? 'Pašalinti iš meniu' : 'Remove from menu'}</button><button className={primary} disabled={!dirty} onClick={submit}><Save size={15} />{lt ? 'Išsaugoti' : 'Save'}</button></div></div></section>;
}
