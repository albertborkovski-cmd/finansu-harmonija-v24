import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { toggleFilteredSelection } from '../lib/tableSelection';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowDownToLine, Check, Eye, FileText, Pencil, Play } from "lucide-react";
import type { Company, DbDocument } from "../lib/supabase";
import { ensureOcrReviewExampleFields } from '../lib/supabase';
import { loadOcrDocumentSource } from "../lib/ocrDocumentSource";
import { loadSavedReviewDocumentTask, loadSavedReviewDocumentTasks, OCR_REVIEW_DOCUMENT_TASK_KEYS } from "../lib/ocrReviewDocuments";
import { ocrDocumentStage } from '../lib/ocrDocumentWorkflow';
import { ocrRoutingTypeCodes } from '../lib/ocrApprovalRouting';
import { hasOcrValue, isRecognizedOcrDocumentType, ocrDocumentFieldValue } from '../lib/ocrRequiredFields';
import { teamLeadColumns } from '../lib/ocrTeamLeadReview';
import { documentWorkEntry, ocrTaskWorker, type OcrWorker } from '../lib/ocrTeamLeadWorkers';
import { canViewTeamLeadOrganization } from '../lib/ocrTeamLeadAccess';
import { OCR_DOCUMENT_WORK_LOG_KEY, type OcrDocumentWorkLog } from './ocrDocumentWorkTimeStore';
import { loadOrganizationReferenceRecords } from './OrganizationReferenceValuesView';
import { processingColumns, processingDocumentNumber } from '../lib/ocrProcessingDocuments';
import { documentTypeCatalogLabel, documentTypeColumns } from '../lib/documentTypeCatalog';
import { loadDocumentPurposeCatalog, recognizedOcrDocumentPurpose } from '../lib/documentPurposeCatalog';
import { WorkspaceDocumentEditor, type WorkspaceTask } from './WorkspaceView';
import { usePersistentState } from "../hooks/usePersistentState";
import { PageActionButton } from "./PageHeader";
import OcrDocumentsWorkspace from "./OcrDocumentsWorkspace";
import OcrDocumentDeliveryActions from './OcrDocumentDeliveryActions';
import OcrSearchField from "./OcrSearchField";
import SystemAddFilters, { type SystemFilterColumn } from "./SystemAddFilters";
import ColumnSettingsPanel, { type ColConfig } from "./ColumnSettingsPanel";
import ColumnSortButton, { useMultiColumnSort } from "./ColumnSortButton";
import { ColumnSettingsButton } from "./ScopedActionButtons";
import RefreshAllButton from "./RefreshAllButton";
import HorizontalTableScrollbar from "./HorizontalTableScrollbar";
import TablePagination from "./TablePagination";
import { TABLE_BATCH_SIZE } from "../lib/tablePaging";
import { PROCESSING_COLUMNS, REVIEW_COLUMNS, TEAM_LEAD_COLUMNS } from '../lib/ocrDocumentColumns';
import { ResizeHandle, useColumnResize } from "./useColumnResize";
import {
  OCR_FIELD_VALIDATION_CHANGED_EVENT,
  loadOcrFieldValidationRules,
  type OcrFieldValidationLevel,
} from "../lib/ocrFieldValidation";

type ProcessedColumnKey =
  | "workerComment"
  | "worker"
  | "organization"
  | "status"
  | "receiveDate"
  | "clientCounterparty"
  | "counterpartyCode"
  | "documentType"
  | "invoice"
  | "source"
  | "totalAmount"
  | "amountWithoutVat"
  | "vat"
  | "vatPercent"
  | "dueEndDate"
  | "fileCase"
  | "orderNo"
  | "number"
  | "type"
  | "subtype"
  | "documentDate"
  | "documentPurpose"
  | "invoiceContractDate"
  | "operationDate"
  | "glAccount"
  | "vatClassifier"
  | "productGroup"
  | "series"
  | "costCenter"
  | "objectProject"
  | "departmentCode"
  | "currency";

type ProcessedRow = Record<ProcessedColumnKey, string> & {
  id: string;
  organizationId: string;
  organizationName: string;
  workerEmail: string;
};

export type ReviewDocumentReference = {
  id: string;
  name: string;
  companyId?: string;
};


function rowProductGroup(document: DbDocument) {
  const values = [...(document.summary_line_items ?? []), ...(document.line_items ?? [])]
    .map((line) => line.productGroup?.trim())
    .filter((value): value is string => Boolean(value));
  return Array.from(new Set(values)).join(", ");
}

function statusColor(status: string) {
  const normalized = status.toLocaleLowerCase();
  if (["completed", "processed", "paid", "transferred", "approved"].includes(normalized)) return "#12B886";
  if (["duplicate", "rejected", "overdue"].includes(normalized)) return "#FF6200";
  if (normalized === 'worker review') return '#D92D20';
  if (["in progress", "pending", "processing"].includes(normalized)) return "#E6A700";
  return "#7288A3";
}

function SelectionCheckbox({
  checked,
  mixed = false,
  label,
  onChange,
}: {
  checked: boolean;
  mixed?: boolean;
  label: string;
  onChange: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (inputRef.current) inputRef.current.indeterminate = mixed;
  }, [mixed]);

  return (
    <input
      ref={inputRef}
      type="checkbox"
      checked={checked}
      aria-label={uiText(label)}
      onClick={(event) => event.stopPropagation()}
      onChange={(event) => {
        event.stopPropagation();
        onChange();
      }}
      className="h-[18px] w-[18px] cursor-pointer rounded border border-[#A1B6C6] accent-[#007EA7]"
    />
  );
}

export function ProcessedDocumentsTable({
  embedded = false,
  reviewOnly = false,
  teamLead = false,
  onOpenWorker,
  showAllDocuments = false,
  processingQueue = false,
  selectable = false,
  onViewDocument,
  onEditDocument,
  onRunDocument,
  onApproveDocument,
  onImportDocuments,
  importActionContainer,
  selectionActionVariant = "import",
  accountingDelivery = false,
  documentIds,
  onRefreshDocuments,
  emptyMessage,
}: {
  embedded?: boolean;
  reviewOnly?: boolean;
  teamLead?: boolean;
  onOpenWorker?: (worker: OcrWorker) => void;
  showAllDocuments?: boolean;
  /** My tasks uses the shared Processing group while preserving its existing table layout. */
  processingQueue?: boolean;
  selectable?: boolean;
  onViewDocument?: (document: ReviewDocumentReference, index: number, documents: ReviewDocumentReference[]) => void;
  onEditDocument?: (document: ReviewDocumentReference, index: number, documents: ReviewDocumentReference[]) => void;
  onRunDocument?: (document: ReviewDocumentReference) => void | Promise<void>;
  onApproveDocument?: (document: ReviewDocumentReference) => void;
  onImportDocuments?: (documents: ReviewDocumentReference[]) => void | Promise<void>;
  importActionContainer?: HTMLElement | null;
  selectionActionVariant?: "import" | "run";
  /** Reuse Companies / Documents delivery only on the approval screen. */
  accountingDelivery?: boolean;
  /** A hard task scope, independent of the user-clearable table filters. */
  documentIds?: ReadonlySet<string>;
  onRefreshDocuments?: () => void | Promise<unknown>;
  emptyMessage?: string;
}) {
  const processingView = !reviewOnly && !showAllDocuments;
  const defaultColumns = teamLead ? TEAM_LEAD_COLUMNS : processingView ? PROCESSING_COLUMNS : REVIEW_COLUMNS;
  const [classificationRecords, setClassificationRecords] = useState(() => loadOrganizationReferenceRecords('Document type'));
  const [purposeRecords, setPurposeRecords] = useState(loadDocumentPurposeCatalog);
  const [organizations, setOrganizations] = useState<Company[]>([]);
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [savedTasks, setSavedTasks] = useState<Map<string, WorkspaceTask | undefined>>(new Map());
  const [workLog, setWorkLog] = useState<OcrDocumentWorkLog>({});
  const [query, setQuery] = useState("");
  const [columns, setColumns] = usePersistentState<ColConfig[]>(
    teamLead ? "finansu-harmonija:v22:ocr:team-lead:columns" : reviewOnly
      ? "finansu-harmonija:v12:ml:need-review-documents:columns"
      : processingView ? "finansu-harmonija:v22:ocr:processing-documents:columns"
      : "finansu-harmonija:v12:ocr:processed-documents:columns",
    () => {
      if (teamLead) {
        try {
          const saved = JSON.parse(localStorage.getItem('finansu-harmonija:v12:ml:need-review-documents:columns') || 'null');
          if (Array.isArray(saved)) return teamLeadColumns(saved);
        } catch { /* Retain system defaults for invalid legacy preferences. */ }
      }
      if (processingView) {
        try {
          const saved = JSON.parse(localStorage.getItem('finansu-harmonija:v12:ocr:processed-documents:columns') || 'null');
          if (Array.isArray(saved)) return processingColumns(saved);
        } catch { /* Use the system defaults if legacy preferences are unavailable. */ }
      }
      return defaultColumns;
    },
  );
  const [selectedOrganizationIds, setSelectedOrganizationIds] = usePersistentState<string[]>(
    teamLead ? "finansu-harmonija:v22:ocr:team-lead:organizations" : "finansu-harmonija:v12:ocr:processed-documents:organizations",
    [],
  );
  const [organizationSelectionInitialized, setOrganizationSelectionInitialized] = usePersistentState(
    teamLead ? "finansu-harmonija:v22:ocr:team-lead:organizations-initialized" : "finansu-harmonija:v12:ocr:processed-documents:organizations-initialized",
    false,
  );
  const [activeFilterKeys, setActiveFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const [showColumns, setShowColumns] = useState(false);
  const [page, setPage] = useState(1);
  const [selectedRowIds, setSelectedRowIds] = useState<Set<string>>(new Set());
  const [importing, setImporting] = useState(false);
  const [fieldValidationRules, setFieldValidationRules] = useState(() => loadOcrFieldValidationRules());
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(columns, setColumns);

  const loadData = useCallback(async () => {
    if (reviewOnly) await ensureOcrReviewExampleFields();
    const { organizations: nextOrganizations, documents: nextDocuments } = await loadOcrDocumentSource();
    const accessibleOrganizations = teamLead ? nextOrganizations.filter(canViewTeamLeadOrganization) : nextOrganizations;
    const companyIds = new Set(accessibleOrganizations.map(company => company.id));
    const accessibleDocuments = teamLead ? nextDocuments.filter(document => companyIds.has(document.company_id ?? '')) : nextDocuments;
    setOrganizations(accessibleOrganizations);
    setDocuments(accessibleDocuments);
    setSavedTasks(loadSavedReviewDocumentTasks(accessibleDocuments, localStorage));
    try { setWorkLog(JSON.parse(localStorage.getItem(OCR_DOCUMENT_WORK_LOG_KEY) || '{}') || {}); }
    catch { setWorkLog({}); }
    setSelectedOrganizationIds((current) => {
      const validIds = new Set(accessibleOrganizations.map((organization) => organization.id));
      const validSelection = current.filter((id) => validIds.has(id));
      if (validSelection.length > 0 || organizationSelectionInitialized) {
        return validSelection;
      }
      return accessibleOrganizations.map((organization) => organization.id);
    });
    if (!organizationSelectionInitialized) setOrganizationSelectionInitialized(true);
  }, [organizationSelectionInitialized, setOrganizationSelectionInitialized, setSelectedOrganizationIds, teamLead, reviewOnly]);

  useEffect(() => {
    void loadData();
    const reload = () => {
      setClassificationRecords(loadOrganizationReferenceRecords('Document type'));
      setPurposeRecords(loadDocumentPurposeCatalog());
      void loadData();
    };
    window.addEventListener("finansu-harmonija:data-changed", reload);
    window.addEventListener("finansu-harmonija:settings-data-changed", reload);
    window.addEventListener('organization-reference-updated', reload);
    const taskChanged = (event: Event) => {
      if (event.type === 'storage') {
        setPurposeRecords(loadDocumentPurposeCatalog());
        setClassificationRecords(loadOrganizationReferenceRecords('Document type'));
      }
      const key = event instanceof StorageEvent ? event.key : (event as CustomEvent<{ storageKey?: string }>).detail?.storageKey;
      if (key && ((OCR_REVIEW_DOCUMENT_TASK_KEYS as readonly string[]).includes(key) || key === OCR_DOCUMENT_WORK_LOG_KEY)) void loadData();
    };
    window.addEventListener('storage', taskChanged);
    window.addEventListener('finansu-harmonija:persistent-state-changed', taskChanged);
    return () => {
      window.removeEventListener("finansu-harmonija:data-changed", reload);
      window.removeEventListener("finansu-harmonija:settings-data-changed", reload);
      window.removeEventListener('organization-reference-updated', reload);
      window.removeEventListener('storage', taskChanged);
      window.removeEventListener('finansu-harmonija:persistent-state-changed', taskChanged);
    };
  }, [loadData]);

  useEffect(() => {
    const reloadRules = () => setFieldValidationRules(loadOcrFieldValidationRules());
    window.addEventListener(OCR_FIELD_VALIDATION_CHANGED_EVENT, reloadRules);
    return () => window.removeEventListener(OCR_FIELD_VALIDATION_CHANGED_EVENT, reloadRules);
  }, []);

  useEffect(() => {
    setColumns((current) => {
      const migrated = documentTypeColumns(teamLead ? teamLeadColumns(current) : processingView ? processingColumns(current) : current);
      const missing = defaultColumns.filter(
        (defaultColumn) => !migrated.some((column) => column.key === defaultColumn.key),
      );
      const next = [...migrated, ...missing];
      return JSON.stringify(next) === JSON.stringify(current) ? current : next;
    });
  }, [defaultColumns, processingView, setColumns, teamLead]);

  const organizationById = useMemo(
    () => new Map(organizations.map((organization) => [organization.id, organization])),
    [organizations],
  );
  const workflowById = useMemo(() => new Map(documents.map(document => [document.id,
    ocrDocumentStage(document, savedTasks.get(document.id))])), [documents, savedTasks]);

  const counterpartyCodes = useMemo(() => {
    try {
      const stored = window.localStorage.getItem("finansu-harmonija:v7:settings:counterparties");
      const counterparties = stored ? (JSON.parse(stored) as Company[]) : [];
      return new Map(counterparties.map((counterparty) => [counterparty.name.trim().toLocaleLowerCase(), counterparty.company_code ?? ""]));
    } catch {
      return new Map<string, string>();
    }
  }, []);

  const documentById = useMemo(() => new Map(documents.map(document => [document.id, document])), [documents]);
  const rows = useMemo<ProcessedRow[]>(() => documents
    .filter((document) => !documentIds || documentIds.has(document.id))
    .filter((document) => selectedOrganizationIds.includes(document.company_id ?? ""))
    .filter((document) => showAllDocuments || workflowById.get(document.id)?.queue === (reviewOnly ? 'approval' : 'processing'))
    .map((document) => ({
      id: document.id,
      organizationId: document.company_id ?? "",
      organizationName: organizationById.get(document.company_id ?? "")?.name ?? "—",
      organization: organizationById.get(document.company_id ?? "")?.name ?? "—",
      status: processingQueue ? 'Processing' : teamLead && showAllDocuments
        ? savedTasks.get(document.id)?.teamLeadReview?.status === 'Pending' ? 'Awaiting team lead'
          : savedTasks.get(document.id)?.status || workflowById.get(document.id)?.status || document.status || '—'
        : showAllDocuments ? document.status || "—" : workflowById.get(document.id)?.status || "—",
      workerComment: savedTasks.get(document.id)?.teamLeadReview?.comment || "—",
      worker: ocrTaskWorker(savedTasks.get(document.id), documentWorkEntry(workLog, document.id))?.name || '—',
      workerEmail: ocrTaskWorker(savedTasks.get(document.id), documentWorkEntry(workLog, document.id))?.email || '',
      receiveDate: document.receive_date || "—",
      clientCounterparty: document.client_counterparty || "—",
      counterpartyCode: document.counterparty_code || counterpartyCodes.get((document.client_counterparty ?? "").trim().toLocaleLowerCase()) || document.counterparty_id || "—",
      documentType: uiText(documentTypeCatalogLabel(document, classificationRecords) || '—'),
      invoice: /invoice/i.test(document.document_type || "") ? "Yes" : "No",
      source: document.source || "—",
      totalAmount: document.total_amount || "—",
      amountWithoutVat: document.amount_without_vat || "—",
      vat: document.vat || "—",
      vatPercent: document.vat_percent || "—",
      dueEndDate: document.due_end_date || "—",
      fileCase: document.file_case || "—",
      orderNo: document.order_no || "—",
      number: processingDocumentNumber(document),
      type: uiText(documentTypeCatalogLabel(document, classificationRecords) || '—'),
      subtype: uiText(documentTypeCatalogLabel(document, classificationRecords) || '—'),
      documentDate: document.document_date || "—",
      documentPurpose: uiText(recognizedOcrDocumentPurpose(document, purposeRecords)?.fullName || ''),
      invoiceContractDate: document.invoice_contract_date || "—",
      operationDate: document.operation_date || "—",
      glAccount: document.expense_account || "—",
      vatClassifier: document.vat_classifier || "—",
      productGroup: rowProductGroup(document) || "—",
      series: document.series || "—",
      costCenter: document.cost_center || "—",
      objectProject: document.object_project || "—",
      departmentCode: document.department_code || "—",
      currency: document.currency || "—",
    })), [classificationRecords, counterpartyCodes, documentIds, documents, organizationById, processingQueue, processingView, purposeRecords, reviewOnly, savedTasks, selectedOrganizationIds, showAllDocuments, teamLead, workLog, workflowById]);

  const filterColumns = useMemo<SystemFilterColumn[]>(() => defaultColumns.map((column) => ({
    key: column.key,
    label: column.label,
    options: Array.from(new Set(rows.map((row) => column.key === 'worker' ? row.workerEmail : row[column.key as ProcessedColumnKey]).filter((value) => value && value !== "—"))).sort(),
    ...(column.key === 'worker' ? { optionLabels: Object.fromEntries(rows.filter(row => row.workerEmail).map(row => [row.workerEmail, `${row.worker} · ${row.workerEmail}`])) } : {}),
  })), [defaultColumns, rows]);

  const filteredRows = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    return rows.filter((row) => {
      if (normalizedQuery && !Object.values(row).some((value) => String(value).toLocaleLowerCase().includes(normalizedQuery))) return false;
      return activeFilterKeys.every((key) => {
        const selectedValues = filterValues[key] ?? [];
        return selectedValues.length === 0 || selectedValues.includes(key === 'worker' ? row.workerEmail : row[key as ProcessedColumnKey]);
      });
    });
  }, [activeFilterKeys, filterValues, query, rows]);

  const { sortedRows, changeSort, directionFor } = useMultiColumnSort<ProcessedRow, ProcessedColumnKey>(
    filteredRows,
    (row, key) => row[key],
  );
  const pageSize = TABLE_BATCH_SIZE;
  const totalPages = Math.max(1, Math.ceil(sortedRows.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const displayedRows = sortedRows.slice(0, safePage * pageSize);
  const effectiveColumns = documentTypeColumns(teamLead ? teamLeadColumns(columns) : processingView ? processingColumns(columns) : columns);
  const visibleColumns = effectiveColumns.filter((column) => column.visible);
  const rowActionCount = Number(Boolean(onViewDocument)) + Number(Boolean(onEditDocument)) + Number(Boolean(onRunDocument)) + Number(Boolean(onApproveDocument));
  const rowActionsWidth = rowActionCount ? Math.max(88, rowActionCount * 36 + 12) : 0;
  const validationLevelByField = useMemo(
    () => {
      const byType = new Map<string, Map<string, OcrFieldValidationLevel>>();
      return new Map(documents.map(document => {
        const documentTypes = ocrRoutingTypeCodes(document, classificationRecords), key = JSON.stringify(documentTypes);
        let levels = byType.get(key);
        if (!levels) {
          levels = new Map(loadOcrFieldValidationRules({ documentTypes }).filter(rule => rule.enabled !== false && !rule.inactive)
            .map(rule => [rule.key, rule.required ? 'red' : rule.level]));
          byType.set(key, levels);
        }
        return [document.id, levels];
      }));
    },
    [documents, classificationRecords, fieldValidationRules],
  );
  const reviewDocumentQueue = useMemo<ReviewDocumentReference[]>(() => sortedRows.map((row) => ({
    id: row.id,
    name: row.fileCase === "—" ? `Document ${row.id}` : row.fileCase,
    companyId: row.organizationId,
  })), [sortedRows]);

  const allRowsSelected = selectable && sortedRows.length > 0 && sortedRows.every((row) => selectedRowIds.has(row.id));
  const someRowsSelected = selectable && !allRowsSelected && sortedRows.some((row) => selectedRowIds.has(row.id));

  const toggleAllRows = () => {
    setSelectedRowIds(current => toggleFilteredSelection(current, sortedRows.map(row => row.id)));
  };

  const toggleRow = (rowId: string) => {
    setSelectedRowIds((current) => {
      const next = new Set(current);
      if (next.has(rowId)) next.delete(rowId);
      else next.add(rowId);
      return next;
    });
  };

  const importSelectedDocuments = async () => {
    if (!onImportDocuments || selectedRowIds.size === 0 || importing) return;
    const selectedDocuments = reviewDocumentQueue.filter((document) => selectedRowIds.has(document.id));
    if (selectedDocuments.length === 0) return;
    setImporting(true);
    try {
      await onImportDocuments(selectedDocuments);
      setSelectedRowIds(new Set());
      await loadData();
    } finally {
      setImporting(false);
    }
  };

  useEffect(() => setPage(1), [activeFilterKeys, filterValues, query, selectedOrganizationIds]);

  const importAction = selectable && onImportDocuments ? (
    <PageActionButton
      ariaLabel={`${selectionActionVariant === "run" ? "Run" : "Import"} selected documents`}
      icon={selectionActionVariant === "run"
        ? <Play size={15} className={importing ? "animate-pulse" : undefined} />
        : <ArrowDownToLine size={15} className={importing ? "animate-pulse" : undefined} />}
      disabled={selectedRowIds.size === 0 || importing}
      onClick={() => void importSelectedDocuments()}
    >
      {importing
        ? selectionActionVariant === "run" ? uiText("Running…") : uiText("Importing…")
        : selectionActionVariant === "run" ? uiText("Run") : uiText("Import")}
    </PageActionButton>
  ) : null;

  return (
    <>
      {importActionContainer && importAction ? createPortal(importAction, importActionContainer) : null}
    <OcrDocumentsWorkspace
      title={uiText("Processing documents")}
      organizations={organizations}
      selectedIds={selectedOrganizationIds}
      onOrganizationsChange={setSelectedOrganizationIds}
      embedded={embedded}
    >
          <div className="system-table-toolbar flex min-h-8 shrink-0 flex-wrap items-center gap-x-1 gap-y-2">
            <OcrSearchField ariaLabel={reviewOnly ? uiText("Search documents requiring review") : uiText("Search processing documents")} value={query} onChange={setQuery} />
            <SystemAddFilters
              columns={filterColumns}
              activeKeys={activeFilterKeys}
              values={filterValues}
              onActiveKeysChange={setActiveFilterKeys}
              onValuesChange={setFilterValues}
              persistenceKey={teamLead ? "finansu-harmonija:v22:ocr:team-lead:filters" : reviewOnly ? "finansu-harmonija:v12:ml:need-review-documents:filters" : "finansu-harmonija:v12:ocr:processed-documents:filters"}
            />
            <div className="ml-auto flex h-7 shrink-0 items-center gap-3">
              {!importActionContainer && importAction}
              <ColumnSettingsButton onClick={() => setShowColumns(true)} />
              {selectable && accountingDelivery && <OcrDocumentDeliveryActions
                selectedIds={selectedRowIds} documents={documents} companies={organizations}
                actionContainer={importActionContainer} />}
              <RefreshAllButton onRefresh={async () => { await onRefreshDocuments?.(); await loadData(); }} />
            </div>
          </div>


          <div ref={tableScrollRef} className={`min-h-0 flex-1 overflow-x-auto overscroll-contain scrollbar-hide ${!embedded ? 'lg:overflow-y-auto' : ''}`}>
            <div style={{ minWidth: visibleColumns.reduce((sum, column) => sum + column.width, (selectable ? 42 : 0) + rowActionsWidth) }}>
          <div className="mb-1 flex h-10 items-center border-b border-[#D3E1EC]">
            {selectable && (
              <div data-table-header-select="true" className="flex w-[42px] flex-shrink-0 items-center justify-center">
                <SelectionCheckbox checked={allRowsSelected} mixed={someRowsSelected} label={uiText("Select all documents")} onChange={toggleAllRows} />
              </div>
            )}
            {visibleColumns.map((column, visibleIndex) => {
              const columnIndex = columns.findIndex((item) => item.key === column.key);
              return (
                <div
                  key={column.key}
                  style={{ width: column.width }}
                  className={`relative flex flex-shrink-0 items-center gap-1 px-3 font-montserrat text-[12px] font-medium text-[#7288A3] ${visibleIndex ? "border-l border-[#D3E1EC]" : ""}`}
                >
                  <span className="truncate">{uiText(column.label)}</span>
                  <ColumnSortButton
                    columnLabel={uiText(column.label)}
                    direction={directionFor(column.key as ProcessedColumnKey)}
                    onDirectionChange={(direction) => { changeSort(column.key as ProcessedColumnKey, direction); setPage(1); }}
                  />
                  <ResizeHandle onMouseDown={(event) => startResize(columnIndex, event)} />
                </div>
              );
            })}
            {rowActionCount > 0 && <div style={{ width: rowActionsWidth }} className="flex-shrink-0" aria-hidden="true" />}
          </div>

              <div className="flex flex-col gap-0.5">
            {displayedRows.map((row, index) => (
              <div key={row.id} className={`flex h-10 items-center rounded-lg font-montserrat text-[12px] font-normal leading-[18px] ${index % 2 === 0 ? "bg-[#F8FDFF]" : "bg-white"} hover:bg-[#E7F4F9]`}>
                {selectable && (
                  <div className="flex w-[42px] flex-shrink-0 items-center justify-center">
                    <SelectionCheckbox checked={selectedRowIds.has(row.id)} label={`Select ${row.fileCase === "—" ? row.id : row.fileCase}`} onChange={() => toggleRow(row.id)} />
                  </div>
                )}
                {visibleColumns.map((column) => {
                  const key = column.key as ProcessedColumnKey;
                  const sourceDocument = documentById.get(row.id);
                  const invalidType = Boolean(sourceDocument && ['documentType', 'subtype'].includes(key)
                    && !isRecognizedOcrDocumentType(sourceDocument, classificationRecords));
                  const validationLevel = invalidType ? 'red' : validationLevelByField.get(row.id)?.get(key) as OcrFieldValidationLevel | undefined;
                  const needsAttention = invalidType || key !== 'workerComment' && key !== 'worker' && Boolean(validationLevel)
                    && (sourceDocument ? !hasOcrValue(ocrDocumentFieldValue(sourceDocument, key)) : row[key] === "—");
                  const validationColors = validationLevel === "red"
                    ? { background: "bg-[#FFF0F0]", text: "text-[#D92D20]" }
                    : validationLevel === "yellow"
                      ? { background: "bg-[#FFF8E5]", text: "text-[#9A6700]" }
                      : { background: "bg-[#EAF8F2]", text: "text-[#087A55]" };
                  return (
                    <div
                      key={key}
                      style={{ width: column.width }}
                      className={`flex h-10 flex-shrink-0 items-center overflow-hidden px-3 ${needsAttention ? `rounded-md ${validationColors.background}` : ""}`}
                      title={invalidType ? uiText('Select a valid document type from the configured list.') : needsAttention ? `${column.label} was not digitized (${validationLevel})` : undefined}
                    >
                      {key === 'worker' && row.workerEmail && onOpenWorker
                        ? <button type="button" onClick={() => onOpenWorker({ email: row.workerEmail, name: row.worker })} title={row.workerEmail}
                          aria-label={`View tasks for ${row.worker} (${row.workerEmail})`} className="truncate text-left text-[#007EA7] hover:underline">{row.worker}</button>
                        : key === 'workerComment' ? <span title={row.workerComment} className="line-clamp-2 whitespace-pre-wrap break-words font-montserrat text-[12px] leading-4 text-[#10233A]">{row.workerComment}</span> : key === "status" ? (
                        <span className="flex items-center gap-2 font-montserrat text-[12px] text-[#10233A]">
                          <span className="h-2 w-2 flex-shrink-0 rounded-full" style={{ backgroundColor: statusColor(row.status) }} />
                          <span className="truncate">{statusText(row.status)}</span>
                        </span>
                      ) : key === 'fileCase' && onViewDocument && row.fileCase !== '—' ? (
                        <a href={`#ocr-document-${encodeURIComponent(row.id)}`} title={`View ${row.fileCase}`}
                          onClick={event => {
                            event.preventDefault();
                            const queueIndex = reviewDocumentQueue.findIndex(document => document.id === row.id);
                            const selectedDocument = reviewDocumentQueue[queueIndex];
                            if (selectedDocument) onViewDocument(selectedDocument, queueIndex, reviewDocumentQueue);
                          }}
                          className="truncate text-[#007EA7] hover:underline focus-visible:underline">{row.fileCase}</a>
                      ) : (
                        <span className={`block truncate font-montserrat text-[12px] font-normal ${needsAttention ? `font-medium ${validationColors.text}` : "text-[#10233A]"}`} title={needsAttention ? undefined : row[key]}>{invalidType ? `${row[key]} !` : needsAttention ? '—' : row[key]}</span>
                      )}
                    </div>
                  );
                })}
                {rowActionCount > 0 && (
                  <div style={{ width: rowActionsWidth }} className="system-table-row-actions flex h-10 flex-shrink-0 items-center justify-center gap-2 border-l border-[#E5EDF9] bg-inherit">
                    {onViewDocument && <button
                        type="button"
                        title={uiText("VIEW")}
                        aria-label={`View ${row.fileCase}`}
                        onClick={() => {
                          const queueIndex = reviewDocumentQueue.findIndex(document => document.id === row.id);
                          const selectedDocument = reviewDocumentQueue[queueIndex];
                          if (selectedDocument) onViewDocument(selectedDocument, queueIndex, reviewDocumentQueue);
                        }}
                        className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7]"
                      >
                        <Eye size={15} strokeWidth={1.8} />
                      </button>}
                    {onEditDocument && <button
                        type="button"
                        title={uiText("EDIT")}
                        aria-label={`EDIT ${row.fileCase}`}
                        onClick={() => {
                          const queueIndex = reviewDocumentQueue.findIndex((document) => document.id === row.id);
                          const selectedDocument = reviewDocumentQueue[queueIndex];
                          if (selectedDocument) onEditDocument(selectedDocument, queueIndex, reviewDocumentQueue);
                        }}
                        className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7]"
                      >
                        <Pencil size={15} strokeWidth={1.8} />
                      </button>}
                    {onRunDocument && <button
                        type="button"
                        title={uiText("RUN")}
                        aria-label={`RUN ${row.fileCase}`}
                        onClick={() => {
                          const selectedDocument = reviewDocumentQueue.find((document) => document.id === row.id);
                          if (selectedDocument) void onRunDocument(selectedDocument);
                        }}
                        className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7]"
                      >
                        <Play size={15} strokeWidth={1.8} />
                      </button>}
                    {onApproveDocument && <button
                        type="button"
                        title={uiText("APPROVE")}
                        aria-label={`APPROVE ${row.fileCase}`}
                        onClick={() => {
                          const selectedDocument = reviewDocumentQueue.find((document) => document.id === row.id);
                          if (selectedDocument) onApproveDocument(selectedDocument);
                        }}
                        className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#12B886] hover:text-[#12B886]"
                      >
                        <Check size={15} strokeWidth={2} />
                      </button>}
                  </div>
                )}
              </div>
            ))}
            {displayedRows.length === 0 && (
              <div className="flex min-h-[280px] flex-col items-center justify-center gap-3 font-montserrat text-[#7288A3]">
                <FileText size={30} />
                <span className="text-[14px] font-semibold">{emptyMessage || (reviewOnly ? "No documents awaiting approval" : "No documents currently being processed")}</span>
              </div>
            )}
              </div>
            </div>
          </div>

          <HorizontalTableScrollbar scrollRef={tableScrollRef} />
          <TablePagination
            currentPage={safePage}
            totalPages={totalPages}
            itemCount={sortedRows.length}
            itemsPerPage={pageSize}
            onPageChange={setPage}
            scrollRef={tableScrollRef}
          />
      {showColumns && (
        <ColumnSettingsPanel
          columns={effectiveColumns}
          defaultColumns={defaultColumns}
          onSave={(next) => {
            setColumns(processingView ? processingColumns(next) : next);
            setShowColumns(false);
          }}
          onClose={() => setShowColumns(false)}
        />
      )}
      </OcrDocumentsWorkspace>
    </>
  );
}

export default function OcrProcessedDocumentsView() {
  const [viewedDocument, setViewedDocument] = useState<{
    reference: ReviewDocumentReference; position: number; total: number; savedTask?: WorkspaceTask;
  } | null>(null);
  return <>
    <div hidden={Boolean(viewedDocument)}>
      <ProcessedDocumentsTable onViewDocument={(reference, index, documents) => setViewedDocument({
        reference, position: index + 1, total: documents.length,
        savedTask: loadSavedReviewDocumentTask(reference, localStorage),
      })} />
    </div>
    {viewedDocument && <WorkspaceDocumentEditor
      key={viewedDocument.reference.id}
      documentId={viewedDocument.reference.id}
      documentName={viewedDocument.reference.name}
      companyId={viewedDocument.reference.companyId}
      savedTask={viewedDocument.savedTask}
      filePosition={viewedDocument.position}
      fileTotal={viewedDocument.total}
      readOnly
      viewNotice="Saved result · Read-only"
      onBack={() => setViewedDocument(null)}
    />}
  </>;
}
