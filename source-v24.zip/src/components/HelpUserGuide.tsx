import { ArrowRight, CheckCircle2, Info, MapPin } from 'lucide-react';
import { OCR_USER_GUIDES, type OcrUserGuide } from '../lib/ocrUserGuides';
import { HelpScreenshot } from './HelpMedia';
import { SECURITY_USER_GUIDES } from '../lib/securityUserGuides';
import { useHelpContent } from './HelpContentProvider';
import { isHelpVisible } from '../lib/helpContent';

export default function HelpUserGuide({ guide, lang }: { guide: OcrUserGuide; lang: 0 | 1 }) {
  const lt = lang === 1;
  const { state } = useHelpContent();
  const related = guide.related.flatMap(id => { const item = [...OCR_USER_GUIDES, ...SECURITY_USER_GUIDES].find(candidate => candidate.id === id); return item && isHelpVisible(`./#help?category=${item.category}&article=${item.id}`, state) ? [item] : []; });
  return <div className="space-y-7 [&_th]:!resize-none [&_th]:after:!hidden">
    <nav aria-label={lt ? 'Šiame straipsnyje' : 'In this article'} className="rounded-lg border border-[#D3E1EC] bg-[#F5F9FC] p-4">
      <h2 className="mb-3 text-[13px] font-semibold">{lt ? 'Šiame straipsnyje' : 'In this article'}</h2>
      <ol className="grid gap-2 sm:grid-cols-2">{guide.sections.map((section, index) => <li key={section.id}>
        <a href={`#guide-${section.id}`} onClick={event => { event.preventDefault(); const target = document.getElementById(`guide-${section.id}`); target?.scrollIntoView({ behavior: 'smooth', block: 'start' }); target?.focus({ preventScroll: true }); }} className="inline-flex gap-2 rounded text-[12px] leading-5 text-[#007EA7] hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]"><span>{index + 1}.</span>{section.title[lang]}</a>
      </li>)}</ol>
    </nav>
    <p className="text-[11px] leading-5 text-[#7288A3]">{lt ? 'Nuotraukos iš FH V25. Paspauskite nuotrauką, kad atvertumėte didesnį vaizdą naujame skirtuke. Nuotraukose matomi pavyzdiniai įrašai ir lietuvių kalbos sąsaja; jūsų duomenys ir skaičiai gali skirtis.' : 'Screenshots from FH V25. Click any image to open it larger in a new tab. They show example records and the Lithuanian interface; your data and counts may differ.'}</p>
    {guide.sections.map((section, index) => <section key={section.id} id={`guide-${section.id}`} tabIndex={-1} aria-labelledby={`guide-title-${section.id}`} className="scroll-mt-24 border-t border-[#E5EDF9] pt-6 outline-none">
      <h2 id={`guide-title-${section.id}`} className="mb-4 flex items-start gap-3 text-[18px] font-semibold leading-7"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-[#E5EDF9] text-[12px] text-[#007EA7]">{index + 1}</span>{section.title[lang]}</h2>
      {section.path && <p className="mb-5 flex items-start gap-2 rounded-lg bg-[#F3F8FB] px-3 py-2 text-[12px] font-medium leading-6 text-[#526B86]"><MapPin size={15} className="mt-1 shrink-0 text-[#007EA7]" aria-hidden="true" />{section.path[lang]}</p>}
      {section.paragraphs?.map(text => <p key={text[0]} className="mb-4 text-[13px] leading-7 text-[#526B86]">{text[lang]}</p>)}
      {section.steps && <ol className="space-y-4">{section.steps.map((text, step) => <li key={text[0]} className="flex gap-3 text-[13px] leading-7 text-[#526B86]"><span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[#D3E1EC] text-[11px] font-semibold text-[#007EA7]">{step + 1}</span><p>{text[lang]}</p></li>)}</ol>}
      {section.table && <div className="my-5 overflow-x-auto rounded-lg border border-[#D3E1EC]"><table className="w-full text-left text-[12px] leading-6"><thead className="bg-[#F2F7FA]"><tr>{section.table.headers.map(cell => <th key={cell[0]} scope="col" className="px-4 py-3 font-semibold">{cell[lang]}</th>)}</tr></thead><tbody className="divide-y divide-[#E5EDF9]">{section.table.rows.map((row, i) => <tr key={i}>{row.map((cell, j) => j === 0 ? <th key={j} scope="row" className="px-4 py-3 align-top font-medium">{cell[lang]}</th> : <td key={j} className="px-4 py-3 align-top text-[#526B86]">{cell[lang]}</td>)}</tr>)}</tbody></table></div>}
      {section.result && <div className="mt-5 flex gap-2.5 rounded-lg border border-[#D1E7DE] bg-[#F3FAF7] p-4 text-[12px] leading-6 text-[#42665B]"><CheckCircle2 size={17} className="mt-1 shrink-0" aria-hidden="true" /><p><strong>{lt ? 'Rezultatas: ' : 'Result: '}</strong>{section.result[lang]}</p></div>}
      {section.warning && <div className="mt-5 flex gap-2.5 rounded-lg border border-[#D3E1EC] bg-[#F0F6FA] p-4 text-[12px] leading-6 text-[#526B86]"><Info size={17} className="mt-1 shrink-0 text-[#007EA7]" aria-hidden="true" /><p>{section.warning[lang]}</p></div>}
      {section.images?.map(visual => <HelpScreenshot key={visual.file} lt={lt} file={visual.file} caption={visual.caption[lang]} />)}
    </section>)}
    {related.length > 0 && <section className="border-t border-[#D3E1EC] pt-5"><h2 className="mb-3 text-[15px] font-semibold">{lt ? 'Kitas žingsnis ir susiję paaiškinimai' : 'Next steps and related guides'}</h2><ul className="space-y-3">{related.map(item => <li key={item.id}><a href={`./#help?${new URLSearchParams({ category: item.category, article: item.id })}`} className="inline-flex items-start gap-2 text-[12px] leading-6 text-[#007EA7] underline decoration-[#BCD7E3] underline-offset-4"><ArrowRight size={14} className="mt-1.5 shrink-0" />{item.title[lang]}</a></li>)}</ul></section>}
  </div>;
}
