import { translateMessage, translateUi as uiText } from '../i18n/language';
import { toggleFilteredSelection } from '../lib/tableSelection';
import { useEffect, useMemo, useRef, useState } from 'react';
import { usePersistentState } from '../hooks/usePersistentState';
import { Bell, CreditCard, MailCheck, MoreVertical } from 'lucide-react';
import { createPortal } from 'react-dom';
import type { Company } from '../lib/supabase';
import { debtActionState, debtInTab, debtPaymentDraft, groupDebtActions, type DebtAction, type DebtActionGroup, type DebtTab } from '../lib/debtActions';
import { debtActionRights } from '../lib/debtActionAccess';
import { allDebtColumns, DEBT_AGING_GROUPS, debtColumnSortValue, debtColumnValue, restoreDebtColumns } from '../lib/debtTableColumns';
import { loadOrganizationCounterparties } from '../lib/organizationReferenceLists';
import { counterpartyIbans } from '../lib/companyCounterpartyImport';
import { companyBankAccounts } from '../lib/bankTransaction';
import type { CompanyPayment } from '../lib/companyPayments';
import NewPaymentForm from './NewPaymentForm';
import SendInvoicePanel from './invoices/SendInvoicePanel';
import { importMenuRecords } from '../lib/menuImport';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import OcrSearchField from './OcrSearchField';
import { PageActionButton, PageHeader } from './PageHeader';
import { ColumnSettingsButton, ImportDataButton } from './ScopedActionButtons';
import RefreshAllButton from './RefreshAllButton';
import TablePagination from './TablePagination';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import SystemAddFilters, { type SystemFilterColumn } from './SystemAddFilters';
import RelatedObjectPreview from './RelatedObjectPreview';
import DebtDetailsView from './DebtDetailsView';

import { DEBT_ROWS, type DebtRow } from '../lib/companyRelatedObjectData';
const DEFAULT_COLUMNS: ColConfig[] = [
  { key: 'counterpartyName', label: 'Counterparty name', width: 200, visible: true },
  { key: 'documentReference', label: 'Document reference', width: 176, visible: true },
  { key: 'dueDate', label: 'Due date', width: 112, visible: true },
  { key: 'totalAmount', label: 'Total amount', width: 128, visible: true },
  { key: 'paidAmount', label: 'Paid amount', width: 128, visible: true },
  { key: 'outstandingAmount', label: 'Outstanding amount', width: 176, visible: true },
  { key: 'currency', label: 'Currency', width: 96, visible: true },
  { key: 'daysOverdue', label: 'Days overdue', width: 128, visible: true },
  { key: 'debtStatus', label: 'Debt status', width: 150, visible: true },
  { key: 'debtDirection', label: 'Debt direction', width: 144, visible: false },
  { key: 'counterpartyCode', label: 'Counterparty code', width: 136, visible: false },
  { key: 'counterpartyType', label: 'Counterparty type', width: 132, visible: false },
  { key: 'documentType', label: 'Document type', width: 125, visible: false },
  { key: 'issueDate', label: 'Issue date', width: 96, visible: false },
  { key: 'reminderStage', label: 'Reminder stage', width: 116, visible: false },
  { key: 'lastReminderDate', label: 'Last reminder date', width: 128, visible: false },
  { key: 'nextReminderDate', label: 'Next reminder date', width: 152, visible: false },
  { key: 'paymentPriority', label: 'Payment priority', width: 120, visible: false },
  { key: 'department', label: 'Department / Project', width: 145, visible: false },
  { key: 'notes', label: 'Notes indicator', width: 112, visible: false },
  { key: 'actions', label: '', width: 200, visible: true },
];
const ALL_COLUMNS = allDebtColumns(DEFAULT_COLUMNS);

const TABS: DebtTab[] = ['Receivables', 'Payables', 'All', 'Overdue'];
type DebtBatch = { action: DebtAction; groups: Array<DebtActionGroup & { contact?: Company }>; index: number };

export default function CompanyDebtsView({ company, companyName = "", initialRecordId, onRelatedObjectBack }: { company?: Company; companyName?: string; initialRecordId?: string; onRelatedObjectBack?: () => void }) {
  const [relatedObjectClosed, setRelatedObjectClosed] = useState(false);
  const [detailId, setDetailId] = useState<string | null>(null);
  const openedDebtId = detailId || (relatedObjectClosed ? undefined : initialRecordId);
  const openedDebt = DEBT_ROWS.find(row => row.id === openedDebtId);
  const [activeTab, setActiveTab] = useState<DebtTab>('Payables');
  const [query, setQuery] = useState('');
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [standardColumns, setStandardColumns] = usePersistentState<ColConfig[]>('finansu-harmonija:v24:company-debts-standard-columns', DEFAULT_COLUMNS);
  const [allColumns, setAllColumns] = usePersistentState<ColConfig[]>('finansu-harmonija:v24:company-debts-all-columns', ALL_COLUMNS);
  const columnGroup = activeTab === 'All' ? 'all' : 'standard';
  const savedColumns = activeTab === 'All' ? allColumns : standardColumns;
  const setColumns = activeTab === 'All' ? setAllColumns : setStandardColumns;
  const defaultColumns = activeTab === 'All' ? ALL_COLUMNS : DEFAULT_COLUMNS;
  const columns = useMemo(() => restoreDebtColumns(defaultColumns, savedColumns), [defaultColumns, savedColumns]);
  const [showColumns, setShowColumns] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [activeFilterKeys, setActiveFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const [batch, setBatch] = useState<DebtBatch | null>(null);
  const [notice, setNotice] = useState('');
  const [actionError, setActionError] = useState('');
  const selectedDebts = DEBT_ROWS.filter(row => selectedRows.has(row.id));
  const actions = debtActionState(activeTab, selectedDebts, debtActionRights(company));
  const currentGroup = batch?.groups[batch.index];
  const batchLabel = batch && currentGroup ? translateMessage('Recipient {current} of {total} · {direction} · Documents: {documents}', {
    current: batch.index + 1, total: batch.groups.length, direction: uiText(currentGroup.direction === 'receivable' ? 'Receivables' : 'Payables'), documents: currentGroup.rows.length,
  }) : '';
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(columns, setColumns, {
    layout: `company-debts-${columnGroup}-v24`, widths: `company-debts-${columnGroup}-v24`,
  });
  const visibleColumns = [
    ...columns.filter(column => column.visible && column.key !== 'actions'),
    DEFAULT_COLUMNS.find(column => column.key === 'actions')!,
  ];
  const tableMinWidth = visibleColumns.reduce((sum, column) => sum + column.width, 50);
  const numericColumn = (key: string) => ['totalAmount', 'paidAmount', 'daysOverdue', 'outstandingAmount'].includes(key);

  useEffect(() => setCurrentPage(1), [activeTab, activeFilterKeys, filterValues, query, companyName]);

  const filterColumns = useMemo<SystemFilterColumn[]>(
    () => [
      ...defaultColumns.filter(column => column.key !== 'actions').map(column => ({
        key: column.key,
        label: column.label,
        options: Array.from(
          new Set(
            DEBT_ROWS.map(row => String(debtColumnValue(row, column.key))).filter(Boolean),
          ),
        ).sort((left, right) => left.localeCompare(right, undefined, { numeric: true })),
      })),
      { key: 'agingGroup', label: 'Aging group', options: [...DEBT_AGING_GROUPS] },
    ],
    [defaultColumns],
  );

  const filteredRows = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return DEBT_ROWS.filter(row => {
      if (!debtInTab(row, activeTab)) return false;
      if (
        normalized &&
        ![...Object.values(row), uiText(row.debtStatus), uiText(String(debtColumnValue(row, 'debtDirection')))].some(value =>
          String(value).toLocaleLowerCase().includes(normalized),
        )
      ) {
        return false;
      }

      return activeFilterKeys.every(key => {
        const selectedValues = filterValues[key] ?? [];
        return (
          selectedValues.length === 0 ||
          selectedValues.includes(String(debtColumnValue(row, key)))
        );
      });
    });
  }, [activeTab, activeFilterKeys, filterValues, query]);

  const { sortedRows, changeSort, directionFor } = useMultiColumnSort(
    filteredRows,
    debtColumnSortValue,
  );

  const toggleAll = () => {
    setSelectedRows(current => toggleFilteredSelection(current, sortedRows.map(row => row.id)));
  };

  const toggleRow = (id: string) => {
    setSelectedRows(current => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const startAction = (action: DebtAction, detailRows?: DebtRow[]) => {
    setActionError(''); setNotice('');
    const selected = detailRows ?? DEBT_ROWS.filter(row => selectedRows.has(row.id));
    if (!company || (!detailRows && selected.length !== selectedRows.size) || !debtActionState(detailRows ? 'All' : activeTab, selected, debtActionRights(company))[action].enabled) {
      setActionError('This action is not available for the selected debts.'); return;
    }
    try {
      const contacts = loadOrganizationCounterparties(company.id);
      const groups = groupDebtActions(selected, action).map(group => {
        const matches = contacts.filter(contact => group.counterpartyCode
          ? [contact.company_code, contact.accounting_system_code].includes(group.counterpartyCode)
          : contact.name.trim().toLowerCase() === group.counterpartyName.trim().toLowerCase());
        return { ...group, contact: matches.length === 1 ? matches[0] : undefined };
      });
      setBatch({ action, groups, index: 0 });
    } catch (cause) { setActionError(cause instanceof Error ? cause.message : 'The debt action could not be opened.'); }
  };

  const completeGroup = (payment?: CompanyPayment) => {
    if (!batch || !currentGroup) return;
    const completedIds = new Set(payment?.allocations?.map(line => line.debtId) || currentGroup.rows.map(row => row.id));
    setSelectedRows(previous => new Set([...previous].filter(id => !completedIds.has(id))));
    if (batch.index + 1 < batch.groups.length) setBatch({ ...batch, index: batch.index + 1 });
    else {
      setNotice(batch.action === 'payment' ? 'Payment drafts saved. No payments have been submitted to the bank.' : 'Messages saved to Organization email history.');
      setBatch(null);
    }
  };

  useEffect(() => {
    if (!batch || batch.action === 'payment') return;
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape' && !event.defaultPrevented) { event.preventDefault(); setBatch(null); } };
    window.addEventListener('keydown', escape);
    return () => window.removeEventListener('keydown', escape);
  }, [batch]);

  const cell = (row: DebtRow, key: string) => {
    if (key === 'debtDirection') return uiText(String(debtColumnValue(row, key)));
    if (key === 'daysOverdue' && row.daysOverdue > 0) {
      return <span className="inline-flex min-w-7 items-center justify-center rounded bg-[#FFF4DF] px-2 py-0.5 font-semibold tabular-nums text-[#9A5B00]">{row.daysOverdue}</span>;
    }
    if (key === 'outstandingAmount') {
      return <span className="font-semibold tabular-nums text-[#007EA7]">{row.outstandingAmount}</span>;
    }
    if (key === 'debtStatus') {
      const partiallyPaid = row.debtStatus === 'Partially paid';
      return <span title={uiText(row.debtStatus)} className={`inline-flex max-w-full items-center gap-1.5 rounded px-2 py-1 font-medium ${partiallyPaid ? 'bg-[#E5EDF9] text-[#007EA7]' : 'bg-[#EFF3F7] text-[#536B85]'}`}>
        <span aria-hidden="true" className="h-1.5 w-1.5 shrink-0 rounded-full bg-current" />
        <span className="truncate">{uiText(row.debtStatus)}</span>
      </span>;
    }
    if (key === 'actions') {
      return (
        <div className="flex w-full items-center justify-end gap-1">
          <button type="button" onClick={() => { setDetailId(row.id); setNotice(''); setActionError(''); }} aria-label={`${uiText('View details')} · ${row.documentReference}`} className="h-7 shrink-0 whitespace-nowrap rounded border-2 border-[#D3E1EC] bg-white px-2 text-[12px] font-semibold text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]">{uiText("View details")}</button>
          <button type="button" aria-label={`Actions for ${row.documentReference}`} className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><MoreVertical size={14} /></button>
        </div>
      );
    }
    const value = debtColumnValue(row, key);
    return value === '' ? '—' : String(value);
  };

  if (company && batch?.action === 'payment' && currentGroup) {
    const today = new Date(), date = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const accounts = companyBankAccounts(company);
    return <NewPaymentForm key={`${company.id}:${currentGroup.key}`} company={company} fromDebts
      initialDraft={debtPaymentDraft(currentGroup, date, currentGroup.contact ? counterpartyIbans(currentGroup.contact)[0] || '' : '', accounts.length === 1 ? accounts[0].iban : '')}
      canSave={() => debtActionRights(company).payment} onCancel={() => setBatch(null)} onSaved={completeGroup} />;
  }

  const emailDialog = company && batch && batch.action !== 'payment' && currentGroup && createPortal(<div className="fixed inset-0 z-[5400] bg-[#10233A]/20">
    <SendInvoicePanel key={`${company.id}:${batch.action}:${currentGroup.key}`} purpose={batch.action} batchLabel={batchLabel}
      relatedDebtIds={currentGroup.rows.map(row => row.id)}
      invoice={{ id: currentGroup.rows.map(row => row.id).join('-'), number: currentGroup.references, buyer: currentGroup.counterpartyName, totalAmount: currentGroup.amount, currency: currentGroup.currency }}
      organizationId={company.id} senderName={company.name} senderEmail={company.email}
      senderDetails={{ name: company.name, companyCode: company.company_code, vatCode: company.vat_code, address: company.address, email: company.email, phone: company.phone }}
      recipientName={currentGroup.counterpartyName} recipientEmail={currentGroup.contact?.email || ''}
      canSend={() => debtActionRights(company).send} onSent={completeGroup} onClose={() => setBatch(null)} />
  </div>, document.body);
  const backToDebts = () => {
    setDetailId(null); setRelatedObjectClosed(true); setNotice(''); setActionError('');
    if (initialRecordId && !relatedObjectClosed) onRelatedObjectBack?.();
  };
  if (openedDebtId && !openedDebt) return <RelatedObjectPreview companyName={companyName} section="Debts" title={uiText('Debt details')} fields={[]} unavailable backLabel="Back to debts" onBack={backToDebts} />;
  if (openedDebt) {
    const detailActions = debtActionState('All', [openedDebt], debtActionRights(company));
    return <><DebtDetailsView key={`${company?.id}:${openedDebt.id}`} debt={openedDebt} company={company} companyName={companyName} onBack={backToDebts}
      message={actionError ? <p role="alert" className="text-[12px] text-[#B42318]">{uiText(actionError)}</p> : notice ? <p role="status" className="text-[12px] text-[#7288A3]">{uiText(notice)}</p> : undefined}
      actions={<>{detailActions.reminder.visible && <PageActionButton icon={<Bell size={15} />} disabled={!detailActions.reminder.enabled} onClick={() => startAction('reminder', [openedDebt])}>{uiText('Send reminder')}</PageActionButton>}
        {detailActions.payment.visible && <PageActionButton icon={<CreditCard size={15} />} disabled={!detailActions.payment.enabled} onClick={() => startAction('payment', [openedDebt])}>{uiText('Create payment')}</PageActionButton>}</>} />{emailDialog}</>;
  }

  return (
    <div className="relative flex min-h-full min-w-0 flex-col gap-4 bg-white px-4 py-10 sm:px-8 lg:px-[56px]">
      <PageHeader
        title={uiText("Debts")}
        className="!h-auto !min-h-[42px] !flex-wrap [&>div:first-child]:min-w-[100px] [&>div:last-child]:max-w-full [&>div:last-child]:flex-wrap"
        actions={
          <>
            {actions.reminder.visible && <PageActionButton ariaLabel={uiText('Send reminder')} icon={<Bell size={15} />} disabled={!actions.reminder.enabled} onClick={() => startAction('reminder')}>{uiText('Send reminder')}</PageActionButton>}
            {actions.payment.visible && <PageActionButton ariaLabel={uiText('Create payment')} icon={<CreditCard size={15} />} disabled={!actions.payment.enabled} onClick={() => startAction('payment')}>{uiText('Create payment')}</PageActionButton>}
            <PageActionButton ariaLabel={uiText('Send balance confirmation')} icon={<MailCheck size={15} />} disabled={!actions['balance-confirmation'].enabled} onClick={() => startAction('balance-confirmation')}>{uiText('Send balance confirmation')}</PageActionButton>
          </>
        }
      />
      {companyName && (
        <CompanyBreadcrumb companyName={companyName} items={["Debts"]} />
      )}

      <div className="flex h-10 min-w-0 flex-shrink-0 items-start gap-6 overflow-x-auto border-b border-[#E5EDF9]">
        {TABS.map(tab => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`flex h-10 flex-col justify-between whitespace-nowrap font-montserrat text-[14px] font-medium ${activeTab === tab ? 'text-[#007EA7]' : 'text-[#10233A]'}`}
          >
            <span>{uiText(tab)}</span>
            <span className={`h-0.5 w-full ${activeTab === tab ? 'bg-[#007EA7]' : 'bg-transparent'}`} />
          </button>
        ))}
      </div>

      <div className="flex min-h-5 flex-wrap items-center gap-3 text-[12px] text-[#7288A3]" aria-live="polite">
        {selectedRows.size > 0 && <><span>{translateMessage('Selected debts: {count}', { count: selectedRows.size })}</span><button type="button" className="text-[#007EA7] hover:underline" onClick={() => setSelectedRows(new Set())}>{uiText('Clear selection')}</button></>}
        {actions.outsideTab ? <span>{uiText('Selected debts include another tab. Open All or clear the selection to continue.')}</span> : actions.mixed && <span>{uiText('Select only receivables for reminders or only payables for payments. Balance confirmation supports both.')}</span>}
        {!actions.outsideTab && actions.multiplePaymentGroups && <span>{uiText('Select one supplier and one currency for a payment. Create multi-supplier payment batches in Payments.')}</span>}
        {actionError ? <span role="alert" className="text-[#B42318]">{uiText(actionError)}</span> : notice && <span role="status">{uiText(notice)}</span>}
      </div>

      <div className="flex flex-shrink-0 flex-wrap items-center justify-between gap-2">
        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5">
          <OcrSearchField ariaLabel={uiText("Search debts")} value={query} onChange={setQuery} className="!w-[220px] !min-w-[220px] !max-w-[220px]" />
          <SystemAddFilters
            persistenceKey={`finansu-harmonija:v12:filters:company-debts:${activeTab}`}
            columns={filterColumns}
            activeKeys={activeFilterKeys}
            values={filterValues}
            onActiveKeysChange={setActiveFilterKeys}
            onValuesChange={setFilterValues}
          />
        </div>
        <div className="flex flex-shrink-0 items-center gap-4 p-[6px]">
          <ColumnSettingsButton onClick={() => setShowColumns(true)} />
          <ImportDataButton
            disabled={DEBT_ROWS.length === 0}
            onClick={() => importMenuRecords(`company:${companyName}:debts`, DEBT_ROWS.map(row => row.id))}
          />
          <RefreshAllButton onRefresh={() => undefined} />
        </div>
      </div>

      <div ref={tableScrollRef} className="flex min-h-[160px] min-w-0 flex-1 flex-col overflow-x-auto scrollbar-hide">
        <div style={{ minWidth: tableMinWidth }}>
          <div className="system-table-header-row mb-1 flex min-h-10 items-start border-b border-[#E5EDF9] pl-3 pr-2">
            <div data-table-header-select="true" className="flex w-[30px] flex-shrink-0 items-center">
              <input type="checkbox" aria-label={uiText("Select all debts")} checked={sortedRows.length > 0 && sortedRows.every(row => selectedRows.has(row.id))} onChange={toggleAll} className="h-[18px] w-[18px] cursor-pointer rounded border border-[#A1B6C6] accent-[#007EA7]" />
            </div>
            {visibleColumns.map(column => {
              const columnIndex = columns.findIndex(item => item.key === column.key);
              return (
                <div key={column.key} data-debt-column={column.key} style={{ width: column.width }} className={`${column.key === 'actions' ? 'system-table-row-actions ' : ''}${numericColumn(column.key) ? 'justify-end text-right ' : ''}relative flex min-w-0 flex-shrink-0 items-start gap-1 px-3 font-montserrat text-[12px] font-medium text-[#10233A]`}>
                  {column.label && <><span>{uiText(column.label)}</span><ColumnSortButton columnLabel={uiText(column.label)} direction={directionFor(column.key)} onDirectionChange={direction => changeSort(column.key, direction)} /></>}
                  {column.key !== 'actions' && <ResizeHandle onMouseDown={event => startResize(columnIndex, event)} />}
                </div>
              );
            })}
          </div>

          {sortedRows.slice(0, currentPage * TABLE_BATCH_SIZE).map((row, index) => (
            <div key={row.id} data-debt-row={row.id} className={`system-table-row group flex min-h-10 items-center rounded-lg pl-3 pr-2 transition-colors hover:bg-[#EEF6FA] ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'}`}>
              <div className="flex w-[30px] flex-shrink-0 items-center">
                <input type="checkbox" aria-label={`Select ${row.documentReference}`} checked={selectedRows.has(row.id)} onChange={() => toggleRow(row.id)} className="h-[18px] w-[18px] cursor-pointer rounded border border-[#A1B6C6] accent-[#007EA7]" />
              </div>
              {visibleColumns.map(column => (
                <div key={column.key} data-debt-cell={column.key} style={{ width: column.width }} className={`${column.key === 'actions' ? 'system-table-row-actions ' : ''}${numericColumn(column.key) ? 'pl-3 pr-[30px] text-right tabular-nums ' : 'px-3 '}flex min-w-0 flex-shrink-0 items-center overflow-hidden font-montserrat text-[12px] text-[#10233A]`}>
                  <div className="w-full min-w-0 truncate">{cell(row, column.key)}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      <HorizontalTableScrollbar scrollRef={tableScrollRef} />
      <div className="flex flex-shrink-0 items-center justify-between pt-2">
        <TablePagination
          scrollRef={tableScrollRef}
          currentPage={currentPage}
          totalPages={Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE))}
          itemCount={sortedRows.length}
          itemsPerPage={TABLE_BATCH_SIZE}
          onPageChange={setCurrentPage}
        />
      </div>

      {showColumns && <ColumnSettingsPanel key={columnGroup} columns={columns.filter(column => column.key !== 'actions')} defaultColumns={defaultColumns.filter(column => column.key !== 'actions')} onSave={next => setColumns([...next, DEFAULT_COLUMNS.find(column => column.key === 'actions')!])} onClose={() => setShowColumns(false)} />}
      {emailDialog}
    </div>
  );
}
