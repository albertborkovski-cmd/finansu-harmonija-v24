import type { Company } from './supabase';
import { canEditMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canEditCompanyDocuments } from './documentEditAccess';
import { canCreateCompanyBankTransaction } from './bankTransactionCreation';
import { isInactiveRecord } from './recordLifecycle';

export function debtActionRights(company?: Company) {
  try {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    const send = Boolean(company && !isInactiveRecord(company) && session && canEditMenu(session, 'reports') && canEditCompanyDocuments(company));
    return { send, payment: Boolean(send && company && canCreateCompanyBankTransaction(company)) };
  } catch { return { send: false, payment: false }; }
}
