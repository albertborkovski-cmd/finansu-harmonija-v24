import { isClientReconciliationItem, parseReconciliationState, type ReconciliationState } from './reconciliation';
import type { GlJournalRow } from './glJournal';

export const RECONCILIATION_CHANGED = 'reconciliation-changed';
export const reconciliationStorageKey = (companyId: string) => `finansu-harmonija:v15:reconciliation-examples-v2:${companyId}`;
export const reconciliationJournalNumber = (index: number, allocationIndex: number, reversal = false) => `${reversal ? 'RC-R' : 'RC'}-${String(index + 1).padStart(4, '0')}-${allocationIndex + 1}`;

/** Supply metadata only to the synthetic ledger, never infer real GL accounts. */
export function enableReconciliationAccounting(state: ReconciliationState, baseCurrency: string): ReconciliationState {
  return { ...state, accountingCurrency: baseCurrency, items: state.items.map(item => {
    if (!item.id.startsWith(`${state.organizationId}:demo`) || !isClientReconciliationItem(item)) return item;
    const advance = item.kind === 'Advance' || item.kind === 'Deposit';
    const glAccountCode = item.glAccountCode || (item.side === 'Receivable' ? advance ? '4420' : '2410' : advance ? '2910' : '4430');
    const demoRate = item.currency === baseCurrency ? 1 : item.currency === 'USD' && baseCurrency === 'EUR' ? 0.92 : undefined;
    return { ...item, glAccountCode, ...(item.exchangeRate || !demoRate ? {} : { exchangeRate: demoRate, exchangeRateCurrency: baseCurrency }) };
  }) };
}

/** Reversal adds an opposite posting; original GL operations stay unchanged. */
export function reconciliationJournalRows(state: ReconciliationState, activeAccounts: ReadonlySet<string> = new Set()): GlJournalRow[] {
  const rows: GlJournalRow[] = [];
  state.batches.forEach((batch, batchIndex) => {
    batch.accounting?.allocations.forEach((snapshot, allocationIndex) => {
      if (snapshot.fundingAccount === snapshot.invoiceAccount) return;
      const allocation = batch.allocations[allocationIndex];
      const originalId = `reconciliation:${state.organizationId}:${batch.id}:${allocationIndex}`;
      for (const reversal of batch.reversedAt ? [false, true] : [false]) {
        const id = reversal ? `${originalId}:reversal` : originalId;
        const number = reconciliationJournalNumber(batchIndex, allocationIndex, reversal);
        const at = reversal ? batch.reversedAt! : batch.at;
        const description = `${snapshot.fundingNumber} ↔ ${snapshot.invoiceNumber}`;
        for (const funding of [true, false]) {
          const side = funding ? snapshot.fundingSide : snapshot.invoiceSide;
          const debit = reversal ? side === 'Debit' : side === 'Credit';
          const amount = allocation.amountMinor / 100;
          const account = funding ? snapshot.fundingAccount : snapshot.invoiceAccount;
          rows.push({ id: `${id}:${funding ? 'funding' : 'invoice'}`, documentNumber: number, internalNumber: number,
            operationDate: at.slice(0, 10), counterparty: funding ? snapshot.fundingCounterparty : snapshot.invoiceCounterparty,
            account, description, documentType: reversal ? 'Reconciliation reversal' : 'Reconciliation', documentSubtype: 'GL transfer',
            costCenter: '', createdBy: reversal ? batch.reversedBy || batch.actor : batch.actor, createdAt: at,
            postingStatus: 'Posted', posted: true, balanced: true, accountActive: activeAccounts.has(account),
            debit: debit ? amount : 0, credit: debit ? 0 : amount, total: amount,
            baseCurrency: batch.accounting!.baseCurrency, baseDebit: debit ? snapshot.baseAmountMinor! / 100 : 0, baseCredit: debit ? 0 : snapshot.baseAmountMinor! / 100,
            reconciliationBatchId: batch.id, reconciliationOriginalId: reversal ? originalId : undefined,
            document: { id, number, currency: snapshot.currency, status: 'Approved', documentType: 'Accounting note', source: 'Reconciliation', note: description, documentDate: at.slice(0, 10) } });
        }
      }
    });
  });
  return rows;
}

export function loadReconciliationJournal(storage: Pick<Storage, 'getItem'>, companyId: string, accounts: ReadonlySet<string>): GlJournalRow[] {
  const raw = storage.getItem(reconciliationStorageKey(companyId));
  return raw ? reconciliationJournalRows(parseReconciliationState(raw, companyId), accounts) : [];
}
