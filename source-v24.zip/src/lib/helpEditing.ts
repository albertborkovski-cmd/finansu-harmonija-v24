import type { EditableHelpArticle } from './helpContent';

export function helpParent(article: EditableHelpArticle): string {
  if (article.parentKey !== undefined) return article.parentKey;
  return /^(integration|organization|export):/.test(article.key) && !article.key.endsWith(':overview')
    ? article.key.slice(0, article.key.lastIndexOf(':') + 1) + 'overview' : '';
}
export function helpDescendants(key: string, articles: EditableHelpArticle[]): Set<string> {
  const result = new Set<string>();
  const visit = (parent: string) => articles.filter(article => helpParent(article) === parent).forEach(article => {
    if (article.key !== key && !result.has(article.key)) { result.add(article.key); visit(article.key); }
  });
  visit(key);
  return result;
}
export function replaceHelpSelection(body: string, start: number, end: number, replacement: string) {
  const from = Math.max(0, Math.min(start, body.length)), to = Math.max(from, Math.min(end, body.length));
  return { body: body.slice(0, from) + replacement + body.slice(to), cursor: from + replacement.length };
}
export function helpLinkMarkdown(label: string, url: string) {
  return `[${label.replace(/[\[\]\n\r]/g, ' ')}](${url.replace(/\(/g, '%28').replace(/\)/g, '%29')})`;
}
