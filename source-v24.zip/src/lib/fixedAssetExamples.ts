import { assetBalance, assetMonthEnd, blankAsset, changeAssetStore, nextAssetMonth, type AssetCommand, type AssetContext, type AssetGroup, type AssetKind, type AssetStore, type FixedAsset } from './fixedAssets';

export const ALICE_ASSET_EXAMPLES_VERSION = 1;
export const ASSET_EXAMPLE_COMPANY_ID = '00000000-0000-4000-8000-000000000002';
export function shouldPrepareAssetExamples(company: { id: string; name: string }, store: AssetStore) {
  return company.id === ASSET_EXAMPLE_COMPANY_ID && company.name === 'Alice Stone' && store.companyId === company.id && store.currency === 'EUR' && (store.examplesVersion || 0) < ALICE_ASSET_EXAMPLES_VERSION;
}

/** Missing accounts are added only to Alice Stone's own chart, never a Settings template. */
export const ASSET_EXAMPLE_ACCOUNTS = [
  ['1240', 'Equipment acquisition cost', '1'], ['1248', 'Accumulated equipment depreciation', '1'],
  ['1230', 'Vehicle acquisition cost', '1'], ['1238', 'Accumulated vehicle depreciation', '1'],
  ['1220', 'Machinery acquisition cost', '1'], ['1228', 'Accumulated machinery depreciation', '1'],
  ['1130', 'Software acquisition cost', '1'], ['1138', 'Accumulated software amortization', '1'],
  ['1200', 'Land acquisition cost', '1'], ['1208', 'Accumulated land adjustments', '1'],
  ['6306', 'Depreciation and amortization expenses', '6'], ['4430', 'Trade payables', '4'],
  ['3900', 'Opening balance clearing', '3'], ['3210', 'Asset revaluation reserve', '3'],
  ['6309', 'Asset write-off expenses', '6'], ['2040', 'Assets held for sale', '2'],
].map(([code, name, parentCode]) => ({ code, name, parentCode }));

/** Append the requested examples once. Existing IDs, edits, history and numbering are retained. */
export function prepareAssetExamples(previous: AssetStore, ctx: AssetContext): AssetStore {
  if (previous.companyId !== ASSET_EXAMPLE_COMPANY_ID || previous.currency !== 'EUR' || (previous.examplesVersion || 0) >= ALICE_ASSET_EXAMPLES_VERSION) return previous;
  let state = previous;
  const run = (command: AssetCommand) => { state = changeAssetStore(state, command, ctx); };
  const month = (offset: number) => new Date(Date.UTC(Number(ctx.today.slice(0, 4)), Number(ctx.today.slice(5, 7)) - 1 + offset, 1)).toISOString().slice(0, 7);
  const first = (offset: number) => `${month(offset)}-01`;
  const unique = (base: string, used: string[]) => { let candidate = base, suffix = 2; while (used.some(v => v.toLowerCase() === candidate.toLowerCase())) candidate = `${base}-${suffix++}`; return candidate; };
  const group = (code: string, name: string, assetAccount: string, depreciationAccount: string, lifeMonths: number): AssetGroup => {
    const value: AssetGroup = { id: ctx.id(), code: unique(code, state.groups.map(g => g.code)), name, assetAccount, depreciationAccount, expenseAccount: '6306', lifeMonths, method: 'Straight-line', inactive: false };
    run({ type: 'save-group', group: value }); return value;
  };
  const equipment = group('EQ', 'Computer and office equipment', '1240', '1248', 36);
  const vehicles = group('VEH', 'Vehicles', '1230', '1238', 72);
  const machinery = group('MCH', 'Production machinery', '1220', '1228', 96);
  const furniture = group('FUR', 'Office furniture', '1240', '1248', 60);
  const software = group('SW', 'Software and licences', '1130', '1138', 36);
  const land = group('LAND', 'Land', '1200', '1208', 1200);
  const definitions: { name: string; group: AssetGroup; cost: number; extra?: Partial<FixedAsset>; draft?: boolean }[] = [
    { name: 'Dell Latitude 5450', group: equipment, cost: 165000, extra: { location: 'Vilnius · 201', department: 'Administration' } },
    { name: 'HP LaserJet Enterprise M507', group: equipment, cost: 89000, extra: { location: 'Kaunas · 104', department: 'Accounting', method: 'Double-declining balance' } },
    { name: 'Toyota Corolla Touring Sports', group: vehicles, cost: 2850000, extra: { residual: 350000, openingDepreciation: 570000, location: 'Vilnius', department: 'Sales' } },
    { name: 'CNC milling machine M-350', group: machinery, cost: 4800000, extra: { residual: 200000, totalUnits: 240000, method: 'Units of production', location: 'Kaunas · Workshop', department: 'Production' } },
    { name: 'Oak meeting table · 12 seats', group: furniture, cost: 245000, extra: { location: 'Vilnius · Meeting room', residual: 5000 } },
    { name: 'CAD design software licence', group: software, cost: 360000, extra: { location: 'Design office', department: 'Design', method: 'Sum-of-years-digits' } },
    { name: 'Industrial plot · Kaunas', group: land, cost: 6200000, extra: { depreciable: false, location: 'Kaunas', residual: 6200000 } },
    { name: 'Apple MacBook Pro 14', group: equipment, cost: 249900, extra: { location: 'Vilnius · 203', department: 'Design' }, draft: true },
    { name: 'Canon imageRUNNER 2520', group: equipment, cost: 120000, extra: { openingDepreciation: 119900, residual: 100, location: 'Kaunas · Archive' } },
    { name: 'Air compressor Atlas Copco', group: machinery, cost: 680000, extra: { openingDepreciation: 204000, location: 'Kaunas · Workshop', department: 'Production' } },
    { name: 'Volkswagen Caddy', group: vehicles, cost: 1850000, extra: { openingDepreciation: 1110000, residual: 100000, location: 'Vilnius · Garage', department: 'Logistics' } },
    { name: 'Server Dell PowerEdge T350', group: equipment, cost: 420000, extra: { location: 'Vilnius · Server room', department: 'IT', residual: 10000 } },
  ];
  const assets = definitions.map((definition, index) => {
    const asset: FixedAsset = { ...blankAsset(ctx.id(), definition.group), number: unique(`IT-${String(index + 1).padStart(4, '0')}`, state.assets.map(a => a.number)), name: definition.name, cost: definition.cost, acquisitionDate: first(-4), ...definition.extra };
    run({ type: 'save-asset', asset }); return asset;
  });
  const post = (a: FixedAsset, kind: Exclude<AssetKind, 'Depreciation'>, date: string, account: string, amount = 0, lifeExtension = 0) => run({ type: 'post', assetId: a.id, kind, date, account, amount, lifeExtension, reason: `${kind} · ${a.number}` });
  assets.forEach((a, index) => { if (!definitions[index].draft) post(a, a.openingDepreciation ? 'Opening balance' : 'Commissioning', first(-4), a.openingDepreciation ? '3900' : '4430'); });
  for (let period = month(-3); period < month(-1); period = nextAssetMonth(period)) {
    const eligible = assets.filter((a, i) => !definitions[i].draft && a.depreciable && assetBalance(state, a).book > a.residual);
    run({ type: 'depreciate', month: period, assetIds: eligible.map(a => a.id), units: Object.fromEntries(eligible.filter(a => a.method === 'Units of production').map(a => [a.id, 3200])) });
  }
  post(assets[3], 'Modernization', first(-1), '4430', 650000, 12);
  post(assets[6], 'Revaluation', first(-1), '3210', 350000);
  post(assets[9], 'Write-off', first(-1), '6309');
  post(assets[10], 'Withdrawal for sale', first(-1), '2040');
  run({ type: 'remove', collection: 'assets', id: assets[11].id });
  const lines = assets.filter(a => { const b = assetBalance(state, a); return b.start && !b.disposed; }).map(a => ({ assetId: a.id, number: a.number, name: a.name, bookQuantity: a.quantity, actualQuantity: a.quantity, bookValue: 0, note: '' }));
  run({ type: 'save-inventory', inventory: { id: ctx.id(), number: unique('INV-IT-001', state.inventories.map(i => i.number)), date: assetMonthEnd(month(-2)), locked: true, lines } });
  run({ type: 'save-inventory', inventory: { id: ctx.id(), number: unique('INV-IT-002', state.inventories.map(i => i.number)), date: ctx.today, locked: false, lines: lines.map((l, i) => i === 1 ? { ...l, actualQuantity: 0, note: 'Check the asset location.' } : l) } });
  return { ...state, examplesVersion: ALICE_ASSET_EXAMPLES_VERSION };
}
