import { normalizeAdditionalColumnRules } from './documentAdditionalColumns';

export const COMPANY_EXPORT_FORMATS = [
  'Agnum', 'Apskaita5', 'BSS', 'BSS Api', 'Business Central', 'Būtent', 'Būtent kiekinis', 'Centas', 'CSV',
  'Debetas', 'Debetas Excel', 'Dineta', 'Directo', 'Euroskaita', 'Excel', 'Finvalda', 'Finvalda Excel', 'iSAF',
  'Json', 'Lobasoft', 'Monet', 'Odoo', 'Optimum', 'Paulita', 'Pragma3', 'Pragma4', 'Pragma4 V2', 'Rivilė',
  'Rivilė API', 'Rivilė ERP', 'Roda', 'Saikas', 'Site.pro', 'StandardERP', 'Syrve', 'UCS StoreHouse v4', 'Uniconta', 'XML',
] as const;

export const SALES_OPERATION_TYPES = ['Waybill', 'Order', 'Reservation', 'Offer'] as const;
export const PURCHASE_OPERATION_TYPES = ['Waybill', 'Order', 'Offer'] as const;
export const DEFAULT_DIGITIZATION_SETTINGS = {
  database: '', itemAccountLinkCode: '', itemType: '', updateProducts: false, updateServices: false, updateCodes: false,
  postInRivile: false, salesPaymentAccount: '', purchasePaymentAccount: '', salesOperation: 'Waybill', purchaseOperation: 'Waybill',
  individualBuyerCode: 'unique', fixedBuyerCode: '', primaryLineCode: 'barcode', additionalColumnsAt: 'digitization',
  vatSeparation: 'automatic', foreignVatAsCompanyCode: false, dueDateFromInvoiceDate: false,
  createCompaniesOnExport: false, createProductsOnExport: false, exportAfterDigitization: false,
  additionalColumns: normalizeAdditionalColumnRules(undefined),
};
export type CompanyDigitizationSettings = typeof DEFAULT_DIGITIZATION_SETTINGS;

/** Explicit whitelist: credentials are never serialized into browser/shared demo data. */
export function parseCompanyDigitizationSettings(raw?: string, company?: Record<string, unknown>): CompanyDigitizationSettings {
  const value: unknown = raw ? JSON.parse(raw) : {};
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Could not read export settings.');
  return Object.fromEntries(Object.entries(DEFAULT_DIGITIZATION_SETTINGS).map(([key, fallback]) => {
    const saved = (value as Record<string, unknown>)[key];
    if (key === 'additionalColumns') return [key, normalizeAdditionalColumnRules(saved, company)];
    return [key, typeof saved === typeof fallback ? saved : fallback];
  })) as CompanyDigitizationSettings;
}

export function serializeCompanyDigitizationSettings(settings: CompanyDigitizationSettings) {
  const clean = parseCompanyDigitizationSettings(JSON.stringify(settings));
  if (!SALES_OPERATION_TYPES.includes(clean.salesOperation as typeof SALES_OPERATION_TYPES[number])
    || !PURCHASE_OPERATION_TYPES.includes(clean.purchaseOperation as typeof PURCHASE_OPERATION_TYPES[number])
    || !['unique', 'fixed'].includes(clean.individualBuyerCode)
    || !['barcode', 'code'].includes(clean.primaryLineCode)
    || !['digitization', 'export'].includes(clean.additionalColumnsAt)
    || !['automatic', 'separate-non-payers', 'include-payers'].includes(clean.vatSeparation)) throw new Error('Select a valid settings option.');
  if (clean.individualBuyerCode === 'fixed' && !clean.fixedBuyerCode.trim()) throw new Error('Enter the fixed buyer code.');
  if (Object.values(clean).some(value => typeof value === 'string' && value.length > 500)) throw new Error('One of the values is too long.');
  if (Object.values(clean.additionalColumns).some(rule => rule.defaultValue.length > 500 || rule.defaultLabel.length > 500)) throw new Error('One of the values is too long.');
  return JSON.stringify(clean);
}
