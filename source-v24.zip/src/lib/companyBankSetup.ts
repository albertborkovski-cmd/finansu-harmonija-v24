import { supabase, type Company } from './supabase';
import { canEditMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY, getCurrentUserName } from './currentUser';
import { canAccessAssignedOrganization } from './linkedSettingsData';
import { isInactiveRecord } from './recordLifecycle';

export type BankConnectionStatus = 'Connected' | 'Not connected' | 'Connection error';
export type BankSetupAccount = { id: string; iban: string; bank?: string; glAccount?: string; active?: boolean; inactive?: boolean };
export type BankConnectionPreference = { version: 1; companyId: string; accountId: string; iban: string; provider: 'bank' | 'gateway'; status: 'Setup required'; updatedAt: string; updatedBy: string };
export const BANK_CONNECTION_CHANGED = 'finansu-harmonija:bank-connection-changed';
export const bankConnectionKey = (companyId: string, accountId: string) => `finansu-harmonija:v20:bank-connection:${companyId}:${accountId}`;
export function canManageCompanyBankSetup(company: Company) {
  try {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    return Boolean(session && !isInactiveRecord(company) && canEditMenu(session, 'companies') && canAccessAssignedOrganization(company, session));
  } catch { return false; }
}
export function readBankConnectionPreference(companyId: string, account: BankSetupAccount): BankConnectionPreference | null {
  const raw = window.localStorage.getItem(bankConnectionKey(companyId, account.id));
  if (!raw) return null;
  const value = JSON.parse(raw) as BankConnectionPreference;
  if (value.version !== 1 || value.companyId !== companyId || value.accountId !== account.id || !['bank', 'gateway'].includes(value.provider) || value.status !== 'Setup required') throw new Error('Bank connection settings could not be read.');
  return value.iban === account.iban ? value : null;
}
/** Provider selection is not bank authorization. No credentials or invented auth URL are stored. */
export async function saveBankConnectionPreference(companyId: string, account: BankSetupAccount, provider: string) {
  if (!['bank', 'gateway'].includes(provider)) throw new Error('Select a bank / gateway provider.');
  const result = await supabase.from('companies').select('*').eq('id', companyId);
  const company = result.data?.[0] as unknown as Company | undefined;
  if (result.error || !company || !canManageCompanyBankSetup(company)) throw new Error('You do not have permission to connect this company’s bank accounts.');
  const accounts = JSON.parse(company.organization_bank_accounts || '[]') as BankSetupAccount[];
  const saved = Array.isArray(accounts) && accounts.find(row => row.id === account.id && row.iban === account.iban && row.iban.trim() && !isInactiveRecord(row));
  if (!saved) throw new Error('Save this bank account before connecting it.');
  readBankConnectionPreference(companyId, saved);
  const value: BankConnectionPreference = { version: 1, companyId, accountId: saved.id, iban: saved.iban, provider: provider as 'bank' | 'gateway', status: 'Setup required', updatedAt: new Date().toISOString(), updatedBy: getCurrentUserName() };
  window.localStorage.setItem(bankConnectionKey(companyId, saved.id), JSON.stringify(value));
  window.dispatchEvent(new CustomEvent(BANK_CONNECTION_CHANGED, { detail: { companyId, accountId: saved.id } }));
  return value;
}
export function validateBankGlAssignments(accounts: readonly BankSetupAccount[], availableCodes: readonly string[], previous: readonly BankSetupAccount[]) {
  for (const account of accounts) {
    const code = account.glAccount || '';
    if (code && !availableCodes.includes(code) && !previous.some(row => row.id === account.id && row.glAccount === code))
      throw new Error('Select a Bank GL account from this company’s active chart of accounts.');
  }
}
/** Synchronization timestamps/errors never imply a connection state. */
export function bankAccountConnectionStatus(account: { connectionStatus?: string; lastSyncedAt?: string; syncError?: string }): BankConnectionStatus {
  return account.connectionStatus === 'Connected' || account.connectionStatus === 'Connection error' ? account.connectionStatus : 'Not connected';
}
export function bankConnectionExamples(companyId: string) {
  if (companyId !== '00000000-0000-4000-8000-000000000002') return [];
  return (['Connected', 'Not connected', 'Connection error'] as const).map((connectionStatus, index) => ({
    id: `bank-connection-demo-${index + 1}`, iban: `•••• ${['1234', '5678', '9012'][index]}`, bank: ['SEB', 'Swedbank', 'Luminor'][index],
    bankCode: '', swift: '', primary: index === 0, connectionStatus, demonstration: true,
  }));
}
