import type { DbDocument } from './supabase';
import { createOcrRegisterExamples } from './ocrRegisterExamples';

export const OCR_VISUAL_EXAMPLE_BATCH = 'v24-ocr-visual-documents-1';
const xml = (value: unknown) => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[character]!));

/** A frozen, entirely fictional source image. Editing OCR fields does not rewrite the source invoice. */
export function exampleInvoiceImage(document: DbDocument, organization: string): string {
  const sale = document.document_purpose === 'Sale';
  const seller = sale ? organization : document.client_counterparty;
  const buyer = sale ? document.client_counterparty : organization;
  const currency = document.currency || 'EUR';
  const text = (x: number, y: number, value: unknown, size = 13, bold = false, color = '#23364B', anchor = 'start') =>
    `<text x="${x}" y="${y}" font-size="${size}" font-weight="${bold ? 700 : 400}" fill="${color}" text-anchor="${anchor}">${xml(value)}</text>`;
  const rows = document.line_items || [];
  const bottom = 420 + rows.length * 54;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="794" height="1123" viewBox="0 0 794 1123">
    <rect width="794" height="1123" fill="white"/><g font-family="Arial, sans-serif">
    <rect x="44" y="44" width="48" height="48" rx="12" fill="#007EA7"/>${text(68, 75, 'FH', 21, true, 'white', 'middle')}
    ${text(108, 65, seller, 20, true)}${text(108, 86, 'Verslo paslaugos ir prekės', 12, false, '#71839A')}
    <line x1="44" x2="750" y1="116" y2="116" stroke="#D3E1EC"/>
    ${text(44, 158, 'PVM SĄSKAITA FAKTŪRA', 25, true)}${text(44, 188, document.number, 18, true, '#007EA7')}
    ${text(750, 155, 'Išrašymo data', 12, false, '#71839A', 'end')}${text(750, 177, document.document_date, 15, true, '#23364B', 'end')}
    ${text(44, 237, 'PARDAVĖJAS', 11, true, '#71839A')}${text(414, 237, 'PIRKĖJAS', 11, true, '#71839A')}
    ${text(44, 263, seller, 17, true)}${text(414, 263, buyer, 17, true)}
    ${text(44, 287, 'Įmonės kodas: DEMO-1001')}${text(414, 287, 'Įmonės kodas: DEMO-2001')}
    ${text(44, 308, 'PVM kodas: LT-DEMO-1001')}${text(414, 308, 'PVM kodas: LT-DEMO-2001')}
    ${text(44, 329, 'Pavyzdžio g. 12, Vilnius, Lietuva')}${text(414, 329, 'Verslo g. 8, Kaunas, Lietuva')}
    <rect x="44" y="360" width="706" height="40" rx="5" fill="#EAF3F8"/>
    ${text(58, 385, 'Kodas / prekė arba paslauga', 12, true)}${text(505, 385, 'Kiekis', 12, true, '#23364B', 'end')}
    ${text(615, 385, 'Kaina', 12, true, '#23364B', 'end')}${text(735, 385, `Suma, ${currency}`, 12, true, '#23364B', 'end')}
    ${rows.map((row, index) => { const y = 429 + index * 54; return `${text(58, y, row.description || row.product, 13, true)}${text(58, y + 18, row.code, 10, false, '#71839A')}${text(505, y, row.qty, 13, false, '#23364B', 'end')}${text(615, y, row.price, 13, false, '#23364B', 'end')}${text(735, y, row.subtotal, 13, false, '#23364B', 'end')}<line x1="44" x2="750" y1="${y + 28}" y2="${y + 28}" stroke="#E7EEF4"/>`; }).join('')}
    ${text(460, bottom + 35, 'Suma be PVM')}${text(735, bottom + 35, `${document.amount_without_vat} ${currency}`, 14, true, '#23364B', 'end')}
    ${text(460, bottom + 63, `PVM (${document.vat_percent})`)}${text(735, bottom + 63, `${document.vat} ${currency}`, 14, false, '#23364B', 'end')}
    <rect x="442" y="${bottom + 80}" width="308" height="52" rx="6" fill="#EAF3F8"/>
    ${text(460, bottom + 112, 'Iš viso', 16, true)}${text(735, bottom + 112, `${document.total_amount} ${currency}`, 19, true, '#007EA7', 'end')}
    ${text(44, bottom + 166, `Apmokėti iki: ${document.due_end_date}`, 13, true)}${text(44, bottom + 190, `Užsakymo numeris: ${document.order_no}`)}
    ${document.with_receipt ? `<rect x="44" y="${bottom + 220}" width="320" height="95" rx="6" fill="#F6FAFC" stroke="#D3E1EC"/>${text(62, bottom + 248, 'PRIDĖTAS MOKĖJIMO KVITAS', 12, true)}${text(62, bottom + 274, `Apmokėta: ${document.total_amount} ${currency}`, 14, true)}${text(62, bottom + 295, 'Mokėjimo būdas: kortele', 12)}` : ''}
    <line x1="44" x2="750" y1="1040" y2="1040" stroke="#D3E1EC"/>${text(44, 1065, 'Pavyzdinis dokumentas sąsajos peržiūrai. Ne mokėjimui.', 11, false, '#71839A')}${text(750, 1065, '1 / 1', 11, false, '#71839A', 'end')}
    </g></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export function createOcrVisualExamples(companyId: string, organization: string, at = new Date().toISOString()): DbDocument[] {
  const examples = createOcrRegisterExamples(companyId, at);
  return [0, 1, 4, 6, 2].map((sourceIndex, index) => {
    const source = examples[sourceIndex];
    const id = `${companyId}:${OCR_VISUAL_EXAMPLE_BATCH}:${index + 1}`, number = `OCR-VIS-00${index + 1}`;
    const rekey = (lines: NonNullable<DbDocument['line_items']>, kind: string) => lines.map((row, line) => ({ ...row, id: `${id}:${kind}:${line}` }));
    const document: DbDocument = { ...source, id, number, file_case: `${number}.svg`,
      status: 'Processed', line_items: rekey(source.line_items || [], 'line'), summary_line_items: rekey(source.summary_line_items || [], 'allocation'),
      notes: `${source.notes} · Visual example`, image_url: null };
    return { ...document, image_url: exampleInvoiceImage(document, organization) };
  });
}
