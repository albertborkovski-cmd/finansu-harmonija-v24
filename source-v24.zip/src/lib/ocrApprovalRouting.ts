export type OcrApprovalDestination = 'FH' | 'TeamLead';
export type OcrApprovalRule = {
  id: string; organizationId: string; documentType: string; destination: OcrApprovalDestination;
  active: boolean; updatedAt: string; updatedBy: string;
};
export type OcrApprovalRoutingStore = {
  version: 1; rules: OcrApprovalRule[];
  history: { at: string; by: string; before?: OcrApprovalRule; after: OcrApprovalRule }[];
};
export type OcrRoutingResult = { destination: OcrApprovalDestination; ruleId?: string };
export type OcrDocumentType = { code: string; fullName: string; parentCode: string; status: string };
export type OcrDocumentTypeRouting = {
  mode: 'inherit' | 'disabled' | 'all' | 'organizations' | 'custom';
  organizationIds: string[];
};

export function getOcrDocumentTypeRouting(rules: readonly OcrApprovalRule[], documentType: string): OcrDocumentTypeRouting {
  const scoped = rules.filter(rule => rule.active && rule.documentType === documentType);
  if (!scoped.length) return { mode: 'inherit', organizationIds: [] };
  const shared = scoped.find(rule => !rule.organizationId);
  const overrides = scoped.filter(rule => rule.organizationId);
  if (shared && !overrides.length) return { mode: shared.destination === 'FH' ? 'disabled' : 'all', organizationIds: [] };
  if (shared?.destination === 'FH' && overrides.every(rule => rule.destination === 'TeamLead'))
    return { mode: 'organizations', organizationIds: overrides.map(rule => rule.organizationId) };
  // Preserve older, more complex rules until an administrator explicitly replaces them.
  return { mode: 'custom', organizationIds: [] };
}

/** Replace only this type's configuration; retain other types and all audit history. */
export function configureOcrDocumentTypeRouting(store: OcrApprovalRoutingStore, previousCode: string, documentType: string,
  config: OcrDocumentTypeRouting | null, updatedBy: string, updatedAt: string): OcrApprovalRoutingStore {
  if (!documentType.trim() || !updatedBy) throw new Error('Document type and user are required.');
  if (config && !['inherit', 'disabled', 'all', 'organizations', 'custom'].includes(config.mode)) throw new Error('Choose a valid TeamLead setting.');
  const ids = [...new Set(config?.organizationIds.map(id => id.trim()).filter(Boolean) ?? [])];
  if (config?.mode === 'organizations' && !ids.length) throw new Error('Select at least one organization.');
  let next = store;
  if (previousCode && previousCode !== documentType) {
    if (store.rules.some(rule => rule.active && rule.documentType === documentType)) throw new Error('Routing already exists for this document type code.');
    for (const rule of store.rules.filter(rule => rule.documentType === previousCode))
      next = putOcrApprovalRule(next, { ...rule, documentType, updatedBy, updatedAt });
  }
  if (!config || config.mode === 'custom') return next;
  const desired: { organizationId: string; destination: OcrApprovalDestination }[] = config.mode === 'inherit' ? [] : [
    { organizationId: '', destination: config.mode === 'all' ? 'TeamLead' : 'FH' },
    ...(config.mode === 'organizations' ? ids.map(organizationId => ({ organizationId, destination: 'TeamLead' as const })) : []),
  ];
  for (const rule of next.rules.filter(rule => rule.active && rule.documentType === documentType)) {
    if (!desired.some(value => value.organizationId === rule.organizationId))
      next = putOcrApprovalRule(next, { ...rule, active: false, updatedBy, updatedAt });
  }
  for (const value of desired) {
    const before = next.rules.find(rule => rule.documentType === documentType && rule.organizationId === value.organizationId && rule.active)
      || next.rules.find(rule => rule.documentType === documentType && rule.organizationId === value.organizationId);
    if (before?.active && before.destination === value.destination) continue;
    next = putOcrApprovalRule(next, { id: before?.id || crypto.randomUUID(), documentType, ...value, active: true, updatedBy, updatedAt });
  }
  return next;
}

/** Most-specific type first, followed by its parents. Persist codes, never labels. */
export function ocrRoutingTypeCodes(document: { document_type?: string; document_subtype?: string }, catalog: readonly OcrDocumentType[]): string[] {
  const normalized = (value = '') => value.trim().toLowerCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
  const aliases: Record<string, string> = { 'credit note': 'credit invoice', 'debit note': 'debit invoice', receipt: 'cash receipt' };
  const match = (value?: string) => catalog.find(type => value && [type.code, type.fullName]
    .some(name => normalized(name) === (aliases[normalized(value)] || normalized(value))));
  let type = match(document.document_subtype) || match(document.document_type);
  const codes: string[] = [];
  while (type && !codes.includes(type.code)) {
    codes.push(type.code);
    type = catalog.find(parent => parent.code === type?.parentCode);
  }
  return codes.length ? codes : [document.document_subtype, document.document_type].filter((value): value is string => Boolean(value));
}

/** Organization overrides beat shared type rules. Subtypes beat their parent groups. */
export function resolveOcrApprovalRoute(rules: readonly OcrApprovalRule[], organizationId: string, typeCodes: readonly string[]): OcrRoutingResult {
  const matches = rules.filter(rule => rule.active && (!rule.organizationId || rule.organizationId === organizationId)
    && (!rule.documentType || typeCodes.includes(rule.documentType)));
  const score = (rule: OcrApprovalRule) => (rule.organizationId ? 10000 : 0)
    + (rule.documentType ? 1000 - typeCodes.indexOf(rule.documentType) : 0);
  const rule = matches.sort((a, b) => score(b) - score(a) || b.updatedAt.localeCompare(a.updatedAt))[0];
  return rule ? { destination: rule.destination, ruleId: rule.id } : { destination: 'FH' };
}

export function putOcrApprovalRule(store: OcrApprovalRoutingStore, rule: OcrApprovalRule): OcrApprovalRoutingStore {
  if (!rule.id || !rule.updatedBy || !['FH', 'TeamLead'].includes(rule.destination)) throw new Error('Choose a valid destination and sign in.');
  if (rule.active && store.rules.some(other => other.id !== rule.id && other.active
    && other.organizationId === rule.organizationId && other.documentType === rule.documentType))
    throw new Error('An active rule already exists for this organization and document type. Edit that rule instead.');
  const before = store.rules.find(other => other.id === rule.id);
  return { ...store, rules: before ? store.rules.map(other => other.id === rule.id ? rule : other) : [...store.rules, rule],
    history: [...store.history, { at: rule.updatedAt, by: rule.updatedBy, before, after: rule }] };
}

export function ocrCompletionDestination(route: OcrRoutingResult, existingReviewStatus?: string): OcrRoutingResult {
  // An explicit Worker referral always requires a review; confirming it finishes the route.
  return existingReviewStatus === 'Pending' || existingReviewStatus === 'Approved' ? { destination: 'FH', ruleId: route.ruleId } : route;
}
