/** The same stored document is projected in Worker, Issues, TeamLead and Documents. */
export const OCR_SHARED_FIELDS = {
  expense_account: 'expense', vat_classifier: 'vatClass', department_code: 'department',
  object_project: 'object', cost_center: 'center', series: null, product_group: 'productGroup',
  accountable_responsible: null,
} as const;
export type OcrSharedField = keyof typeof OCR_SHARED_FIELDS;
export type OcrFieldOverride = { source: 'accountant' | 'addinfo'; value: string; at?: string };
export const documentFieldText = (value: unknown): string => ['—', '-'].includes(String(value ?? '').trim()) ? '' : String(value ?? '').trim();

/** Mixed allocations have no single document-level value. Never concatenate codes for learning. */
export function sharedDocumentField(document: object, field: OcrSharedField | 'vat_percent'): string {
  const row = document as Record<string, unknown>;
  const line = field === 'vat_percent' ? 'vatPct' : OCR_SHARED_FIELDS[field];
  const allocations = row.summary_line_items;
  if (line && Array.isArray(allocations) && allocations.length) {
    const values = allocations.map(item => documentFieldText(item?.[line]));
    return values.every(value => value === values[0]) ? values[0] : '';
  }
  return documentFieldText(row[field]);
}

export function ocrFieldOverrides(document: object): Partial<Record<OcrSharedField, OcrFieldOverride>> {
  const value = (document as Record<string, unknown>).ocr_field_overrides;
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Partial<Record<OcrSharedField, OcrFieldOverride>> : {};
}

/** Record explicit corrections, including clearing a value. Defaults must not refill a cleared field. */
export function markAccountantFieldChanges<T extends object>(before: object, after: T, at: string): T {
  const previous = before as Record<string, unknown>, next = after as Record<string, unknown>;
  if (next.entry_method === 'manual') return after;
  const overrides = { ...ocrFieldOverrides(before) };
  for (const field of Object.keys(OCR_SHARED_FIELDS) as OcrSharedField[]) {
    const line = OCR_SHARED_FIELDS[field];
    const projection = (row: Record<string, unknown>) => JSON.stringify([row[field] ?? '',
      ...(line && Array.isArray(row.summary_line_items) ? row.summary_line_items.map(item => item?.[line] ?? '') : []),
      ...(field === 'accountable_responsible' ? [row.accountable_responsible_id ?? ''] : [])]);
    if (projection(previous) !== projection(next)) overrides[field] = { source: 'accountant', value: sharedDocumentField(after, field), at };
  }
  if (!Object.keys(overrides).length) return after;
  const synchronized = Object.fromEntries(Object.entries(overrides).map(([field, override]) => [field, override.value]));
  return { ...after, ...synchronized, ocr_field_overrides: overrides };
}

/** OCR can update recognized facts, not replace explicit accountant/ADDINFO assignments. */
export function preserveOcrAssignments<T extends object>(document: object, patch: T): T {
  const next: Record<string, unknown> = { ...patch } as Record<string, unknown>;
  const original = document as Record<string, unknown>;
  // A shared correction must also reach its allocation, otherwise registers would
  // continue displaying the old line value. Do not flatten differing allocations.
  for (const [field, line] of Object.entries({ ...OCR_SHARED_FIELDS, vat_percent: 'vatPct' })) {
    if (!line || !Object.hasOwn(next, field)) continue;
    const rows = original.summary_line_items;
    if (!Array.isArray(rows) || !rows.length) continue;
    const values = rows.map(item => documentFieldText(item?.[line]));
    if (values.every(value => value === values[0])) next.summary_line_items = (next.summary_line_items as Record<string, unknown>[] | undefined ?? rows)
      .map(item => ({ ...item, [line]: next[field] }));
  }
  for (const [field, override] of Object.entries(ocrFieldOverrides(document))) {
    if (!override || !['accountant', 'addinfo'].includes(override.source)) continue;
    next[field] = override.value;
    if (field === 'accountable_responsible') next.accountable_responsible_id = original.accountable_responsible_id ?? '';
    const line = OCR_SHARED_FIELDS[field as OcrSharedField];
    if (line && override.source === 'accountant' && Array.isArray(original.summary_line_items)) {
      const originalRows = original.summary_line_items;
      const rows = (next.summary_line_items ?? originalRows) as Record<string, unknown>[];
      next.summary_line_items = rows.map((item, index) => ({ ...item, [line]: originalRows[index]?.[line] ?? '' }));
    }
    if (line && override.source === 'addinfo') for (const key of ['summary_line_items', 'line_items']) {
      const rows = next[key] ?? original[key];
      if (Array.isArray(rows)) next[key] = rows.map(item => ({ ...item, [line]: override.value }));
    }
  }
  return next as T;
}

/** Organization-scoped reference code; an internal database ID is never a company code. */
export function documentCounterpartyCode(document: object, storage?: Pick<Storage, 'getItem'>): string {
  const row = document as Record<string, unknown>;
  try {
    const source = storage ?? (typeof localStorage !== 'undefined' ? localStorage : undefined);
    const records = JSON.parse(source?.getItem(`finansu-harmonija:v18:company-counterparties:${row.company_id || ''}`) || '[]');
    if (!row.company_id || !Array.isArray(records)) return '';
    const byId = records.find(item => item.id && item.id === row.counterparty_id);
    if (byId) return documentFieldText(byId.company_code);
    const code = documentFieldText(row.counterparty_code), name = documentFieldText(row.client_counterparty).toLocaleLowerCase();
    const matches = records.filter(item => code ? documentFieldText(item.company_code) === code
      : name && documentFieldText(item.name).toLocaleLowerCase() === name);
    return matches.length === 1 ? documentFieldText(matches[0].company_code) : '';
  } catch { return ''; }
}
