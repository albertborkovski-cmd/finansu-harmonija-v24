import { HELP_CATEGORIES, helpCenterHref, type HelpCategory } from './helpCenterCatalog';
import { INTEGRATION_ARTICLES } from './integrationHelp';
import { integrationTopics } from './integrationHelpTopics';
import { ORGANIZATION_HELP_SECTIONS, organizationHelpHref, organizationHelpSteps } from './organizationSettingsHelp';
import { exportHelpHref, exportHelpFields, exportFieldHelp } from './exportSettingsHelp';
import { exportSetupSteps, FILE_EXPORT_STEPS, API_EXPORT_STEPS, type HelpText } from './exportHelpGuide';
import { COMPANY_EXPORT_FORMATS } from './companyDigitizationSettings';
import { exportHelpVisual, integrationHelpVisuals, organizationHelpVisuals, type HelpVisual } from './helpVisuals';
import { helpArticleKey, integrationHelpGroup, isHelpVisible, isHelpGroupVisible, type EditableHelpArticle, type HelpContentState } from './helpContent';
import { helpParent } from './helpEditing';

const textPair = (fn: (lang: 0 | 1) => string): HelpText => [fn(0), fn(1)];
const images = (visuals: Array<HelpVisual | undefined>, lang: 0 | 1) => visuals.filter((image): image is HelpVisual => Boolean(image)).map(image => `![${image.caption[lang].replace(/\]/g, '')}](help/${image.file})`).join('\n\n');
const table = (value: { headers: HelpText[]; rows: HelpText[][] }, lang: 0 | 1) => [value.headers.map(cell => cell[lang]).join(' | '), value.headers.map(() => '---').join(' | '), ...value.rows.map(row => row.map(cell => cell[lang]).join(' | '))].map(row => `| ${row} |`).join('\n');
const article = (href: string, category: string, title: HelpText, description: HelpText, body: HelpText): EditableHelpArticle => ({ key: helpArticleKey(href), href, category, title, description, body });
const catalog: EditableHelpArticle[] = [];

for (const category of HELP_CATEGORIES) for (const entry of category.entries) {
  if (!entry.paragraphs) continue;
  const body = textPair(lang => entry.guide ? entry.guide.sections.map(section => [
    `## ${section.title[lang]}`, section.path?.[lang], ...(section.paragraphs || []).map(p => p[lang]),
    ...(section.steps || []).map((p, index) => `${index + 1}. ${p[lang]}`), section.table ? table(section.table, lang) : '',
    section.result ? `${lang ? 'Rezultatas' : 'Result'}: ${section.result[lang]}` : '', section.warning?.[lang], images(section.images || [], lang),
  ].filter(Boolean).join('\n\n')).join('\n\n') : entry.paragraphs!.map(p => p[lang]).join('\n\n'));
  catalog.push(article(entry.href, category.id, entry.title, entry.description, body));
}
for (const integration of INTEGRATION_ARTICLES) {
  const category = integration.group === 'collection' ? 'collection' : HELP_CATEGORIES.find(item => item.id === integrationHelpGroup(integration.id))?.id || 'other-integrations';
  const href = (topic?: string) => `./#help/integrations?${new URLSearchParams({ integration: integration.id, ...(topic ? { topic } : {}) })}`;
  const topics = integrationTopics(integration.id);
  catalog.push(article(href(), category, integration.name, integration.summary, textPair(lang => topics.map(topic => `## [${topic.title[lang]}](${href(topic.id)})\n\n${topic.description[lang]}`).join('\n\n'))));
  for (const topic of topics) catalog.push(article(href(topic.id), category, topic.title, topic.description, textPair(lang => [
    ...topic.sections.map(section => [
      `## ${section.title[lang]}`, ...(section.paragraphs || []).map(p => p[lang]), ...(section.steps || []).map((p, index) => `${index + 1}. ${p[lang]}`),
      section.table ? table(section.table, lang) : '', section.example ? [`### ${section.example.title[lang]}`, section.example.code ? '```\n' + section.example.code + '\n```' : '', ...section.example.paragraphs.map(p => p[lang])].join('\n\n') : '',
      ...(section.links || []).map(link => `[${link.label[lang]}](./#help/integrations?${new URLSearchParams({ integration: link.integration || integration.id, topic: link.topic })})`),
    ].filter(Boolean).join('\n\n')),
    topic.note?.[lang], images(integrationHelpVisuals(integration.id, topic.id).length ? integrationHelpVisuals(integration.id, topic.id) : topic.screenshot ? [topic.screenshot] : [], lang),
    ...(integration.links || []).map(link => `[${link.label}](${link.url})`),
    ...(topic.fieldReference ? exportHelpFields(integration.id, 'overview').map(field => `### ${field.label}\n\n${exportFieldHelp(field, Boolean(lang))}`) : []),
  ].filter(Boolean).join('\n\n'))));
}
for (const section of ORGANIZATION_HELP_SECTIONS) for (const topic of ['overview', ...section.articles.map(item => item.id)]) {
  const selected = section.articles.find(item => item.id === topic);
  const parent = HELP_CATEGORIES[0].entries.find(item => item.id === `organization-${section.id}`)!;
  catalog.push(article(organizationHelpHref(section.id, topic), 'system', selected ? [section.label + ' · ' + selected.label, parent.title[1] + ' · ' + selected.label] : parent.title, section.intro,
    textPair(lang => [
      ...(!selected ? organizationHelpSteps(section.id).map((step, i) => `${i + 1}. ${step[lang]}`) : []),
      ...(selected ? [selected] : section.articles).map(item => `## ${item.label}\n\n${item.body[lang]}`), images(organizationHelpVisuals(section.id, topic), lang),
    ].filter(Boolean).join('\n\n'))));
}
const exportTopics: Array<[string, HelpText]> = [['overview', ['Setup', 'Nustatymas']], ['transfer', ['File or API?', 'Failas ar API?']], ['fields', ['Field descriptions', 'Laukų paaiškinimai']], ['columns', ['Additional columns', 'Papildomi stulpeliai']], ['errors', ['Troubleshooting', 'Klaidų sprendimas']]];
for (const format of COMPANY_EXPORT_FORMATS) {
  const category = HELP_CATEGORIES.find(item => item.id === integrationHelpGroup(format))?.id || 'other-integrations';
  for (const [topic, title] of [...exportTopics, ...exportHelpFields(format, 'overview').map(field => [field.key, [field.label, field.label]] as [string, HelpText])]) {
    const body = textPair(lang => {
      if (topic === 'overview') return exportSetupSteps(format).map((step, index) => `## ${index + 1}. ${step.title[lang]}\n\n${step.body[lang]}`).join('\n\n') + '\n\n' + images([exportHelpVisual(format)!], lang);
      if (topic === 'transfer') return [...FILE_EXPORT_STEPS, ...API_EXPORT_STEPS].map((p, index) => `${index + 1}. ${p[lang]}`).join('\n\n');
      if (topic === 'columns') return (lang ? 'Privalomas – tuščiam laukui rodomas įspėjimas. Priskirti automatiškai – tuščiam laukui pritaikoma numatytoji reikšmė. Numatytoji reikšmė pasirenkama iš organizacijos kodų sąrašo.' : 'Required flags an empty field. Assign automatically fills an empty field with its default. Select defaults from the organization’s codes.') + '\n\n' + images([exportHelpVisual(format, 'columns')!], lang);
      if (topic === 'errors') return lang ? 'Patikrinkite organizaciją, gavėjo duomenų bazę, eksporto formatą, privalomus laukus ir apskaitos kodus. Patikrinkite, ar nėra neišspręstos dokumento klaidos ir ar gavėjo sistemoje leidžiamas dokumento laikotarpis. Prieš kartodami siuntimą įsitikinkite, kad dokumentas jau nebuvo sukurtas.' : 'Check the organization, destination database, export format, required fields and accounting codes. Check unresolved issues and the allowed posting period. Before retrying, check whether the document already exists.';
      return exportHelpFields(format, topic === 'fields' ? 'overview' : topic).map(field => `## ${field.label}\n\n${exportFieldHelp(field, Boolean(lang))}`).join('\n\n');
    });
    if (body.some(Boolean)) catalog.push(article(exportHelpHref(format, topic), category, [`${format} · ${title[0]}`, `${format} · ${title[1]}`], [format + ' export settings', format + ' eksporto nustatymai'], body));
  }
}
export const EDITORIAL_HELP_ARTICLES = Array.from(new Map(catalog.map(item => [item.key, item])).values());
export function editorialArticles(state: HelpContentState) { return Array.from(new Map([...EDITORIAL_HELP_ARTICLES, ...Object.values(state.articles)].map(item => [item.key, item])).values()); }
export function editorialArticle(href: string, state: HelpContentState) { const key = helpArticleKey(href); return state.articles[key] || EDITORIAL_HELP_ARTICLES.find(item => item.key === key); }
export function helpCategories(state: HelpContentState): HelpCategory[] {
  return [...HELP_CATEGORIES.map(category => ({ ...category, ...state.categories?.[category.id] })),
    ...Object.values(state.categories || {}).filter(category => !HELP_CATEGORIES.some(base => base.id === category.id)).map(category => ({ ...category, icon: 'system' as const, entries: [] })),
  ];
}
export function visibleHelpCategories(state: HelpContentState): HelpCategory[] {
  const order = new Map(editorialArticles(state).map((article, index) => [article.key, article.order ?? index]));
  return helpCategories(state).filter(category => isHelpGroupVisible(category.id, state)).map(category => ({ ...category, entries: [
    ...category.entries.filter(entry => {
      const key = helpArticleKey(entry.href), edited = state.articles[key], base = EDITORIAL_HELP_ARTICLES.find(item => item.key === key);
      return isHelpVisible(entry.href, state) && (!edited || edited.category === base?.category || edited.category === category.id);
    }).map(entry => {
      const edited = state.articles[helpArticleKey(entry.href)];
      return edited ? { ...entry, title: edited.title, description: edited.description, searchText: edited.body, parentKey: helpParent(edited), order: edited.order } : entry;
    }),
    ...Object.values(state.articles).filter(item => item.category === category.id && isHelpVisible(item.href, state)).map(item => ({ id: item.key, title: item.title, description: item.description, href: item.href, searchText: item.body, parentKey: helpParent(item), order: item.order })),
  ].filter((entry, index, all) => all.findIndex(item => item.href === entry.href) === index).sort((a, b) => (order.get(helpArticleKey(a.href)) ?? 0) - (order.get(helpArticleKey(b.href)) ?? 0)) })).filter(category => category.entries.length);
}
export function newHelpArticle(category: string): EditableHelpArticle {
  const id = `custom-${crypto.randomUUID()}`, href = helpCenterHref(category, id);
  return { key: helpArticleKey(href), href, category, custom: true, title: ['', ''], description: ['', ''], body: ['', ''] };
}
