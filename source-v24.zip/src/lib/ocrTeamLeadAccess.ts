import { canViewMenu } from './accessControl';
import { documentIssueSession } from './documentIssueAccess';
import { canAccessAssignedOrganization, loadLinkedDirectoryUsers } from './linkedSettingsData';

export function canViewTeamLeadWork() {
  const session = documentIssueSession();
  return Boolean(session && canViewMenu(session, 'ocr-ml')
    && !session.roleNames.includes('External demo user')
    && !loadLinkedDirectoryUsers('External users').some(user => user.email?.toLowerCase() === session.email.toLowerCase()));
}

export function canViewTeamLeadOrganization(company: { id: string; name: string; assigned_accountant?: string }) {
  const session = documentIssueSession();
  return Boolean(session && canViewTeamLeadWork() && canAccessAssignedOrganization(company, session));
}
