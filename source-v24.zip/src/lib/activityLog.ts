export type ActivityLogScope = 'ocr' | 'fh';
export type ActivityLogRow = { id: string; change: string; version: string; name: string; user: string; fields: string; date: string };
type AuditRecord = Record<string, unknown>;

export function activityLogScope(record: AuditRecord): ActivityLogScope {
  const area = String(record.module || record.category || '').toLowerCase();
  const action = String(record.action || '').toLowerCase();
  return /ocr|digitiz|machine learning|team.?lead|worker/.test(area)
    || /ocr|digitiz|team.?lead|worker|issue reported|report.*issue|issue.*(fixed|resolved)|review started/.test(action) ? 'ocr' : 'fh';
}

/** Keep audit records read-only and within the user's accessible company scope. */
export function activityLogRows(records: readonly AuditRecord[], documents: readonly AuditRecord[], companyIds: ReadonlySet<string>, scope: ActivityLogScope): ActivityLogRow[] {
  const documentsById = new Map(documents.map(document => [String(document.id), document]));
  return records.filter(record => {
    const document = documentsById.get(String(record.document_id || ''));
    const companyId = String(record.organization_id || record.company_id || document?.company_id || '');
    if (companyId && !companyIds.has(companyId)) return false;
    if (record.document_id && !companyId) return false;
    return activityLogScope(record) === scope;
  }).map(record => {
    const document = documentsById.get(String(record.document_id || ''));
    return {
      id: String(record.id || ''), change: String(record.action || '—'), version: String(record.version || '—'),
      name: String(document?.number || document?.file_case || record.organization_name || record.category || '—'),
      user: String(record.user_name || record.actor || '—'), fields: String(record.details || '—'),
      date: String(record.created_at || record.at || ''),
    };
  }).sort((a, b) => b.date.localeCompare(a.date));
}
