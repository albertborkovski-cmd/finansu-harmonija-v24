import { loadInvoiceLineTypeCatalog } from './invoiceLineTypes';

/** The renamed General settings catalog retains its stable Type storage key.
 * Its classification is separate from Purchase / Sale accounting direction. */
export function documentPurposeCatalogOptions() {
  return loadInvoiceLineTypeCatalog().filter(row => row.status === 'Active')
    .map(row => ({ value: row.code, label: row.fullName || row.code }));
}

export function validateDocumentPurposeCode(value: string) {
  if (!documentPurposeCatalogOptions().some(option => option.value === value))
    throw new Error('Select an active document purpose from General settings.');
}

export function globalDocumentColumn<T extends { key: string; label: string; width?: number; visible?: boolean }>(column: T): T {
  if (column.key === 'type') return { ...column, key: 'purposeCode', label: 'Document purpose', ...(column.width === undefined ? {} : { width: 160 }) };
  return column;
}

/** Remove register columns, not their stored document/line data. */
export function globalDocumentColumns<T extends { key: string; label: string; width?: number; visible?: boolean }>(columns: readonly T[]): T[] {
  return columns.filter(column => !['documentPurpose', 'productGroup'].includes(column.key)).map(globalDocumentColumn);
}
