import type { Company, DbDocument } from './supabase';
import { documentEditStateError } from './documentInlineEditing';
import { documentLineNumber } from './documentDetailEditing';
import type { InvoiceAttachment } from './invoiceCreation';
import type { ReconciliationState } from './reconciliation';

export type BankAllocation = { id: string; description: string; glAccount: string; department: string; project: string; costCenter: string; amount: string };
export type BankTransaction = {
  version: 1; date: string; bankAccount: string; counterpartyId: string; counterpartyName: string; counterpartyCode: string;
  counterpartyIban: string; paymentPurpose: string; amount: string; currency: string; exchangeRateDate: string;
  /** Bank posting date, separate from the transaction and exchange rate dates. Absent on older imports. */
  bookingDate?: string;
  referenceNo: string; transferNo: string; originalStatement: string; notes: string; allocations: BankAllocation[]; attachments: InvoiceAttachment[];
};
export type BankAccountOption = { id?: string; iban: string; bank?: string; bankCode?: string; primary?: boolean; inactive?: boolean; active?: boolean };
export function companyBankAccounts(company: Company): BankAccountOption[] {
  try {
    const rows = JSON.parse(company.organization_bank_accounts || '[]');
    return Array.isArray(rows) ? rows.filter(row => row && typeof row.iban === 'string' && row.iban.trim() && !row.inactive && row.active !== false) : [];
  } catch { return []; }
}
const date = (value: string) => /^\d{4}-\d{2}-\d{2}/.test(value) ? value.slice(0, 10) : /^\d{2}\.\d{2}\.\d{4}$/.test(value) ? value.split('.').reverse().join('-') : '';
const cents = (value: string) => /^-?\d+(?:[.,]\d{1,2})?$/.test(value.trim()) ? Math.round(Number(value.replace(',', '.')) * 100) : NaN;
export function bankAllocationTotals(transaction: Pick<BankTransaction, 'amount' | 'allocations'>) {
  const amount = cents(transaction.amount), values = transaction.allocations.map(row => cents(row.amount));
  const allocated = values.reduce((sum, value) => sum + value, 0);
  return { amount, allocated, remaining: amount - allocated, valid: [amount, allocated, ...values].every(Number.isSafeInteger) };
}
/** Replace only the original synthetic payment descriptions; retain any user-entered text. */
export function bankPaymentPurpose(documentId: string, companyId: string, value: string) {
  if (companyId !== '00000000-0000-4000-8000-000000000002') return value;
  if (documentId === '10000000-0000-4000-8000-000000000004' && value === 'Advance invoice') return 'Payment for invoice ADV-004';
  if (documentId === '10000000-0000-4000-8000-000000000003' && value === 'Receipt') return 'Payment for invoice EXP-003';
  return value;
}
export function bankTransactionFromDocument(document: DbDocument, company: Company): BankTransaction {
  if (document.bank_transaction) return structuredClone(document.bank_transaction);
  const accounts = companyBankAccounts(company), account = accounts.find(row => row.primary) || accounts[0];
  const amount = documentLineNumber(document.total_amount || document.amount_without_vat).toFixed(2);
  const operationDate = date(document.operation_date || document.document_date || document.receive_date);
  const allocations = document.summary_line_items?.length ? document.summary_line_items.map(row => ({
    id: row.id, description: row.product || 'Other transaction', glAccount: row.expense || '', department: row.department || '',
    project: row.object || '', costCenter: row.center || '', amount: documentLineNumber(row.total || row.subtotal).toFixed(2),
  })) : [{ id: `${document.id}:bank-allocation`, description: document.document_purpose || 'Other transaction', glAccount: document.expense_account || '',
    department: document.department_code || '', project: document.object_project || '', costCenter: document.cost_center || '', amount }];
  return { version: 1, date: operationDate, bankAccount: account?.iban || '', counterpartyId: document.counterparty_id || '',
    counterpartyName: document.client_counterparty || '', counterpartyCode: document.counterparty_code || '', counterpartyIban: '',
    paymentPurpose: bankPaymentPurpose(document.id, company.id, document.notes || document.document_subtype || document.document_type || ''), amount, currency: document.currency || company.base_currency || 'EUR',
    exchangeRateDate: operationDate, referenceNo: document.number || '', transferNo: document.order_no || document.number || '',
    originalStatement: document.notes || '', notes: document.notes || '', allocations, attachments: [] };
}
export function bankTransactionSnapshot(document: DbDocument) {
  return JSON.stringify(document);
}
export const BANK_RECONCILIATION_STATUSES = ['Unmatched', 'Partially matched', 'Matched'] as const;
export function bankReconciliation(documentId: string, companyId: string, raw: string | null) {
  const empty = { status: 'Unmatched', documents: [] as { id: string; number: string }[], matched: false, hasRecord: false };
  if (!raw) return empty;
  try {
    const state = JSON.parse(raw) as ReconciliationState;
    if (state.organizationId !== companyId || !Array.isArray(state.items) || !Array.isArray(state.batches)) return { ...empty, status: 'Unavailable' };
    const item = state.items.find(row => row.id === documentId && row.organizationId === companyId);
    if (!item) return empty;
    const ids = new Set(state.batches.filter(batch => !batch.reversedAt).flatMap(batch => batch.allocations
      .filter(row => row.fundingId === documentId || row.invoiceId === documentId)
      .map(row => row.fundingId === documentId ? row.invoiceId : row.fundingId)));
    const documents = state.items.filter(row => ids.has(row.id)).map(row => ({ id: row.id, number: row.documentNumber }));
    const matched = item.remainingMinor < item.originalMinor;
    return { status: !matched ? 'Unmatched' : item.remainingMinor === 0 ? 'Matched' : 'Partially matched', documents, matched, hasRecord: true };
  } catch { return { ...empty, status: 'Unavailable' }; }
}
/** Seed-row presentation only. Actual reconciliation always wins; no settlement or posting is created. */
export function bankReconciliationForDisplay(documentId: string, companyId: string, raw: string | null) {
  const reconciliation = bankReconciliation(documentId, companyId, raw);
  const demo = !reconciliation.hasRecord && reconciliation.status === 'Unmatched'
    && companyId === '00000000-0000-4000-8000-000000000002'
    && documentId === '10000000-0000-4000-8000-000000000003';
  return { ...reconciliation, status: demo ? 'Matched' : reconciliation.status, demo };
}
export const bankReconciliationKey = (companyId: string) => `finansu-harmonija:v15:reconciliation-examples-v2:${companyId}`;
export type BankValidationOptions = { allowed: boolean; accountIbans: string[]; counterparties: { id: string; name: string; company_code?: string }[]; glAccounts: string[]; reconciled: boolean };
/** Bank-specific edits are an overlay, never an invoice rewrite, posting or settlement. */
export function validateBankTransaction(document: DbDocument, company: Company, draft: BankTransaction, expected: string, options: BankValidationOptions): BankTransaction {
  if (!options.allowed) throw new Error('You do not have permission to edit this company’s bank entries.');
  if (document.company_id !== company.id || document.document_deletion) throw new Error('The bank entry is no longer available in this company.');
  const stateError = documentEditStateError(document as unknown as Parameters<typeof documentEditStateError>[0]);
  if (stateError) throw new Error(stateError);
  if (bankTransactionSnapshot(document) !== expected) throw new Error('The bank entry changed. Reopen it before saving.');
  const previous = bankTransactionFromDocument(document, company);
  if (draft.version !== 1 || Object.keys(draft).some(key => !Object.hasOwn(previous, key))) throw new Error('Invalid bank transaction data.');
  for (const [key, value] of Object.entries(draft)) {
    if (['version', 'allocations', 'attachments'].includes(key)) continue;
    if (typeof value !== 'string' || value.length > (['notes', 'originalStatement', 'paymentPurpose'].includes(key) ? 5000 : 500)) throw new Error('A bank field contains an invalid value.');
  }
  for (const value of [draft.date, draft.exchangeRateDate]) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString().slice(0, 10) !== value) throw new Error('Select valid transaction and exchange rate dates.');
  }
  if (!/^[A-Z]{3}$/.test(draft.currency)) throw new Error('Select a valid currency.');
  if (draft.originalStatement !== previous.originalStatement) throw new Error('The original bank statement text cannot be changed.');
  // Imported bank facts are immutable, including when changing only accounting allocations.
  // Historical/missing account references may remain as imported; they are not new selections.
  const importedFields = ['date', 'bankAccount', 'counterpartyId', 'counterpartyName', 'counterpartyCode', 'counterpartyIban',
    'paymentPurpose', 'amount', 'currency', 'exchangeRateDate', 'bookingDate', 'referenceNo', 'transferNo'] as const;
  if (importedFields.some(key => draft[key] !== previous[key]))
    throw new Error('Original bank data (bank account, amount, dates and payment details) cannot be changed. Use Edit matching data for reconciliation.');
  if (!Array.isArray(draft.allocations) || !draft.allocations.length || draft.allocations.length > 200) throw new Error('Add at least one accounting allocation.');
  const totals = bankAllocationTotals(draft);
  if (!totals.valid || totals.amount === 0) throw new Error('Enter valid amounts with up to two decimal places.');
  if (totals.remaining !== 0) throw new Error('The allocated amount must equal the transaction amount.');
  const ids = new Set<string>();
  for (const row of draft.allocations) {
    if (!row || typeof row.id !== 'string' || !row.id || ids.has(row.id) || Object.values(row).some(value => typeof value !== 'string' || value.length > 1000)) throw new Error('Invalid allocation row.');
    ids.add(row.id);
    if (!row.description.trim() || !row.glAccount.trim()) throw new Error('Each allocation needs a description and GL account.');
    const old = previous.allocations.find(item => item.id === row.id);
    if (!options.glAccounts.includes(row.glAccount) && old?.glAccount !== row.glAccount) throw new Error('Select an active GL account from this company’s chart of accounts.');
  }
  if (!Array.isArray(draft.attachments) || draft.attachments.length > 20) throw new Error('A maximum of 20 attachments is allowed.');
  let size = 0;
  for (const file of draft.attachments) {
    if (!file || typeof file.name !== 'string' || !file.name.trim() || file.name.length > 255 || !Number.isSafeInteger(file.size) || file.size <= 0 || file.size > 2 * 1024 * 1024
      || !['application/pdf', 'image/png', 'image/jpeg'].includes(file.type) || typeof file.url !== 'string' || !file.url.startsWith(`data:${file.type};base64,`) || file.url.length > 3 * 1024 * 1024) throw new Error('Use PDF, PNG or JPG attachments up to 2 MB each.');
    size += file.size;
  }
  if (size > 8 * 1024 * 1024) throw new Error('Attachments must not exceed 8 MB in total.');
  return structuredClone(draft);
}
