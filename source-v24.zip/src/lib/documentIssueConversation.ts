import { documentIssueEvent, type DocumentIssue, type DocumentIssueMessage } from './documentIssues';

export type IssueConversationSide = DocumentIssueMessage['authorSide'];
export type IssueConversationCommand =
  | { type: 'reply'; issueId: string; side: IssueConversationSide; messageId: string; text: string }
  | { type: 'read'; issueId: string; side: IssueConversationSide; messageIds: string[] };

export function issueConversationMessages(issue: DocumentIssue): DocumentIssueMessage[] {
  return [{ id: `report:${issue.id}`, text: issue.message, sentAt: issue.createdAt, author: issue.createdBy,
    authorEmail: issue.createdByEmail || '', authorSide: 'accountant' }, ...(issue.messages ?? [])];
}

export function unreadIssueMessages(issue: DocumentIssue, email: string, side: IssueConversationSide) {
  const viewer = email.trim().toLowerCase();
  if (!viewer) return [];
  return (issue.messages ?? []).filter(message => message.authorEmail.toLowerCase() !== viewer
    && message.authorSide !== side && !message.readBy?.some(reader => reader.email.toLowerCase() === viewer));
}

/** Replies and read receipts never change the document or issue workflow. */
export function updateIssueConversation(issue: DocumentIssue, command: IssueConversationCommand, actor: { name: string; email: string }): DocumentIssue {
  const email = actor.email.trim().toLowerCase();
  if (!email || !actor.name.trim()) throw new Error('Sign in to use the issue conversation.');
  if (command.issueId !== issue.id) throw new Error('This reported issue is no longer available.');
  if (!['accountant', 'worker'].includes(command.side)) throw new Error('You do not have access to this issue conversation.');
  if (issue.messages !== undefined && !Array.isArray(issue.messages)) throw new Error('Unable to read the issue conversation. History was not overwritten.');
  const messages = issue.messages ?? [];
  if (command.type === 'read') {
    const shown = new Set(command.messageIds);
    const unread = new Set(unreadIssueMessages(issue, email, command.side).filter(message => shown.has(message.id)).map(message => message.id));
    if (!unread.size) return issue;
    const at = new Date().toISOString();
    return { ...issue, messages: messages.map(message => unread.has(message.id)
      ? { ...message, readBy: [...(message.readBy ?? []), { email, side: command.side, at }] } : message) };
  }
  const text = command.text.trim();
  if (!text || text.length > 5000) throw new Error('Enter a message (1–5,000 characters).');
  if (!/^[a-zA-Z0-9-]{8,100}$/.test(command.messageId)) throw new Error('Invalid message identifier.');
  const duplicate = messages.find(message => message.id === command.messageId);
  if (duplicate) {
    if (duplicate.authorEmail === email && duplicate.authorSide === command.side && duplicate.text === text) return issue;
    throw new Error('The message identifier is already in use.');
  }
  if (issue.status === 'Resolved') throw new Error('This issue is fixed. Report a new issue to start another conversation.');
  const event = documentIssueEvent(actor.name, 'Issue message sent', text);
  return { ...issue, messages: [...messages, { id: command.messageId, text, sentAt: event.at, author: actor.name,
    authorEmail: email, authorSide: command.side, readBy: [] }], events: [...issue.events, event] };
}
