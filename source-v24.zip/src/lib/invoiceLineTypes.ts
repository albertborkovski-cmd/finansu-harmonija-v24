export const DEFAULT_INVOICE_LINE_TYPES = ['Service', 'Product', 'Code'] as const;
export const INVOICE_LINE_TYPE_CATALOG_KEY = 'finansu-harmonija:organization-reference:Type';
export type LineTypeCatalogRecord = { code: string; fullName: string; description: string; country: string; status: string; parentCode: string };
export function loadInvoiceLineTypeCatalog(): LineTypeCatalogRecord[] {
  const defaults = DEFAULT_INVOICE_LINE_TYPES.map(value => ({ code: value, fullName: value, description: '', country: '', status: 'Active', parentCode: '' }));
  try {
    const raw = typeof window === 'undefined' ? null : window.localStorage.getItem(INVOICE_LINE_TYPE_CATALOG_KEY);
    if (raw === null) return defaults;
    const stored: unknown = JSON.parse(raw);
    if (!Array.isArray(stored)) return [];
    return stored.flatMap(item => {
      if (typeof item === 'string') return [{ code: item, fullName: item, description: '', country: '', status: 'Active', parentCode: '' }];
      if (!item || typeof item.code !== 'string' || !item.code.trim()) return [];
      return [{ code: item.code.trim(), fullName: String(item.fullName || item.code), description: String(item.description || ''), country: '', status: item.status === 'Inactive' ? 'Inactive' : 'Active', parentCode: '' }];
    });
  } catch { return []; }
}
export const invoiceLineTypeScope = (companyId: string) => `invoice_line_type::company::${companyId}`;
export type InvoiceLineTypeRecord = { type?: unknown; value?: unknown; inactive?: unknown; active?: unknown; is_active?: unknown; status?: unknown };
const active = (row: InvoiceLineTypeRecord) => !row.inactive && row.active !== false && row.is_active !== false && String(row.status ?? '').toLowerCase() !== 'inactive';
const identity = (value: string) => value.normalize('NFKC').toLowerCase();

export function normalizeInvoiceLineType(value: unknown): string {
  if (typeof value !== 'string' || [...value].some(char => char.charCodeAt(0) < 32 || char.charCodeAt(0) === 127)) throw new Error('Enter a valid type name.');
  const name = value.trim().replace(/\s+/g, ' ');
  if (!name || name.length > 80) throw new Error('Enter a type name between 1 and 80 characters.');
  return name;
}

export function invoiceLineTypeValues(companyId: string, records: readonly InvoiceLineTypeRecord[]): string[] {
  const catalog = loadInvoiceLineTypeCatalog();
  const values = catalog.filter(row => row.status === 'Active').map(row => row.code);
  const seen = new Set(values.map(identity));
  for (const row of records) {
    if (row.type !== invoiceLineTypeScope(companyId) || !active(row)) continue;
    try {
      const value = normalizeInvoiceLineType(row.value);
      if (!seen.has(identity(value)) && !catalog.some(item => identity(item.code) === identity(value))) { seen.add(identity(value)); values.push(value); }
    } catch { /* Invalid legacy values are never offered or accepted on invoices. */ }
  }
  return values;
}

export function invoiceLineTypeOptions(companyId: string, records: readonly InvoiceLineTypeRecord[]) {
  const catalog = loadInvoiceLineTypeCatalog();
  return invoiceLineTypeValues(companyId, records).map(value => ({ value, label: catalog.find(row => row.code === value)?.fullName || value }));
}

/** Reuse an existing name without duplicating it or reactivating inactive records. */
export function prepareInvoiceLineType(companyId: string, name: unknown, records: readonly InvoiceLineTypeRecord[]) {
  if (!companyId) throw new Error('Select a company before creating a type.');
  const value = normalizeInvoiceLineType(name), key = identity(value), type = invoiceLineTypeScope(companyId);
  const catalog = loadInvoiceLineTypeCatalog();
  const match = catalog.find(row => identity(row.code) === key || identity(row.fullName) === key);
  if (match) {
    if (match.status !== 'Active') throw new Error('This type is inactive and cannot be recreated.');
    return { type, value: match.code, create: false };
  }
  const existing = invoiceLineTypeValues(companyId, records).find(item => identity(item) === key);
  if (existing) return { type, value: existing, create: false };
  if (records.some(row => row.type === type && typeof row.value === 'string' && identity(row.value.trim().replace(/\s+/g, ' ')) === key))
    throw new Error('This type is inactive and cannot be recreated.');
  return { type, value, create: true };
}
