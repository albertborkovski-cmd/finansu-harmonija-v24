import { canEditMenu, canViewMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization } from './linkedSettingsData';
import { canCreateCompanyDocument, documentActionRights } from './documentRowActionAccess';
import { isInactiveRecord, isRecordLinked } from './recordLifecycle';
import { rememberReconciliationLedgerUsage } from './generalLedgerUsage';
import type { Company } from './supabase';
import { emptyCash, type CashBase, type CashStore } from './cash';
import { normalizeCashExampleLabels } from './cashExamples';

export const CASH_CHANGED = 'finansu-harmonija:cash-changed';
export const cashStorageKey = (companyId: string) => `finansu-harmonija:v22:cash:${encodeURIComponent(companyId)}`;
export function cashPermissions(company: Company) {
  try {
    const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
    const view = !!session && !isInactiveRecord(company) && canAccessAssignedOrganization(company, session) && canViewMenu(session, 'bank');
    const edit = view && !!session && canEditMenu(session, 'bank');
    return { view, edit, create: edit && canCreateCompanyDocument(company), delete: edit && documentActionRights(company).delete };
  } catch { return { view: false, edit: false, create: false, delete: false }; }
}
export function parseCashStore(raw: string | null, companyId: string): CashStore {
  if (raw === null) return emptyCash(companyId);
  const value = JSON.parse(raw) as CashStore;
  const collections = ['accounts', 'people', 'series', 'documents', 'audit'] as const;
  if (!value || value.version !== 1 || value.companyId !== companyId || !Number.isSafeInteger(value.revision) || !collections.every(key => Array.isArray(value[key]))) throw new Error('Cash data could not be read. Existing records have not been overwritten.');
  for (const key of ['accounts', 'people', 'series', 'documents'] as const) {
    if (value[key].some(row => !row || !row.id || row.companyId !== companyId || !Number.isSafeInteger(row.revision)) || new Set(value[key].map(row => row.id)).size !== value[key].length) throw new Error('Cash data contains invalid or differently scoped records.');
  }
  if (value.documents.some(row => !Array.isArray(row.lines) || !['Draft', 'Approved'].includes(row.status) || row.lines.some(line => !Number.isSafeInteger(line.amountMinor)))) throw new Error('Saved cash document data is invalid.');
  return normalizeCashExampleLabels(value);
}
export function loadCash(companyId: string): CashStore {
  return parseCashStore(localStorage.getItem(cashStorageKey(companyId)), companyId);
}

/** Own creation/update audit is history, not an accounting assignment. Other links still count. */
export function cashHasExternalLinks(record: CashBase, storage: Storage = localStorage): boolean {
  const key = cashStorageKey(record.companyId);
  const readable = {
    get length() { return storage.length; },
    key: (index: number) => storage.key(index),
    getItem: (name: string) => {
      const raw = storage.getItem(name);
      return name === key && raw !== null ? JSON.stringify({ ...parseCashStore(raw, record.companyId), audit: [] }) : raw;
    },
  } as Storage;
  return isRecordLinked(record, key, readable);
}
/** One synchronous commit for numbering, document and audit; stale editors fail closed. */
export function updateCash(company: Company, expectedRevision: number, action: 'edit' | 'create' | 'delete', change: (store: CashStore) => CashStore) {
  if (!cashPermissions(company)[action]) throw new Error('You do not have permission to perform this cash operation.');
  const current = loadCash(company.id);
  if (current.revision !== expectedRevision) throw new Error('Cash records changed in another window. Refresh and try again.');
  const next = change(current);
  const serialized = JSON.stringify(next);
  parseCashStore(serialized, company.id);
  if (next.revision <= current.revision) throw new Error('The cash update has no valid revision.');
  // Keep historical GL usage even if an unused draft is later removed.
  rememberReconciliationLedgerUsage(current, company.id, company.general_ledger || '');
  rememberReconciliationLedgerUsage(next, company.id, company.general_ledger || '');
  localStorage.setItem(cashStorageKey(company.id), serialized);
  window.dispatchEvent(new CustomEvent(CASH_CHANGED, { detail: { companyId: company.id } }));
  return next;
}
