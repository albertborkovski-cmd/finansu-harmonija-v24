/** Company-local reporting mappings. These links never create or change GL postings. */
export type StatementReport = 'Balance sheet' | 'Profit and loss';
export type StatementOperation = 'Debit' | 'Credit';
export type StatementAccount = { code: string; name: string; parentCode?: string };
export type StatementArticle = { id: string; code: string; name: string; report: StatementReport; group: string; operation: StatementOperation; inactive: boolean };
export type StatementMapping = { id: string; articleId: string; accountCode: string; accountName: string; operation: StatementOperation; createdAt: string; updatedAt: string; updatedBy: string };
export type StatementAudit = { id: string; at: string; by: string; action: string; articleId: string; articleCode: string; accountCode?: string; before?: string; after?: string };
export type StatementStore = { version: 1; companyId: string; template: string; revision: number; articles: StatementArticle[]; mappings: StatementMapping[]; audit: StatementAudit[] };
export type StatementCommand =
  | { type: 'save-article'; article: StatementArticle }
  | { type: 'remove-article'; articleId: string; linked?: boolean }
  | { type: 'assign'; links: { articleId: string; accountCode: string; operation: StatementOperation }[] }
  | { type: 'edit-mapping'; mappingId: string; articleId: string; operation: StatementOperation }
  | { type: 'unlink'; mappingIds: string[] };

export const STATEMENT_STORAGE_PREFIX = 'finansu-harmonija:v20:financial-statement-articles:';
export const statementStorageKey = (companyId: string, template: string) => `${STATEMENT_STORAGE_PREFIX}${encodeURIComponent(companyId)}:${encodeURIComponent(template)}`;
export const STATEMENT_REPORTS: StatementReport[] = ['Balance sheet', 'Profit and loss'];
export const STATEMENT_OPERATIONS: StatementOperation[] = ['Debit', 'Credit'];

// Starter reporting headings, editable per company. Not a statutory filing schema.
const STARTER_GROUPS: { report: StatementReport; group: string; operation: StatementOperation; rows: [string, string][] }[] = [
  { report: 'Balance sheet', group: 'Non-current assets · Intangible assets', operation: 'Debit', rows: [['A-1.1', 'Development costs'], ['A-1.2', 'Goodwill'], ['A-1.3', 'Software'], ['A-1.4', 'Licences, patents and similar rights'], ['A-1.5', 'Other intangible assets'], ['A-1.6', 'Advances for intangible assets']] },
  { report: 'Balance sheet', group: 'Non-current assets · Tangible assets', operation: 'Debit', rows: [['A-2.1', 'Land'], ['A-2.2', 'Buildings and structures'], ['A-2.3', 'Machinery and equipment'], ['A-2.4', 'Vehicles'], ['A-2.5', 'Other tangible assets'], ['A-2.6', 'Construction in progress']] },
  { report: 'Balance sheet', group: 'Non-current assets · Other', operation: 'Debit', rows: [['A-3', 'Financial assets'], ['A-4', 'Other non-current assets']] },
  { report: 'Balance sheet', group: 'Current assets', operation: 'Debit', rows: [['B-1', 'Inventories'], ['B-2', 'Advances paid'], ['B-3', 'Trade receivables'], ['B-4', 'Other receivables'], ['B-5', 'Short-term investments'], ['B-6', 'Cash and cash equivalents'], ['B-7', 'Prepayments and accrued income']] },
  { report: 'Balance sheet', group: 'Equity', operation: 'Credit', rows: [['C-1', 'Share capital'], ['C-2', 'Share premium'], ['C-3', 'Revaluation reserve'], ['C-4', 'Reserves'], ['C-5', 'Retained earnings']] },
  { report: 'Balance sheet', group: 'Grants and provisions', operation: 'Credit', rows: [['D-1', 'Grants and subsidies'], ['E-1', 'Provisions']] },
  { report: 'Balance sheet', group: 'Liabilities', operation: 'Credit', rows: [['F-1', 'Non-current liabilities'], ['F-2', 'Trade payables'], ['F-3', 'Advances received'], ['F-4', 'Tax liabilities'], ['F-5', 'Payroll liabilities'], ['F-6', 'Other current liabilities'], ['F-7', 'Accrued expenses and deferred income']] },
  { report: 'Profit and loss', group: 'Operating result', operation: 'Credit', rows: [['PL-1', 'Sales revenue'], ['PL-4', 'Other operating income']] },
  { report: 'Profit and loss', group: 'Operating result', operation: 'Debit', rows: [['PL-2', 'Cost of sales'], ['PL-3', 'Selling and administrative expenses'], ['PL-5', 'Other operating expenses']] },
  { report: 'Profit and loss', group: 'Financial result and tax', operation: 'Credit', rows: [['PL-6', 'Financial income']] },
  { report: 'Profit and loss', group: 'Financial result and tax', operation: 'Debit', rows: [['PL-7', 'Financial expenses'], ['PL-8', 'Income tax expense']] },
];

export function newStatementStore(companyId: string, template: string): StatementStore {
  return { version: 1, companyId, template, revision: 0, articles: STARTER_GROUPS.flatMap(group => group.rows.map(([code, name]) => ({ id: `statement-${code}`, code, name, report: group.report, group: group.group, operation: group.operation, inactive: false }))), mappings: [], audit: [] };
}

const obj = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const str = (value: unknown): value is string => typeof value === 'string';
const report = (value: unknown): value is StatementReport => STATEMENT_REPORTS.includes(value as StatementReport);
const operation = (value: unknown): value is StatementOperation => STATEMENT_OPERATIONS.includes(value as StatementOperation);
export function parseStatementStore(raw: string | null, companyId: string, template: string): StatementStore {
  if (raw === null) return newStatementStore(companyId, template);
  const value: unknown = JSON.parse(raw);
  if (!obj(value) || value.version !== 1 || value.companyId !== companyId || value.template !== template || !Number.isInteger(value.revision) || Number(value.revision) < 0
    || !Array.isArray(value.articles) || !Array.isArray(value.mappings) || !Array.isArray(value.audit)
    || !value.articles.every(a => obj(a) && ['id', 'code', 'name', 'group'].every(key => str(a[key]) && String(a[key]).trim()) && report(a.report) && operation(a.operation) && typeof a.inactive === 'boolean')
    || !value.mappings.every(m => obj(m) && ['id', 'articleId', 'accountCode', 'accountName', 'createdAt', 'updatedAt', 'updatedBy'].every(key => str(m[key])) && operation(m.operation))
    || !value.audit.every(a => obj(a) && ['id', 'at', 'by', 'action', 'articleId', 'articleCode'].every(key => str(a[key])))) throw new Error('Reporting mappings could not be read. Existing data has not been overwritten.');
  const store = value as StatementStore;
  if (new Set(store.articles.map(a => a.id)).size !== store.articles.length || new Set(store.articles.map(a => a.code.toLowerCase())).size !== store.articles.length || new Set(store.mappings.map(m => m.id)).size !== store.mappings.length || store.mappings.some(m => !m.accountCode || !store.articles.some(a => a.id === m.articleId))) throw new Error('Invalid or duplicate reporting mappings.');
  const keys = store.mappings.map(m => `${store.articles.find(a => a.id === m.articleId)!.report}:${m.accountCode}`);
  if (new Set(keys).size !== keys.length) throw new Error('A GL account is assigned more than once within the same report.');
  return store;
}

export function statementLeafAccounts(accounts: StatementAccount[]) {
  const parents = new Set(accounts.map(a => a.parentCode).filter(Boolean));
  return accounts.filter(a => a.code.trim() && !parents.has(a.code));
}
export const statementArticleUsed = (store: StatementStore, id: string) => store.mappings.some(m => m.articleId === id) || store.audit.some(a => a.articleId === id && a.accountCode);

/** Pure, atomic command: validate everything before returning a new store. */
export function changeStatementStore(store: StatementStore, command: StatementCommand, accounts: StatementAccount[], by: string, at: string, uuid: () => string): StatementStore {
  const next: StatementStore = structuredClone(store);
  const log = (action: string, article: StatementArticle, accountCode?: string, before?: string, after?: string) => next.audit.push({ id: uuid(), at, by, action, articleId: article.id, articleCode: article.code, accountCode, before, after });
  const articleById = (id: string) => { const a = next.articles.find(item => item.id === id); if (!a || a.inactive) throw new Error('Select an active financial statement item.'); return a; };
  const leaf = new Map(statementLeafAccounts(accounts).map(a => [a.code, a]));
  const ensureUnique = (article: StatementArticle, code: string, except?: string) => {
    if (next.mappings.some(m => m.id !== except && m.accountCode === code && next.articles.find(a => a.id === m.articleId)?.report === article.report)) throw new Error(`GL account ${code} already has a mapping in ${article.report}. Edit its existing mapping instead.`);
  };
  if (command.type === 'save-article') {
    const a = { ...command.article, code: command.article.code.trim(), name: command.article.name.trim(), group: command.article.group.trim() };
    if (!a.id || !a.code || !a.name || !a.group || a.code.length > 40 || a.name.length > 180 || a.group.length > 120 || !report(a.report) || !operation(a.operation)) throw new Error('Enter a code, name, report, group and operation.');
    const old = next.articles.find(item => item.id === a.id);
    if (next.articles.some(item => item.id !== a.id && item.code.toLowerCase() === a.code.toLowerCase())) throw new Error('This item code already exists.');
    if (old && old.report !== a.report && statementArticleUsed(next, a.id)) throw new Error('The report of a used item cannot be changed. Create a new item instead.');
    if (old) next.articles = next.articles.map(item => item.id === a.id ? a : item); else next.articles.push(a);
    log(old ? 'Item updated' : 'Item created', a, undefined, old ? JSON.stringify(old) : undefined, JSON.stringify(a));
  } else if (command.type === 'remove-article') {
    const a = articleById(command.articleId);
    if (command.linked || statementArticleUsed(next, a.id)) { a.inactive = true; log('Item deactivated', a); }
    else { next.articles = next.articles.filter(item => item.id !== a.id); log('Unused item deleted', a); }
  } else if (command.type === 'assign') {
    if (!command.links.length) throw new Error('Select at least one GL account.');
    for (const link of command.links) {
      const a = articleById(link.articleId), account = leaf.get(link.accountCode);
      if (!account) throw new Error(`GL account ${link.accountCode} is unavailable, inactive or a parent account. Refresh the company chart.`);
      if (!operation(link.operation)) throw new Error('Select Debit or Credit.');
      ensureUnique(a, account.code);
      next.mappings.push({ id: uuid(), articleId: a.id, accountCode: account.code, accountName: account.name, operation: link.operation, createdAt: at, updatedAt: at, updatedBy: by });
      log('Account linked', a, account.code, undefined, link.operation);
    }
  } else if (command.type === 'edit-mapping') {
    const mapping = next.mappings.find(m => m.id === command.mappingId);
    if (!mapping) throw new Error('The mapping no longer exists. Refresh the list.');
    const a = articleById(command.articleId);
    if (!leaf.has(mapping.accountCode) || !operation(command.operation)) throw new Error('Select an available GL account and valid operation.');
    ensureUnique(a, mapping.accountCode, mapping.id);
    const previousArticle = next.articles.find(item => item.id === mapping.articleId)!;
    log('Mapping changed', previousArticle, mapping.accountCode, `${previousArticle.code} / ${mapping.operation}`, `${a.code} / ${command.operation}`);
    if (previousArticle.id !== a.id) log('Account linked', a, mapping.accountCode, previousArticle.code, command.operation);
    Object.assign(mapping, { articleId: a.id, operation: command.operation, updatedAt: at, updatedBy: by });
  } else {
    if (!command.mappingIds.length) throw new Error('Select at least one mapping.');
    for (const id of new Set(command.mappingIds)) {
      const mapping = next.mappings.find(m => m.id === id);
      if (!mapping) throw new Error('A mapping has changed. Refresh the list.');
      const a = next.articles.find(item => item.id === mapping.articleId)!;
      log('Account unlinked', a, mapping.accountCode, mapping.operation);
      next.mappings = next.mappings.filter(m => m.id !== id);
    }
  }
  next.revision++;
  return next;
}

const normalize = (value: string) => value.toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
// Suggestions use recognizable account names, never account numbers alone. Manual review is required.
const SUGGESTION_RULES: [string, RegExp][] = [
  ['A-1.1', /pletros darb|development cost/], ['A-1.2', /prestiz|goodwill/], ['A-1.3', /programin.*irang|software/],
  ['A-1.4', /patent|licenc|licens|konces/], ['A-2.1', /\bzeme|\bland\b/], ['A-2.2', /pastat|statini|building/],
  ['A-2.4', /transporto priemon|automobil|vehicles?/], ['B-1', /atsarg|inventor/], ['B-3', /pirkeju skol|trade receivable/],
  ['B-6', /banko saskait|bank account|pinigai|cash/], ['C-1', /istatin.*kapital|share capital/],
  ['C-5', /nepaskirstyt.*peln|retained earning/], ['F-2', /skolos tiekej|saskaitos tiekej|trade payable/],
  ['F-3', /gauti avans|advances received/], ['PL-1', /pardavimo pajam|pardavimu pajam|sales revenue/],
  ['PL-2', /pardavimo savikain|pardavimu savikain|cost of sales/], ['PL-8', /pelno mokescio sanaud|income tax expense/],
];
export type StatementSuggestion = { accountCode: string; accountName: string; articleId: string; operation: StatementOperation; reason: string };
export function suggestStatementMappings(store: StatementStore, accounts: StatementAccount[], selectedReport: StatementReport): StatementSuggestion[] {
  return statementLeafAccounts(accounts).flatMap(account => {
    if (store.mappings.some(m => m.accountCode === account.code && store.articles.find(a => a.id === m.articleId)?.report === selectedReport)) return [];
    const name = normalize(account.name);
    const matches = SUGGESTION_RULES.filter(([, rule]) => rule.test(name)).flatMap(([code]) => store.articles.filter(a => a.code === code && a.report === selectedReport && !a.inactive));
    if (matches.length !== 1) return [];
    const a = matches[0];
    return [{ accountCode: account.code, accountName: account.name, articleId: a.id, operation: a.operation, reason: `Account name matches ${a.name}. Review before applying.` }];
  });
}

export function statementMappingsCsv(store: StatementStore, presentation?: { label: (value: string) => string; article: (article: StatementArticle, field: 'name' | 'group') => string }) {
  const label = presentation?.label ?? ((value: string) => value);
  const articleText = presentation?.article ?? ((article: StatementArticle, field: 'name' | 'group') => article[field]);
  const cell = (value: unknown) => `"${String(value ?? '').replace(/^[\s]*[=+@-]/, "'$&").replace(/"/g, '""')}"`;
  const rows = store.mappings.map(m => { const a = store.articles.find(item => item.id === m.articleId)!; return [m.accountCode, m.accountName, label(m.operation), label(a.report), a.code, articleText(a, 'group'), articleText(a, 'name'), label(a.inactive ? 'Inactive' : 'Active'), m.updatedBy, m.updatedAt]; });
  return '\uFEFF' + [['GL account', 'Account name', 'Operation', 'Report', 'Item code', 'Group', 'Financial statement item', 'Item status', 'Updated by', 'Last update'].map(value => label(value)), ...rows].map(row => row.map(cell).join(',')).join('\r\n');
}
