import type { Company } from './supabase';

export type CounterpartyDraft = { accountingCode: string; companyCode: string; vatCode: string; name: string; ibans: string };
export const COUNTERPARTY_FIELDS = ['accountingCode', 'companyCode', 'vatCode', 'name', 'ibans'] as const;
export const COUNTERPARTY_LABELS = ['Accounting system code', 'Company code', 'VAT code', 'Name', 'IBAN'] as const;
export const emptyCounterpartyDraft = (): CounterpartyDraft => ({ accountingCode: '', companyCode: '', vatCode: '', name: '', ibans: '' });
export const splitCounterpartyIbans = (value: string) => [...new Set(value.split(/[,;]/).map(iban => iban.replace(/\s/g, '').toUpperCase()).filter(Boolean))];
const key = (value: string) => value.trim().toLocaleLowerCase();

/** Excel clipboard data uses TAB-separated strings; do not coerce identifiers to numbers. */
export function parseCounterpartyPaste(text: string): CounterpartyDraft[] {
  if (text.length > 1_000_000) throw new Error('Paste up to 1,000 companies at a time.');
  const source = text.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const rows: string[][] = [];
  let row: string[] = [], cell = '', quoted = false, closed = false;
  const finishCell = () => { row.push(cell.trim()); cell = ''; closed = false; };
  const finishRow = () => { finishCell(); if (row.some(Boolean)) rows.push(row); row = []; if (rows.length > 1001) throw new Error('Paste up to 1,000 companies at a time.'); };
  for (let index = 0; index < source.length; index++) {
    const char = source[index];
    if (quoted) {
      if (char === '"' && source[index + 1] === '"') { cell += '"'; index++; }
      else if (char === '"') { quoted = false; closed = true; }
      else cell += char;
    } else if (char === '\t') finishCell();
    else if (char === '\n') finishRow();
    else if (closed) throw new Error('Check the pasted cells: quotation marks are incomplete.');
    else if (char === '"' && !cell) quoted = true;
    else cell += char;
  }
  if (quoted) throw new Error('Check the pasted cells: quotation marks are incomplete.');
  finishRow();
  const normalize = (value: string) => key(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (rows[0]?.length === 5 && ['accounting system code', 'kodas apskaitos programoje'].includes(normalize(rows[0][0]))
    && ['name', 'pavadinimas'].includes(normalize(rows[0][3]))) rows.shift();
  if (rows.length > 1000) throw new Error('Paste up to 1,000 companies at a time.');
  if (rows.some(values => values.length !== 5)) throw new Error('Use five TAB-separated columns: accounting system code, company code, VAT code, name, IBAN.');
  return rows.map(([accountingCode, companyCode, vatCode, name, ibans]) => ({ accountingCode, companyCode, vatCode, name, ibans }));
}

export function counterpartyDraftErrors(rows: CounterpartyDraft[], existing: readonly Company[]): string[][] {
  const fields = ['accountingCode', 'companyCode', 'vatCode'] as const;
  const stored = ['accounting_system_code', 'company_code', 'vat_code'] as const;
  return rows.map(row => {
    const errors: string[] = [];
    if (!row.name.trim()) errors.push('Name is required.');
    if (COUNTERPARTY_FIELDS.some(field => row[field].length > (field === 'ibans' ? 2000 : 500))) errors.push('One of the values is too long.');
    if (COUNTERPARTY_FIELDS.some(field => /[\u0000-\u001F]/.test(row[field]))) errors.push('Remove line breaks and control characters from company fields.');
    if (splitCounterpartyIbans(row.ibans).some(iban => !/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban))) errors.push('Check the IBAN format. Separate accounts with commas or semicolons.');
    if (fields.some((field, index) => row[field].trim() && existing.some(item => key(String(item[stored[index]] || '')) === key(row[field])))) errors.push('A company with this code already exists in this organization.');
    if (fields.some(field => row[field].trim() && rows.filter(item => key(item[field]) === key(row[field])).length > 1)) errors.push('A company code is repeated in the pasted rows.');
    return errors;
  });
}

export function counterpartyIbans(company: Company): string[] {
  if (!company.counterparty_bank_accounts) return [];
  try {
    const rows: unknown = JSON.parse(company.counterparty_bank_accounts);
    if (!Array.isArray(rows)) return [];
    return rows.flatMap(row => typeof row === 'string' ? [row] : row && typeof row.iban === 'string' ? [row.iban] : []);
  } catch { return splitCounterpartyIbans(company.counterparty_bank_accounts); }
}

export function prepareCompanyCounterparties(rows: CounterpartyDraft[], existing: Company[], actor: string, at: string, createId: () => string): Company[] {
  if (!rows.length || rows.length > 1000 || counterpartyDraftErrors(rows, existing).some(errors => errors.length)) throw new Error('Correct the highlighted rows before saving.');
  return rows.map(row => ({ id: createId(), accounting_system_code: row.accountingCode.trim(), company_code: row.companyCode.trim(), vat_code: row.vatCode.trim(), name: row.name.trim(),
    company_status: 'Active', client_since: new Date(at).getFullYear(), action_required: 0,
    counterparty_bank_accounts: JSON.stringify(splitCounterpartyIbans(row.ibans).map((iban, index) => ({ id: createId(), iban, bank: '', bankCode: '', swift: '', primary: index === 0 }))),
    counterparty_created_by: actor, counterparty_created_at: at,
    counterparty_activity_log: JSON.stringify([{ date: at, user: actor, action: 'Counterparty created' }]),
  }));
}
