import { parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import type { MigrationSetup } from './organizationMigration';

export type ProfileSharePoint = {
  sharepoint_client_id: string; sharepoint_tenant_id: string; sharepoint_urls: string;
  sharepoint_sync_schedule: string; sharepoint_sync_time: string;
};
export type ProfileSetup = { version: 1; migration: MigrationSetup; sharepoint: ProfileSharePoint; updatedAt: string };
type StorageLike = Pick<Storage, 'getItem' | 'setItem'>;
export const profileSetupKey = (email: string) => `finansu-harmonija-v24:profile-setup:v1:${email.trim().toLowerCase()}`;
const schedules = ['Every 5 minutes', 'Every hour', 'Every day', 'Synchronization disabled', 'Manual synchronization'];
export function emptyProfileSetup(): ProfileSetup {
  return { version: 1, updatedAt: '', migration: { source: '', portfolio: '', asOf: '', status: 'Not started', results: [] }, sharepoint: {
    sharepoint_client_id: '', sharepoint_tenant_id: '', sharepoint_urls: '', sharepoint_sync_schedule: 'Manual synchronization', sharepoint_sync_time: '09:00',
  } };
}
function ownProfile(storage: Pick<Storage, 'getItem'>, email: string) {
  const session = parseSession(storage.getItem(AUTH_SESSION_KEY));
  if (!email.trim() || session?.email.trim().toLowerCase() !== email.trim().toLowerCase() || session.roleNames.includes('Inactive')) throw new Error('Only your own profile settings can be changed.');
}
export function readProfileSetup(storage: Pick<Storage, 'getItem'>, email: string): ProfileSetup {
  ownProfile(storage, email);
  const raw = storage.getItem(profileSetupKey(email));
  if (!raw) return emptyProfileSetup();
  try {
    const value = JSON.parse(raw) as ProfileSetup;
    if (value.version !== 1 || !value.migration || !Array.isArray(value.migration.results) || !value.sharepoint) throw Error();
    return value;
  } catch { throw new Error('Profile setup could not be loaded. Saved data has not been changed.'); }
}
/** Profile configuration only: no company updates, company audit or connector calls. */
export function saveProfileSetup(storage: StorageLike, email: string, patch: { migration?: MigrationSetup; sharepoint?: ProfileSharePoint }) {
  ownProfile(storage, email);
  const current = readProfileSetup(storage, email);
  if (patch.migration) {
    const value = patch.migration;
    if (!['Rivilė', 'Other ERP', 'File'].includes(value.source) || !value.portfolio.trim() || !/^\d{4}-\d{2}-\d{2}$/.test(value.asOf) || !Number.isFinite(Date.parse(value.asOf))) throw new Error('Complete the source system, database and migration date.');
    current.migration = structuredClone(value);
  }
  if (patch.sharepoint) {
    const input = patch.sharepoint;
    if (!schedules.includes(input.sharepoint_sync_schedule) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(input.sharepoint_sync_time)) throw new Error('Select a valid synchronization schedule and time.');
    for (const url of input.sharepoint_urls.split(/\r?\n/).map(value => value.trim()).filter(Boolean)) {
      try { const parsed = new URL(url); if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw Error(); }
      catch { throw new Error('Enter HTTPS SharePoint URLs without embedded credentials.'); }
    }
    // Explicit allowlist: never persist client secrets or tokens in browser storage.
    current.sharepoint = {
      sharepoint_client_id: input.sharepoint_client_id.trim(), sharepoint_tenant_id: input.sharepoint_tenant_id.trim(),
      sharepoint_urls: input.sharepoint_urls.trim(), sharepoint_sync_schedule: input.sharepoint_sync_schedule, sharepoint_sync_time: input.sharepoint_sync_time,
    };
  }
  current.updatedAt = new Date().toISOString();
  storage.setItem(profileSetupKey(email), JSON.stringify(current));
  return current;
}
