import { testDocumentStornoBlocker, validAccountingDate, type StornoDocument } from './documentStorno';

export type DocumentRowAction = { kind: 'delete' | 'storno' | 'correction'; label: string; disabledReason: string };
export type DocumentManagementActionKind = DocumentRowAction['kind'] | 'cancel-approval';
export type DocumentActionRights = { delete: boolean; create: boolean; storno: boolean };
export type DocumentCorrectionCommand = { expectedSnapshot: string; number: string; date: string; reason: string };
export const DOCUMENT_RECORDS_KEY = 'finansu-harmonija-v4:data:documents';
const text = (value: unknown) => String(value ?? '').trim();
const normalized = (value: unknown) => text(value).toLowerCase();
const approved = new Set(['approved', 'confirmed', 'accepted', 'completed', 'processed', 'transferred', 'exported', 'posted', 'paid']);

export function documentActionSnapshot(document: StornoDocument) { return JSON.stringify(document); }
export function documentRestoreBlocker(document: Pick<StornoDocument, 'company_id'> & { document_deletion?: unknown }, allowed: boolean) {
  if (!document.company_id) return 'Assign an organization before using document actions.';
  if (!allowed) return 'You need Delete access to this company’s documents.';
  if (!document.document_deletion) return 'This document is not deleted. Refresh the list.';
  return '';
}
export function documentHasActionHistory(document: StornoDocument) {
  return Boolean(document.correction_of_document_id || document.corrected_by_document_id)
    || ['digitization_issues', 'accounting_test_deliveries', 'inline_edit_history', 'detail_edit_history', 'correction_history']
      .some(key => Array.isArray(document[key]) && document[key].length > 0);
}
export function documentIsInvoice(document: StornoDocument) {
  return /^(invoices?|sales?[\s_-]*invoices?|purchase[\s_-]*invoices?|credit[\s_-]*(note|invoice)|debit[\s_-]*(note|invoice))$/i.test(text(document.document_type));
}
export function documentCorrectionKind(document: StornoDocument): 'Credit note' | 'Debit note' {
  return /credit/i.test(text(document.document_subtype) + ' ' + text(document.document_type)) || documentNumericValue(document.total_amount) < 0 ? 'Debit note' : 'Credit note';
}
export function documentNumericValue(value: unknown) {
  const numeric = text(value).replace(/\s/g, '').replace(/[A-Z]{3}$/i, '');
  const normalized = numeric.includes('.') ? numeric.replace(/,/g, '') : numeric.replace(',', '.');
  if (!/^-?\d+(?:\.\d+)?$/.test(normalized)) return NaN;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : NaN;
}
/** Opening Delete is not deletion: the confirmation rechecks permissions and
 * approval state before enabling its Delete button. */
export function canOpenDocumentRowAction(action: DocumentRowAction) {
  return action.kind === 'delete' || !action.disabledReason;
}
export function documentRowAction(document: StornoDocument, rights: DocumentActionRights, _linked = false): DocumentRowAction {
  const states = [normalized(document.status), normalized(document.accounting_note_status)];
  const inactive = document.inactive || document.active === false || document.is_active === false || states.includes('inactive');
  const confirmed = states.some(state => approved.has(state)) || Boolean(document.accounting_posting);
  const common = inactive ? 'Inactive documents cannot be changed.' : states.includes('processing') ? 'Wait until document processing is complete.' : '';
  // Invoice corrections take precedence over reversing their associated posting.
  if (confirmed && documentIsInvoice(document)) {
    const total = documentNumericValue(document.total_amount);
    return { kind: 'correction', label: `Create ${documentCorrectionKind(document).toLowerCase()}`, disabledReason: common
      || (!rights.create ? 'You need View, Edit and Create access to this company’s documents.' : '')
      || (document.accounting_storno || document.document_storno ? 'The original operation has already been reversed.' : '')
      || (!Number.isFinite(total) || total === 0 ? 'A non-zero invoice amount is required for a correction.' : '') };
  }
  if (confirmed || document.accounting_storno || document.document_storno) return { kind: 'storno', label: 'Storno', disabledReason: common || testDocumentStornoBlocker(document, rights.storno) };
  // Every unconfirmed document can be removed from the register. The delete
  // command retains its record and history, so references are not a blocker.
  return { kind: 'delete', label: 'Delete', disabledReason:
    document.document_deletion ? 'This document has already been deleted.'
      : !rights.delete ? 'You need Delete access to this company’s documents.' : '' };
}

/** Create a draft correction only. The source document and its GL posting are never mutated. */
export function prepareDocumentCorrection(source: StornoDocument, command: DocumentCorrectionCommand, context: { allowed: boolean; today: string; now: string; actor: string; id: string }) {
  const action = documentRowAction(source, { delete: false, storno: false, create: context.allowed });
  if (action.kind !== 'correction') throw new Error('Only confirmed invoices can have a corrective document.');
  if (action.disabledReason) throw new Error(action.disabledReason);
  if (command.expectedSnapshot !== documentActionSnapshot(source)) throw new Error('The source document changed. Reopen the action before continuing.');
  if (!command.number.trim() || command.number.trim().length > 100) throw new Error('Enter a document number (up to 100 characters).');
  if (!command.reason.trim() || command.reason.trim().length > 2000) throw new Error('Enter a correction reason (up to 2000 characters).');
  if (!validAccountingDate(command.date) || command.date > context.today || (validAccountingDate(text(source.document_date)) && command.date < text(source.document_date))) throw new Error('Select a valid correction date, not before the original or in the future.');
  const negate = (value: unknown) => {
    if (!text(value)) return '';
    const amount = documentNumericValue(value);
    if (!Number.isFinite(amount)) throw new Error('The original amounts are invalid. Review the invoice before creating a correction.');
    return (-amount).toFixed(2);
  };
  const copyLines = (value: unknown, prefix: string) => {
    if (value == null) return [];
    if (!Array.isArray(value)) throw new Error('The original document lines are unavailable.');
    return value.map((line, index) => {
      if (!line || typeof line !== 'object' || Array.isArray(line)) throw new Error('The original document lines are invalid.');
      const next = { ...line, id: `${context.id}:${prefix}:${index + 1}`, systemId: '', originalLineId: line.id };
      for (const key of ['qty', 'subtotal', 'discount', 'vat', 'total']) if (text(line[key])) {
        const negative = negate(line[key]);
        next[key] = key === 'qty' ? String(-documentNumericValue(line[key])) : negative;
      }
      return next;
    });
  };
  const preserved = ['company_id', 'client_counterparty', 'counterparty_id', 'counterparty_code', 'document_type', 'type', 'currency', 'expense_account', 'vat_classifier', 'vat_percent', 'department_code', 'object_project', 'cost_center', 'product_group', 'accountable_responsible', 'accountable_responsible_id'];
  const kind = documentCorrectionKind(source);
  return {
    ...Object.fromEntries(preserved.filter(key => key in source).map(key => [key, source[key]])),
    id: context.id, number: command.number.trim(), status: 'Draft', source: 'Manual', document_subtype: kind,
    document_date: command.date, operation_date: command.date, receive_date: command.date,
    due_end_date: '', order_no: '', series: '', file_case: '', image_url: null,
    total_amount: negate(source.total_amount), amount_without_vat: negate(source.amount_without_vat), vat: negate(source.vat),
    document_purpose: `${kind} for ${text(source.number) || source.id}`, notes: command.reason.trim(),
    line_items: copyLines(source.line_items, 'item'), summary_line_items: copyLines(source.summary_line_items, 'allocation'),
    correction_of_document_id: source.id, correction_kind: kind, correction_reason: command.reason.trim(),
    correction_history: [{ id: `${context.id}:created`, at: context.now, actor: context.actor, action: `${kind} draft created`,
      details: `Original: ${text(source.number) || source.id}. ${command.reason.trim()}`, originalDocumentId: source.id }],
    created_at: context.now, created_by: context.actor,
  };
}
