import { canEditMenu, canViewMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY, getCurrentUserIdentity } from './currentUser';
import { canAccessAssignedOrganization } from './linkedSettingsData';
import { isRecordLinked } from './recordLifecycle';
import { supabase, type Company } from './supabase';
import { loadCompanyGeneralLedgerAccountHierarchy, loadGeneralLedgerTemplates } from '../components/GeneralLedgerView';
import { changeStatementStore, parseStatementStore, statementArticleUsed, statementStorageKey, type StatementCommand, type StatementStore } from './financialStatementArticles';

export const STATEMENT_CHANGED = 'finansu-harmonija:financial-statement-items-changed';
export function statementPermissions(company: Company) {
  const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
  const access = !!session && canAccessAssignedOrganization(company, session);
  return { view: !!session && access && canViewMenu(session, 'documents'), edit: !!session && access && canViewMenu(session, 'documents') && canEditMenu(session, 'documents') };
}
export function loadStatementStore(company: Company): StatementStore {
  if (!statementPermissions(company).view) throw new Error('You do not have access to this company’s financial statement items.');
  const template = company.general_ledger?.trim() || '';
  return parseStatementStore(localStorage.getItem(statementStorageKey(company.id, template)), company.id, template);
}
export function loadStatementAccounts(company: Company) {
  if (!company.general_ledger?.trim() || !statementPermissions(company).view) return [];
  if (!loadGeneralLedgerTemplates().some(template => template.name === company.general_ledger)) throw new Error('The assigned chart is unavailable. Check Manage company → Accounting setup.');
  return loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger);
}
export function statementArticleLinked(store: StatementStore, articleId: string) {
  const article = store.articles.find(item => item.id === articleId);
  return !!article && (statementArticleUsed(store, articleId) || isRecordLinked({ ...article, companyId: store.companyId }, statementStorageKey(store.companyId, store.template)));
}
/** Fresh company, permission, chart and revision checks; never overwrite a concurrent edit. */
export async function updateStatementStore(company: Company, revision: number, command: StatementCommand) {
  if (!statementPermissions(company).edit) throw new Error('You do not have permission to edit this company’s financial statement items.');
  const result = await supabase.from('companies').select('*').eq('id', company.id);
  if (result.error) throw new Error('Company settings could not be verified.');
  const fresh = (result.data as unknown as Company[] | null)?.find(item => item.id === company.id);
  if (!fresh || !statementPermissions(fresh).edit) throw new Error('Company access is no longer available.');
  if ((fresh.general_ledger?.trim() || '') !== (company.general_ledger?.trim() || '')) throw new Error('The company chart has changed. Reopen this page before editing mappings.');
  const previous = loadStatementStore(fresh);
  if (previous.revision !== revision) throw new Error('Mappings changed in another window. Refresh and try again.');
  const key = statementStorageKey(fresh.id, previous.template);
  if (command.type === 'remove-article') {
    command = { ...command, linked: statementArticleLinked(previous, command.articleId) };
  }
  const user = getCurrentUserIdentity();
  const next = changeStatementStore(previous, command, loadStatementAccounts(fresh), user.email || user.fullName, new Date().toISOString(), () => crypto.randomUUID());
  localStorage.setItem(key, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent(STATEMENT_CHANGED, { detail: { companyId: fresh.id } }));
  return next;
}
