import type { DbDocument } from './supabase';
import { uploadedStatus, uploadedStatusGroup, type UploadedDocumentsGroup } from './uploadedDocuments';
import { isDocumentArchived } from './documentArchive';
import { isInactiveRecord } from './recordLifecycle';

export const UPLOADED_LIFECYCLE_FILTERS = [
  { value: 'digitizing', label: 'Digitizing' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'not-exported', label: 'Not exported yet' },
  { value: 'exported', label: 'Exported' },
  { value: 'deleted', label: 'Deleted' },
] as const;
export type UploadedLifecycleFilter = typeof UPLOADED_LIFECYCLE_FILTERS[number]['value'];

/** Dashboard links use the same visible filter as the uploaded-document toolbar. */
export function uploadedLifecycleFiltersForGroup(group: UploadedDocumentsGroup): UploadedLifecycleFilter[] {
  if (group === 'Processing') return ['digitizing'];
  if (group === 'Processed') return ['not-exported'];
  if (group === 'Needs attention') return ['rejected'];
  return [];
}

export function uploadedLifecycleState(document: DbDocument): UploadedLifecycleFilter | null {
  const raw = String(document.status || '').toLowerCase();
  if (document.document_deletion || isInactiveRecord(document)
    || ['deleted', 'inactive', 'deactivated'].includes(raw)) return 'deleted';
  if (isDocumentArchived(document as unknown as Record<string, unknown>)) return 'exported';
  const status = uploadedStatus(document);
  if (uploadedStatusGroup(status) === 'Needs attention') return 'rejected';
  if (status === 'Processing') return 'digitizing';
  if (status === 'Processed' || raw === 'uploaded') return 'not-exported';
  return null;
}

export function matchesUploadedLifecycle(document: DbDocument, selected: readonly UploadedLifecycleFilter[]) {
  return selected.length === 0 || selected.includes(uploadedLifecycleState(document)!);
}
