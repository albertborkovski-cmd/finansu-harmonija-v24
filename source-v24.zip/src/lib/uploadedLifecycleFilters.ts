import type { DbDocument } from './supabase';
import { uploadedStatus, uploadedStatusGroup, type UploadedDocumentsGroup } from './uploadedDocuments';
import { isDocumentArchived } from './documentArchive';
import { isInactiveRecord } from './recordLifecycle';

export const UPLOADED_LIFECYCLE_FILTERS = [
  { value: 'digitizing', label: 'Digitizing' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'not-exported', label: 'Not exported yet' },
  { value: 'exported', label: 'Exported' },
  { value: 'deleted', label: 'Deleted' },
  { value: 'organization-not-found', label: 'Organization not found' },
] as const;
export type UploadedLifecycleFilter = typeof UPLOADED_LIFECYCLE_FILTERS[number]['value'];

/** Assignment is the source of truth, even while OCR reports another status. */
export function hasUnidentifiedOrganization(document: DbDocument): boolean {
  return !String(document.company_id || '').trim();
}

/** The missing-organization shortcut is exclusive so one click never also
 * includes unrelated rows from a previously selected lifecycle category. */
export function toggleUploadedLifecycleFilter(
  selected: readonly UploadedLifecycleFilter[], next: UploadedLifecycleFilter,
): UploadedLifecycleFilter[] {
  if (selected.includes(next)) return selected.filter(value => value !== next);
  if (next === 'organization-not-found') return [next];
  return [...selected.filter(value => value !== 'organization-not-found'), next];
}

/** Normal entry starts with work in progress and rejected uploads. Explicit
 * Dashboard links still select their requested lifecycle category. */
export function uploadedLifecycleFiltersForGroup(group: UploadedDocumentsGroup): UploadedLifecycleFilter[] {
  if (group === 'Processing') return ['digitizing'];
  if (group === 'Processed') return ['not-exported'];
  if (group === 'Needs attention') return ['rejected'];
  return ['digitizing', 'rejected'];
}

export function uploadedLifecycleState(document: DbDocument): UploadedLifecycleFilter | null {
  const raw = String(document.status || '').toLowerCase();
  if (document.document_deletion || isInactiveRecord(document)
    || ['deleted', 'inactive', 'deactivated'].includes(raw)) return 'deleted';
  if (isDocumentArchived(document as unknown as Record<string, unknown>)) return 'exported';
  const status = uploadedStatus(document);
  if (uploadedStatusGroup(status) === 'Needs attention') return 'rejected';
  if (status === 'Processing') return 'digitizing';
  if (status === 'Processed' || raw === 'uploaded') return 'not-exported';
  return null;
}

export function matchesUploadedLifecycle(document: DbDocument, selected: readonly UploadedLifecycleFilter[]) {
  if (selected.includes('organization-not-found')) return hasUnidentifiedOrganization(document);
  return selected.length === 0 || selected.includes(uploadedLifecycleState(document)!);
}
