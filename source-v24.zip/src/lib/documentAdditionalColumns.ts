export const ADDITIONAL_DOCUMENT_COLUMNS = [
  { key: 'departmentCode', label: 'Department', header: 'department_code', line: 'department', legacy: ['department_codes'] },
  { key: 'objectProject', label: 'Object', header: 'object_project', line: 'object', legacy: ['objects', 'projects'] },
  { key: 'series', label: 'Series', header: 'series', line: null, legacy: ['document_series'] },
  { key: 'costCenter', label: 'Center', header: 'cost_center', line: 'center', legacy: ['cost_centers'] },
  { key: 'accountableResponsible', label: 'Accountable person', header: 'accountable_responsible', line: null, legacy: [] },
  { key: 'productGroup', label: 'Product group', header: 'product_group', line: 'productGroup', legacy: ['product_groups'] },
  { key: 'note', label: 'Note', header: 'notes', line: null, legacy: [] },
  { key: 'expenseAccount', label: 'Expense code', header: 'expense_account', line: 'expense', legacy: [] },
  { key: 'vatClassifier', label: 'VAT classifier', header: 'vat_classifier', line: 'vatClass', legacy: [] },
] as const;
export type AdditionalDocumentColumn = typeof ADDITIONAL_DOCUMENT_COLUMNS[number]['key'];
export type AdditionalColumnRule = { required: boolean; automatic: boolean; defaultValue: string; defaultLabel: string };
export type AdditionalColumnRules = Record<AdditionalDocumentColumn, AdditionalColumnRule>;
type CompanySettings = { document_export_settings?: string; [key: string]: unknown };
const filled = (value: unknown) => !['', '—', '-'].includes(String(value ?? '').trim());
const legacyRequired = (raw: unknown) => {
  if (typeof raw !== 'string' || !raw.trim()) return false;
  try { const value = JSON.parse(raw); return Array.isArray(value?.items) && value.enabled === true; }
  catch { return !/^[\[{]/.test(raw.trim()) && raw.split(',').some(value => value.trim()); }
};

/** Migrate old company flags only before the new per-column configuration exists. */
export function normalizeAdditionalColumnRules(raw: unknown, company?: Record<string, unknown>): AdditionalColumnRules {
  const configured = raw != null && typeof raw === 'object' && !Array.isArray(raw);
  return Object.fromEntries(ADDITIONAL_DOCUMENT_COLUMNS.map(column => {
    const saved = configured ? (raw as Record<string, Partial<AdditionalColumnRule>>)[column.key] : undefined;
    return [column.key, {
      required: configured ? saved?.required === true : column.legacy.some(key => legacyRequired(company?.[key])),
      automatic: saved?.automatic === true,
      defaultValue: typeof saved?.defaultValue === 'string' ? saved.defaultValue : '',
      defaultLabel: typeof saved?.defaultLabel === 'string' ? saved.defaultLabel : '',
    }];
  })) as AdditionalColumnRules;
}

export function organizationAdditionalColumnRules(company?: CompanySettings): AdditionalColumnRules {
  let settings: Record<string, unknown> = {};
  try { settings = JSON.parse(company?.document_export_settings || '{}') || {}; } catch { /* Preserve legacy required indicators when settings cannot be read. */ }
  return normalizeAdditionalColumnRules(settings.additionalColumns, company);
}

/** Defaults fill missing values only; no OCR amount, workflow status or manual override is changed. */
export function applyAdditionalColumnDefaults<T extends Record<string, unknown>>(document: T, company: CompanySettings, stage: 'digitization' | 'export'): T {
  if (document.entry_method === 'manual') return document;
  const settings = JSON.parse(company.document_export_settings || '{}');
  if (!settings || (settings.additionalColumnsAt || 'digitization') !== stage) return document;
  const rules = normalizeAdditionalColumnRules(settings.additionalColumns, company);
  const next: Record<string, unknown> = { ...document };
  for (const column of ADDITIONAL_DOCUMENT_COLUMNS) {
    // Explicit assignments (including an intentional empty value) outrank defaults.
    if (document.ocr_field_overrides && typeof document.ocr_field_overrides === 'object'
      && column.header in document.ocr_field_overrides) continue;
    const rule = rules[column.key];
    if (!rule.automatic || !filled(rule.defaultValue)) continue;
    const value = rule.defaultValue.trim();
    if (column.key === 'accountableResponsible') {
      if (!filled(next.accountable_responsible) && !filled(next.accountable_responsible_id)) {
        next.accountable_responsible_id = value;
        next.accountable_responsible = rule.defaultLabel || value;
      }
      continue;
    }
    if (!filled(next[column.header])) next[column.header] = value;
    if (column.line) for (const key of ['summary_line_items', 'line_items']) {
      if (Array.isArray(next[key])) next[key] = (next[key] as unknown[]).map(row => {
        if (!row || typeof row !== 'object' || Array.isArray(row)) return row;
        const item = row as Record<string, unknown>;
        return filled(item[column.line!]) ? row : { ...item, [column.line!]: value };
      });
    }
  }
  return next as T;
}
