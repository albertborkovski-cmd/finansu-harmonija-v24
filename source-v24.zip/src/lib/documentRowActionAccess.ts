import { canEditCompanyDocuments, canViewCompanyDocuments } from './documentEditAccess';
import { isSystemAdministratorRole, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { isInactiveRecord } from './recordLifecycle';
import { canStornoDocument } from './documentStornoAccess';
import type { Company } from './supabase';
import type { DocumentActionRights } from './documentRowActions';
import { loadLinkedDirectoryUsers } from './linkedSettingsData';

function resolveDocumentActionRights(company: Company | undefined, requireEdit: boolean): DocumentActionRights {
  const denied = { delete: false, create: false, storno: false };
  try {
    if (!company || !(requireEdit ? canEditCompanyDocuments(company) : canViewCompanyDocuments(company))) return denied;
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    if (!session) return denied;
    if (session.roleNames.some(isSystemAdministratorRole)) return { delete: true, create: true, storno: true };
    const internal = loadLinkedDirectoryUsers('Internal users').some(user => user.email?.trim().toLowerCase() === session.email.trim().toLowerCase());
    const external = loadLinkedDirectoryUsers('External users').some(user => user.email?.trim().toLowerCase() === session.email.trim().toLowerCase());
    if (internal === external) return denied;
    const audience = internal ? 'internal' : 'external';
    const raw = JSON.parse(window.localStorage.getItem(`finansu-harmonija:v7:settings:${audience}:roles`) || '[]');
    if (!Array.isArray(raw)) return denied;
    const matching = raw.filter(role => session.roleNames.includes(role.name));
    const active = matching.filter(role => !isInactiveRecord(role));
    if (!matching.length && audience === 'internal' && session.roleNames.includes('Meso accountant')) return { delete: true, create: true, storno: canStornoDocument(company) };
    const actions = new Set(active.flatMap(role => {
      if (role.actionPermissions) {
        const settings = JSON.parse(role.actionPermissions);
        return Array.isArray(settings.documents) ? settings.documents : [];
      }
      return String(role.permissions ?? '').split(',').map(value => value.trim());
    }));
    const view = actions.has('VIEW') || actions.has('READ');
    return { delete: view && actions.has('DELETE'), create: view && actions.has('CREATE'), storno: view && actions.has('CREATE') && canStornoDocument(company) };
  } catch { return denied; }
}

export const documentActionRights = (company: Company | undefined) => resolveDocumentActionRights(company, true);
/** Creating a new draft needs View + Create, not Edit permission on existing records. */
export const canCreateCompanyDocument = (company: Company | undefined) => resolveDocumentActionRights(company, false).create;
