import type { Company, DbDocument } from './supabase';
import { primaryDocumentDeliveryDestination, selectedDocumentRecords } from './documentExport';
import { documentTestDeliverySnapshot, type DocumentTestDelivery, type TestDeliveryCommand } from './documentTestDelivery';

/** Resolve Primary export format against fresh company and document data.
 * Missing or stale configuration is an inline error, never another dialog. */
export function prepareDirectDocumentDelivery(
  documents: DbDocument[], companies: Company[], ids: string[], companyId: string,
  expectedDestinationId: string | undefined, requestId: string,
): TestDeliveryCommand {
  const selected = selectedDocumentRecords(documents, ids, companyId);
  const companyIds = new Set(selected.map(record => record.company_id));
  if (companyIds.size !== 1) throw new Error('Select documents from one company for each transfer.');
  const company = companies.find(item => companyIds.has(item.id));
  if (!company) throw new Error('The selected company is no longer available. Refresh the list.');
  const destination = primaryDocumentDeliveryDestination(company);
  if (!destination) throw new Error('Set an active Primary export format in Manage company → Documents & digitization setup.');
  if (expectedDestinationId && destination?.value !== expectedDestinationId) {
    throw new Error('Primary export format has changed. The button is updated; click it again to use the new setting.');
  }
  return {
    requestId, companyId: company.id, ids: selected.map(record => record.id),
    destinationId: destination.value, destinationSource: 'primary-export-format', scenario: 'accepted',
    snapshots: Object.fromEntries(selected.map(record => [record.id, documentTestDeliverySnapshot(record as unknown as Record<string, unknown>)])),
  };
}

export function directDocumentDeliveryNotice(
  records: { number: string; testDeliveries?: DocumentTestDelivery[] }[], requestId: string,
) {
  const results = records.flatMap(record => (record.testDeliveries ?? [])
    .filter(receipt => receipt.requestId === requestId)
    .map(receipt => ({ ...receipt, documentNumber: record.number })));
  const accepted = results.filter(receipt => receipt.outcome === 'Accepted').length;
  const failed = results.filter(receipt => receipt.outcome !== 'Accepted');
  const details = failed.slice(0, 3).map(receipt => `${receipt.documentNumber}: ${receipt.message}`).join(' ');
  if (!results.length) return { error: true, message: 'No delivery result received. Check document history before trying again.' };
  const destination = results[0].destinationName;
  return {
    error: failed.length > 0,
    message: failed.length
      ? `Test send to ${destination} · ${accepted} accepted · ${failed.length} blocked or rejected. No real transfer. ${details}${failed.length > 3 ? ' See document history for all results.' : ''}`
      : `Test send to ${destination} completed · ${accepted} ${accepted === 1 ? 'document' : 'documents'}. No real transfer.`,
  };
}
