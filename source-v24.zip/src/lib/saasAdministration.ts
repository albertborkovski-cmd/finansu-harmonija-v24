import { parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canManageContractPricing, readContractPricing } from './contractPricing';

export const SAAS_SUBSCRIPTIONS_KEY = 'finansu-harmonija-v24:saas-subscriptions:v1';
export const SAAS_SUBSCRIPTIONS_CHANGED = 'finansu-harmonija:saas-subscriptions-changed';
export type SaasSubscription = { companyId: string; planId: string; status: 'Active' | 'Paused' | 'Cancelled'; startsOn: string; updatedAt: string; updatedBy: string };
export type SaasSubscriptionCatalog = { revision: number; subscriptions: SaasSubscription[]; history: { at: string; by: string; companyId: string; previous: SaasSubscription | null; next: SaasSubscription }[] };
export function readSaasSubscriptions(storage: Pick<Storage, 'getItem'>): SaasSubscriptionCatalog {
  const raw = storage.getItem(SAAS_SUBSCRIPTIONS_KEY);
  if (!raw) return { revision: 0, subscriptions: [], history: [] };
  try {
    const value = JSON.parse(raw) as SaasSubscriptionCatalog;
    if (!Number.isInteger(value.revision) || value.revision < 0 || !Array.isArray(value.subscriptions) || !Array.isArray(value.history)
      || value.subscriptions.some(row => !row || !row.companyId || !row.planId || !['Active', 'Paused', 'Cancelled'].includes(row.status))
      || new Set(value.subscriptions.map(row => row.companyId)).size !== value.subscriptions.length) throw Error();
    return value;
  } catch { throw new Error('SaaS subscriptions could not be loaded. Saved data has not been changed.'); }
}

/** One atomic configuration write, no contract rewriting, payment or access revocation. */
export function saveSaasSubscription(storage: Pick<Storage, 'getItem' | 'setItem'>, revision: number, input: Pick<SaasSubscription, 'companyId' | 'planId' | 'status' | 'startsOn'>, companyIds: readonly string[]) {
  if (!canManageContractPricing(storage)) throw new Error('Only an administrator can manage SaaS subscriptions.');
  const current = readSaasSubscriptions(storage);
  if (current.revision !== revision) throw new Error('Subscriptions have changed. Reopen the editor.');
  if (!companyIds.includes(input.companyId)) throw new Error('Select an existing company.');
  if (!readContractPricing(storage).plans.some(plan => plan.id === input.planId)) throw new Error('Select an available plan.');
  if (!['Active', 'Paused', 'Cancelled'].includes(input.status)) throw new Error('Select a valid subscription status.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.startsOn) || !Number.isFinite(Date.parse(input.startsOn)) || new Date(input.startsOn).toISOString().slice(0, 10) !== input.startsOn) throw new Error('Select a valid subscription start date.');
  const previous = current.subscriptions.find(row => row.companyId === input.companyId) ?? null;
  const at = new Date().toISOString(), by = parseSession(storage.getItem(AUTH_SESSION_KEY))!.email;
  const next: SaasSubscription = { companyId: input.companyId, planId: input.planId, status: input.status, startsOn: input.startsOn, updatedAt: at, updatedBy: by };
  const result = { revision: current.revision + 1, subscriptions: [...current.subscriptions.filter(row => row.companyId !== input.companyId), next], history: [...current.history, { at, by, companyId: input.companyId, previous, next }] };
  storage.setItem(SAAS_SUBSCRIPTIONS_KEY, JSON.stringify(result));
  return result;
}
