import type { ColConfig } from '../components/ColumnSettingsPanel';

type Classification = { code: string; fullName: string; parentCode: string; status: string };
type DocumentClassification = { document_type?: string; document_subtype?: string; document_purpose?: string; type?: string; series?: string; number?: string };
const normalized = (value = '') => value.trim().toLowerCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
const aliases: Record<string, string> = { 'credit note': 'credit invoice', 'debit note': 'debit invoice', receipt: 'cash receipt' };
const findClassification = (value: string, records: readonly Classification[]) => records.find(record =>
  [normalized(record.code), normalized(record.fullName)].includes(aliases[normalized(value)] || normalized(value)));

export function processingSubtype(document: DocumentClassification, records: readonly Classification[]) {
  const explicit = findClassification(document.document_subtype || '', records);
  if (explicit?.parentCode) return explicit;
  const legacy = findClassification(document.document_type || '', records);
  return legacy?.parentCode ? legacy : undefined;
}

/** Legacy descriptions remain untouched; only an explicit purchase/sale value
 * is displayed in this classification column. Never infer it from an amount. */
export function processingDocumentPurpose(document: DocumentClassification) {
  for (const value of [document.document_purpose, document.type]) {
    if (normalized(value) === 'purchase') return 'Purchase';
    if (normalized(value) === 'sale') return 'Sale';
  }
  return '';
}

export function processingDocumentNumber(document: DocumentClassification) {
  const series = document.series?.trim() || '';
  const number = document.number?.trim() || '';
  if (!series || number.toLowerCase().startsWith(series.toLowerCase())) return number || series || '—';
  return number ? `${series} / ${number}` : series;
}

/** Retain users' widths, visibility and ordering while migrating old columns. */
export function processingColumns(columns: readonly ColConfig[]) {
  const seen = new Set<string>();
  return columns.flatMap(column => {
    const key = column.key === 'type' ? 'subtype' : column.key;
    if (key === 'invoice' || seen.has(key)) return [];
    seen.add(key);
    return [{ ...column, key, label: key === 'subtype' ? 'Subtype' : key === 'number' ? 'Series / No.' : column.label }];
  });
}
