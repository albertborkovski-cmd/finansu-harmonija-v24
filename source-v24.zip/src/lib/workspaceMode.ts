/** Navigation preference only: never grants permissions or changes stored records. */
export type WorkspaceMode = 'ocr' | 'combined' | 'fh';
export const WORKSPACE_MODES: readonly { value: WorkspaceMode; label: string }[] = [
  { value: 'ocr', label: 'OCR' },
  { value: 'combined', label: 'OCR + Finansų harmonija' },
  { value: 'fh', label: 'Finansų harmonija' },
];
export function normalizeWorkspaceMode(value: unknown): WorkspaceMode {
  return value === 'ocr' || value === 'fh' ? value : 'combined';
}
export function workspaceModeStorageKey(email: string) {
  return `finansu-harmonija:v23:workspace-mode:${email.trim().toLowerCase()}`;
}
export function workspaceMenuVisible(mode: WorkspaceMode, menu: string): boolean {
  if (mode === 'ocr' && ['settings', 'module:settings', 'settings-internal', 'settings-internal-users', 'settings-internal-roles',
    'settings-organizations', 'settings-organizations-document-status', 'settings-organizations-document-status-ocr',
    'settings-administrator', 'settings-organizations-operation-date-validation', 'ocr-admin-document-type'].includes(menu)) return true;
  if (mode === 'ocr' && (menu === 'dashboard' || menu.startsWith('settings-')
    || menu === 'ocr-admin-document-type' || menu === 'ocr-admin-activity' || menu.startsWith('ocr-admin-activity-'))) return false;
  if (menu === 'saas') return true;
  if (menu === 'uploaded-documents-invoices') return false;
  if (menu === 'ocr-admin-document-type' || menu === 'ocr-admin-activity' || menu.startsWith('ocr-admin-activity-')) return true;
  if (mode === 'combined') return true;
  const ocr = menu === 'ocr' || menu.startsWith('ocr-') || menu === 'uploaded-documents' || menu.startsWith('uploaded-documents-');
  if (mode === 'fh') return !ocr;
  return ocr || ['global-dashboard', 'profile', 'messages'].includes(menu);
}
export function companyMenuVisible(mode: WorkspaceMode, menu: string): boolean {
  return mode !== 'ocr' || menu === 'overview' || menu === 'manage-company';
}

export function companyColumnVisible(mode: WorkspaceMode, key: string): boolean {
  return mode !== 'ocr' || key !== 'assigned_accountant';
}

export function companySettingsSectionVisible(mode: WorkspaceMode, section: string): boolean {
  return mode !== 'ocr' || !['Bank setup', 'Bank GL account', 'Sent documents history', 'banking', 'email-history'].includes(section);
}

/** Product mode limits navigation; existing administrator-only tabs stay protected. */
export function profileSettingsTabVisible(mode: WorkspaceMode, tab: string, canManageSystemOwner: boolean): boolean {
  if (['generalStatus', 'ownerSettings'].includes(tab) && !canManageSystemOwner) return false;
  if (tab === 'sharing') return mode !== 'fh';
  return mode !== 'ocr' || ['generalStatus', 'setupIntegration', 'security', 'accessActivity', 'contract'].includes(tab);
}

/** Saving the OCR column picker must not erase the hidden FH column preferences. */
export function mergeCompanyWorkspaceColumns<T extends { key: string }>(mode: WorkspaceMode, current: T[], next: T[]): T[] {
  if (mode !== 'ocr') return next;
  const available = next.filter(column => companyColumnVisible(mode, column.key));
  return current.flatMap(column => {
    if (!companyColumnVisible(mode, column.key)) return [column];
    const replacement = available.shift();
    return replacement ? [replacement] : [];
  }).concat(available);
}
