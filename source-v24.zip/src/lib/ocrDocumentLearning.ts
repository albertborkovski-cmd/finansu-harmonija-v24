import { automaticLearningValue, confirmLearning, retireDocumentFieldLearning, type LearningActor, type LearningContext, type LearningStore } from './ocrLearning';
import { OCR_SHARED_FIELDS, documentFieldText, ocrFieldOverrides, sharedDocumentField, type OcrSharedField } from './documentSharedFields';

type Row = Record<string, unknown>;
export function sharedLearningContext(document: object, company: object): LearningContext | undefined {
  const row = document as Row, organization = company as Row;
  const name = documentFieldText(row.client_counterparty);
  const id = documentFieldText(row.counterparty_id), companyId = documentFieldText(row.company_id);
  if (!companyId || companyId !== organization.id || (!id && (!name || /^(unassigned|unknown|no buyer|—)$/i.test(name))) || row.entry_method === 'manual') return;
  return { companyId, companyName: documentFieldText(organization.name), supplierKey: id || `name:${name.toLocaleLowerCase()}`,
    supplierName: name, vatRate: sharedDocumentField(document, 'vat_percent') };
}

/** Explicit human evidence only: configured defaults and automatic suggestions do not train themselves. */
export function learnOcrDocument(store: LearningStore, document: object, company: object, actor: LearningActor,
  source: 'review' | 'accountant' | 'addinfo', at: string): LearningStore {
  const context = sharedLearningContext(document, company), row = document as Row;
  if (!context || !row.id) return store;
  const overrides = ocrFieldOverrides(document);
  for (const field of Object.keys(OCR_SHARED_FIELDS) as OcrSharedField[]) {
    const override = overrides[field];
    if (source !== 'review' && (!override || (source === 'addinfo' && override.source !== 'addinfo'))) continue;
    const value = sharedDocumentField(document, field);
    store = value ? confirmLearning(store, { ...context, documentId: String(row.id),
      documentName: documentFieldText(row.file_case || row.number || row.id), field, value,
      source: override?.source || source, confirmedAt: at, confirmedBy: actor })
      : retireDocumentFieldLearning(store, context.companyId, String(row.id), field, actor, at);
  }
  return store;
}

/** Eligible learned values fill empty fields, never recognized values, mixed lines or explicit clearings. */
export function applyLearnedOcrFields<T extends object>(store: LearningStore, document: T, company: object): T {
  const context = sharedLearningContext(document, company);
  if (!context) return document;
  const next: Row = { ...document } as Row, overrides = ocrFieldOverrides(document);
  for (const field of Object.keys(OCR_SHARED_FIELDS) as OcrSharedField[]) {
    const line = OCR_SHARED_FIELDS[field];
    if (overrides[field] || documentFieldText(next[field])) continue;
    if (line && Array.isArray(next.summary_line_items) && next.summary_line_items.some(item => documentFieldText(item?.[line]))) continue;
    const suggestion = automaticLearningValue(store, context, field);
    if (!suggestion) continue;
    next[field] = suggestion.value;
    if (field === 'accountable_responsible') next.accountable_responsible_id = '';
    if (line) for (const key of ['summary_line_items', 'line_items']) {
      if (Array.isArray(next[key])) next[key] = (next[key] as Row[]).map(item => documentFieldText(item[line]) ? item : { ...item, [line]: suggestion.value });
    }
  }
  return next as T;
}
