import { EXPORT_FORMAT_SCHEMAS } from './exportFormatSchemas';
import { API_EXPORT_FORMATS, type HelpText } from './exportHelpGuide';
import { LATVIAN_ACCOUNTING_GUIDES, latvianIntegrationLinks } from './latvianIntegrationGuides';

/** FH instructions describe the configured interface, not an active external connector. */
export type IntegrationArticle = {
  id: string; name: HelpText; group: 'collection' | 'accounting';
  method: 'file' | 'api' | 'folder' | 'email' | 'planned';
  summary: HelpText; setup: HelpText; checks: HelpText;
  steps?: HelpText[]; fields?: { label: HelpText; description: HelpText }[];
  links?: { label: string; url: string }[];
};
type FormatGuide = { summary: HelpText; setup: HelpText; checks: HelpText };
const guide = (summary: HelpText, setup: HelpText, checks: HelpText): FormatGuide => ({ summary, setup, checks });

export const ACCOUNTING_INTEGRATION_GUIDES: Record<string, FormatGuide> = {
  ...LATVIAN_ACCOUNTING_GUIDES,
  Agnum: guide(
    ['Invoice file for Agnum, with expense / item codes, VAT and warehouse allocation.', 'Sąskaitų failas „Agnum“ su išlaidų ar prekių kodais, PVM ir sandėlių paskirstymu.'],
    ['Match Agnum item and warehouse codes. Configure the item account code and registration-number preference, then download the selected invoices for import in Agnum.', 'Suderinkite „Agnum“ prekių ir sandėlių kodus. Nustatykite prekės sąskaitos kodą bei registracijos numerio parinktį, tada atsisiųskite pažymėtas sąskaitas importui į „Agnum“.'],
    ['Check warehouse, VAT and item codes; unpack a ZIP before selecting its import files. Compare invoice numbers to avoid duplicates.', 'Patikrinkite sandėlio, PVM ir prekių kodus; ZIP išarchyvuokite prieš rinkdamiesi importo failus. Sutikrinkite sąskaitų numerius, kad nesusidarytų dublikatų.']),
  Apskaita5: guide(
    ['File-based invoice transfer to Apskaita5.', 'Sąskaitų perdavimas į „Apskaita5“ failu.'],
    ['Use the expense / income and VAT codes of the receiving company. This form has no API credentials; generate a file and use the destination import function.', 'Naudokite gavėjo įmonės išlaidų ar pajamų ir PVM kodus. Šioje formoje API prisijungimo laukų nėra: sugeneruokite failą ir naudokite gavėjo importo funkciją.'],
    ['Check the selected company, code mappings and the import specification supported by your Apskaita5 installation.', 'Patikrinkite pasirinktą įmonę, kodų atitikmenis ir jūsų „Apskaita5“ diegimo palaikomą importo specifikaciją.']),
  BSS: guide(
    ['BSS file import; this is separate from BSS Api.', 'BSS failo importas; tai atskiras pasirinkimas nuo „BSS Api“.'],
    ['Map tax, warehouse, department and expense codes. BSS imports may use an Excel data file and an XML template: load a new template first if the receiving setup requires it.', 'Susiekite mokesčių, sandėlio, padalinio ir išlaidų kodus. BSS importas gali naudoti „Excel“ duomenis ir XML šabloną: jei gavėjo nustatymams reikia naujo šablono, jį įkelkite pirmą.'],
    ['Check that the BSS import template matches the file columns. A successful download is not a completed BSS import.', 'Patikrinkite, ar BSS importo šablonas atitinka failo stulpelius. Sėkmingas atsisiuntimas dar nereiškia importo į BSS.']),
  'BSS Api': guide(
    ['Direct BSS connection settings, including optional API v2 settings.', 'Tiesioginio BSS ryšio nustatymai, įskaitant neprivalomą API v2 konfigūraciją.'],
    ['Obtain the server URL, integration username, API key and portfolio from BSS. For v2, use the supplied URL, environment and company identifiers; do not mix two environments.', 'Iš BSS gaukite serverio adresą, integracijos naudotoją, API raktą ir portfelį. V2 atveju naudokite pateiktą adresą, aplinkos ir įmonės identifikatorius; nemaišykite skirtingų aplinkų.'],
    ['Check portfolio / company access, credential expiry and which API version your BSS installation accepts.', 'Patikrinkite portfelio bei įmonės prieigą, prisijungimo duomenų galiojimą ir jūsų BSS diegimo API versiją.']),
  'Business Central': guide(
    ['OAuth-based Business Central invoice integration.', '„Business Central“ sąskaitų integracija su OAuth autorizacija.'],
    ['The administrator provides the authorization URL, company API URL, client ID and secret. Confirm that the required invoice API extension is installed; a generic BC URL is not necessarily compatible.', 'Administratorius pateikia autorizacijos adresą, įmonės API adresą, kliento ID ir slaptą reikšmę. Patikrinkite, ar įdiegtas reikiamas sąskaitų API plėtinys; bendras BC adresas nebūtinai tinka.'],
    ['Check tenant, environment, company ID, customer / supplier templates and product / VAT posting groups.', 'Patikrinkite nuomininką, aplinką, įmonės ID, pirkėjų ir tiekėjų šablonus bei prekių ir PVM registravimo grupes.']),
  Būtent: guide(
    ['Būtent invoice export with warehouse, operation and cost codes.', '„Būtent“ sąskaitų eksportas su sandėlio, operacijos ir sąnaudų kodais.'],
    ['Select the Būtent import variant agreed with your accountant. Map codes and decide whether non-positive amounts should be ignored before generating a file.', 'Pasirinkite su buhalteriu suderintą „Būtent“ importo variantą. Susiekite kodus ir prieš generuodami failą nustatykite, ar praleisti neteigiamas sumas.'],
    ['Inspect omitted zero / negative lines and check that credit documents remain represented correctly.', 'Patikrinkite praleistas nulines ar neigiamas eilutes ir ar teisingai pateikti kreditiniai dokumentai.']),
  'Būtent kiekinis': guide(
    ['Quantity-based Būtent export preserving item-level allocation.', 'Kiekinis „Būtent“ eksportas su prekių eilučių paskirstymu.'],
    ['Use this variant for item quantities and prices. Check every item code, quantity, unit and warehouse rather than allocating only the document total.', 'Šį variantą rinkitės prekių kiekiams ir kainoms. Tikrinkite kiekvienos eilutės kodą, kiekį, vienetą ir sandėlį, ne tik bendrą dokumento sumą.'],
    ['Compare line totals to the invoice and review the non-positive amount option.', 'Sutikrinkite eilučių sumas su sąskaita ir neteigiamų sumų praleidimo parinktį.']),
  Centas: guide(
    ['Centas file export with item debit, credit and revenue mappings.', 'Failo eksportas į „Centas“ su prekės debeto, kredito ir pajamų sąskaitomis.'],
    ['Enter account codes from Centas and match item / service, warehouse, object and VAT codes. Import the downloaded file in the correct company.', 'Įrašykite „Centas“ sąskaitų kodus, suderinkite prekių ar paslaugų, sandėlio, objekto ir PVM kodus. Atsisiųstą failą importuokite reikiamoje įmonėje.'],
    ['Check counterparty duplicates, currency and the import format supported by the receiving Centas version.', 'Patikrinkite kontrahentų dublikatus, valiutą ir gavėjo „Centas“ versijos palaikomą importo formatą.']),
  CSV: guide(
    ['A tabular exchange file, not a direct accounting connection.', 'Lentelinis duomenų failas, o ne tiesioginis ryšys su apskaita.'],
    ['Agree the column mapping, separator, date format and decimal format with the receiving system. Export a sample and check it before a batch import.', 'Su gavėjo sistema suderinkite stulpelių atitikmenis, skirtuką, datos ir dešimtainių skaičių formatą. Prieš masinį importą patikrinkite vieną pavyzdį.'],
    ['Preserve leading zeros in codes. Opening and saving in Excel can change dates or identifiers.', 'Išsaugokite pradžioje esančius kodų nulius. Atidarius ir išsaugojus per „Excel“ gali pasikeisti datos arba identifikatoriai.']),
  Debetas: guide(
    ['Debetas file export with branch and credit-account settings.', '„Debetas“ failo eksportas su filialo ir kredito sąskaitos nustatymais.'],
    ['Set branch and credit codes; map department, object, expense article, materially responsible person and VAT. Use the receiving Debetas import module.', 'Nustatykite filialo ir kredito kodus; susiekite padalinį, objektą, išlaidų straipsnį, materialiai atsakingą asmenį bei PVM. Naudokite gavėjo „Debetas“ importo modulį.'],
    ['Check codes against the receiving company, not just their display names. Debetas Excel is a different format.', 'Kodų atitikimą tikrinkite gavėjo įmonėje, ne vien pagal pavadinimus. „Debetas Excel“ yra kitas formatas.']),
  'Debetas Excel': guide(
    ['Spreadsheet variant for Debetas.', 'Skaičiuoklės variantas „Debetas“ sistemai.'],
    ['Map department, object, expense and VAT codes. Select Debetas Excel specifically when the receiving import expects a spreadsheet.', 'Susiekite padalinio, objekto, išlaidų ir PVM kodus. „Debetas Excel“ rinkitės tada, kai gavėjo importui reikia skaičiuoklės.'],
    ['Keep the generated column order and code formatting; do not substitute a generic Excel export.', 'Išlaikykite sugeneruotų stulpelių tvarką ir kodų formatą; nekeiskite šio varianto bendru „Excel“ eksportu.']),
  Dineta: guide(
    ['Dineta connection using a service URL and integration credentials.', '„Dineta“ ryšys naudojant paslaugos adresą ir integracijos prisijungimo duomenis.'],
    ['Ask the Dineta representative for the integration username, password and server URL. Select purchase / sales GL templates and the correct warehouse.', 'Iš „Dineta“ atstovo gaukite integracijos naudotoją, slaptažodį ir serverio adresą. Parinkite pirkimų bei pardavimų DK šablonus ir sandėlį.'],
    ['Check server address, integration-user rights and the template / warehouse codes of the target company.', 'Patikrinkite serverio adresą, integracijos naudotojo teises ir gavėjo įmonės šablonų bei sandėlių kodus.']),
  Directo: guide(
    ['Directo has separate purchase and sales API key fields in FH.', 'FH „Directo“ nustatymuose yra atskiri pirkimų ir pardavimų API raktų laukai.'],
    ['Obtain both keys needed for your document directions. Map warehouse, expense and VAT; choose when additional-column defaults should be assigned.', 'Gaukite naudojamoms dokumentų kryptims reikalingus raktus. Susiekite sandėlį, išlaidas ir PVM; pasirinkite papildomų stulpelių priskyrimo etapą.'],
    ['A valid purchase key does not establish sales access. Check direction, key scope and exact codes.', 'Tinkamas pirkimų raktas nesuteikia pardavimų prieigos. Tikrinkite kryptį, rakto teises ir tikslius kodus.']),
  Euroskaita: guide(
    ['Euroskaita file export with type and warehouse allocation.', '„Euroskaita“ failo eksportas su tipo ir sandėlio paskirstymu.'],
    ['Match document type, warehouse, expense and VAT codes to Euroskaita, then import the generated file through the receiving system.', 'Suderinkite dokumento tipo, sandėlio, išlaidų ir PVM kodus su „Euroskaita“, tada importuokite sugeneruotą failą gavėjo sistemoje.'],
    ['Confirm the destination import specification before using FH sample files for real accounting.', 'Prieš naudodami FH pavyzdinius failus tikrai apskaitai patvirtinkite gavėjo importo specifikaciją.']),
  Excel: guide(
    ['General spreadsheet export for review or a separately mapped import.', 'Bendras skaičiuoklės eksportas peržiūrai arba atskirai suderintam importui.'],
    ['Download selected records and map the columns to the recipient’s template. Choose a named accounting format instead when it has a dedicated adapter.', 'Atsisiųskite pažymėtus įrašus ir susiekite stulpelius su gavėjo šablonu. Jei yra specialus apskaitos formatas, naudokite jį.'],
    ['Check dates, numeric precision and text codes. A spreadsheet is not automatically compatible with every accounting program.', 'Patikrinkite datas, skaičių tikslumą ir tekstinius kodus. Skaičiuoklė savaime nėra suderinama su kiekviena apskaitos programa.']),
  Finvalda: guide(
    ['Finvalda file export with item kind, warehouse, type and journal codes.', '„Finvalda“ failo eksportas su prekės rūšies, sandėlio, tipo ir žurnalo kodais.'],
    ['Check the destination VAT and debit / credit mappings. In Finvalda use Data import → From file, choose the file and review the import result.', 'Patikrinkite gavėjo PVM ir debeto bei kredito atitikmenis. „Finvalda“ naudokite Duomenų importas → Iš failo, pasirinkite failą ir peržiūrėkite importo rezultatą.'],
    ['Check new-item account links, VAT and warehouse defaults in Finvalda. FH codes must match that company’s codes.', 'Patikrinkite naujų prekių sąskaitų ryšį, PVM ir sandėlio numatytąsias reikšmes „Finvalda“ sistemoje. FH kodai turi sutapti su tos įmonės kodais.']),
  'Finvalda Excel': guide(
    ['Finvalda spreadsheet variant with type, expense and VAT allocation.', '„Finvalda“ skaičiuoklės variantas su tipo, išlaidų ir PVM paskirstymu.'],
    ['Choose the spreadsheet import template accepted by your Finvalda installation. Keep type, expense and VAT columns mapped to the receiving codes.', 'Pasirinkite jūsų „Finvalda“ diegimui tinkamą skaičiuoklės importo šabloną. Tipo, išlaidų ir PVM stulpelius susiekite su gavėjo kodais.'],
    ['Do not interchange this file with the regular Finvalda format without checking the import template.', 'Nekeiskite šio failo įprastu „Finvalda“ formatu nepatikrinę importo šablono.']),
  iSAF: guide(
    ['Invoice-register export format; it is not a general-ledger posting integration.', 'Sąskaitų registro eksporto formatas; tai nėra DK operacijų registravimo integracija.'],
    ['Check company identifiers, invoice numbers, dates, purchase / sale direction and VAT classification before generating the register file.', 'Prieš generuodami registro failą patikrinkite įmonių identifikatorius, numerius, datas, pirkimo ar pardavimo kryptį ir PVM klasifikaciją.'],
    ['Validate the final production file with the receiving register specification. FH preview export does not submit a declaration.', 'Galutinį produkcinį failą tikrinkite pagal gavėjo registro specifikaciją. FH peržiūros eksportas deklaracijos nepateikia.']),
  Json: guide(
    ['Structured JSON data for a separately implemented receiving adapter.', 'Struktūriniai JSON duomenys atskirai įdiegtam gavėjo adapteriui.'],
    ['Agree property names, document / line structure and code mappings with the receiving developer. This format is a file, not the FH API key.', 'Su gavėjo programuotoju suderinkite laukų pavadinimus, dokumento bei eilučių struktūrą ir kodų atitikmenis. Šis formatas yra failas, ne FH API raktas.'],
    ['Check schema, decimal values, dates and required identifiers. Do not equate downloading JSON with API delivery.', 'Tikrinkite schemą, skaičius, datas ir privalomus identifikatorius. JSON atsisiuntimas nėra perdavimas per API.']),
  Lobasoft: guide(
    ['Lobasoft file export using the common invoice settings.', '„Lobasoft“ failo eksportas naudojant bendrus sąskaitų nustatymus.'],
    ['Set expense and VAT mappings and common export preferences. Confirm the Lobasoft file specification with its administrator before importing.', 'Nustatykite išlaidų ir PVM atitikmenis bei bendras eksporto parinktis. Prieš importą su administratoriumi patvirtinkite „Lobasoft“ failo specifikaciją.'],
    ['This form has no live Lobasoft login. Check import validation and document totals in the receiving system.', 'Ši forma neturi aktyvaus „Lobasoft“ prisijungimo. Patikrinkite importo validaciją ir dokumentų sumas gavėjo sistemoje.']),
  Monet: guide(
    ['Monet export with an identification code and correspondence mapping.', '„Monet“ eksportas su identifikavimo kodu ir korespondencijos atitikmenimis.'],
    ['Use the identification code supplied for your Monet setup. Map correspondence, expense and VAT codes before preparing the export.', 'Naudokite jūsų „Monet“ konfigūracijai suteiktą identifikavimo kodą. Prieš eksportą susiekite korespondencijos, išlaidų ir PVM kodus.'],
    ['An identification code is not proof of an active connection. Confirm the delivery/import method with the Monet administrator.', 'Identifikavimo kodas nepatvirtina aktyvaus ryšio. Perdavimo ar importo būdą patvirtinkite su „Monet“ administratoriumi.']),
  Odoo: guide(
    ['Odoo service settings with default product and payable-account mappings.', '„Odoo“ paslaugos nustatymai su numatytąja preke ir mokėtinų sumų sąskaita.'],
    ['Obtain the API URL, client ID and client password for the agreed adapter. Enter the default product name and payable account, then map VAT and expense codes.', 'Gaukite suderinto adapterio API adresą, kliento ID ir slaptažodį. Įrašykite numatytosios prekės pavadinimą bei mokėtinų sumų sąskaitą, susiekite PVM ir išlaidų kodus.'],
    ['Confirm adapter compatibility, company access and account codes; Odoo versions and custom modules can differ.', 'Patikrinkite adapterio suderinamumą, įmonės prieigą ir sąskaitų kodus: „Odoo“ versijos bei individualūs moduliai gali skirtis.']),
  Optimum: guide(
    ['Optimum API transfer with defaults for newly created records.', 'Perdavimas per „Optimum“ API su naujų įrašų numatytosiomis reikšmėmis.'],
    ['In Optimum, the API key is available through Help → API key. Configure VAT account, customer / supplier / product groups and item defaults for the selected company.', '„Optimum“ API raktą rasite Pagalba → API raktas. Pasirinktai įmonei nustatykite PVM sąskaitą, pirkėjų, tiekėjų bei prekių grupes ir prekių numatytąsias reikšmes.'],
    ['Check missing related codes, allowed code length, employee / warehouse mappings and rejected non-positive lines.', 'Patikrinkite trūkstamus susijusius kodus, leidžiamą jų ilgį, darbuotojų bei sandėlių atitikmenis ir atmestas neteigiamas eilutes.']),
  Paulita: guide(
    ['Paulita invoice export after expense / income allocation.', '„Paulita“ sąskaitų eksportas priskyrus išlaidų ar pajamų kodus.'],
    ['Allocate expense / income and VAT codes. Download the chosen Paulita format and import it in the intended company in Paulita.', 'Priskirkite išlaidų ar pajamų ir PVM kodus. Atsisiųskite pasirinktą „Paulita“ formatą ir importuokite jį reikiamoje „Paulita“ įmonėje.'],
    ['Confirm file compatibility and compare invoice totals after import; no API credentials are configured here.', 'Patvirtinkite failo suderinamumą ir po importo sutikrinkite sumas; API prisijungimo duomenys čia nekonfigūruojami.']),
  Pragma3: guide(
    ['Pragma3 file with debit / credit and credit-document sign rules.', '„Pragma3“ failas su debeto, kredito ir kreditinių dokumentų ženklų taisyklėmis.'],
    ['Set debit and credit codes, credit-note direction and warehouse / project mappings. Use the Pragma3 import specification, not a Pragma4 template.', 'Nustatykite debeto bei kredito kodus, kreditinių dokumentų kryptį ir sandėlio bei projektų atitikmenis. Naudokite „Pragma3“, ne „Pragma4“ importo specifikaciją.'],
    ['Check supplier codes and negative quantity / amount rules before retrying a rejected document.', 'Prieš kartodami atmestą dokumentą patikrinkite tiekėjo kodą ir neigiamo kiekio bei sumos taisykles.']),
  Pragma4: guide(
    ['Pragma4 file with credit-document sign preferences.', '„Pragma4“ failas su kreditinių dokumentų ženklų parinktimis.'],
    ['Map warehouse, correspondence, item and VAT codes. Choose the credit purchase / sales sign rules agreed with the receiving setup.', 'Susiekite sandėlio, korespondencijos, prekių ir PVM kodus. Parinkite su gavėju suderintas kreditinių pirkimų ir pardavimų ženklų taisykles.'],
    ['Check whether counterparties already exist and whether your import expects Pragma4 or Pragma4 V2.', 'Patikrinkite, ar kontrahentai jau sukurti ir ar importui reikia „Pragma4“, ar „Pragma4 V2“.']),
  'Pragma4 V2': guide(
    ['A separate Pragma4 import variant.', 'Atskiras „Pragma4“ importo variantas.'],
    ['Use V2 only when the receiving template requires it. Match warehouse, correspondence, item and VAT codes to that template.', 'V2 rinkitės tik tada, kai jo reikia gavėjo šablonui. Su šablonu suderinkite sandėlio, korespondencijos, prekių ir PVM kodus.'],
    ['Changing the format name does not convert a destination template. Verify one document with the administrator first.', 'Formato pavadinimo pakeitimas nepakeičia gavėjo šablono. Pirmiausia su administratoriumi patikrinkite vieną dokumentą.']),
  Rivilė: guide(
    ['Rivilė GAMA file export; direct API is a separate selection.', '„Rivilė GAMA“ failo eksportas; tiesioginė API yra atskiras pasirinkimas.'],
    ['Configure item account links, item type, payment-account codes and purchase / sales operation types. Match analytical codes, then download and import the file in GAMA.', 'Nustatykite prekių sąskaitų ryšį, prekės tipą, apmokėjimo sąskaitų kodus bei pirkimo ir pardavimo operacijų tipus. Susiekite analitinius kodus, atsisiųskite ir importuokite failą į GAMA.'],
    ['Check item / service / code type, account-link code, department and VAT. A file download does not need the GAMA API key.', 'Tikrinkite prekės, paslaugos ar kodo tipą, sąskaitų ryšio kodą, padalinį ir PVM. Failo atsisiuntimui GAMA API rakto nereikia.']),
  'Rivilė API': guide(
    ['Rivilė GAMA direct integration through Manorivile-Gateway.', 'Tiesioginė „Rivilė GAMA“ integracija per „Manorivile-Gateway“.'],
    ['The Rivilė administrator enables API access for the company database, issues a key and configures Gateway. Set code updates and automatic posting separately from document creation.', 'Rivilės administratorius įjungia API konkrečiai įmonės bazei, suteikia raktą ir sukonfigūruoja „Gateway“. Kodų atnaujinimą ir automatinį perkėlimą nustatykite atskirai nuo dokumento sukūrimo.'],
    ['401: key / access; 502: Gateway connection; timeout: check whether the document was created before retrying. See the full Rivilė API error guide.', '401: raktas ar prieiga; 502: „Gateway“ ryšys; pasibaigus laukimui prieš kartojimą patikrinkite, ar dokumentas sukurtas. Žr. išsamų Rivilė API klaidų aprašymą.']),
  'Rivilė ERP': guide(
    ['Rivilė ERP integration with its own API key, separate from GAMA.', '„Rivilė ERP“ integracija su atskiru API raktu, nesusijusiu su GAMA.'],
    ['Create the ERP key for the intended company and integration permissions. Match product / service, department, object and VAT codes.', 'ERP raktą sukurkite reikiamai įmonei ir integracijos teisėms. Suderinkite prekių ar paslaugų, padalinio, objekto ir PVM kodus.'],
    ['Check key expiry and company assignment. A GAMA key and Gateway configuration are not ERP credentials.', 'Patikrinkite rakto galiojimą ir įmonės priskyrimą. GAMA raktas ir „Gateway“ konfigūracija nėra ERP prisijungimo duomenys.']),
  Roda: guide(
    ['Roda export with department, object, expense and VAT mappings.', '„Roda“ eksportas su padalinio, objekto, išlaidų ir PVM atitikmenimis.'],
    ['Set the receiving company’s codes and common export preferences. Obtain the accepted file specification from the Roda administrator.', 'Nustatykite gavėjo įmonės kodus ir bendras eksporto parinktis. Priimamą failo specifikaciją gaukite iš „Roda“ administratoriaus.'],
    ['No direct-connection credentials appear in this form; verify the file in the receiving import before production use.', 'Tiesioginio prisijungimo laukų šioje formoje nėra; prieš naudojimą produkcijoje failą patikrinkite gavėjo importe.']),
  Saikas: guide(
    ['Saikas file export with separate purchase / sales and VAT accounts.', '„Saikas“ failo eksportas su atskiromis pirkimų, pardavimų ir PVM sąskaitomis.'],
    ['Set the four account mappings and department / expense / VAT codes. In Saikas use Functions → Data import, choose the purchase or sales template, read the file and review it.', 'Nustatykite keturis sąskaitų atitikmenis bei padalinio, išlaidų ir PVM kodus. „Saikas“ rinkitės Funkcijos → Duomenų importavimas, pirkimų ar pardavimų šabloną, nuskaitykite failą ir jį patikrinkite.'],
    ['Check document direction and the selected import template before registering the result.', 'Prieš registruodami rezultatą patikrinkite dokumento kryptį ir pasirinktą importo šabloną.']),
  'Site.pro': guide(
    ['Site.pro API invoice transfer with warehouse and operation mappings.', 'Sąskaitų perdavimas per „Site.pro“ API su sandėlio ir operacijos atitikmenimis.'],
    ['Ask the Site.pro administrator to enable API #2 for the company and provide its key. Match warehouse, operation, expense and VAT codes; review negative-credit preferences.', 'Paprašykite „Site.pro“ administratoriaus įjungti įmonės API #2 ir pateikti raktą. Susiekite sandėlio, operacijos, išlaidų ir PVM kodus; patikrinkite neigiamų kreditinių sumų parinktis.'],
    ['For an item-date conflict, review the stock chronology and document dates. Do not alter factual invoice dates merely to bypass an error.', 'Prekės datos konflikto atveju tikrinkite atsargų chronologiją ir dokumentų datas. Nekeiskite faktinių sąskaitos datų vien tam, kad apeitumėte klaidą.']),
  StandardERP: guide(
    ['StandardERP export with warehouse and accounting-code allocation.', '„StandardERP“ eksportas su sandėlio ir apskaitos kodų paskirstymu.'],
    ['Map warehouse, expense and VAT codes, then agree the import file variant with your StandardERP administrator.', 'Susiekite sandėlio, išlaidų ir PVM kodus, tuomet su „StandardERP“ administratoriumi suderinkite importo failo variantą.'],
    ['Confirm exact code values and file compatibility; this form has no active StandardERP connection.', 'Patvirtinkite tikslias kodų reikšmes ir failo suderinamumą; ši forma neturi aktyvaus „StandardERP“ ryšio.']),
  Syrve: guide(
    ['Syrve API integration for item / stock-related invoices.', '„Syrve“ API integracija prekių ir atsargų sąskaitoms.'],
    ['Obtain the API URL and integration credentials. Match products, warehouses and concepts; review raw-material-only, quantity-recalculation and create-product preferences.', 'Gaukite API adresą ir integracijos prisijungimo duomenis. Suderinkite prekes, sandėlius ir koncepcijas; peržiūrėkite žaliavų, kiekio perskaičiavimo ir prekių kūrimo parinktis.'],
    ['If a product is not found, check its exact code in Syrve and the selected warehouse. Verify quantities and units after any recalculation.', 'Jei prekė nerasta, patikrinkite tikslų jos kodą „Syrve“ bei sandėlį. Po perskaičiavimo sutikrinkite kiekius ir mato vienetus.']),
  'UCS StoreHouse v4': guide(
    ['StoreHouse v4 export settings include a destination email address.', '„StoreHouse v4“ eksporto nustatymuose yra gavėjo el. pašto adresas.'],
    ['Confirm the receiving email with the administrator, then map department and expense codes. Configure actual mail delivery on the server before using it.', 'Su administratoriumi patvirtinkite gavėjo el. paštą, susiekite padalinio bei išlaidų kodus. Prieš naudojimą serveryje turi būti sukonfigūruotas tikras laiškų siuntimas.'],
    ['Saving an address sends no mail. Check delivery and the receiving import result separately.', 'Adreso išsaugojimas laiško nesiunčia. Pristatymą ir gavėjo importo rezultatą tikrinkite atskirai.']),
  Uniconta: guide(
    ['Uniconta file-format selection with common invoice preferences.', '„Uniconta“ failo formato pasirinkimas su bendromis sąskaitų parinktimis.'],
    ['Match expense and VAT codes and confirm the accepted import template with the Uniconta administrator.', 'Susiekite išlaidų bei PVM kodus ir su „Uniconta“ administratoriumi patvirtinkite priimamą importo šabloną.'],
    ['No Uniconta credentials are configured here; confirm the actual receiving adapter before production import.', '„Uniconta“ prisijungimo duomenys čia nekonfigūruojami; prieš produkcinį importą patvirtinkite gavėjo adapterį.']),
  XML: guide(
    ['Structured XML file for a separately agreed receiving schema.', 'Struktūrinis XML failas pagal atskirai suderintą gavėjo schemą.'],
    ['Agree element names, required fields and department / object / expense / VAT mappings. A named system’s XML is not necessarily equivalent to this generic format.', 'Suderinkite elementų pavadinimus, privalomus laukus ir padalinio, objekto, išlaidų bei PVM atitikmenis. Konkrečios sistemos XML nebūtinai sutampa su šiuo bendru formatu.'],
    ['Validate against the destination schema, including encoding, decimal values and dates.', 'Tikrinkite pagal gavėjo schemą, įskaitant koduotę, dešimtaines reikšmes ir datas.']),
};

export const COLLECTION_INTEGRATIONS: IntegrationArticle[] = [
  { id: 'email', name: ['Email', 'El. paštas'], group: 'collection', method: 'email',
    summary: ['Receive invoice attachments through the FH document-upload mailbox.', 'Gaukite sąskaitų priedus per FH dokumentų įkėlimo pašto dėžutę.'],
    setup: ['Use only the upload address displayed in your FH account. It is not the user’s login email or the recipient for payment reminders.', 'Naudokite tik jūsų FH paskyroje rodomą įkėlimo adresą. Tai ne naudotojo prisijungimo el. paštas ir ne mokėjimų priminimų gavėjas.'],
    checks: ['Check the exact recipient, attached files and rejected-mail response. A sent email alone does not prove that its documents were imported.', 'Patikrinkite tikslų gavėją, pridėtus failus ir laiško atmetimo atsakymą. Išsiųstas laiškas dar neįrodo, kad dokumentai importuoti.'],
    steps: [
      ['Find the document email address in the Dashboard upload area.', 'Dokumentų el. paštą raskite Apžvalgos įkėlimo srityje.'],
      ['Attach the invoice files and send them to the configured receiving mailbox.', 'Pridėkite sąskaitų failus ir siųskite į sukonfigūruotą gavimo pašto dėžutę.'],
      ['In a connected service, received files appear in All Documents → Uploaded documents with Email as their source and the sender address beneath it.', 'Prijungtoje tarnyboje gauti failai atsiranda Visi dokumentai → Įkelti dokumentai, su šaltiniu „El. paštas“ ir siuntėjo adresu po juo.'],
      ['Follow Processing / Needs attention. Organization recognition and OCR review use the same workflow as manual upload.', 'Sekite apdorojimą ir dėmesio reikalaujančius įrašus. Organizacijos atpažinimas ir OCR peržiūra veikia pagal tą pačią eigą kaip rankinis įkėlimas.'],
    ] },
  { id: 'google-drive', name: ['Google Drive', 'Google Drive'], group: 'collection', method: 'folder',
    summary: ['Two separate directions: incoming files to OCR and processed PDFs to an archive.', 'Dvi atskiros kryptys: gaunami failai į OCR ir apdoroti PDF į archyvą.'],
    setup: ['Profile settings → Setup & integration → Google Drive. Configure the incoming folder and archive independently. FH must use its own service account and authorization.', 'Profilio nustatymai → Nustatymai ir integracija → Google Drive. Gaunamų dokumentų aplanką ir archyvą konfigūruokite atskirai. FH turi naudoti savo tarnybinę paskyrą ir autorizaciją.'],
    checks: ['Check the account, folder address, access and shared-drive ID. Removing folder access stops a connected reader; it does not delete the source files.', 'Tikrinkite paskyrą, aplanko adresą, prieigą ir bendro disko ID. Pašalinus prieigą sustoja prijungtas skaitytuvas, bet pradiniai failai neištrinami.'],
    fields: [
      { label: ['Import folder / URL', 'Importo aplankas / adresas'], description: ['The incoming folder, not a single-file link. Include subfolders only when required.', 'Gaunamų dokumentų aplankas, ne atskiro failo nuoroda. Poaplankius įtraukite tik prireikus.'] },
      { label: ['Archive folder', 'Archyvo aplankas'], description: ['Destination for processed documents; keep it separate from the incoming folder to avoid re-import loops.', 'Apdorotų dokumentų paskirties vieta; atskirkite nuo gavimo aplanko, kad nebūtų pakartotinio importo ciklų.'] },
      { label: ['Shared drive ID', 'Bendro disko ID'], description: ['Only the identifier of a Google Workspace shared drive; leave empty for a personal drive.', 'Tik „Google Workspace“ bendro disko identifikatorius; asmeniniam diskui palikite tuščią.'] },
    ],
    steps: [
      ['Set the folder name / URL and the Include subfolders preference.', 'Nustatykite aplanko pavadinimą ar adresą ir poaplankių įtraukimo parinktį.'],
      ['After the backend connector is installed, grant its FH service account access to the intended folder only.', 'Įdiegus serverio jungtį, suteikite jos FH tarnybinei paskyrai prieigą tik prie reikiamo aplanko.'],
      ['Check connection before enabling scheduled reading. Saving preferences alone does not read Google Drive.', 'Prieš įjungdami periodinį skaitymą patikrinkite ryšį. Vien parinkčių išsaugojimas „Google Drive“ neskaito.'],
      ['For archiving, authorize the destination separately and confirm which organizations and periods to include.', 'Archyvavimui paskirties vietą autorizuokite atskirai ir patvirtinkite įtraukiamas organizacijas bei laikotarpius.'],
    ], links: [{ label: 'Google Drive · Sharing and permissions', url: 'https://support.google.com/drive/answer/7166529' }] },
  { id: 'sharepoint', name: ['SharePoint', 'SharePoint'], group: 'collection', method: 'folder',
    summary: ['Read documents from configured SharePoint libraries or folders into OCR.', 'Dokumentų skaitymas į OCR iš nustatytų „SharePoint“ bibliotekų ar aplankų.'],
    setup: ['Profile settings → Setup & integration → SharePoint. The Microsoft administrator provides the app registration, tenant ID and client ID, and stores the secret through a secure backend.', 'Profilio nustatymai → Nustatymai ir integracija → SharePoint. „Microsoft“ administratorius paruošia programos registraciją, nuomininko bei kliento ID, o slaptą reikšmę saugo per saugų serverį.'],
    checks: ['Check secret expiry, tenant / app IDs, granted site access and the folder path. Never grant access to every site merely to make a connection test pass.', 'Tikrinkite slaptos reikšmės galiojimą, nuomininko bei programos ID, suteiktą svetainės prieigą ir aplanko kelią. Nesuteikite visų svetainių prieigos vien tam, kad pavyktų ryšio testas.'],
    fields: [
      { label: ['Tenant ID', 'Nuomininko ID'], description: ['Microsoft organization identifier.', '„Microsoft“ organizacijos identifikatorius.'] },
      { label: ['Client ID', 'Kliento ID'], description: ['Identifier of the registered integration application, not a user email.', 'Registruotos integracijos programos identifikatorius, ne naudotojo el. paštas.'] },
      { label: ['Client secret', 'Slapta kliento reikšmė'], description: ['Secret value, not the secret ID. The frontend does not store this credential.', 'Slaptoji reikšmė, ne jos ID. Frontend šio prisijungimo duomens nesaugo.'] },
      { label: ['SharePoint URLs / schedule', 'SharePoint adresai / grafikas'], description: ['One library or folder URL per line; choose frequency and, for a daily run, time. The server must confirm timezone and path-pattern support.', 'Po vieną bibliotekos ar aplanko adresą eilutėje; pasirinkite dažnį, o kasdieniam vykdymui – laiką. Laiko juostą ir kelio šablonų palaikymą turi patvirtinti serveris.'] },
    ],
    steps: [
      ['In Microsoft Entra, ask the administrator to select the FH application registration.', '„Microsoft Entra“ paprašykite administratoriaus pasirinkti FH programos registraciją.'],
      ['Grant the least permissions supported by the connector. Selected-site permission also requires an explicit grant to that site.', 'Suteikite mažiausias jungties palaikomas teises. Pasirinktų svetainių leidimui taip pat reikia atskiro prieigos suteikimo tai svetainei.'],
      ['Enter library / folder URLs, not a sharing link to one file, and set the reading schedule.', 'Įrašykite bibliotekos ar aplanko adresus, ne vieno failo bendrinimo nuorodą, ir nustatykite skaitymo grafiką.'],
      ['After server connection, check a permitted folder and follow imported documents in Uploaded documents.', 'Prijungę serverį patikrinkite leistiną aplanką ir sekite gautus dokumentus skiltyje Įkelti dokumentai.'],
    ], links: [{ label: 'Microsoft Learn · Selected permissions', url: 'https://learn.microsoft.com/en-us/graph/permissions-selected-overview' }, { label: 'Microsoft Entra', url: 'https://entra.microsoft.com/' }] },
  { id: 'fh-api', name: ['FH API', 'FH API'], group: 'collection', method: 'api',
    summary: ['Programmatic document upload and result retrieval; different from an accounting provider’s API key.', 'Programinis dokumentų įkėlimas ir rezultatų gavimas; skiriasi nuo apskaitos tiekėjo API rakto.'],
    setup: ['Profile settings → Setup & integration → Working with the system → API access. Choose a key label and only the required upload / result-reading permissions.', 'Profilio nustatymai → Nustatymai ir integracija → Darbas su sistema → API prieiga. Pasirinkite rakto pavadinimą ir tik reikalingas įkėlimo bei rezultatų skaitymo teises.'],
    checks: ['The current frontend generates no API key and exposes no documented production endpoint. Do not put credentials in query strings, screenshots or browser storage.', 'Dabartinis frontend API rakto nesukuria ir neturi aprašyto produkcinio galinio taško. Raktų nedėkite į URL parametrus, ekrano nuotraukas ar naršyklės saugyklą.'],
    steps: [
      ['Save the desired access and permission preferences.', 'Išsaugokite pageidaujamą prieigą ir teisių parinktis.'],
      ['Before connecting another app, obtain the deployed FH API specification and server-issued credential from the administrator.', 'Prieš prijungdami kitą programą iš administratoriaus gaukite įdiegtos FH API specifikaciją ir serverio išduotą raktą.'],
      ['The connected client uploads a document and keeps the returned identifier; processing is asynchronous.', 'Prijungtas klientas įkelia dokumentą ir išsaugo gautą identifikatorių; apdorojimas vyksta asinchroniškai.'],
      ['Read the processing result using that identifier. A received request is not yet a processed or exported invoice.', 'Pagal identifikatorių perskaitykite apdorojimo rezultatą. Gauta užklausa dar nereiškia apdorotos ar eksportuotos sąskaitos.'],
    ] },
  { id: 'dropbox', name: ['Dropbox', 'Dropbox'], group: 'collection', method: 'planned',
    summary: ['Dropbox can be shown as a document source; no Dropbox connection form is implemented in this version.', '„Dropbox“ gali būti rodomas kaip dokumento šaltinis; šioje versijoje „Dropbox“ prijungimo forma neįgyvendinta.'],
    setup: ['For now, download documents from your Dropbox and use the FH upload area. A source label in a sample record does not establish synchronization.', 'Kol kas atsisiųskite dokumentus iš savo „Dropbox“ ir naudokite FH įkėlimo sritį. Šaltinio žyma pavyzdiniame įraše sinchronizavimo nesukuria.'],
    checks: ['Automatic collection requires a dedicated connector, authorization, folder selection and duplicate controls. None are activated by this help page.', 'Automatiniam surinkimui reikia atskiros jungties, autorizacijos, aplanko pasirinkimo ir dublikatų kontrolės. Šis pagalbos puslapis jų neįjungia.'],
    steps: [
      ['Download the intended invoice files from Dropbox.', 'Atsisiųskite reikiamus sąskaitų failus iš „Dropbox“.'],
      ['Upload them through Dashboard or All Documents → Uploaded documents.', 'Įkelkite juos per Apžvalgą arba Visi dokumentai → Įkelti dokumentai.'],
      ['Follow their processing in the standard OCR workflow.', 'Sekite jų apdorojimą įprastoje OCR darbų eigoje.'],
    ] },
];

export const INTEGRATION_ARTICLES: IntegrationArticle[] = [
  ...COLLECTION_INTEGRATIONS,
  ...Object.keys(EXPORT_FORMAT_SCHEMAS).map(format => ({
    id: format, name: [format, format] as HelpText, group: 'accounting' as const,
    method: (API_EXPORT_FORMATS.includes(format) ? 'api' : format === 'UCS StoreHouse v4' ? 'email' : 'file') as IntegrationArticle['method'],
    ...ACCOUNTING_INTEGRATION_GUIDES[format],
    links: latvianIntegrationLinks(format),
  })),
];
export function integrationArticle(id: string | null) {
  return INTEGRATION_ARTICLES.find(article => article.id === id) || INTEGRATION_ARTICLES.find(article => article.id === 'Rivilė API')!;
}
