import type { DocumentTypeReference } from './documentSubtypeOptions';

type DocumentClassification = { document_type?: unknown; document_subtype?: unknown; [key: string]: unknown };

function findRecord(records: readonly DocumentTypeReference[], value: string) {
  const normalized = value.trim().toLocaleLowerCase();
  return records.find(record => record.code === value)
    ?? records.find(record => record.fullName.trim().toLocaleLowerCase() === normalized);
}

function activePath(records: readonly DocumentTypeReference[], record: DocumentTypeReference) {
  const path: DocumentTypeReference[] = [];
  const seen = new Set<string>();
  let current: DocumentTypeReference | undefined = record;
  while (current) {
    if (seen.has(current.code) || current.status.toLowerCase() !== 'active') return [];
    seen.add(current.code);
    path.unshift(current);
    if (!current.parentCode) return path;
    current = records.find(item => item.code === current?.parentCode);
  }
  return [];
}

/** Settings order and parent descriptions make every active type/subtype searchable. */
export function documentTypeCatalogOptions(records: readonly DocumentTypeReference[]) {
  const options: { value: string; label: string; description?: string }[] = [];
  const visited = new Set<string>();
  const append = (record: DocumentTypeReference) => {
    if (visited.has(record.code)) return;
    visited.add(record.code);
    const path = activePath(records, record);
    if (!path.length) return;
    const parents = path.slice(0, -1);
    options.push({ value: record.code, label: record.fullName || record.code,
      ...(parents.length ? { description: parents.map(parent => parent.fullName || parent.code).join(' / ') } : {}) });
    records.filter(child => child.parentCode === record.code).forEach(append);
  };
  records.filter(record => !record.parentCode).forEach(append);
  return options;
}

export function documentTypeCatalogSelection(document: DocumentClassification, records: readonly DocumentTypeReference[]) {
  const value = String(document.document_subtype || document.document_type || '');
  return findRecord(records, value)?.code || value;
}

/** A subtype selection never replaces the parent type with a child code. */
export function documentTypeCatalogPatch(records: readonly DocumentTypeReference[], value: string) {
  const selected = records.find(record => record.code === value);
  const path = selected ? activePath(records, selected) : [];
  if (!selected || !path.length) throw new Error('Select an active document type or subtype from General settings.');
  return { document_type: path[0].code, document_subtype: path.length > 1 ? selected.code : '' };
}
