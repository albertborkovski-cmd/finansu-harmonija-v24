import type { DbDocument } from './supabase';
import type { DocumentIssueStatus } from './documentIssues';

export const OCR_REGISTER_EXAMPLE_BATCH = 'v24-ocr-register-examples-1';
export const OCR_NO_BUYER_EXAMPLE_BATCH = 'v24-ocr-no-buyer-examples-1';
const money = (cents: number) => (cents / 100).toFixed(2);
const split = (cents: number, count: number) => Array.from({ length: count }, (_, index) =>
  Math.round(cents * (index + 1) / count) - Math.round(cents * index / count));

/** OCR facts only. No manual invoice, Storno, GL posting or external transfer is created. */
export function createOcrRegisterExamples(companyId: string, at = new Date().toISOString()): DbDocument[] {
  if (!companyId || !Number.isFinite(Date.parse(at))) throw new Error('A company and a valid date are required.');
  const received = new Date(at).toISOString().slice(0, 10);
  const previousMonth = new Date(at); previousMonth.setUTCDate(1); previousMonth.setUTCMonth(previousMonth.getUTCMonth() - 2);
  const oldDate = previousMonth.toISOString().slice(0, 10);
  const cases: Array<{ name: string; status?: string; side?: 'Sale' | 'Purchase'; net?: number; rate?: number; currency?: string; quantity?: number; allocations?: number; receipt?: boolean; missing?: string; error?: string; issue?: DocumentIssueStatus; late?: boolean; duplicate?: boolean; unassigned?: boolean }> = [
    { name: 'Office supplies', net: 18650 },
    { name: 'Accounting services', side: 'Sale', net: 400000 },
    { name: 'Fuel receipt', receipt: true, net: 7430 },
    { name: 'Retail sale with receipt', side: 'Sale', receipt: true, net: 12899 },
    { name: 'Computer accessories', quantity: 4, net: 145899 },
    { name: 'Office rent allocation', allocations: 3, net: 240000 },
    { name: 'Cloud services', currency: 'USD', rate: 0, net: 32890 },
    { name: 'Software subscription', currency: 'GBP', rate: 0, net: 54999 },
    { name: 'Returned goods credit', net: -7250 },
    { name: 'Department to be assigned', missing: 'department', net: 28300 },
    { name: 'Project to be assigned', missing: 'object', net: 89100 },
    { name: 'Cost center to be assigned', missing: 'center', net: 46750 },
    { name: 'Expense code to be assigned', missing: 'expense', net: 8900 },
    { name: 'Monthly maintenance', duplicate: true, net: 32000 },
    { name: 'Monthly maintenance duplicate number', duplicate: true, net: 32000 },
    { name: 'Supplier code not recognized', error: 'Supplier code was not found in the accounting system.', net: 62000 },
    { name: 'Closed accounting period', error: 'The accounting period is locked in Rivilė. Choose an available operation date.', late: true, net: 19400 },
    { name: 'Invoice received after period deadline', late: true, net: 84000 },
    { name: 'Supplier corrected by Worker', issue: 'Resolved', net: 71500 },
    { name: 'Export excluded invoice', net: 15700 },
    { name: 'Approved purchase', status: 'Approved', net: 78000 },
    { name: 'Approved sale', status: 'Approved', side: 'Sale', net: 219900 },
    { name: 'Transferred purchase', status: 'Transferred', net: 44900 },
    { name: 'Exported sale', status: 'Exported', side: 'Sale', net: 130000 },
    { name: 'OCR is reading the invoice', status: 'Processing', quantity: 3 },
    { name: 'Waiting for Worker', status: 'Queued' },
    { name: 'Waiting for OCR reprocessing', status: 'Awaiting OCR' },
    { name: 'TeamLead review requested', status: 'Awaiting approval' },
    { name: 'Unreadable supplier details', status: 'Exception' },
    { name: 'Repeated uploaded invoice', status: 'Duplicate' },
    { name: 'Organization not recognized', status: 'Organization not identified', unassigned: true },
    { name: 'Attachment is not an invoice', status: 'Not document' },
    { name: 'Accountant requested supplier correction', status: 'Processing', issue: 'Open' },
    { name: 'Worker is checking invoice details', status: 'Processing', issue: 'In progress' },
    { name: 'Worker correction sent back to OCR', status: 'Processing', issue: 'Awaiting OCR' },
    { name: 'Newly uploaded attachment', status: 'Uploaded' },
    { name: 'Removed upload', status: 'Deleted' },
    { name: 'Zero VAT international sale', side: 'Sale', rate: 0, net: 287500 },
    { name: 'Equipment and installation', quantity: 6, allocations: 2, net: 1234567 },
    { name: 'Travel expenses with receipt', quantity: 3, receipt: true, net: 19999 },
  ];
  const parties = ['Baltic Paper UAB', 'Amber Consulting UAB', 'River Transport UAB', 'Vilnius Office UAB', 'Northwind Services UAB', 'Cloud Solutions Ltd'];
  return cases.map((example, index) => {
    const sequence = String(index + 1).padStart(3, '0'), id = `${companyId}:${OCR_REGISTER_EXAMPLE_BATCH}:${sequence}`;
    const number = example.duplicate ? 'OCR-24-014' : `OCR-24-${sequence}`;
    const side = example.side || 'Purchase', net = example.net ?? (12500 + index * 375), rate = example.rate ?? 21;
    const vat = Math.round(net * rate / 100), currency = example.currency || 'EUR', date = example.late ? oldDate : received;
    const makeLines = (count: number, allocation: boolean) => {
      const nets = split(net, count), vats = split(vat, count);
      return nets.map((amount, line) => ({ id: `${id}:${allocation ? 'allocation' : 'quantity'}:${line}`, systemId: `${sequence}-${line + 1}`,
        code: `ITEM-${sequence}-${line + 1}`, barcode: '', product: example.name, description: count > 1 ? `${example.name} ${line + 1}` : example.name,
        qty: '1', unit: 'pcs', price: money(amount), subtotal: money(amount), discount: '0.00', vatPct: `${rate}%`, vat: money(vats[line]), total: money(amount + vats[line]),
        expense: example.missing === 'expense' ? '' : side === 'Sale' ? '5000' : '6300', vatClass: rate ? 'PVM1' : 'PVM5',
        department: example.missing === 'department' ? '' : 'ADMIN', object: example.missing === 'object' ? '' : `PROJECT-${line + 1}`,
        center: example.missing === 'center' ? '' : 'KC01', productGroup: 'Services', series: 'OCR24',
      }));
    };
    const lines = makeLines(example.quantity || 1, false), allocations = makeLines(example.allocations || 1, true);
    const sources = [
      { source: 'Email', source_details: { senderEmail: 'invoices@baltic-paper.example' } },
      { source: 'SharePoint', source_details: { folderPath: '/Organizations/Alice Stone/Invoices/2026-11' } },
      { source: 'Dropbox', source_details: { folderPath: '/Accounting/Receipts/November' } },
      { source: 'Manual', source_details: { uploadedBy: 'Aurika Žilinskaitė', uploadedByRoles: ['Meso accountant'] } },
      { source: 'Google Drive', source_details: { folderPath: '/Finance/Invoices/Incoming' } },
      { source: 'SharePoint', source_details: { folderPath: '/Organizations/Alice Stone/Invoices/Incoming' } },
    ];
    const document: DbDocument = {
      id, company_id: example.unassigned ? '' : companyId, number, file_case: `${number}${example.duplicate && index === 14 ? '-copy' : ''}.pdf`,
      document_type: 'INVOICES', document_subtype: net < 0 ? 'CREDIT_INVOICE' : 'VAT_INVOICE',
      status: example.status || 'Processed', type: side, document_purpose: side, currency,
      receive_date: received, document_date: date, invoice_contract_date: date, operation_date: date, due_end_date: received,
      order_no: `PO-24-${sequence}`, client_counterparty: parties[index % parties.length], counterparty_code: `CP-${index % parties.length + 1}`,
      ...sources[index % sources.length], amount_without_vat: money(net), vat: money(vat), total_amount: money(net + vat), vat_percent: `${rate}%`,
      expense_account: allocations[0].expense, vat_classifier: allocations[0].vatClass, department_code: allocations[0].department,
      object_project: allocations.length === 1 ? allocations[0].object : '', cost_center: allocations[0].center,
      series: 'OCR24', valid_form: '', accountable_responsible: '', notes: example.name, with_receipt: Boolean(example.receipt),
      line_items: lines, summary_line_items: allocations, created_at: new Date(Date.parse(at) - index * 60000).toISOString(), created_by: 'Aurika Žilinskaitė', image_url: null,
    };
    if (index === 19) document.excluded_from_export = true;
    if (example.error) document.accounting_test_deliveries = [{ mode: 'test', requestId: `${id}:response`, destinationId: 'rivile', destinationName: 'Rivilė', scenario: 'rejected', outcome: 'Rejected', reference: `RIV-${sequence}`, at, actor: 'Aurika Žilinskaitė', message: example.error, sourceSnapshot: '', sourceRegister: 'all-documents' }];
    if (example.issue) {
      const message = 'Please verify the supplier code and the invoice allocation against the attached document.';
      document.digitization_issues = [{ id: `${id}:issue`, message, status: example.issue, organizationId: companyId, documentLabel: number,
        blocksApproval: example.issue !== 'Resolved', createdAt: at, createdBy: 'Aurika Žilinskaitė',
        ...(example.issue === 'Resolved' ? { resolvedAt: at, resolution: 'Supplier details verified and corrected. OCR reprocessing completed.' } : {}),
        events: [{ id: `${id}:reported`, at, actor: 'Aurika Žilinskaitė', action: 'Reported to Worker', details: message }],
        messages: [{ id: `${id}:message`, text: message, sentAt: at, author: 'Aurika Žilinskaitė', authorEmail: 'aurika@example.invalid', authorSide: 'accountant' }],
      }];
    }
    if (index === 29) document.number = 'OCR-24-001';
    return document;
  });
}

/** A completed batch is never recreated, including after editing or removing its records. */
export function missingOcrRegisterExamples(existing: readonly { id?: unknown }[], companyId: string, at?: string) {
  const prefix = `${companyId}:${OCR_REGISTER_EXAMPLE_BATCH}:`;
  return existing.some(document => String(document.id || '').startsWith(prefix)) ? [] : createOcrRegisterExamples(companyId, at);
}

/** Completed OCR invoices awaiting organization assignment, visible in the No buyer filter. */
export function createNoBuyerOcrExamples(companyId: string, at = new Date().toISOString()): DbDocument[] {
  const source = createOcrRegisterExamples(companyId, at);
  return [source[0], source[4]].map((document, index) => {
    const id = `${companyId}:${OCR_NO_BUYER_EXAMPLE_BATCH}:${index + 1}`;
    const number = `OCR-NB-00${index + 1}`;
    const rekey = (lines: NonNullable<DbDocument['line_items']>, kind: string) => lines.map((line, lineIndex) => ({ ...line, id: `${id}:${kind}:${lineIndex}` }));
    return { ...document, id, company_id: '', number, file_case: `${number}.pdf`, status: 'Processed',
      client_counterparty: index === 0 ? 'Baltic Paper UAB' : 'Northwind Services UAB',
      notes: index === 0 ? 'Office supplies — assign the buyer organization.' : 'Computer accessories — assign the buyer organization.',
      source: index === 0 ? 'Email' : 'SharePoint',
      source_details: index === 0 ? { senderEmail: 'invoices@baltic-paper.example' } : { folderPath: '/Accounting/Unassigned invoices' },
      line_items: rekey(document.line_items || [], 'quantity'), summary_line_items: rekey(document.summary_line_items || [], 'allocation'),
    };
  });
}

/** Correct only the untouched API origins from this requested example batch. */
export function correctOcrExampleSources<T extends { id?: unknown; source?: unknown; source_details?: unknown }>(rows: readonly T[], companyId: string): T[] {
  const prefix = `${companyId}:${OCR_REGISTER_EXAMPLE_BATCH}:`;
  return rows.map(row => {
    const details = row.source_details as { integrationName?: string; reference?: string } | undefined;
    if (!String(row.id || '').startsWith(prefix) || row.source !== 'API' || details?.integrationName !== 'Document intake API') return row;
    return { ...row, source: 'SharePoint', source_details: { folderPath: '/Organizations/Alice Stone/Invoices/Incoming' } };
  });
}
