import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentWorkEntry, OcrDocumentWorkLog } from '../components/ocrDocumentWorkTimeStore';
import type { DbDocument } from './supabase';
import type { LinkedDirectoryUser } from './linkedSettingsData';
import { isInactiveRecord } from './recordLifecycle';
import { isWorkerProcessingDocument } from './ocrMyTasks';

export type OcrWorker = { email: string; name: string };
const emailKey = (email?: string) => email?.trim().toLowerCase() || '';

/** Ownership is resolved by email, never by a potentially duplicated display name. */
export function ocrTaskWorker(task?: WorkspaceTask, work?: OcrDocumentWorkEntry): OcrWorker | undefined {
  const email = emailKey(task?.assignedToEmail || task?.teamLeadReview?.requestedByEmail || work?.email);
  if (!email) return undefined;
  const name = task?.assignedToEmail ? task.assignedToName
    : task?.teamLeadReview?.requestedByEmail ? task.teamLeadReview.requestedBy : work?.user;
  return { email, name: name?.trim() || email };
}

export function documentWorkEntry(log: OcrDocumentWorkLog, id: string) {
  return log[id] ?? log[`document-set-${id}`];
}

export function teamLeadWorkerDirectory(documents: readonly DbDocument[], tasks: ReadonlyMap<string, WorkspaceTask | undefined>,
  log: OcrDocumentWorkLog, users: readonly LinkedDirectoryUser[]): OcrWorker[] {
  const workers = new Map<string, OcrWorker>();
  for (const document of documents) {
    const worker = ocrTaskWorker(tasks.get(document.id), documentWorkEntry(log, document.id));
    if (worker) workers.set(worker.email, worker);
    for (const issue of document.digitization_issues ?? []) {
      const email = emailKey(issue.assignedToEmail);
      if (email) workers.set(email, { email, name: issue.assignedToName?.trim() || email });
    }
  }
  const names = new Map(users.filter(user => user.email).map(user => [emailKey(user.email), user.fullName]));
  return [...workers.values()].map(worker => ({ ...worker, name: names.get(worker.email) || worker.name }))
    .sort((a, b) => a.name.localeCompare(b.name) || a.email.localeCompare(b.email));
}

export function teamLeadWorkerDocumentIds(documents: readonly DbDocument[], tasks: ReadonlyMap<string, WorkspaceTask | undefined>,
  log: OcrDocumentWorkLog, workerEmail = ''): ReadonlySet<string> {
  const selected = emailKey(workerEmail);
  return new Set(documents.filter(document => {
    if (isInactiveRecord(document)) return false;
    const worker = ocrTaskWorker(tasks.get(document.id), documentWorkEntry(log, document.id));
    // All workers also includes the unclaimed Processing queue visible in My tasks.
    // Selecting an individual worker still requires an exact email assignment.
    return selected ? worker?.email === selected : Boolean(worker) || isWorkerProcessingDocument(document, tasks.get(document.id));
  }).map(document => document.id));
}

export function matchesIssueWorker(issue: { assignedToEmail?: string }, workerEmail = '') {
  return !workerEmail || emailKey(issue.assignedToEmail) === emailKey(workerEmail);
}
