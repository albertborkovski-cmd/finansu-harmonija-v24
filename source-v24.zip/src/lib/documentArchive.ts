import type { DbDocument } from './supabase';
import { uploadedStatus } from './uploadedDocuments';
import { ocrDocumentStage } from './ocrDocumentWorkflow';
import { ocrStatusGroup } from './ocrStatuses';

/** Approved documents and saved deliveries leave the OCR working register.
 * The existing frontend delivery simulator is supported without claiming a real ERP transfer.
 * No document, company relationship or action history is moved or removed.
 */
export function isDocumentArchived(document: Record<string, unknown>): boolean {
  const receipts = document.accounting_test_deliveries;
  if (Array.isArray(receipts) && receipts.some(receipt =>
    receipt?.sourceRegister === 'all-documents' && receipt.outcome === 'Accepted')) return true;
  if (['approved', 'confirmed', 'posted', 'transferred', 'exported', 'paid'].includes(String(document.status ?? '').trim().toLowerCase())) return true;
  if (document.manual_export_status === 'Exported') return true;
  return ['transferred_at', 'exported_at', 'external_document_id', 'external_posting_id']
    .some(key => Boolean(document[key]));
}

export function documentRegisterScope<T extends { inlineSource: Record<string, unknown> }>(
  documents: T[], globalRegister: boolean, archive: boolean,
): T[] {
  if (!globalRegister) return documents;
  return documents.filter(document => {
    if (String(document.inlineSource.entry_method ?? '').trim().toLowerCase() === 'manual') return false;
    if (isDocumentArchived(document.inlineSource) !== archive) return false;
    // Only completed OCR work belongs in the accountant's working register.
    // Processing and attention states remain in Uploaded documents / OCR queues.
    if (archive) return true;
    // Manual upload is an OCR source; explicit manual entry is Create invoice in FH.
    const source = document.inlineSource as unknown as DbDocument;
    // OCR can finish before the buyer has been assigned. Keep those invoices
    // available under No buyer, but never include unresolved errors or reruns.
    if (!source.company_id && !source.document_deletion && ocrStatusGroup(source.status) === 'Processed'
      && !ocrDocumentStage(source)) return true;
    return uploadedStatus(source) === 'Processed';
  });
}
