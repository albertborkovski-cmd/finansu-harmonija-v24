import type { DbDocument } from './supabase';
import { uploadedStatus } from './uploadedDocuments';

/** Approved documents and saved deliveries leave the OCR working register.
 * The existing frontend delivery simulator is supported without claiming a real ERP transfer.
 * No document, company relationship or action history is moved or removed.
 */
export function isDocumentArchived(document: Record<string, unknown>): boolean {
  const receipts = document.accounting_test_deliveries;
  if (Array.isArray(receipts) && receipts.some(receipt =>
    receipt?.sourceRegister === 'all-documents' && receipt.outcome === 'Accepted')) return true;
  if (['approved', 'confirmed', 'posted', 'transferred', 'exported', 'paid'].includes(String(document.status ?? '').trim().toLowerCase())) return true;
  if (document.manual_export_status === 'Exported') return true;
  return ['transferred_at', 'exported_at', 'external_document_id', 'external_posting_id']
    .some(key => Boolean(document[key]));
}

export function documentRegisterScope<T extends { inlineSource: Record<string, unknown> }>(
  documents: T[], globalRegister: boolean, archive: boolean,
): T[] {
  if (!globalRegister) return documents;
  return documents.filter(document => {
    if (String(document.inlineSource.entry_method ?? '').trim().toLowerCase() === 'manual') return false;
    if (isDocumentArchived(document.inlineSource) !== archive) return false;
    // Only completed OCR work belongs in the accountant's working register.
    // Processing and attention states remain in Uploaded documents / OCR queues.
    if (archive) return true;
    // Manual upload is an OCR source; explicit manual entry is Create invoice in FH.
    const source = document.inlineSource as unknown as DbDocument;
    // Missing organization is still an intake problem, even if a legacy record
    // contains a completed OCR status. Keep it in Uploaded documents.
    if (!source.company_id) return false;
    return uploadedStatus(source) === 'Processed';
  });
}
