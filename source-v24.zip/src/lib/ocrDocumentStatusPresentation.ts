import type { DbDocument } from './supabase';
import { awaitingTeamLead } from './ocrDocumentWorkflow';
import { OCR_STATUS_DESCRIPTIONS, OCR_STATUS_CATALOG_GROUPS, customOcrStatus, ocrStatusRecords, ocrStatusGroup, type OcrStatusGroup } from './ocrStatuses';
import { uploadedStatus, uploadedStatusGroup } from './uploadedDocuments';

/** The intake register displays individual OCR states, not dashboard groups. */
export const UPLOADED_DOCUMENT_STATUS_OPTIONS = [
  ...OCR_STATUS_CATALOG_GROUPS.flatMap(group => [...group.statuses]),
  'Inactive',
];
export function uploadedDocumentStatusOptions(documents: readonly DbDocument[] = []) {
  return [...new Set([
    ...ocrStatusRecords().filter(row => !row.inactive).map(row => row.status),
    'Inactive', ...documents.map(uploadedDocumentDisplayStatus),
  ])];
}
export function ocrDocumentStatusOptions(documents: readonly DbDocument[] = [], group?: OcrStatusGroup) {
  return [...new Set([
    ...ocrStatusRecords().filter(row => !row.inactive).map(row => row.status),
    ...documents.map(ocrDocumentRegisterStatus),
  ])].filter(status => !group || ocrStatusGroup(status) === group);
}

export function uploadedDocumentDisplayStatus(document: DbDocument) {
  const status = uploadedStatus(document);
  if (status === 'Other statuses') return document.status || 'Uploaded';
  if (status === 'Processed' && document.status?.trim().toLowerCase() === 'approved') return 'Approved';
  const custom = customOcrStatus(document.status || '');
  if (custom && document.company_id && uploadedStatusGroup(status) === custom.group
    && !document.digitization_issues?.some(issue => ['Open', 'In progress', 'Awaiting OCR'].includes(issue.status))
    && !awaitingTeamLead(document)
    && !(document.ocr_rerun_request && document.ocr_rerun_request.status !== 'Completed')) return custom.status;
  if (status !== 'Processing') return status;
  if (awaitingTeamLead(document)) return 'Awaiting TeamLead';
  if (document.digitization_issues?.some(issue => issue.status === 'Awaiting OCR')
    || (document.ocr_rerun_request && document.ocr_rerun_request.status !== 'Completed')) return 'Awaiting OCR';
  const raw = (document.status || '').trim().toLowerCase();
  if (raw === 'received') return 'Received';
  if (raw === 'queued' || raw === 'uploaded' || raw === 'submitted') return 'Queued';
  if (raw === 'awaiting ocr' || raw === 'pending ocr') return 'Awaiting OCR';
  if (raw === 'awaiting teamlead' || raw === 'awaiting approval') return 'Awaiting TeamLead';
  return status;
}

/** OCR completion and the accountant's approval are separate workflow steps. */
export function ocrDocumentRegisterStatus(document: DbDocument) {
  return uploadedDocumentDisplayStatus(document);
}

export function ocrDocumentStatusPresentation(document: DbDocument, descriptions: Record<string, string> = OCR_STATUS_DESCRIPTIONS) {
  const status = uploadedStatus(document);
  const registerStatus = ocrDocumentRegisterStatus(document);
  const detail = registerStatus;
  return {
    status,
    group: status === 'Inactive' ? status : uploadedStatusGroup(status),
    registerStatus,
    detail,
    description: detail === 'Awaiting OCR' && document.ocr_rerun_request?.source === 'Detailed digitization'
      ? 'The selected document has been returned to OCR for detailed digitization and review.'
      : detail === 'Awaiting OCR' && document.ocr_rerun_request?.source === 'Digitize anyway'
        ? 'The selected document has been returned to OCR for digitization and review.'
      : descriptions[detail]?.trim() || '',
    color: status === 'Processed' ? '#32966E' : status === 'Processing' ? '#007EA7'
      : status === 'Inactive' ? '#A1B6C6' : status === 'Exception' ? '#D64545' : '#D99420',
  };
}
