type ScrollViewport = Pick<HTMLElement, 'scrollWidth' | 'clientWidth' | 'scrollLeft'>;

/** Use the same pixel geometry for drawing, track clicks and dragging. */
export function horizontalScrollbarGeometry(viewport: ScrollViewport, trackWidth: number) {
  const width = Math.max(0, trackWidth);
  const maximum = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
  const ratio = maximum ? Math.min(1, Math.max(0, viewport.scrollLeft / maximum)) : 0;
  const visibleRatio = viewport.scrollWidth ? Math.min(1, viewport.clientWidth / viewport.scrollWidth) : 1;
  const thumbWidth = Math.min(width, Math.max(40, width * visibleRatio));
  const travel = Math.max(0, width - thumbWidth);
  return { maximum, ratio, thumbWidth, thumbLeft: ratio * travel, travel, trackWidth: width };
}

export type HorizontalScrollbarGeometry = ReturnType<typeof horizontalScrollbarGeometry>;

/** Tracks native scrolling as well as loading, column resizing and workspace expansion. */
export function observeHorizontalTableScroll(viewport: HTMLElement, track: HTMLElement, onChange: (geometry: HorizontalScrollbarGeometry) => void) {
  let frame: number | undefined;
  const update = () => onChange(horizontalScrollbarGeometry(viewport, track.clientWidth));
  const schedule = () => {
    if (frame !== undefined) return;
    frame = requestAnimationFrame(() => { frame = undefined; observeChildren(); update(); });
  };
  const sizes = new ResizeObserver(schedule);
  const children = new Set<Element>();
  const observeChildren = () => {
    for (const child of children) if (child.parentElement !== viewport) { sizes.unobserve(child); children.delete(child); }
    for (const child of viewport.children) if (!children.has(child)) { children.add(child); sizes.observe(child); }
  };
  sizes.observe(viewport);
  sizes.observe(track);
  observeChildren();
  const mutations = new MutationObserver(schedule);
  mutations.observe(viewport, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'], characterData: true });
  viewport.addEventListener('scroll', update, { passive: true });
  update();
  return () => {
    viewport.removeEventListener('scroll', update);
    sizes.disconnect(); mutations.disconnect();
    if (frame !== undefined) cancelAnimationFrame(frame);
  };
}
