import type { ColConfig } from '../components/ColumnSettingsPanel';
import { processingColumns } from './ocrProcessingDocuments';
import { teamLeadColumns } from './ocrTeamLeadReview';
import { documentTypeColumns } from './documentTypeCatalog';

export const DEFAULT_COLUMNS: ColConfig[] = documentTypeColumns([
  { key: "status", label: "Status", width: 150, visible: true },
  { key: "receiveDate", label: "Receive date", width: 150, visible: true },
  { key: "clientCounterparty", label: "Counterparty", width: 210, visible: true },
  { key: "counterpartyCode", label: "Counterparty code", width: 175, visible: true },
  { key: "documentType", label: "Document type", width: 180, visible: true },
  { key: "source", label: "Source", width: 140, visible: true },
  { key: "totalAmount", label: "Total amount", width: 150, visible: true },
  { key: "amountWithoutVat", label: "Amount without VAT", width: 170, visible: true },
  { key: "vat", label: "VAT", width: 130, visible: true },
  { key: "vatPercent", label: "VAT %", width: 130, visible: true },
  { key: "dueEndDate", label: "Due/End date", width: 150, visible: true },
  { key: "fileCase", label: "File/Case", width: 210, visible: true },
  { key: "orderNo", label: "Order No.", width: 150, visible: true },
  { key: "number", label: "Document Number", width: 160, visible: true },
  { key: "documentDate", label: "Document date", width: 160, visible: true },
  { key: "documentPurpose", label: "Document purpose", width: 190, visible: true },
  { key: "invoiceContractDate", label: "Invoice/Contract date", width: 200, visible: true },
  { key: "operationDate", label: "Operation date", width: 170, visible: true },
  { key: "glAccount", label: "GL account", width: 150, visible: true },
  { key: "vatClassifier", label: "VAT classifier", width: 165, visible: true },
  { key: "productGroup", label: "Product Group", width: 170, visible: true },
  { key: "currency", label: "Currency", width: 130, visible: true },
]);

export const PROCESSING_COLUMNS = processingColumns(DEFAULT_COLUMNS);

export const REVIEW_COLUMNS: ColConfig[] = [
  { key: "organization", label: "Organizations", width: 190, visible: true },
  ...DEFAULT_COLUMNS,
  { key: "series", label: "Series", width: 130, visible: true },
  { key: "costCenter", label: "Cost center", width: 150, visible: true },
  { key: "objectProject", label: "Object/Project", width: 170, visible: true },
  { key: "departmentCode", label: "Department code", width: 175, visible: true },
];

export const TEAM_LEAD_COLUMNS = teamLeadColumns(REVIEW_COLUMNS);
