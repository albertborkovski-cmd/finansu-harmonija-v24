import { exportSections, type ExportField } from './exportFormatSchemas';

export function exportHelpHref(format: string, topic = 'overview') {
  return `./#help/export?${new URLSearchParams({ format, topic }).toString()}`;
}

/** Local FH guidance: no company data, credentials or third-party help links. */
export function exportFieldHelp(field: ExportField, lt: boolean): string {
  const descriptions: Record<string, [string, string]> = {
    individualBuyerCode: ['Choose a unique code for each individual buyer, or use one fixed code for all individual buyers.', 'Pasirinkite unikalų kodą kiekvienam fiziniam pirkėjui arba vieną fiksuotą kodą visiems fiziniams pirkėjams.'],
    fixedBuyerCode: ['Enter the buyer code that already exists in the destination accounting system. It is required when Fixed value is selected.', 'Įveskite apskaitos sistemoje naudojamą fizinio pirkėjo kodą. Jis privalomas pasirinkus fiksuotą reikšmę.'],
    primaryLineCode: ['Choose Barcode or Code. When Barcode is selected and the invoice line has no barcode, the line code is used.', 'Pasirinkite barkodą arba kodą. Pasirinkus barkodą, bet sąskaitos eilutėje jo nesant, naudojamas eilutės kodas.'],
    additionalColumnsAt: ['Choose when automatic defaults should fill empty fields: during digitization or during export. Existing manually entered values are retained.', 'Pasirinkite, kada automatinės numatytosios reikšmės pildo tuščius laukus: skaitmeninimo ar eksportavimo metu. Jau įvestos reikšmės nekeičiamos.'],
    vatSeparation: ['Choose automatic VAT handling, separation for non-VAT payers, or no separation for VAT payers. Align this option with the destination system setup.', 'Pasirinkite automatinį PVM išskyrimą, PVM išskyrimą ne PVM mokėtojams arba PVM neišskyrimą PVM mokėtojams. Suderinkite su apskaitos sistemos nustatymais.'],
    foreignVatAsCompanyCode: ['For foreign companies, use the VAT number in the company-code field of the export.', 'Užsienio įmonėms eksportuojamo įmonės kodo lauke naudojamas PVM kodas.'],
    dueDateFromInvoiceDate: ['If the invoice has no due date, use its invoice date. A due date already present on the document is not replaced.', 'Jei sąskaitoje nenurodyta mokėjimo data, naudojama sąskaitos data. Esama mokėjimo data nekeičiama.'],
    salesOperation: ['Select the sales operation type expected in Rivilė: Waybill, Order, Reservation or Offer.', 'Pasirinkite Rivilėje naudojamą pardavimo operacijos tipą: važtaraštis, užsakymas, rezervavimas arba pasiūlymas.'],
    purchaseOperation: ['Select the purchase operation type expected in Rivilė: Waybill, Order or Offer.', 'Pasirinkite Rivilėje naudojamą pirkimo operacijos tipą: važtaraštis, užsakymas arba pasiūlymas.'],
    ignoreNonPositive: ['Exclude invoice lines whose amount is zero or negative from the export. Review credit invoices before enabling this option.', 'Į eksportą neįtraukiamos eilutės, kurių suma lygi 0 arba neigiama. Prieš įjungdami įvertinkite kreditinių sąskaitų eksportą.'],
    exportAfterDigitization: ['This preference requests export after digitization. Automatic delivery requires a connected integration and document validation; this frontend does not send documents to an external system.', 'Ši parinktis numato eksportą po skaitmeninimo. Automatiniam perdavimui reikalinga prijungta integracija ir dokumento validacija; ši frontend versija į išorinę sistemą dokumentų nesiunčia.'],
    postInRivile: ['Controls whether the integration should post the document in Rivilė after creating it. This setting alone does not connect or execute an integration.', 'Nurodo, ar integracija turėtų perkelti sukurtą dokumentą Rivilėje. Vien šis nustatymas neprijungia ir nepaleidžia integracijos.'],
    importAttachments: ['Include document attachments when exporting to Optimum. Actual attachment transfer requires a configured integration.', 'Eksportuojant į Optimum įtraukiami dokumento priedai. Tikram priedų perdavimui reikalinga prijungta integracija.'],
    exportEmail: ['Enter the destination address for exported documents. Saving the address does not send an email.', 'Įveskite adresą eksportuojamiems dokumentams. Išsaugojus adresą el. laiškas nesiunčiamas.'],
    externalRawMaterialsOnly: ['Limit the product search to external raw materials in Syrve.', 'Prekių paieška ribojama tik išorinėmis žaliavomis Syrve sistemoje.'],
    recalculateItemQuantity: ['Use the quantity conversion configured on the Syrve item card.', 'Kiekio perskaičiavimui naudojami Syrve prekės kortelės nustatymai.'],
    reverseSummaryCreditDirection: ['For summary credit invoices, switch purchase and sale direction in the export. Original OCR document data stays unchanged.', 'Eksportuojant sumines kreditines sąskaitas pirkimo kryptis keičiama į pardavimo ir atvirkščiai. Originalūs OCR duomenys nekeičiami.'],
    reverseDetailedCreditDirection: ['For detailed credit invoices, switch purchase and sale direction in the export. Original OCR document data stays unchanged.', 'Eksportuojant detalias kreditines sąskaitas pirkimo kryptis keičiama į pardavimo ir atvirkščiai. Originalūs OCR duomenys nekeičiami.'],
    negativeSummaryCredit: ['Use negative amounts in exported summary credit invoices. This does not reverse or modify the original document.', 'Eksportuojamose suminėse kreditinėse sąskaitose naudojamos neigiamos sumos. Originalus dokumentas nestornuojamas ir nekeičiamas.'],
    negativeQuantityCredit: ['Use negative amounts in exported quantity credit invoices. This does not reverse or modify the original document.', 'Eksportuojamose kiekinėse kreditinėse sąskaitose naudojamos neigiamos sumos. Originalus dokumentas nestornuojamas ir nekeičiamas.'],
  };
  if (descriptions[field.key]) return descriptions[field.key][lt ? 1 : 0];
  if (field.type === 'password') return lt ? 'Raktą ar slaptažodį suteikia apskaitos sistemos administratorius. „Finansų harmonija“ demonstracinėje aplinkoje įvesti prisijungimo duomenys neišsaugomi ir nesiunčiami. Nenaudokite produkcinių raktų.' : 'Your accounting-system administrator supplies this credential. Credentials entered in the Finansų harmonija frontend are not saved or sent. Do not use production keys.';
  if (/url/i.test(field.key)) return lt ? 'Įveskite integracijos administratoriaus pateiktą paslaugos adresą. Nustatymo išsaugojimas neatlieka prisijungimo ir nesiunčia dokumentų.' : 'Enter the service address supplied by the integration administrator. Saving this setting does not connect to the service or send documents.';
  if (field.type === 'checkbox') return lt ? 'Įjunkite, jei pasirinktai apskaitos sistemai turi būti taikoma ši eksporto taisyklė. Parinktis saugoma tik šios organizacijos ir šio eksporto formato nustatymuose.' : 'Enable this export rule when needed by the selected accounting system. The preference is stored only for this organization and export format.';
  if (field.type === 'number') return lt ? 'Įveskite neneigiamą skaitinę reikšmę pagal apskaitos sistemos nustatymus. Tuščias laukas reiškia, kad atskira reikšmė nenurodyta.' : 'Enter a non-negative number matching the accounting-system setup. Leave empty when no explicit value is required.';
  return lt ? 'Įveskite atitinkamą kodą ar reikšmę iš pasirinktos apskaitos sistemos. Ji saugoma šios organizacijos pasirinkto eksporto formato nustatymuose; kitų organizacijų nustatymai nesikeičia.' : 'Enter the corresponding code or value from the selected accounting system. It is stored for this organization and export format; other organizations are unaffected.';
}

export function exportHelpFields(format: string, topic: string) {
  const sections = exportSections(format);
  const field = sections.flatMap(section => section.fields).find(item => item.key === topic);
  if (field) return [field];
  return (sections.find(section => section.title === topic)?.fields || sections.flatMap(section => section.fields));
}
