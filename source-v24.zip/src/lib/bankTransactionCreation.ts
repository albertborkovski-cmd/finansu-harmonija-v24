import type { Company, DbDocument } from './supabase';
import { bankTransactionSnapshot, validateBankTransaction, type BankTransaction, type BankValidationOptions } from './bankTransaction';
import { canEditCompanyBankEntries } from './companyBankEditing';
import { canCreateCompanyDocument } from './documentRowActionAccess';
import { isInactiveRecord } from './recordLifecycle';

export function canCreateCompanyBankTransaction(company: Company) {
  return !isInactiveRecord(company) && canEditCompanyBankEntries(company) && canCreateCompanyDocument(company);
}

/** An unsaved manual bank record. Opening/closing the form never writes a record. */
export function newBankTransactionDocument(company: Company, id: string, date = ''): DbDocument {
  const bank: BankTransaction = { version: 1, date, bankAccount: '',
    counterpartyId: '', counterpartyName: '', counterpartyCode: '', counterpartyIban: '', paymentPurpose: '', amount: '',
    currency: '', exchangeRateDate: date, referenceNo: '', transferNo: '', originalStatement: '', notes: '',
    allocations: [{ id: `${id}:allocation:1`, description: 'Other transaction', glAccount: '', department: '', project: '', costCenter: '', amount: '' }], attachments: [] };
  return { id, company_id: company.id, bank_transaction: bank, bank_processing_status: 'New', source: 'Manual bank entry',
    document_type: 'Bank transaction', document_subtype: '', receive_date: date, client_counterparty: '', counterparty_id: '', counterparty_code: '',
    total_amount: '', due_end_date: '', file_case: '', order_no: '', number: '', type: 'Bank', document_date: date, document_purpose: '',
    invoice_contract_date: '', operation_date: date, expense_account: '', vat_classifier: '', currency: bank.currency,
    amount_without_vat: '', vat: '0', vat_percent: '0', department_code: '', object_project: '', valid_form: '',
    accountable_responsible: '', cost_center: '', series: '', status: 'Draft', created_at: '', image_url: null };
}

export function prepareNewBankTransaction(company: Company, id: string, draft: BankTransaction, options: BankValidationOptions, at: string, actor: string): DbDocument {
  if (!options.allowed || isInactiveRecord(company)) throw new Error('You do not have permission to create this company’s bank transactions.');
  if (!id || !draft || typeof draft.date !== 'string') throw new Error('Invalid new bank transaction.');
  const blank = newBankTransactionDocument(company, id, draft.date).bank_transaction!;
  if (Object.keys(draft).some(key => !Object.hasOwn(blank, key))) throw new Error('Invalid new bank transaction data.');
  if (!draft.bankAccount || !options.accountIbans.includes(draft.bankAccount)) throw new Error('Select an active bank account belonging to this company.');
  if (typeof draft.counterpartyName !== 'string' || !draft.counterpartyName.trim()) throw new Error('Enter a counterparty name.');
  if (draft.counterpartyId && !options.counterparties.some(row => row.id === draft.counterpartyId && row.name === draft.counterpartyName && (row.company_code || '') === draft.counterpartyCode)) throw new Error('Select a counterparty belonging to this company.');
  if (typeof draft.paymentPurpose !== 'string' || !draft.paymentPurpose.trim()) throw new Error('Enter the purpose of payment.');
  if (draft.originalStatement !== '') throw new Error('A manual entry cannot contain imported statement text.');
  if (!Array.isArray(draft.allocations) || draft.allocations.some(row => !options.glAccounts.includes(row.glAccount))) throw new Error('Select active GL accounts from this company’s chart of accounts.');
  const source = { ...newBankTransactionDocument(company, id, draft.date), bank_transaction: structuredClone(draft) };
  const bank = validateBankTransaction(source, company, draft, bankTransactionSnapshot(source), options);
  const number = bank.referenceNo.trim() || `BANK-${id.slice(0, 8).toUpperCase()}`;
  bank.transferNo = bank.transferNo.trim() || number;
  return { ...source, bank_transaction: bank, number, order_no: bank.transferNo, created_at: at, created_by: actor,
    client_counterparty: bank.counterpartyName, counterparty_id: bank.counterpartyId, counterparty_code: bank.counterpartyCode,
    total_amount: bank.amount, amount_without_vat: bank.amount, currency: bank.currency,
    document_purpose: bank.paymentPurpose, notes: bank.notes };
}
