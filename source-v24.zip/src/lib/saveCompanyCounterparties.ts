import { supabase, type Company } from './supabase';
import { canEditCompanySettings } from './documentEditAccess';
import { isInactiveRecord } from './recordLifecycle';
import { companyCounterpartiesKey } from './organizationDirectory';
import { getCurrentUserName } from './currentUser';
import { prepareCompanyCounterparties, type CounterpartyDraft } from './companyCounterpartyImport';

/** Append only to this organization's directory, validating again immediately before writing. */
export async function saveCompanyCounterparties(companyId: string, rows: CounterpartyDraft[]): Promise<number> {
  const { data, error } = await supabase.from('companies').select('*').eq('id', companyId);
  if (error) throw error;
  const company = data?.[0] as unknown as Company | undefined;
  if (!company || !canEditCompanySettings(company) || isInactiveRecord(company)) throw new Error('You do not have permission to change this organization’s counterparties.');
  const storageKey = companyCounterpartiesKey(companyId);
  let current: unknown;
  try { current = JSON.parse(window.localStorage.getItem(storageKey) || '[]'); }
  catch { throw new Error('Could not read organization counterparties. No companies were added.'); }
  if (!Array.isArray(current) || current.some(row => !row || typeof row.id !== 'string' || typeof row.name !== 'string')) throw new Error('Could not read organization counterparties. No companies were added.');
  const additions = prepareCompanyCounterparties(rows, current, getCurrentUserName(), new Date().toISOString(), () => crypto.randomUUID());
  window.localStorage.setItem(storageKey, JSON.stringify([...current, ...additions]));
  window.dispatchEvent(new CustomEvent('counterparties-updated', { detail: { companyId } }));
  return additions.length;
}
