import type { DbDocument } from './supabase';
import { isInactiveRecord } from './recordLifecycle';
import { isDocumentArchived } from './documentArchive';
import { ocrNeedsAttention } from './ocrDocumentWorkflow';
import type { DocumentIssueOcrRequest } from './documentIssues';

export function digitizeAnywayBlocker(document: DbDocument, allowed: boolean): string {
  if (!allowed) return 'You need View and Edit access to Documents and access to this company.';
  if (document.document_deletion || isInactiveRecord(document)) return 'Restore this document before sending it to OCR.';
  if (document.entry_method === 'manual' || isDocumentArchived(document as unknown as Record<string, unknown>)) return 'Only unresolved uploaded documents can be digitized again.';
  if (!document.company_id) return 'Assign an organization before sending this document to OCR.';
  if (document.digitization_issues?.some(issue => ['Open', 'In progress', 'Awaiting OCR'].includes(issue.status))) return 'The Worker must finish correcting the reported issue before OCR reprocessing.';
  if (document.ocr_rerun_request && document.ocr_rerun_request.status !== 'Completed') return 'This document is already queued for OCR.';
  if (!ocrNeedsAttention(document)) return 'Only unresolved uploaded documents can be digitized again.';
  return '';
}

export function requestDigitizeAnyway(document: DbDocument, context: { allowed: boolean; actor: string; at: string; requestId: string }): DbDocument {
  const error = digitizeAnywayBlocker(document, context.allowed);
  if (error) throw new Error(error);
  if (document.ocr_rerun_requests !== undefined && !Array.isArray(document.ocr_rerun_requests)) throw new Error('OCR request history is invalid. It was not overwritten.');
  const request: DocumentIssueOcrRequest = {
    id: context.requestId, documentId: document.id, companyId: document.company_id || '',
    requestedAt: context.at, requestedBy: context.actor, status: 'Pending integration', source: 'Digitize anyway',
    reason: `Digitize anyway requested from Uploaded documents. Previous status: ${document.status}.`,
  };
  const history = [...(document.ocr_rerun_requests || [])];
  if (document.ocr_rerun_request && !history.some(item => item.id === document.ocr_rerun_request?.id)) history.push(document.ocr_rerun_request);
  return { ...document, status: 'Processing', ocr_rerun_request: request, ocr_rerun_requests: [...history, request] };
}
