import type { DbDocument } from './supabase';
import type { AttentionNotification, NotificationRow } from './notifications';
import type { DocumentIssue } from './documentIssues';
import type { IssueConversationSide } from './documentIssueConversation';
import { unreadIssueMessages } from './documentIssueConversation';
import { awaitingTeamLead, ocrDocumentStage } from './ocrDocumentWorkflow';
import { uploadedStatus } from './uploadedDocuments';
import type { WorkspaceTask } from '../components/WorkspaceView';

export interface OcrNotificationAccess {
  email: string;
  canView: (document: DbDocument) => boolean;
  canReviewIssue: (document: DbDocument) => boolean;
  canReviewTeamLead: (document: DbDocument) => boolean;
  companyName: (id: string) => string;
}
export function issueViewerSide(issue: DocumentIssue, email: string, worker: boolean): IssueConversationSide {
  return issue.createdByEmail?.toLowerCase() === email.toLowerCase() || !worker ? 'accountant' : 'worker';
}

/** Signals follow their source; reading a notification never resolves a document problem. */
export function buildOcrNotifications(documents: readonly DbDocument[], tasks: ReadonlyMap<string, WorkspaceTask | undefined>, access: OcrNotificationAccess): AttentionNotification[] {
  const rows: AttentionNotification[] = [];
  for (const document of documents) {
    if (!access.canView(document) || document.entry_method === 'manual' || document.document_deletion
      || ['deleted', 'inactive', 'deactivated'].includes(document.status?.toLowerCase())) continue;
    const name = document.number || document.file_case || document.id;
    const add = (key: string, title: string, severity: NotificationRow['severity'], view: NonNullable<NotificationRow['ocrTarget']>['view'], details: string,
      at = document.created_at, issueId?: string, resolved = false) => {
      rows.push({ id: `ocr:${document.id}:${key}`, workspace: 'ocr', category: 'notifications', origin: 'system', type: view === 'chat' ? 'Chat' : 'OCR',
        name: title, message: details, severity, createdAt: at || undefined, status: resolved ? 'Inactive' : 'Active',
        notificationStatus: resolved ? 'Resolved' : 'Active', requiresAction: !resolved, recipientEmails: [access.email],
        eventKind: severity === 'Critical' ? 'process-error' : severity === 'Warning' ? 'process-exception' : 'information',
        organizationId: document.company_id || undefined, organizationName: document.company_id ? access.companyName(document.company_id) : 'No buyer',
        ocrTarget: { documentId: document.id, issueId, view },
        relatedObject: { id: document.id, recordId: document.id, type: 'Document', organizationId: document.company_id || '', label: name },
      });
    };
    const issues = document.digitization_issues || [];
    for (const issue of issues) {
      const worker = access.canReviewIssue(document);
      const side = issueViewerSide(issue, access.email, worker);
      const assignedHere = !issue.assignedToEmail || issue.assignedToEmail.toLowerCase() === access.email.toLowerCase();
      if (worker && assignedHere && side === 'worker') add(`issue:${issue.id}`, 'Document issue received', 'Warning', 'issue', issue.message,
        issue.createdAt, issue.id, issue.status === 'Resolved');
      const incoming = (issue.messages || []).filter(message => message.authorEmail.toLowerCase() !== access.email.toLowerCase() && message.authorSide !== side);
      const unread = new Set(unreadIssueMessages(issue, access.email, side).map(message => message.id));
      if (side === 'accountant' || assignedHere) for (const message of incoming) add(`message:${message.id}`, 'New issue conversation message', 'Info', 'chat',
        `${message.author}: ${message.text}`, message.sentAt, issue.id, !unread.has(message.id));
    }
    if (!document.company_id) add('organization', 'Document has no organization', 'Warning', 'uploaded', name);
    const task = tasks.get(document.id);
    if (access.canReviewTeamLead(document) && (awaitingTeamLead(document, task) || ocrDocumentStage(document, task)?.queue === 'approval'))
      add('teamlead', 'Worker requested TeamLead review', 'Warning', 'teamlead', task?.teamLeadReview?.comment || name,
        task?.teamLeadReview?.requestedAt || document.ocr_approval_route?.completedAt || document.created_at);
    // Reported issues have their own Warning signal, not a duplicate Critical alert.
    if (issues.some(issue => issue.status !== 'Resolved')) continue;
    const status = uploadedStatus(document);
    if (status === 'Exception') add('exception', 'OCR processing exception', 'Critical', 'uploaded', document.notes || name);
    if (status === 'Duplicate') add('duplicate', 'Duplicate document received', 'Info', 'uploaded', name);
    if (status === 'Not document') add('not-document', 'Received file is not a document', 'Info', 'uploaded', name);
  }
  return rows;
}
