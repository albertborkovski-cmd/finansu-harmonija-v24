import { canEditMenu, canViewMenu, parseSession, resolveSessionForEmail } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization, hasOrganizationSubstitution, isAccountantAssigned, loadLinkedDirectoryUsers, loadOrganizationUserIds, organizationAssignmentStorageKey, type LinkedOrganization, type SettingsAudience } from './linkedSettingsData';
import { registerChatConversation, type InvoiceChatContext } from '../components/invoices/invoiceChat';
import { loadRelatedObjects } from './relatedObjects';
import { OCR_CHAT_REGISTERS, loadOcrChatRelatedObjects, matchesChatRelatedModule, type ChatRelatedObject } from './ocrChatRelatedObjects';

export async function chatRelatedObjects(organization: LinkedOrganization, ocrOnly = false): Promise<ChatRelatedObject[]> {
  const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
  if (!session || !canViewMenu(session, 'messages') || !canAccessAssignedOrganization(organization, session)) return [];
  const [objects, ocrObjects] = await Promise.all([
    !ocrOnly && session.access.companies.view ? loadRelatedObjects(organization, session) : Promise.resolve([]),
    loadOcrChatRelatedObjects(organization, session),
  ]);
  const freshSession = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
  if (!freshSession || freshSession.email !== session.email || !canViewMenu(freshSession, 'messages') || !canAccessAssignedOrganization(organization, freshSession)) return [];
  const result: ChatRelatedObject[] = (freshSession.access.companies.view ? objects : []).flatMap(object => {
    if (object.type === 'Document' || object.type === 'Invoice' || object.type === 'Bank operation' || object.type === 'Reconciliation' || object.type === 'Debt') {
      return [{ ...object, type: object.type }];
    }
    return [];
  });
  for (const object of ocrObjects) {
    const ocrRegisters = object.ocrRegisters?.filter(value => OCR_CHAT_REGISTERS.some(register => register.value === value && canViewMenu(freshSession, register.menu))) ?? [];
    if (!ocrRegisters.length) continue;
    const existing = result.find(item => item.id === object.id);
    if (existing) existing.ocrRegisters = ocrRegisters;
    else result.push({ ...object, ocrRegisters });
  }
  return result;
}

export function chatTargetAudience(currentEmail: string): SettingsAudience | null {
  const email = currentEmail.trim().toLowerCase();
  if (!email) return null;
  for (const audience of ['Internal users', 'External users'] as SettingsAudience[]) {
    if (loadLinkedDirectoryUsers(audience).some(user => user.email?.trim().toLowerCase() === email)) {
      return audience === 'Internal users' ? 'External users' : 'Internal users';
    }
  }
  const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
  return session?.email.trim().toLowerCase() === email && session.roleNames.some(role => ['administrator', 'administration', 'meso accountant'].includes(role.toLowerCase())) ? 'External users' : null;
}

export function chatRecipients(organization: LinkedOrganization, currentEmail: string) {
  const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
  if (!session || session.email.toLowerCase() !== currentEmail.toLowerCase() || !canAccessAssignedOrganization(organization, session)) return [];
  const demo = session.roleNames.includes('External demo user');
  const target = chatTargetAudience(currentEmail);
  const audiences: SettingsAudience[] = demo || target === 'External users' ? ['External users', 'Internal users'] : target ? [target] : [];
  return audiences.flatMap(audience => {
    const assigned = loadOrganizationUserIds(organization.id, audience);
    const hasExplicit = window.localStorage.getItem(organizationAssignmentStorageKey(organization.id, audience)) !== null;
    return loadLinkedDirectoryUsers(audience).filter(user => {
      if (!user.email || user.email.toLowerCase() === currentEmail.toLowerCase() || (user.status && !['enabled', 'active'].includes(user.status.toLowerCase()))) return false;
      if (demo) return true;
      if (assigned.includes(user.id)) return true;
      if (audience === 'Internal users' && (isAccountantAssigned(organization, user) || hasOrganizationSubstitution(organization.id, user.id))) return true;
      return !hasExplicit && (user.organizations?.toLowerCase() === 'all organizations' || user.organizations?.split(',').some(name => [organization.id.toLowerCase(), organization.name.toLowerCase()].includes(name.trim().toLowerCase())));
    }).map(user => ({ id: `${audience}:${user.id}`, email: user.email!, name: user.fullName || user.username || user.email!, audience }));
  });
}

export function chatWorkerRecipients(organization: LinkedOrganization, currentEmail: string) {
  return chatRecipients(organization, currentEmail).filter(user => user.audience === 'Internal users'
    && canEditMenu(resolveSessionForEmail(user.email), 'ocr-workspace'));
}

export async function createContextChat(organization: LinkedOrganization | undefined, recipientId: string, relatedObjectId = '', topic = '', ocrOnly = false, relatedModule = ''): Promise<InvoiceChatContext> {
  const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
  if (!session || !canEditMenu(session, 'messages')) throw new Error('You do not have permission to start a chat.');
  if (!organization || !canAccessAssignedOrganization(organization, session)) throw new Error('Select an available organization.');
  const isAi = recipientId === 'fh-ai';
  const recipient = isAi ? { id: 'fh-ai', name: 'FH AI', email: undefined, audience: undefined }
    : (ocrOnly ? chatWorkerRecipients(organization, session.email) : chatRecipients(organization, session.email)).find(user => user.id === recipientId);
  if (!recipient) throw new Error('Select a participant assigned to this organization.');
  const selectedObject = relatedObjectId ? (await chatRelatedObjects(organization, ocrOnly)).find(object => object.id === relatedObjectId && (!relatedModule || matchesChatRelatedModule(object, relatedModule))) : undefined;
  if (relatedObjectId && !selectedObject) throw new Error('The related object is no longer available in this organization.');
  const freshSession = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
  if (!freshSession || freshSession.email !== session.email || !canEditMenu(freshSession, 'messages') || !canAccessAssignedOrganization(organization, freshSession)) throw new Error('You do not have permission to start a chat.');
  if (!isAi && !(ocrOnly ? chatWorkerRecipients(organization, freshSession.email) : chatRecipients(organization, freshSession.email)).some(user => user.id === recipientId)) throw new Error('Select a participant assigned to this organization.');
  // Register metadata is a live filter, not part of the document identity.
  const relatedObject = selectedObject ? { id: selectedObject.id, organizationId: selectedObject.organizationId, type: selectedObject.type, label: selectedObject.label } : undefined;
  const subject = topic.trim() || relatedObject?.label.trim() || '';
  if (!subject) throw new Error('Enter a Subject or select a related record.');
  const context: InvoiceChatContext = {
    workspace: ocrOnly || relatedModule.startsWith('ocr-') ? 'ocr' : 'fh',
    storageKey: `organization-chat:${organization.id}:${crypto.randomUUID()}`,
    organizationId: organization.id,
    companyName: organization.name,
    title: `${organization.name} / ${subject}`,
    subject,
    sourceType: 'Topic',
    recipientId: recipient.id,
    recipientEmail: recipient.email,
    recipientName: recipient.name,
    createdByEmail: session.email,
    createdByName: session.fullName,
    participantType: isAi ? 'FH AI' : ocrOnly ? 'Worker' : recipient.audience === 'External users' ? 'Client' : 'MESO accountant',
    aiEnabled: isAi,
    relatedObject,
  };
  registerChatConversation(context);
  return context;
}
