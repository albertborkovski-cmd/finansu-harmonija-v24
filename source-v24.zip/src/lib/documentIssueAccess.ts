import { canEditMenu, canViewMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization, loadLinkedDirectoryUsers } from './linkedSettingsData';
import { canEditCompanyDocumentIssues, canEditCompanyDocuments, canViewCompanyDocuments } from './documentEditAccess';
import type { IssueConversationSide } from './documentIssueConversation';

export function documentIssueSession() {
  return parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
}
export function canReviewDocumentIssues() {
  const session = documentIssueSession();
  if (!session || !canEditMenu(session, 'ocr-workspace-document-issues')) return false;
  const external = loadLinkedDirectoryUsers('External users').some(user => user.email?.toLowerCase() === session.email.toLowerCase());
  return !external && !session.roleNames.includes('External demo user');
}
export function canAccessIssueOrganization(organization: { id: string; name: string; assigned_accountant?: string }, edit = false) {
  const session = documentIssueSession();
  return Boolean(session && canAccessAssignedOrganization(organization, session) &&
    (canReviewDocumentIssues() || (edit ? canEditMenu(session, 'documents') : canViewMenu(session, 'documents'))));
}

export function canUseIssueConversation(organization: { id: string; name: string; assigned_accountant?: string }, side: IssueConversationSide, edit = false) {
  const session = documentIssueSession();
  const teamLead = session && (edit ? canEditMenu(session, 'ocr-ml') : canViewMenu(session, 'ocr-ml'))
    && !session.roleNames.includes('External demo user')
    && !loadLinkedDirectoryUsers('External users').some(user => user.email?.toLowerCase() === session.email.toLowerCase());
  if (side === 'worker' && teamLead && canAccessAssignedOrganization(organization, session)) return true;
  return canAccessIssueOrganization(organization, edit) && (side === 'worker'
    ? canReviewDocumentIssues() && canEditCompanyDocumentIssues(organization)
    : edit ? canEditCompanyDocuments(organization) : canViewCompanyDocuments(organization));
}
