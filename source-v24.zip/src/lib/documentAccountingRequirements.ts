import type { Company } from './supabase';
import type { InlineDocumentSource } from './documentInlineEditing';
import { ADDITIONAL_DOCUMENT_COLUMNS, organizationAdditionalColumnRules, type AdditionalDocumentColumn } from './documentAdditionalColumns';

export const ACCOUNTING_REQUIREMENT_COLUMNS = ['departmentCode', 'objectProject', 'costCenter', 'series', 'productGroup'] as const;
export type AccountingRequirementColumn = typeof ACCOUNTING_REQUIREMENT_COLUMNS[number];

export function companyOcrAdditionalColumnRequirements(company?: Company): Set<AdditionalDocumentColumn> {
  const rules = organizationAdditionalColumnRules(company as unknown as Record<string, unknown>);
  return new Set(ADDITIONAL_DOCUMENT_COLUMNS.filter(column => rules[column.key].required).map(column => column.key));
}

/** Matches the Required checkbox stored by the company accounting code editor. */
function required(value?: string): boolean {
  if (!value?.trim()) return false;
  try {
    const config = JSON.parse(value);
    return Boolean(config && typeof config === 'object' && Array.isArray(config.items) && config.enabled);
  } catch {
    // Older company settings stored enabled code lists as comma-separated text.
    return !/^[\[{]/.test(value.trim()) && value.split(',').some(code => code.trim());
  }
}

export function companyAccountingRequirements(company?: Company): Set<AccountingRequirementColumn> {
  const fields = new Set<AccountingRequirementColumn>();
  if (!company) return fields;
  if (required(company.department_codes)) fields.add('departmentCode');
  if (required(company.objects) || required(company.projects)) fields.add('objectProject');
  if (required(company.cost_centers)) fields.add('costCenter');
  if (required(company.document_series)) fields.add('series');
  if (required(company.product_groups)) fields.add('productGroup');
  return fields;
}

const filled = (value: unknown) => !['', '—', '-'].includes(String(value ?? '').trim());

/** Check accounting allocations, not OCR item rows or the collapsed cell label. */
export function missingDocumentAccountingFields(document: InlineDocumentSource, requiredFields?: ReadonlySet<AdditionalDocumentColumn>): Set<AdditionalDocumentColumn> {
  const missing = new Set<AdditionalDocumentColumn>();
  if (!requiredFields) return missing;
  for (const field of requiredFields) {
    const column = ADDITIONAL_DOCUMENT_COLUMNS.find(column => column.key === field);
    if (!column) continue;
    if (!column.line) { if (!filled(document[column.header]) && !(field === 'accountableResponsible' && filled(document.accountable_responsible_id))) missing.add(field); continue; }
    const { header, line } = column;
    const rows = document.summary_line_items;
    if (rows == null || (Array.isArray(rows) && rows.length === 0)) {
      if (!filled(document[header])) missing.add(field);
    } else if (!Array.isArray(rows) || rows.some(row => !row || !filled(row[line]))) missing.add(field);
  }
  return missing;
}
