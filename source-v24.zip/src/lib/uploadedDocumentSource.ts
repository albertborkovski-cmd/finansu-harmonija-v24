/** Provenance captured when a document arrives, not its accounting author. */
export interface DocumentSourceDetails {
  senderEmail?: string;
  folderPath?: string;
  siteUrl?: string;
  location?: string;
  uploadedBy?: string;
  uploadedByEmail?: string;
  uploadedById?: string;
  uploadedByRoles?: string[];
  integrationName?: string;
  reference?: string;
}

type SourceDocument = {
  source?: string;
  created_by?: string;
  source_details?: DocumentSourceDetails;
};

const text = (value: unknown) => typeof value === 'string' ? value.trim() : '';
const join = (...values: string[]) => [...new Set(values.filter(Boolean))].join(' · ');

/** Display an origin path, never a signed URL's credentials/query/fragment. */
function location(value: unknown): string {
  const raw = text(value);
  if (!/^https?:\/\//i.test(raw)) return raw;
  try {
    const url = new URL(raw);
    let path = url.pathname;
    try { path = decodeURIComponent(path); } catch { /* Retain the saved path. */ }
    return `${url.origin}${path}`;
  } catch { return ''; }
}

export function uploadedDocumentSource(document: SourceDocument, translateRole: (role: string) => string = role => role): { type: string; detail: string } {
  const raw = text(document.source);
  // Older intake records may contain both values in a single source string.
  const combined = raw.match(/^(email|mail|sharepoint|dropbox|google[\s_-]*drive)\s*(?:[:·–—-]\s*|(?=\/))(.+)$/i);
  const channel = combined?.[1] || raw;
  const savedOrigin = text(combined?.[2]);
  const normalized = channel.toLowerCase().replace(/[\s_-]+/g, '');
  const details = document.source_details ?? {};
  const emailSource = !combined && /^[^\s<>@]+@[^\s<>@]+\.[^\s<>@]+$/.test(raw);
  const type = emailSource || ['email', 'mail'].includes(normalized) ? 'Email'
    : normalized.includes('sharepoint') ? 'SharePoint'
    : normalized.includes('dropbox') ? 'Dropbox'
    : ['googledrive', 'drive'].includes(normalized) ? 'Google Drive'
    : ['manual', 'manualentry', 'upload', 'dashboardupload', 'fileupload'].includes(normalized) ? 'Manual'
    : normalized === 'api' ? 'API' : raw || '—';

  if (type === 'Email') {
    // created_by may be the accountant/worker; it is not evidence of the sender.
    return { type, detail: text(details.senderEmail) || savedOrigin || (emailSource ? raw : '') || '—' };
  }
  if (['SharePoint', 'Dropbox', 'Google Drive'].includes(type)) {
    const folder = location(details.folderPath || details.location || savedOrigin);
    const site = location(details.siteUrl);
    return { type, detail: (/^https?:\/\//i.test(folder) ? folder : join(site, folder))
      || (/^https?:\/\//i.test(raw) ? location(raw) : '') || '—' };
  }
  if (type === 'Manual') {
    const roles = Array.isArray(details.uploadedByRoles) ? details.uploadedByRoles.map(text).filter(Boolean).map(translateRole).join(', ') : '';
    return { type, detail: join(text(details.uploadedBy) || text(document.created_by), roles) || '—' };
  }
  return { type, detail: join(text(details.integrationName), location(details.location), text(details.reference)) || '—' };
}

/** Resolve old uploader identities only when the directory match is unambiguous.
 * Captured names/roles remain a snapshot; the current viewer is never substituted. */
export function withUploadedDocumentUploader<T extends SourceDocument>(document: T, users: readonly {
  id: string; fullName?: string; username?: string; email?: string; roles?: string;
}[]): T {
  if (uploadedDocumentSource(document).type !== 'Manual') return document;
  const details = document.source_details ?? {};
  const identity = text(details.uploadedById || details.uploadedByEmail || details.uploadedBy || document.created_by).toLocaleLowerCase();
  if (!identity) return document;
  const exact = users.filter(user => [user.id, user.email].some(value => text(value).toLocaleLowerCase() === identity));
  const matches = exact.length ? exact : users.filter(user => [user.fullName, user.username].some(value => text(value).toLocaleLowerCase() === identity));
  const user = matches.length === 1 ? matches[0] : undefined;
  if (!user) return document;
  return { ...document, source_details: {
    ...details,
    uploadedBy: text(details.uploadedBy) || text(user.fullName) || text(document.created_by),
    uploadedByRoles: details.uploadedByRoles ?? (user.roles || '').split(',').map(text).filter(Boolean),
  } };
}
