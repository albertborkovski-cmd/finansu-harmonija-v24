import { parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { readContractPricing } from './contractPricing';
import type { CompanySaasPlan } from './companySaas';

export type ProfileLimitPolicy = CompanySaasPlan['virsijimas'];
export const PROFILE_SAAS_CHANGED = 'finansu-harmonija:profile-saas-changed';
export const profileSaasKey = (email: string) => `finansu-harmonija-v24:profile-saas:${email.trim().toLowerCase()}`;
function requireOwner(storage: Pick<Storage, 'getItem'>, email: string) {
  const session = parseSession(storage.getItem(AUTH_SESSION_KEY));
  if (!email.trim() || session?.roleNames.includes('Inactive') || session?.email.trim().toLowerCase() !== email.trim().toLowerCase()) throw new Error('Only your own profile settings can be changed.');
}
export function readProfileLimitPolicy(storage: Pick<Storage, 'getItem'>, email: string, planId: string, fallback: ProfileLimitPolicy): ProfileLimitPolicy {
  requireOwner(storage, email);
  const raw = storage.getItem(profileSaasKey(email));
  if (!raw) return fallback;
  try { const value = JSON.parse(raw)?.policies?.[planId]; return value === 'charge' || value === 'block' ? value : fallback; }
  catch { throw new Error('SaaS settings could not be loaded.'); }
}
/** Profile preference only; never rewrites a shared plan, signed contract or invoice. */
export function saveProfileLimitPolicy(storage: Pick<Storage, 'getItem' | 'setItem'>, email: string, planId: string, policy: ProfileLimitPolicy) {
  requireOwner(storage, email);
  if (!['charge', 'block'].includes(policy)) throw new Error('Select valid SaaS plan options.');
  if (!readContractPricing(storage).plans.some(plan => plan.id === planId)) throw new Error('Select an available plan.');
  const raw = storage.getItem(profileSaasKey(email));
  let policies: Record<string, ProfileLimitPolicy> = {};
  if (raw) {
    try { const previous = JSON.parse(raw); if (!previous.policies || typeof previous.policies !== 'object' || Array.isArray(previous.policies)) throw Error(); policies = previous.policies; }
    catch { throw new Error('SaaS settings could not be loaded.'); }
  }
  const result = { policies: { ...policies, [planId]: policy }, updatedBy: email.trim().toLowerCase(), updatedAt: new Date().toISOString() };
  storage.setItem(profileSaasKey(email), JSON.stringify(result));
  return result;
}
