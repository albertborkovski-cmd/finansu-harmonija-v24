import type { DbDocument } from './supabase';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentType } from './ocrApprovalRouting';
import { recognizedOcrDocumentPurpose } from './documentPurposeCatalog';

export function isRecognizedOcrDocumentType(document: Pick<DbDocument, 'document_type' | 'document_subtype'>,
  catalog: readonly OcrDocumentType[]): boolean {
  const normalize = (value = '') => value.trim().toLowerCase().replace(/[_-]+/g, ' ');
  const value = normalize(document.document_subtype || document.document_type);
  return Boolean(value) && catalog.some(type => type.status !== 'Inactive'
    && [type.code, type.fullName, ...(type.previousNames || [])].some(label => normalize(label) === value));
}

export function hasOcrValue(value: unknown): boolean {
  return value !== null && value !== undefined && !['', '—', '-'].includes(String(value).trim());
}

export function isRequiredOcrRule(rule: OcrFieldValidationRule): boolean {
  return !rule.inactive && rule.enabled !== false && (rule.required === true || rule.level === 'red');
}

/** Additional configured OCR fields use the same mapping in editor and save guard. */
export const OCR_EDITABLE_FIELD_KEYS = {
  documentPurpose: 'document_purpose', operationDate: 'operation_date', amountWithoutVat: 'amount_without_vat',
  vat: 'vat', currency: 'currency', validFrom: 'valid_form', orderNo: 'order_no', departmentCode: 'department_code',
  objectProject: 'object_project', series: 'series', costCenter: 'cost_center', accountablePerson: 'accountable_responsible',
} as const;
export function ocrAdditionalFieldsPatch(values: Record<string, string> = {}): Partial<DbDocument> {
  return Object.fromEntries(Object.entries(OCR_EDITABLE_FIELD_KEYS)
    .filter(([key]) => Object.prototype.hasOwnProperty.call(values, key))
    .map(([key, column]) => [column, values[key]]));
}

export function ocrDocumentFieldValue(document: Partial<DbDocument>, key: string): unknown {
  if (key === 'documentPurpose') return recognizedOcrDocumentPurpose(document)?.code || '';
  const fields: Record<string, unknown> = {
    documentType: document.document_subtype || document.document_type, invoice: hasOcrValue(document.document_type) ? /invoice/i.test(document.document_type || '') : undefined,
    documentDate: document.document_date, operationDate: document.operation_date,
    number: document.number, clientCounterparty: document.client_counterparty, counterpartyCode: document.counterparty_code || document.counterparty_id,
    amountWithoutVat: document.amount_without_vat, vat: document.vat, vatPercent: document.vat_percent, totalAmount: document.total_amount,
    dueEndDate: document.due_end_date, validFrom: document.valid_form, orderNo: document.order_no, departmentCode: document.department_code,
    objectProject: document.object_project, series: document.series, costCenter: document.cost_center, accountablePerson: document.accountable_responsible,
    glAccount: document.expense_account, vatClassifier: document.vat_classifier, currency: document.currency,
    productGroup: [...(document.summary_line_items ?? []), ...(document.line_items ?? [])].map(line => line.productGroup || '').filter(Boolean).join(', '),
    source: document.source, fileCase: document.file_case, status: document.status, receiveDate: document.receive_date,
    invoiceContractDate: document.invoice_contract_date, type: document.type, subtype: document.document_subtype,
  };
  return fields[key] ?? (document as Record<string, unknown>)[key];
}

export function missingOcrRequiredFields(document: Partial<DbDocument>, rules: readonly OcrFieldValidationRule[]): string[] {
  return rules.filter(rule => isRequiredOcrRule(rule) && !hasOcrValue(ocrDocumentFieldValue(document, rule.key))).map(rule => rule.label);
}

/** Use exactly the same document-level values for preview and the final guard. */
export function ocrCompletionPatch(task: WorkspaceTask, catalog: readonly OcrDocumentType[] = [], original?: Partial<DbDocument>): Partial<DbDocument> {
  const type = catalog.find(item => [item.code, item.fullName, ...(item.previousNames || [])].some(value => value.toLowerCase() === task.documentType.toLowerCase()));
  const previousSubtype = catalog.find(item => item.code === original?.document_subtype || item.fullName === original?.document_subtype);
  return {
    ...ocrAdditionalFieldsPatch(task.ocrFieldValues),
    ...(type ? { document_type: type.parentCode || type.code,
      ...(type.parentCode ? { document_subtype: type.code } : original && previousSubtype?.parentCode !== type.code ? { document_subtype: '' } : {}) } : {}),
    number: task.fields.invoiceNumber, document_date: task.fields.invoiceDate, due_end_date: task.fields.dueDate,
    total_amount: task.fields.totalAmount, client_counterparty: task.fields.companyName.trim(), vat_percent: task.fields.taxRate,
    ...((task.advanceEmployeeId !== undefined || task.advanceEmployee !== undefined) ? {
      advance_employee_id: task.advanceEmployeeId || '', advance_employee: task.advanceEmployee || '',
      ...((task.advanceEmployeeId || task.advanceEmployee) && (original?.document_purpose === 'Purchase' || (!['Purchase', 'Sale'].includes(original?.document_purpose || '') && original?.type === 'Purchase')) && (type ? (type.parentCode || type.code) === 'INVOICES' : original?.document_type === 'INVOICES') ? { document_subtype: 'ADVANCE_INVOICE' } : {}),
    } : {}),
    ...(task.accounting ? { expense_account: task.accounting.expenseAccount, vat_classifier: task.accounting.vatClassifier,
      ...(task.accounting.supplierCode !== undefined ? { counterparty_code: task.accounting.supplierCode } : {}) } : {}),
  };
}
