import type { DbDocument } from './supabase';
import { awaitingTeamLead } from './ocrDocumentWorkflow';
import { customOcrStatus, ocrStatusGroup, isAuxiliaryOcrStatus } from './ocrStatuses';

export type UploadedStatus =
  | 'Processing'
  | 'Processed'
  | 'Organization not identified'
  | 'Rejected'
  | 'Exception'
  | 'Duplicate'
  | 'Not document'
  | 'Other statuses'
  | 'Inactive';

export type UploadedDocumentsGroup =
  | 'All'
  | 'Processing'
  | 'Needs attention'
  | 'Processed';

const UNASSIGNED_TEST_DOCUMENT_ID = 'uploaded-document-unassigned-test';
const DUPLICATE_TEST_DOCUMENT_ID = 'uploaded-document-duplicate-test';

const UNASSIGNED_TEST_DOCUMENT: DbDocument = {
  id: UNASSIGNED_TEST_DOCUMENT_ID,
  receive_date: '28.08.2026',
  client_counterparty: 'Organization pending identification',
  document_type: 'VAT invoice',
  source: 'Email',
  total_amount: '0.00 €',
  due_end_date: '',
  file_case: 'UNASSIGNED-TEST-001.pdf',
  order_no: '',
  number: 'UNASSIGNED-TEST-001',
  type: 'Expense',
  document_date: '28.08.2026',
  document_purpose: 'Organization assignment test',
  invoice_contract_date: '',
  operation_date: '28.08.2026',
  expense_account: '',
  vat_classifier: '',
  currency: 'EUR',
  amount_without_vat: '0.00 €',
  vat: '0.00 €',
  vat_percent: '0%',
  department_code: '',
  object_project: '',
  valid_form: 'Organization identification required',
  accountable_responsible: '',
  cost_center: '',
  series: '',
  status: 'Processing',
  created_at: '2026-08-28T09:00:00.000Z',
  created_by: 'sender@example.com',
  image_url: null,
};

export function uploadedDocumentTimestamp(document: DbDocument) {
  const created = Date.parse(document.created_at || '');
  if (Number.isFinite(created)) return created;
  const parts = (document.receive_date || '').match(
    /^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/,
  );
  return parts
    ? new Date(Number(parts[3]), Number(parts[2]) - 1, Number(parts[1])).getTime()
    : 0;
}

export function uploadedStatus(document: DbDocument): UploadedStatus {
  if (document.document_deletion) return 'Inactive';
  const raw = (document.status || '').trim().toLowerCase();
  if (raw === 'inactive' || raw === 'deactivated') return 'Inactive';
  if (document.digitization_issues?.some(issue => ['Open', 'In progress'].includes(issue.status))) return 'Exception';
  if (awaitingTeamLead(document) || document.digitization_issues?.some(issue => issue.status === 'Awaiting OCR')
    || document.ocr_rerun_request && document.ocr_rerun_request.status !== 'Completed') return 'Processing';
  if (isAuxiliaryOcrStatus(document.status || '')) return 'Other statuses';
  const custom = customOcrStatus(document.status || '');
  if (document.company_id && custom && custom.group !== 'Other statuses') return custom.group === 'Needs attention' ? 'Exception' : custom.group;
  if (raw === 'rejected') return 'Exception';
  if (raw === 'exception' || raw === 'exceptional') return 'Exception';
  if (raw.includes('duplicate') || raw.includes('dublicate')) return 'Duplicate';
  if (raw === 'not document' || raw === 'not documented') return 'Not document';
  if (!document.company_id || raw === 'organization not identified') return 'Organization not identified';
  if (
    raw === 'overdue' ||
    raw === 'needs info' ||
    raw === 'provide additional' ||
    raw === 'provide additional data'
  ) {
    return 'Exception';
  }
  if (
    document.ocr_approval_route?.destination === 'FH' || ['paid', 'accepted', 'processed', 'completed', 'transferred', 'approved', 'confirmed', 'posted', 'exported'].includes(
      raw,
    )
  ) {
    return 'Processed';
  }
  return 'Processing';
}

export function uploadedStatusGroup(
  status: string,
): UploadedDocumentsGroup {
  if (status === 'Inactive' || status === 'Other statuses' || isAuxiliaryOcrStatus(status)) return 'All';
  return ocrStatusGroup(status) ?? 'Needs attention';
}

export function isUploadedDocumentUnresolved(status: UploadedStatus) {
  return status === 'Processing' || uploadedStatusGroup(status) === 'Needs attention';
}

/** Keep deleted uploads in the queue they occupied, for recovery only. The
 * visible status stays Inactive and OCR workers still exclude deleted records. */
export function uploadedRegisterGroup(document: DbDocument): UploadedDocumentsGroup {
  return uploadedStatusGroup(uploadedStatus(document.document_deletion
    ? { ...document, document_deletion: undefined } : document));
}

export function matchesUploadedDateFilter(
  document: DbDocument,
  dateFilter: string,
  now = Date.now(),
) {
  const status = uploadedStatus(document.document_deletion ? { ...document, document_deletion: undefined } : document);
  if (isUploadedDocumentUnresolved(status) || dateFilter === 'all') return true;
  const days = Number(dateFilter || 30);
  const cutoff = now - days * 24 * 60 * 60 * 1000;
  return uploadedDocumentTimestamp(document) >= cutoff;
}

export function prepareUploadedDocuments(sourceDocuments: DbDocument[]) {
  let documents = [...sourceDocuments];
  const generated: DbDocument[] = [];

  if (
    !documents.some((document) => !document.company_id) &&
    !documents.some((document) => document.id === UNASSIGNED_TEST_DOCUMENT_ID)
  ) {
    generated.push(UNASSIGNED_TEST_DOCUMENT);
    documents = [UNASSIGNED_TEST_DOCUMENT, ...documents];
  }

  if (!documents.some((document) => document.id === DUPLICATE_TEST_DOCUMENT_ID)) {
    const duplicateSource = documents.find(
      (document) =>
        document.id !== UNASSIGNED_TEST_DOCUMENT_ID &&
        document.id !== DUPLICATE_TEST_DOCUMENT_ID &&
        !document.status?.toLowerCase().includes('duplicate') &&
        Boolean(document.company_id),
    );
    if (duplicateSource) {
      const duplicateDocument: DbDocument = {
        ...duplicateSource,
        id: DUPLICATE_TEST_DOCUMENT_ID,
        status: 'Duplicate',
        created_at: '2026-08-28T10:00:00.000Z',
        created_by: 'duplicate-detection@meso.lt',
        valid_form: 'A matching original document was detected.',
      };
      generated.push(duplicateDocument);
      documents = [duplicateDocument, ...documents];
    }
  }

  return { documents, generated };
}

/** Stable example arrivals for the requested cloud-source preview. No connector is invoked. */
export function prepareUploadedSourceExamples(sourceDocuments: DbDocument[], organizations: readonly { id: string; name: string }[]) {
  const company = organizations.find(organization => organization.name === 'Alice Stone');
  if (!company) return { documents: sourceDocuments, generated: [] as DbDocument[] };
  const examples = [
    { id: 'uploaded-source-sharepoint-v23', source: 'SharePoint', number: 'SP-2026-0117',
      source_details: { folderPath: '/Companies/Alice Stone/2026/11/Purchases' },
      status: 'Processing', total_amount: '242.00', amount_without_vat: '200.00', vat: '42.00',
      created_at: '2026-11-17T10:15:00.000Z' },
    { id: 'uploaded-source-dropbox-v23', source: 'Dropbox', number: 'DB-2026-0118',
      source_details: { folderPath: '/Alice Stone/Invoices/2026-11' },
      status: 'Processed', total_amount: '605.00', amount_without_vat: '500.00', vat: '105.00',
      created_at: '2026-11-17T10:10:00.000Z' },
  ];
  const generated: DbDocument[] = examples.filter(example => !sourceDocuments.some(document => document.id === example.id)).map(example => ({
    ...UNASSIGNED_TEST_DOCUMENT,
    ...example,
    company_id: company.id,
    client_counterparty: example.source === 'SharePoint' ? 'UAB Baltic Services' : 'UAB Office Solutions',
    file_case: `${example.number}.pdf`,
    receive_date: '17.11.2026', document_date: '17.11.2026', operation_date: '17.11.2026',
    document_purpose: 'Purchase', type: 'Purchase', vat_percent: '21%',
    valid_form: '', created_by: '',
  }));
  return { documents: [...generated, ...sourceDocuments], generated };
}
