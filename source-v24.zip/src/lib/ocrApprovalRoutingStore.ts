import { canEditMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY, getCurrentUserIdentity } from './currentUser';
import { configureOcrDocumentTypeRouting, putOcrApprovalRule, type OcrDocumentTypeRouting, type OcrApprovalRule, type OcrApprovalRoutingStore } from './ocrApprovalRouting';

export const OCR_APPROVAL_ROUTING_KEY = 'finansu-harmonija:v22:ocr:approval-routing';
export const OCR_APPROVAL_ROUTING_CHANGED = 'finansu-harmonija:ocr-approval-routing-changed';
export function loadOcrApprovalRouting(): OcrApprovalRoutingStore {
  const raw = localStorage.getItem(OCR_APPROVAL_ROUTING_KEY);
  if (!raw) return { version: 1, rules: [], history: [] };
  try {
    const saved = JSON.parse(raw) as OcrApprovalRoutingStore;
    if (saved.version !== 1 || !Array.isArray(saved.rules) || !Array.isArray(saved.history)
      || saved.rules.some(rule => !rule.id || typeof rule.active !== 'boolean' || typeof rule.organizationId !== 'string'
        || typeof rule.documentType !== 'string' || !['FH', 'TeamLead'].includes(rule.destination))) throw new Error();
    return saved;
  } catch { throw new Error('Approval routing settings could not be read. Existing settings were not overwritten.'); }
}
export function canEditOcrApprovalRouting() {
  const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
  return Boolean(session && canEditMenu(session, 'ocr-admin-document-type'));
}
export function saveOcrApprovalRule(input: Omit<OcrApprovalRule, 'updatedAt' | 'updatedBy'>) {
  if (!canEditOcrApprovalRouting()) throw new Error('You do not have permission to change document routing.');
  const identity = getCurrentUserIdentity();
  const store = putOcrApprovalRule(loadOcrApprovalRouting(), { ...input, updatedAt: new Date().toISOString(), updatedBy: identity.fullName || identity.email });
  localStorage.setItem(OCR_APPROVAL_ROUTING_KEY, JSON.stringify(store));
  window.dispatchEvent(new CustomEvent(OCR_APPROVAL_ROUTING_CHANGED));
  return store;
}

/** The document type and its routing are saved together, never on dropdown selection. */
export function saveOcrDocumentTypeConfiguration(catalogKey: string, records: unknown[], previousCode: string,
  documentType: string, config: OcrDocumentTypeRouting | null) {
  if (!canEditOcrApprovalRouting()) throw new Error('You do not have permission to change document routing.');
  const identity = getCurrentUserIdentity();
  const store = configureOcrDocumentTypeRouting(loadOcrApprovalRouting(), previousCode, documentType, config,
    identity.fullName || identity.email, new Date().toISOString());
  const previousCatalog = localStorage.getItem(catalogKey);
  const previousRouting = localStorage.getItem(OCR_APPROVAL_ROUTING_KEY);
  try {
    localStorage.setItem(catalogKey, JSON.stringify(records));
    localStorage.setItem(OCR_APPROVAL_ROUTING_KEY, JSON.stringify(store));
  } catch (error) {
    if (previousCatalog === null) localStorage.removeItem(catalogKey); else localStorage.setItem(catalogKey, previousCatalog);
    if (previousRouting === null) localStorage.removeItem(OCR_APPROVAL_ROUTING_KEY); else localStorage.setItem(OCR_APPROVAL_ROUTING_KEY, previousRouting);
    throw error;
  }
  window.dispatchEvent(new CustomEvent(OCR_APPROVAL_ROUTING_CHANGED));
  window.dispatchEvent(new CustomEvent('organization-reference-updated'));
}
