import { canViewMenu, type AppSession } from './accessControl';
import { canAccessAssignedOrganization, type LinkedOrganization } from './linkedSettingsData';
import { supabase, type DbDocument } from './supabase';
import { documentRegisterScope, isDocumentArchived } from './documentArchive';
import type { InvoiceChatContext } from '../components/invoices/invoiceChat';

export const OCR_CHAT_REGISTERS = [
  { value: 'ocr-documents', label: 'All Documents / Documents', menu: 'uploaded-documents-documents' },
  { value: 'ocr-uploaded', label: 'All Documents / Uploaded documents', menu: 'uploaded-documents-uploaded' },
] as const;
export type ChatRelatedObject = NonNullable<InvoiceChatContext['relatedObject']> & { ocrRegisters?: string[] };

/** Read the original OCR registers; never create a second document or copy its conversation. */
export async function loadOcrChatRelatedObjects(organization: LinkedOrganization, session: AppSession): Promise<ChatRelatedObject[]> {
  const allowed = () => canViewMenu(session, 'messages') && canAccessAssignedOrganization(organization, session);
  const registers = OCR_CHAT_REGISTERS.filter(register => canViewMenu(session, register.menu));
  if (!allowed() || !registers.length) return [];
  const result = await supabase.from('documents').select('*').eq('company_id', organization.id);
  if (result.error) throw new Error('Unable to load related objects.');
  if (!allowed()) return [];
  const documents = ((result.data ?? []) as unknown as DbDocument[]).filter(document => document.company_id === organization.id
    && document.id && document.entry_method?.trim().toLowerCase() !== 'manual' && !document.document_deletion);
  const processedIds = new Set(documentRegisterScope(documents.map(document => ({ id: document.id, inlineSource: document as unknown as Record<string, unknown> })), true, false).map(document => document.id));
  const objects = documents.flatMap(document => {
    const ocrRegisters = registers.filter(register => register.value === 'ocr-uploaded' || processedIds.has(document.id)).map(register => register.value);
    if (!ocrRegisters.length) return [];
    return [{ id: document.id, organizationId: organization.id, type: 'Document' as const,
      label: [...new Set([document.number, document.file_case].filter(Boolean))].join(' · ') || document.id, ocrRegisters }];
  });
  const labels = new Map<string, number>();
  objects.forEach(object => labels.set(object.label, (labels.get(object.label) ?? 0) + 1));
  return objects.map(object => (labels.get(object.label) ?? 0) > 1 ? { ...object, label: `${object.label} · ${object.id}` } : object);
}

export function matchesChatRelatedModule(object: ChatRelatedObject, module: string) {
  return module.startsWith('ocr-') ? Boolean(object.ocrRegisters?.includes(module)) : object.type === module;
}

export function ocrChatDocumentDestination(document: DbDocument): 'uploaded-documents-documents' | 'uploaded-documents-uploaded' {
  const inlineSource = document as unknown as Record<string, unknown>;
  return isDocumentArchived(inlineSource) || documentRegisterScope([{ inlineSource }], true, false).length
    ? 'uploaded-documents-documents' : 'uploaded-documents-uploaded';
}
