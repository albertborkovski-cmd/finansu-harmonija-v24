import type { DebtRow } from './companyRelatedObjectData';
import type { PaymentDraft } from './companyPayments';

export type DebtTab = 'Receivables' | 'Payables' | 'All' | 'Overdue';
export type DebtAction = 'reminder' | 'payment' | 'balance-confirmation';
export type DebtDirection = 'receivable' | 'payable';

export function debtDirection(row: DebtRow): DebtDirection | null {
  if (row.direction) return row.direction;
  if (row.counterpartyType === 'Buyer') return 'receivable';
  if (row.counterpartyType === 'Supplier') return 'payable';
  return null;
}

export function debtInTab(row: DebtRow, tab: DebtTab) {
  if (tab === 'Receivables') return debtDirection(row) === 'receivable';
  if (tab === 'Payables') return debtDirection(row) === 'payable';
  return tab !== 'Overdue' || row.daysOverdue > 0;
}

export function debtAmountInCents(value: string) {
  const normalized = value.trim().replace(/\s/g, '');
  if (!/^(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,2})?$/.test(normalized)) return null;
  const amount = Math.round(Number(normalized.replaceAll(',', '')) * 100);
  return Number.isSafeInteger(amount) && amount > 0 ? amount : null;
}

export function debtActionState(tab: DebtTab, selected: readonly DebtRow[], rights: { send: boolean; payment: boolean }) {
  const directions = new Set(selected.map(debtDirection));
  const mixed = directions.has('receivable') && directions.has('payable');
  const outsideTab = selected.some(row => !debtInTab(row, tab));
  const valid = selected.length > 0 && !outsideTab && selected.every(row => debtDirection(row) && debtAmountInCents(row.outstandingAmount) !== null && /^[A-Z]{3}$/.test(row.currency));
  const receivablesOnly = directions.size === 1 && directions.has('receivable');
  const payablesOnly = directions.size === 1 && directions.has('payable');
  const reminderVisible = tab === 'Receivables' || ((tab === 'All' || tab === 'Overdue') && !payablesOnly);
  const paymentVisible = tab === 'Payables' || ((tab === 'All' || tab === 'Overdue') && !receivablesOnly);
  return {
    mixed,
    outsideTab,
    reminder: { visible: reminderVisible, enabled: reminderVisible && valid && receivablesOnly && rights.send },
    payment: { visible: paymentVisible, enabled: paymentVisible && valid && payablesOnly && rights.payment },
    'balance-confirmation': { visible: true, enabled: valid && rights.send },
  };
}

export type DebtActionGroup = {
  key: string; direction: DebtDirection; counterpartyCode: string; counterpartyName: string;
  currency: string; amount: number; rows: DebtRow[]; references: string;
};

/** Never net payables against receivables or add different currencies together. */
export function groupDebtActions(selected: readonly DebtRow[], action: DebtAction): DebtActionGroup[] {
  if (!selected.length) throw new Error('Select at least one debt.');
  const groups = new Map<string, DebtActionGroup>();
  const seen = new Set<string>();
  for (const row of selected) {
    const direction = debtDirection(row), cents = debtAmountInCents(row.outstandingAmount);
    if (seen.has(row.id)) continue;
    seen.add(row.id);
    if (!direction || cents === null || !/^[A-Z]{3}$/.test(row.currency)) throw new Error('The selected debt has an invalid direction, balance or currency.');
    if ((action === 'payment' && direction !== 'payable') || (action === 'reminder' && direction !== 'receivable'))
      throw new Error('Select debts of one direction for this action.');
    const identity = row.counterpartyCode.trim() || row.counterpartyName.trim().toLowerCase();
    if (!identity) throw new Error('The selected debt has no counterparty.');
    const key = JSON.stringify([direction, identity, row.currency]);
    const group = groups.get(key) || { key, direction, counterpartyCode: row.counterpartyCode, counterpartyName: row.counterpartyName, currency: row.currency, amount: 0, rows: [], references: '' };
    group.amount += cents;
    if (!Number.isSafeInteger(group.amount)) throw new Error('The selected debt total is too large.');
    group.rows.push(row);
    groups.set(key, group);
  }
  return [...groups.values()].map(group => ({ ...group, amount: group.amount / 100, references: group.rows.map(row => row.documentReference).join(', ') }));
}

export function debtPaymentDraft(group: DebtActionGroup, date: string, iban = '', debtorAccount = ''): PaymentDraft {
  if (group.direction !== 'payable') throw new Error('Payments can only be created for payables.');
  return { debtorAccount, executionDate: date, counterparty: group.counterpartyName, creditorAccount: iban,
    amount: group.amount.toFixed(2), currency: group.currency, purpose: `Payment for invoices ${group.references}`, relatedDocumentId: '' };
}
