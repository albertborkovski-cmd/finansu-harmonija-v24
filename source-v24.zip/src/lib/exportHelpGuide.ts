/** User-facing integration guidance. Vendor facts were checked on 2026-11-19.
 * These instructions do not imply that this frontend has a live API adapter. */
export type HelpText = readonly [en: string, lt: string];
export type HelpStep = { title: HelpText; body: HelpText };
export const API_EXPORT_FORMATS = ['BSS Api', 'Business Central', 'Dineta', 'Directo', 'Odoo', 'Optimum', 'Rivilė API', 'Rivilė ERP', 'Site.pro', 'Syrve', 'MONEO API', 'Jumis API', 'Horizon API'];
export const RIVILE_GUIDE_SOURCES = [
  { title: 'Rivilė GAMA · API / Gateway', url: 'https://gidas.rivile.lt/internetiniai_moduliai/api_rest' },
  { title: 'Rivilė GAMA · API responses', url: 'https://gidas.rivile.lt/internetiniai_moduliai/api_rest/naudojimo_pagrindai' },
  { title: 'Rivilė GAMA · Gateway', url: 'https://gidas.rivile.lt/internetiniai_moduliai/api_rest/manorivile-gateway' },
  { title: 'Rivilė GAMA · API practices', url: 'https://gidas.rivile.lt/internetiniai_moduliai/api_rest/geroji_praktika' },
  { title: 'Rivilė ERP · API keys', url: 'https://guide.rivile.cloud/api/api_key' },
];
export const CURRENT_INTEGRATION_NOTICE: HelpText = [
  'Current FH version: format selection, field settings and export-flow previews are available. A live accounting API is not connected. Credentials entered here are not saved or sent. A preview success message is not proof that the document exists in your accounting system. Use real credentials only after secure backend integration is enabled.',
  'Dabartinėje FH versijoje veikia formato pasirinkimas, laukų nustatymai ir eksporto eigos peržiūra. Tikra apskaitos API neprijungta. Čia įvesti raktai neišsaugomi ir nesiunčiami. Peržiūros pranešimas apie sėkmę nepatvirtina, kad dokumentas sukurtas apskaitos sistemoje. Tikrus raktus naudokite tik prijungus saugią serverio integraciją.',
];
export function exportSetupSteps(format: string): HelpStep[] {
  const common: HelpStep[] = [
    { title: ['Select the organization', 'Pasirinkite organizaciją'], body: ['Open All Documents → Documents, choose the organization, then its gear icon → Documents & digitization setup. Check the company name before editing: settings are not shared between companies.', 'Atidarykite Visi dokumentai → Dokumentai, pasirinkite organizaciją ir jos dantratį → Dokumentų ir skaitmeninimo nustatymai. Patikrinkite įmonės pavadinimą: nustatymai tarp įmonių nesidalijami.'] },
    { title: ['Choose the transfer method', 'Pasirinkite perdavimo būdą'], body: [
      format === 'Rivilė API' ? 'Choose Rivilė API for the GAMA API connection. Rivilė is the file-based option; Rivilė ERP is a separate product with separate API credentials.' : `Select ${format} in Export format. File export creates a download; an API integration sends a request to the destination system. These are separate actions.`,
      format === 'Rivilė API' ? 'GAMA API ryšiui rinkitės „Rivilė API“. „Rivilė“ skirta failo eksportui, o „Rivilė ERP“ yra kitas produktas su atskirais API prisijungimo duomenimis.' : `Lauke „Eksporto formatas“ pasirinkite „${format}“. Eksportuojant failą jis atsisiunčiamas; API integracija siunčia užklausą gavėjo sistemai. Tai skirtingi veiksmai.`,
    ] },
  ];
  if (format === 'Rivilė API') common.push(
    { title: ['Arrange Rivilė API access', 'Užsakykite Rivilės API prieigą'], body: ['Ask Rivilė or its implementation partner to enable API access for the intended company database and provide its API key. The key is not your FH password and is not interchangeable with a key for another company.', 'Kreipkitės į Rivilę arba diegėją dėl API prieigos konkrečiai įmonės duomenų bazei ir jai skirto rakto. Tai ne FH slaptažodis; kitos įmonės raktas netinka.'] },
    { title: ['Check the Gateway connection', 'Patikrinkite „Gateway“ ryšį'], body: ['The Rivilė administrator installs and configures Manorivile-Gateway on the server that can reach the GAMA database. Confirm that the service is running and the intended database is reachable. A key alone does not establish this connection.', 'Rivilės administratorius įdiegia ir sukonfigūruoja „Manorivile-Gateway“ serveryje, pasiekiančiame GAMA duomenų bazę. Patikrinkite, ar tarnyba veikia ir pasiekia reikiamą bazę. Vien rakto įvedimas šio ryšio nesukuria.'] },
  );
  else if (API_EXPORT_FORMATS.includes(format)) common.push({ title: ['Get the integration credentials', 'Gaukite integracijos duomenis'], body: [format === 'Rivilė ERP' ? 'Use an API key issued in Rivilė ERP for the intended organization and integration permissions. Do not use a GAMA key or its Gateway setup.' : `Ask the ${format} administrator for the credentials and service addresses shown in this form. Confirm the target company and integration permissions; ordinary user credentials are not automatically API credentials.`, format === 'Rivilė ERP' ? 'Naudokite Rivilė ERP išduotą API raktą reikiamai organizacijai ir integracijos teisėms. GAMA raktas ir jos „Gateway“ nustatymai čia netaikomi.' : `Iš „${format}“ administratoriaus gaukite šioje formoje prašomus prisijungimo duomenis ir paslaugų adresus. Patikrinkite įmonę bei integracijos teises; įprasti naudotojo prisijungimai nebūtinai yra API prisijungimai.`] });
  common.push(
    { title: ['Match the accounting codes', 'Suderinkite apskaitos kodus'], body: ['Enter the codes used in the destination system, not their descriptions. Add counterparties and expense / service / product codes in the adjacent sections. Set required fields and defaults under Additional column settings. For example, an expense named Office supplies may use code 6300.', 'Įrašykite gavėjo sistemoje naudojamus kodus, o ne jų aprašymus. Gretimose skiltyse įkelkite kontrahentus ir išlaidų, paslaugų ar prekių kodus. Apačioje nustatykite privalomus laukus ir numatytąsias reikšmes. Pavyzdžiui, išlaidos „Kanceliarinės prekės“ kodas gali būti 6300.'] },
    { title: ['Save and check one document', 'Išsaugokite ir patikrinkite vieną dokumentą'], body: ['Save changes, return to Documents and select a document belonging to this organization. Check the counterparty, purchase / sale direction, amounts, VAT and required codes. Use a single known document to verify mappings before processing a batch.', 'Išsaugokite pakeitimus, grįžkite į Dokumentai ir pažymėkite šios organizacijos dokumentą. Patikrinkite kontrahentą, pirkimo ar pardavimo kryptį, sumas, PVM ir privalomus kodus. Kodų atitikmenis pirmiausia tikrinkite su vienu žinomu dokumentu, ne su visu paketu.'] },
  );
  return common;
}
export const FILE_EXPORT_STEPS: HelpText[] = [
  ['Select invoices → choose the export-file action → select the destination format.', 'Pažymėkite sąskaitas → rinkitės failo eksporto veiksmą → pasirinkite gavėjo formatą.'],
  ['The browser downloads a file. Downloading does not mean it has been imported.', 'Naršyklė atsisiunčia failą. Atsisiuntimas dar nereiškia, kad jis importuotas.'],
  ['Open the correct company in the accounting program and import the file with its supported import function. Follow the destination-specific text guide.', 'Apskaitos programoje atidarykite reikiamą įmonę ir naudokite jos failo importo funkciją. Vadovaukitės atitinkamos sistemos tekstine instrukcija.'],
  ['Compare document numbers, counterparties, totals and accounting codes after import. Current FH sample files require a verified destination adapter before production use.', 'Po importo sutikrinkite numerius, kontrahentus, sumas ir apskaitos kodus. Dabartiniams FH pavyzdiniams failams prieš naudojimą produkcijoje reikia patikrinto konkrečios sistemos adapterio.'],
];
export const API_EXPORT_STEPS: HelpText[] = [
  ['Select invoices → Send to the configured system. The organization’s export format identifies the destination.', 'Pažymėkite sąskaitas → Siųsti į pasirinktą sistemą. Gavėją nustato organizacijos eksporto formatas.'],
  ['In a connected integration, the FH server checks the documents and sends the accounting data using credentials stored securely on the server. A file download is not needed.', 'Prijungtoje integracijoje FH serveris patikrina dokumentus ir perduoda apskaitos duomenis naudodamas serveryje saugiai laikomą raktą. Failo atsisiųsti nereikia.'],
  ['The receiving system returns a result for each document. Only confirmed success should be treated as export completion; a timeout is not a successful receipt.', 'Gavėjo sistema grąžina kiekvieno dokumento rezultatą. Eksporto pabaigą turi patvirtinti sėkmingas atsakymas; laukimo laiko pabaiga nėra gavimo patvirtinimas.'],
  ['Creating a document and posting it are separate steps. In Rivilė API, Automatically post the document controls the second step. Before retrying an uncertain result, check the receiving system for an existing document.', 'Dokumento sukūrimas ir jo perkėlimas apskaitoje yra atskiri veiksmai. Rivilė API parinktis „Automatiškai Rivilėje perkelti dokumentą“ nurodo antrą veiksmą. Prieš kartodami neaiškiai pasibaigusį siuntimą patikrinkite, ar dokumentas jau nėra gavėjo sistemoje.'],
];
export const RIVILE_API_ERRORS: { code: string; meaning: HelpText; action: HelpText }[] = [
  { code: '401', meaning: ['Authentication rejected', 'Prieiga atmesta'], action: ['Ask the administrator to check key validity and the selected database. Do not paste the key into chat or a screenshot.', 'Administratorius turi patikrinti rakto galiojimą ir pasirinktą bazę. Rakto nekopijuokite į pokalbį ar ekrano nuotrauką.'] },
  { code: '400 / 207', meaning: ['Invalid data / partial result', 'Netinkami duomenys / dalinis rezultatas'], action: ['Read the individual document errors; check codes, VAT and mandatory values. Do not resend successful documents with failed ones.', 'Perskaitykite konkrečių dokumentų klaidas: patikrinkite kodus, PVM ir privalomas reikšmes. Sėkmingų dokumentų nesiųskite iš naujo kartu su nepavykusiais.'] },
  { code: '502', meaning: ['Gateway unavailable', '„Gateway“ nepasiekiamas'], action: ['Ask the Rivilė administrator to check the running Gateway service and database connection.', 'Paprašykite Rivilės administratoriaus patikrinti „Gateway“ tarnybą ir ryšį su duomenų baze.'] },
  { code: '504', meaning: ['Response timeout', 'Atsakymo laikas baigėsi'], action: ['First check whether the document was created in Rivilė, then decide whether it needs to be resent.', 'Pirmiausia patikrinkite, ar dokumentas sukurtas Rivilėje, tik tada spręskite dėl pakartotinio siuntimo.'] },
];
