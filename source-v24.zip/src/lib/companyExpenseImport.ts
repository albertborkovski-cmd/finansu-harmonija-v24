export const EXPENSE_CODE_TYPES = ['Code', 'Service', 'Product'] as const;
export type ExpenseCodeType = typeof EXPENSE_CODE_TYPES[number];
export type ExpenseCodeDraft = { code: string; name: string; alternativeCodes: string };
export const MAX_EXPENSE_IMPORT_ROWS = 1000;

/** Excel clipboard text is TSV, not CSV. Keep codes as strings, including leading zeroes. */
export function parseExpenseCodePaste(text: string): ExpenseCodeDraft[] {
  if (text.length > 1_000_000) throw new Error('Paste up to 1,000 code rows at a time.');
  if (!text.trim()) return [];
  const source = text.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const rows: string[][] = [];
  let row: string[] = [], cell = '', quoted = false, closedQuote = false;
  const finishCell = () => { row.push(cell.trim()); cell = ''; closedQuote = false; };
  const finishRow = () => {
    finishCell();
    if (row.some(value => value !== '')) rows.push(row);
    row = [];
    if (rows.length > MAX_EXPENSE_IMPORT_ROWS + 1) throw new Error('Paste up to 1,000 code rows at a time.');
  };
  for (let index = 0; index < source.length; index++) {
    const character = source[index];
    if (quoted) {
      if (character === '"' && source[index + 1] === '"') { cell += '"'; index++; }
      else if (character === '"') { quoted = false; closedQuote = true; }
      else cell += character;
    } else if (character === '\t') finishCell();
    else if (character === '\n') finishRow();
    else if (closedQuote) throw new Error('Check the pasted cells: quotation marks are incomplete.');
    else if (character === '"' && !cell) quoted = true;
    else cell += character;
  }
  if (quoted) throw new Error('Check the pasted cells: quotation marks are incomplete.');
  finishRow();
  const header = (value: string) => value.toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (rows[0]?.length === 2 && ['code', 'kodas'].includes(header(rows[0][0]))
    && ['name', 'description', 'pavadinimas', 'aprasymas', 'pavadinimas / aprasymas'].includes(header(rows[0][1]))) rows.shift();
  if (rows.length > MAX_EXPENSE_IMPORT_ROWS) throw new Error('Paste up to 1,000 code rows at a time.');
  if (rows.some(values => values.length !== 2)) throw new Error('Copy exactly two Excel columns: Code and Name.');
  return rows.map(([code, name]) => ({ code, name, alternativeCodes: '' }));
}

export function expenseCodeRowErrors(rows: ExpenseCodeDraft[], existing: ReadonlyArray<{ code: string }>): string[][] {
  const key = (value: string) => value.trim().toLocaleLowerCase();
  const used = new Set(existing.map(account => key(account.code)));
  const counts = new Map<string, number>();
  rows.forEach(row => counts.set(key(row.code), (counts.get(key(row.code)) || 0) + 1));
  return rows.map(row => {
    const errors: string[] = [];
    if (!row.code.trim()) errors.push('Code is required.');
    if (!row.name.trim()) errors.push('Name is required.');
    if (row.code.length > 100 || row.name.length > 1000 || row.alternativeCodes.length > 2000) errors.push('One of the values is too long.');
    if (/[\t\r\n\u0000-\u001F]/.test(row.code) || /[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(row.name + row.alternativeCodes)) errors.push('Remove control characters from the code or name.');
    if (row.code.trim() && used.has(key(row.code))) errors.push('This code already exists in this organization.');
    if (row.code.trim() && (counts.get(key(row.code)) || 0) > 1) errors.push('This code is repeated in the pasted rows.');
    return errors;
  });
}

export function validateExpenseCodeImport(rows: ExpenseCodeDraft[], type: ExpenseCodeType, existing: ReadonlyArray<{ code: string }>) {
  if (!rows.length) throw new Error('Enter a code and name or paste them from Excel.');
  if (rows.length > MAX_EXPENSE_IMPORT_ROWS) throw new Error('Paste up to 1,000 code rows at a time.');
  if (!EXPENSE_CODE_TYPES.includes(type)) throw new Error('Select Code, Service or Product.');
  const errors = expenseCodeRowErrors(rows, existing);
  if (errors.some(row => row.length)) throw new Error('Correct the highlighted rows before saving.');
  return rows.map(row => ({
    code: row.code.trim(), name: row.name.trim(), expenseType: type,
    alternativeCodes: [...new Set(row.alternativeCodes.split(/[,;\n]/).map(value => value.trim()).filter(Boolean))],
  }));
}
