import { supabase } from './supabase';
import { loadLinkedDirectoryUsers, saveLinkedDirectoryUsers, loadOrganizationUserIds, saveOrganizationUserIds, organizationAssignmentStorageKey } from './linkedSettingsData';

/** User-requested V23 fixtures; never replace user changes or send invitations. */
export async function initializeAdvanceEmployeeExamples() {
  const result = await supabase.from('companies').select('*');
  if (result.error) throw new Error('Could not load companies for the requested examples.');
  const company = result.data?.find(row => row.name === 'Alice Stone');
  if (!company) return;
  const companyId = String(company.id), marker = `finansu-harmonija:v23:advance-examples:${companyId}`;
  if (localStorage.getItem(marker)) return;
  const key = `finansu-harmonija:v18:company-counterparties:${companyId}`;
  const parties = JSON.parse(localStorage.getItem(key) || '[]');
  if (!Array.isArray(parties)) throw new Error('The company counterparties list is unavailable.');
  const users = loadLinkedDirectoryUsers('External users');
  const explicit = localStorage.getItem(organizationAssignmentStorageKey(companyId, 'External users')) !== null;
  // Preserve legacy assignments even for blocked/inactive contacts. Adding
  // examples must not silently remove anybody's existing company assignment.
  const assigned = new Set(explicit ? loadOrganizationUserIds(companyId, 'External users')
    : users.filter(user => String(user.organizations || '').split(',').some(value =>
      ['all organizations', companyId.toLowerCase(), 'alice stone'].includes(value.trim().toLowerCase()))).map(user => user.id));
  const examples = [
    { name: 'UAB Baltijos biuras', people: ['Ieva Vaitkutė', 'Tomas Petrauskas'], city: 'Vilnius' },
    { name: 'UAB Šiaurės įranga', people: ['Rūta Kazlauskė', 'Mantas Jankauskas'], city: 'Kaunas' },
    { name: 'MB Miesto paslaugos', people: ['Eglė Stankevičė', 'Lukas Butkus'], city: 'Klaipėda' },
  ];
  examples.forEach((example, index) => {
    const id = `v23-example-party-${index + 1}`;
    const contacts = example.people.map((fullName, person) => ({ id: `${id}-employee-${person + 1}`, fullName, email: `employee${person + 1}@company${index + 1}.example.test` }));
    if (!parties.some(row => row.id === id)) parties.push({ id, name: example.name, company_code: `EXAMPLE-${index + 1}`, vat_code: '',
      country: 'Lithuania', city: example.city, address: `Pavyzdžio g. ${index + 1}, ${example.city}`, email: `office@company${index + 1}.example.test`,
      base_currency: 'EUR', company_status: 'Active', counterparty_kind: 'Supplier', counterparty_employee_contacts: JSON.stringify(contacts) });
    contacts.forEach(contact => {
      if (!users.some(user => user.id === contact.id || user.email === contact.email)) users.push({ ...contact, username: contact.email,
        roles: '', status: 'Active', organizations: 'Alice Stone', counterpartyId: id, employer: example.name });
      assigned.add(contact.id);
    });
  });
  localStorage.setItem(key, JSON.stringify(parties));
  saveLinkedDirectoryUsers('External users', users, false);
  saveOrganizationUserIds(companyId, 'External users', assigned);
  localStorage.setItem(marker, '1');
  window.dispatchEvent(new CustomEvent('counterparties-updated'));
}
