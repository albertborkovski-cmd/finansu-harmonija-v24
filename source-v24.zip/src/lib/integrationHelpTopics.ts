import type { HelpText } from './exportHelpGuide';

export type IntegrationHelpTopic = {
  id: string;
  title: HelpText;
  description: HelpText;
  sections: {
    title: HelpText;
    system: 'FH' | 'Agnum';
    paragraphs?: HelpText[];
    steps?: HelpText[];
  }[];
  note?: HelpText;
  screenshot?: { file: string; caption: HelpText };
  video?: { id: string; format: string };
};

// The four Agnum topics are checked against the provider collection. Vendor
// instructions are paraphrased; FH instructions describe the current UI only.
export const AGNUM_HELP_TOPICS: IntegrationHelpTopic[] = [
  {
    id: 'invoice-import',
    title: ['Invoice import: totals and quantities', 'Sąskaitų importas: sumos ir kiekiai'],
    description: ['Choose the import method and follow the purchase or sales route.', 'Importavimo būdo pasirinkimas ir pirkimo bei pardavimo sąskaitų keliai.'],
    sections: [
      {
        title: ['Select Agnum in FH', 'Pasirinkimas FH'], system: 'FH',
        steps: [
          ['Open All Documents → Documents, select the organization and open its gear → Documents & digitization setup. Select Agnum as the export format.', 'Atverkite Visi dokumentai → Dokumentai, pasirinkite organizaciją ir jos dantratį → Dokumentų ir skaitmeninimo nustatymai. Eksporto formatu pasirinkite Agnum.'],
          ['Review Item account code and the registration-number option. Under Additional column settings, review the document and line warehouses, group, object, expense and VAT classifier. These settings belong to the selected organization.', 'Patikrinkite prekės sąskaitos kodą ir registracijos numerio parinktį. Papildomų stulpelių nustatymuose peržiūrėkite dokumento ir eilutės sandėlį, grupę, objektą, išlaidą bei PVM klasifikatorių. Nustatymai taikomi pasirinktai organizacijai.'],
          ['Save the settings. In Documents, select the invoices and use the file-export action with Agnum. This is separate from Send to accounting.', 'Išsaugokite nustatymus. Dokumentų sąraše pažymėkite sąskaitas ir failo eksporto veiksme pasirinkite Agnum. Tai atskiras veiksmas nuo Siųsti į apskaitos sistemą.'],
        ],
      },
      {
        title: ['Import in Agnum', 'Importavimas Agnum'], system: 'Agnum',
        steps: [
          ['Unpack ZIP first. Totals import uses accounting schemes; quantity import retains item lines and codes.', 'ZIP pirmiausia išskleiskite. Suminis importas remiasi apskaitos schemomis; kiekinis išlaiko prekių eilutes ir kodus.'],
          ['Purchases: Documents → Receipts → Deferred documents → XML import. Sales: Documents → Sales → Advance invoices → XML import.', 'Pirkimai: Dokumentai → Pajamavimai → Atidėjimai → Importas iš XML. Pardavimai: Dokumentai → Pardavimai → Išankstinės sąskaitos → Importas iš XML.'],
          ['Enable totals-only import for summarized data; disable it for quantities. Load the corresponding XML and verify the import.', 'Suminėms sąskaitoms pažymėkite „Importuoti sumine išraiška“; kiekinėms nuimkite. Nuskaitykite atitinkamą XML ir patikrinkite importą.'],
          ['Filter deferred documents by period. Assign a scheme and post individually, or use bulk deferred-document posting with a chosen scheme.', 'Atidėtus dokumentus atsirinkite pagal laikotarpį. Priskirkite schemą ir perkelkite po vieną arba naudokite masinį atidėtų dokumentų perkėlimą pagal pasirinktą schemą.'],
        ],
      },
    ],
    note: ['FH currently provides export settings and a file preview, not a verified production Agnum adapter. An exported preview is not proof that Agnum accepted or posted an invoice.', 'Dabartinėje FH versijoje yra eksporto nustatymai ir failo peržiūra, bet ne patikrintas produkcinis Agnum adapteris. Eksporto peržiūra nepatvirtina, kad Agnum priėmė ar užregistravo sąskaitą.'],
    video: { id: '_8jTZxbRPpQ', format: 'Agnum' },
  },
  {
    id: 'item-codes',
    title: ['Moving item codes', 'Prekių kodų perkėlimas'],
    description: ['Export the code list from Agnum and add it to the organization in FH.', 'Kodų sąrašo eksportas iš Agnum ir įkėlimas pasirinktai FH organizacijai.'],
    sections: [
      {
        title: ['Export the list from Agnum', 'Sąrašo iškėlimas iš Agnum'], system: 'Agnum',
        paragraphs: [['Using your own item identifiers for detailed invoices helps avoid duplicate item cards based on supplier codes.', 'Kiekinėms sąskaitoms naudojant savo prekių kodus, mažėja rizika sukurti pasikartojančias korteles pagal tiekėjų kodus.']],
        steps: [
          ['Open Tools → Registers → Items. Use Operations → Data export → Excel export.', 'Atverkite Instrumentai → Registrai → Prekės. Pasirinkite Operacijos → Duomenų eksportas → Eksportas į Excel.'],
          ['In the spreadsheet, keep codes in column A and names in column B, then copy both columns.', 'Skaičiuoklėje A stulpelyje palikite kodus, B – pavadinimus ir nukopijuokite abu stulpelius.'],
        ],
      },
      {
        title: ['Import the copied rows into FH', 'Nukopijuotų eilučių įkėlimas į FH'], system: 'FH',
        steps: [
          ['In All Documents → Documents select the organization. Open its gear → Additional columns → Expenses → Import from Excel.', 'Visi dokumentai → Dokumentai pasirinkite organizaciją. Atverkite jos dantratį → Papildomi stulpeliai → Išlaidos → Įkelti iš Excel.'],
          ['Choose the appropriate type: Code, Service or Product. Paste the two columns into the input. Each spreadsheet row becomes a separate code; a TAB separates its code and name.', 'Pasirinkite tinkamą tipą: Kodas, Paslauga arba Prekė. Į įklijavimo lauką įdėkite du stulpelius. Kiekviena skaičiuoklės eilutė tampa atskiru kodu, o kodą nuo pavadinimo skiria TAB.'],
          ['Review the parsed rows and correct reported errors before importing. Do not include a column-heading row as an item.', 'Peržiūrėkite atpažintas eilutes ir prieš įkeldami pataisykite nurodytas klaidas. Stulpelių antraščių eilutės neįtraukite kaip prekės.'],
          ['Import the list. To amend one code, use its Edit action; alternative codes can be added in the individual code form. The list stays with this organization.', 'Įkelkite sąrašą. Vienam kodui pakoreguoti naudokite jo redagavimo veiksmą; alternatyvius kodus galima nurodyti atskiro kodo formoje. Sąrašas išsaugomas šiai organizacijai.'],
          ['Return to Documents and select the saved code in Expense. Loading a code list does not itself change existing invoice allocations.', 'Grįžkite į Dokumentus ir lauke Išlaida pasirinkite išsaugotą kodą. Vien kodų sąrašo įkėlimas esamų sąskaitų paskirstymo nepakeičia.'],
        ],
      },
    ],
    screenshot: { file: 'expense-import.jpg', caption: ['FH expense-code import: paste a code and name from Excel.', 'FH išlaidų kodų įkėlimas: iš Excel įklijuojamas kodas ir pavadinimas.'] },
  },
  {
    id: 'warehouses',
    title: ['Assigning warehouse codes', 'Sandėlių kodų priskyrimas'],
    description: ['Find the Agnum warehouse code and understand the corresponding FH settings.', 'Kur rasti Agnum sandėlio kodą ir kurie FH nustatymai jam skirti.'],
    sections: [
      {
        title: ['Find the warehouse in Agnum', 'Sandėlio paieška Agnum'], system: 'Agnum',
        steps: [
          ['Open Tools → Registers → Warehouses and identify the required warehouse code and description.', 'Atverkite Instrumentai → Registrai → Sandėliai ir raskite reikiamo sandėlio kodą bei aprašymą.'],
          ['Use that identifier, rather than an arbitrary warehouse name, when assigning a warehouse to an invoice.', 'Sąskaitos sandėliui priskirkite šį identifikatorių, o ne laisvai sugalvotą sandėlio pavadinimą.'],
        ],
      },
      {
        title: ['Warehouse fields in FH', 'Sandėlio laukai FH'], system: 'FH',
        steps: [
          ['Select the organization in All Documents → Documents. In its gear open Documents & digitization setup, select Agnum and find Additional column settings.', 'Visi dokumentai → Dokumentai pasirinkite organizaciją. Per jos dantratį atverkite Dokumentų ir skaitmeninimo nustatymus, pasirinkite Agnum ir raskite Papildomų stulpelių nustatymus.'],
          ['Document warehouse and Line warehouse are separate fields. Their Default value cells accept the code as text; do not enter the warehouse description instead.', 'Dokumento sandėlis ir Eilutės sandėlis yra atskiri laukai. Jų Numatytoji reikšmė laukeliuose įrašomas tekstinis kodas, ne sandėlio aprašymas.'],
          ['Required, Assign automatically and Default value are separate choices. A saved default is configuration, not evidence that a warehouse was transferred to Agnum.', 'Privalomas, Priskirti automatiškai ir Numatytoji reikšmė yra atskiros parinktys. Išsaugota numatytoji reikšmė yra nustatymas, ne įrodymas, kad sandėlis jau perduotas į Agnum.'],
        ],
      },
    ],
    note: ['This FH gear menu does not yet have a separate warehouse-code directory or an Agnum warehouse picker for each document. The available fields are export settings; the full per-document warehouse workflow is not implemented here.', 'Šiame FH dantračio meniu dar nėra atskiro sandėlių kodų registro ir Agnum sandėlio pasirinkimo kiekviename dokumente. Esami laukai yra eksporto nustatymai; visas sandėlio priskyrimo dokumentui procesas čia dar neįgyvendintas.'],
  },
  {
    id: 'duplicate-control',
    title: ['Duplicate control', 'Dublikatų kontrolė'],
    description: ['Enable checks in Agnum and distinguish them from OCR duplicate warnings.', 'Dublikatų tikrinimas Agnum ir jo skirtumas nuo OCR įspėjimų.'],
    sections: [
      {
        title: ['Enable the checks in Agnum', 'Tikrinimo įjungimas Agnum'], system: 'Agnum',
        steps: [
          ['Open Tools → Parameters, then the Documents section.', 'Atverkite Instrumentai → Parametrai, tada Dokumentai skiltį.'],
          ['Under Purchases 1 enable the control that prevents repeating an invoice number for the same supplier.', 'Skiltyje Pirkimai 1 įjunkite tikrinimą, neleidžiantį kartoti dokumento numerio tam pačiam tiekėjui.'],
          ['Under Sales 1 enable immediate document-number checking.', 'Skiltyje Pardavimai 1 įjunkite dokumento numerio tikrinimą iš karto.'],
        ],
      },
      {
        title: ['What this means in FH', 'Ką tai reiškia FH'], system: 'FH',
        paragraphs: [
          ['An OCR duplicate warning and the receiving accounting system’s duplicate control are different checks. This help page does not change any Agnum settings.', 'OCR įspėjimas apie dublikatą ir apskaitos sistemos dublikatų kontrolė yra skirtingi tikrinimai. Šis pagalbos puslapis nekeičia jokių Agnum nustatymų.'],
          ['In All Documents → Uploaded documents, click the Duplicate status to review its details. If View original is available, open the referenced document and compare it before proceeding.', 'Visi dokumentai → Įkelti dokumentai paspauskite būseną Dublikatas ir peržiūrėkite paaiškinimą. Jei yra Peržiūrėti originalą nuoroda, atverkite susietą dokumentą ir palyginkite prieš tęsdami.'],
          ['A file downloaded again is still the same invoice, not a new one. Before a real retry, check the destination-system result; FH export or archive state alone cannot prove whether Agnum created the document.', 'Pakartotinai atsisiųstas failas vis tiek yra ta pati sąskaita, ne nauja. Prieš realų pakartotinį importą patikrinkite gavėjo sistemos rezultatą; vien FH eksporto ar archyvo būsena neįrodo, ar Agnum sukūrė dokumentą.'],
        ],
      },
    ],
  },
];

export const integrationTopics = (integration: string): IntegrationHelpTopic[] => integration === 'Agnum' ? AGNUM_HELP_TOPICS : [];
export const integrationTopic = (integration: string, topic: string | null) => integrationTopics(integration).find(item => item.id === topic);
