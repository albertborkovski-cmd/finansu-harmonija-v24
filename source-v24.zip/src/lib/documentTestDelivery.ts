import type { DbDocument } from './supabase';
import { hasBlockingDocumentIssue } from './documentIssues';

export type TestDeliveryScenario = 'accepted' | 'rejected';
export type DocumentTestDelivery = {
  mode: 'test'; requestId: string; destinationId: string; destinationName: string;
  scenario: TestDeliveryScenario; outcome: 'Accepted' | 'Rejected' | 'Blocked';
  reference: string; at: string; actor: string; message: string;
  sourceSnapshot: string;
  sourceRegister?: 'all-documents';
};
export type TestDeliveryCommand = {
  requestId: string; companyId: string; ids: string[]; destinationId: string;
  destinationSource?: 'primary-export-format';
  sourceRegister?: 'all-documents';
  scenario: TestDeliveryScenario; snapshots: Record<string, string>;
};

/** Previous test receipts are excluded; an explicit FH approval changes status
 * and therefore invalidates older source snapshots. No ERP transfer is implied. */
export function documentTestDeliverySnapshot(document: Record<string, unknown>) {
  const keys = [
    'id', 'company_id', 'number', 'client_counterparty', 'counterparty_code',
    'document_type', 'document_subtype', 'type', 'document_date', 'operation_date',
    'order_no', 'document_purpose', 'notes', 'due_end_date', 'invoice_contract_date',
    'department_code', 'object_project', 'cost_center', 'accountable_responsible', 'series', 'line_items',
    'currency', 'amount_without_vat', 'vat', 'total_amount', 'expense_account',
    'vat_classifier', 'summary_line_items', 'status', 'accounting_note_status',
    'accounting_posting', 'accounting_storno', 'document_storno', 'digitization_issues',
    'inactive', 'active', 'is_active', 'excluded_from_export', 'manual_export_status',
  ];
  return JSON.stringify(Object.fromEntries(keys.map(key => [key, document[key] ?? null])));
}

function cents(value: unknown): number | null {
  let text = String(value ?? '').trim().replace(/(?:EUR|USD|GBP|€|\$|£)/gi, '').replace(/\s/g, '');
  if (!/^-?\d[\d.,]*$/.test(text)) return null;
  const comma = text.lastIndexOf(','), dot = text.lastIndexOf('.');
  if (comma >= 0 && dot >= 0) text = comma > dot ? text.replaceAll('.', '').replace(',', '.') : text.replaceAll(',', '');
  else text = text.replace(',', '.');
  const number = Number(text);
  const minor = Math.round(number * 100);
  return Number.isFinite(number) && Number.isSafeInteger(minor) ? minor : null;
}

function validDate(value: unknown) {
  const text = String(value ?? '').trim();
  const iso = /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : text.replace(/^(\d{2})\.(\d{2})\.(\d{4})$/, '$3-$2-$1');
  return /^\d{4}-\d{2}-\d{2}$/.test(iso) && Number.isFinite(Date.parse(iso)) && new Date(iso).toISOString().slice(0, 10) === iso;
}

export function documentTestDeliveryBlocker(document: DbDocument): string {
  const record = document as unknown as Record<string, unknown>;
  const status = String(document.status ?? '').trim().toLowerCase();
  if (record.excluded_from_export) return 'This document is excluded from export. Include it in export before sending.';
  if (record.manual_export_status === 'Exported') return 'This document is marked as exported. Clear the manual export mark before sending again.';
  if (record.inactive || record.active === false || record.is_active === false) return 'Inactive document. Activate it through the permitted workflow first.';
  if (hasBlockingDocumentIssue(document)) return 'Resolve the reported digitization issue before sending this document.';
  if (document.document_storno) return 'This document has been reversed in test mode. Review its document history.';
  if (document.accounting_storno) return 'This operation has been reversed. Review its accounting history.';
  if (['transferred', 'exported'].includes(status) || Object.entries(record).some(([key, value]) => /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key) && Boolean(value))) return 'This document has already been transferred. Duplicate sending is blocked.';
  if (document.ocr_approval_route?.destination === 'TeamLead' || document.ocr_rerun_request && document.ocr_rerun_request.status !== 'Completed') return 'Complete OCR and TeamLead review before sending this document.';
  if (!['draft', 'pending', 'paid', 'manual', 'new', 'approved', 'correcting', 'confirmed', 'posted', 'processed', 'accepted', 'completed'].includes(status)) return `Document status is ${document.status || 'not specified'}. Correct and review it before sending.`;
  if (!document.number?.trim()) return 'Document number is required.';
  if (!document.client_counterparty?.trim()) return 'Counterparty is required.';
  if (!document.document_type?.trim()) return 'Document type is required.';
  if (!validDate(document.document_date)) return 'A valid document date is required.';
  if (!/^[A-Z]{3}$/.test(document.currency)) return 'A three-letter currency code is required.';
  const net = cents(document.amount_without_vat), vat = cents(document.vat), total = cents(document.total_amount);
  if (net === null || vat === null || total === null) return 'Amounts must be valid numbers.';
  if (net + vat !== total) return 'Amount plus VAT must equal Total amount.';
  const allocations = document.summary_line_items;
  if (allocations != null && !Array.isArray(allocations)) return 'Accounting allocations are invalid. Open Edit to correct them.';
  if (allocations?.length) {
    let sumNet = 0, sumVat = 0, sumTotal = 0;
    for (const [index, line] of allocations.entries()) {
      if (!line?.expense?.trim()) return `GL account is required on accounting allocation ${index + 1}.`;
      const lineNet = cents(line.subtotal), lineVat = cents(line.vat), lineTotal = cents(line.total);
      if (lineNet === null || lineVat === null || lineTotal === null || lineNet + lineVat !== lineTotal) return `Check amounts on accounting allocation ${index + 1}.`;
      if (lineVat !== 0 && !line.vatClass?.trim()) return `VAT classifier is required on accounting allocation ${index + 1}.`;
      sumNet += lineNet; sumVat += lineVat; sumTotal += lineTotal;
    }
    if (sumNet !== net || sumVat !== vat || sumTotal !== total) return 'Accounting allocations do not match the document totals.';
  } else {
    if (!document.expense_account?.trim()) return 'GL account is required.';
    if (vat !== 0 && !document.vat_classifier?.trim()) return 'VAT classifier is required.';
  }
  return '';
}

/** Simulation only. No connector, external reference, GL posting or processing
 * status is changed. Blocked records still get an explicit test receipt. */
export function createDocumentTestDelivery(document: DbDocument, command: TestDeliveryCommand, destinationName: string, actor: string, at: string, preparedDocument: DbDocument = document): DocumentTestDelivery {
  const sourceSnapshot = documentTestDeliverySnapshot(document as unknown as Record<string, unknown>);
  if (document.company_id !== command.companyId || !command.ids.includes(document.id)) throw new Error('The document is outside this test selection.');
  if (command.snapshots[document.id] !== sourceSnapshot) throw new Error('A selected document changed. Refresh the list and try again.');
  const blocker = documentTestDeliveryBlocker(preparedDocument);
  return {
    mode: 'test', requestId: command.requestId, destinationId: command.destinationId, destinationName,
    scenario: command.scenario, outcome: blocker ? 'Blocked' : command.scenario === 'rejected' ? 'Rejected' : 'Accepted',
    reference: `TEST-${command.requestId.slice(0, 8).toUpperCase()}-${command.ids.indexOf(document.id) + 1}`,
    at, actor, sourceSnapshot,
    ...(command.sourceRegister ? { sourceRegister: command.sourceRegister } : {}),
    message: blocker || (command.scenario === 'rejected' ? 'Simulated accounting-system rejection. Choose Successful response to retry the test.' : 'Accepted by the test simulator. Nothing was sent to the real accounting system.'),
  };
}
