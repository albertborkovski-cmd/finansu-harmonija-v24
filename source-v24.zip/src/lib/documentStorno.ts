import type { GlJournalRow } from './glJournal';

/** An immutable posting supplied by the posting/import boundary, never inferred
 * from document totals or from the journal's illustrative combined D/K rows. */
export type PostedDocumentLine = {
  id: string; account: string; accountName: string; currency: string;
  debitMinor: number; creditMinor: number; baseDebitMinor: number; baseCreditMinor: number;
  counterparty?: string; costCenter?: string; department?: string; object?: string;
  employee?: string; vehicle?: string; description?: string; originalLineId?: string;
};
export type PostedDocumentOperation = {
  id: string; number: string; companyId: string; documentId: string;
  status: 'Posted'; date: string; postedAt: string; postedBy: string; baseCurrency: string;
  integration: { destination: 'Local' | 'External'; status: 'Not sent' | 'Pending' | 'Transferred' | 'Failed' | 'Unknown'; externalId?: string };
  lines: PostedDocumentLine[];
};
export type DocumentStorno = PostedDocumentOperation & {
  originalOperationId: string; originalOperationNumber: string; reason: string;
  history: { id: string; at: string; actor: string; action: string; details: string }[];
};
/** Document-only test result. Deliberately has no GL operation, accounts or lines. */
export type TestDocumentStorno = {
  mode: 'test'; id: string; number: string; documentId: string; companyId: string;
  status: 'Reversed'; date: string; reason: string; currency: string; sourceSnapshot: string;
  history: DocumentStorno['history'];
};
export type StornoDocument = {
  id: string; company_id?: string; status?: string; accounting_posting?: PostedDocumentOperation;
  accounting_storno?: DocumentStorno;
  advance_employee_reversal?: DocumentStorno;
  document_storno?: TestDocumentStorno;
  [key: string]: unknown;
};
export type StornoCommand = { expectedPosting: string; date: string; reason: string };
export type TestStornoCommand = { expectedDocument: string; date: string; reason: string };
export type StornoPeriodPolicy = { enabled: boolean; cutoffDay: number; closedThrough?: string };
export type StornoContext = { allowed: boolean; actor: string; now: string; today: string; period: StornoPeriodPolicy };
const nonEmptyText = (value: unknown): value is string => typeof value === 'string' && Boolean(value.trim());

export function validAccountingDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
export function accountingToday(now = new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}
export function postedOperationError(posting: PostedDocumentOperation, document: Pick<StornoDocument, 'id' | 'company_id'>): string {
  if (!posting || posting.status !== 'Posted') return 'A confirmed GL operation is required.';
  if (!nonEmptyText(posting.id) || !nonEmptyText(posting.number) || posting.documentId !== document.id || posting.companyId !== document.company_id)
    return 'The GL operation is not linked to this document and company.';
  if (!validAccountingDate(posting.date) || !nonEmptyText(posting.postedAt) || !Number.isFinite(Date.parse(posting.postedAt)) || !nonEmptyText(posting.postedBy) || !/^[A-Z]{3}$/.test(posting.baseCurrency))
    return 'The original posting metadata is incomplete. Correct the posting source first.';
  if (!Array.isArray(posting.lines) || posting.lines.length < 2) return 'The confirmed GL operation must contain complete debit and credit lines.';
  const totals = new Map<string, { debit: number; credit: number }>();
  let baseDebit = 0, baseCredit = 0;
  const ids = new Set<string>();
  for (const line of posting.lines) {
    if (!line || !nonEmptyText(line.id) || ids.has(line.id) || !nonEmptyText(line.account) || typeof line.accountName !== 'string' || !/^[A-Z]{3}$/.test(line.currency)
      || ![line.debitMinor, line.creditMinor, line.baseDebitMinor, line.baseCreditMinor].every(value => Number.isSafeInteger(value) && value >= 0)
      || (line.debitMinor > 0) === (line.creditMinor > 0)
      || (line.debitMinor === 0 && line.baseDebitMinor !== 0) || (line.creditMinor === 0 && line.baseCreditMinor !== 0))
      return 'The original GL lines are invalid. Storno requires exact, separate debit and credit amounts.';
    ids.add(line.id);
    const total = totals.get(line.currency) ?? { debit: 0, credit: 0 };
    total.debit += line.debitMinor; total.credit += line.creditMinor; totals.set(line.currency, total);
    baseDebit += line.baseDebitMinor; baseCredit += line.baseCreditMinor;
  }
  if (![baseDebit, baseCredit, ...[...totals.values()].flatMap(value => [value.debit, value.credit])].every(Number.isSafeInteger)
    || baseDebit !== baseCredit || baseDebit <= 0)
    return 'The confirmed GL operation is not balanced. Correct the posting source first.';
  return '';
}
export function documentStornoBlocker(document: StornoDocument, allowed: boolean): string {
  if (!allowed) return 'You need View, Edit and Create access to Documents and access to this company.';
  if (document.advance_employee_reversal) return 'This GL operation already has an Advance employee reversal.';
  if (document.document_storno) return 'This document has already been reversed in test mode.';
  if (document.accounting_storno) return `This operation has already been reversed (${document.accounting_storno.number}).`;
  if (!document.accounting_posting) return 'No confirmed GL posting is linked to this document. A document status or a calculated GL preview is not a posting.';
  const error = postedOperationError(document.accounting_posting, document);
  if (error) return error;
  const integration = document.accounting_posting.integration;
  if (!integration || integration.destination !== 'Local' || integration.status !== 'Not sent' || integration.externalId
    || /^(transferred|exported)$/i.test(String(document.status))
    || Object.entries(document).some(([key, value]) => /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key) && Boolean(value)))
    return 'External accounting control: this posting is sent, pending, or not verified as local. Reverse it through the connected accounting system and synchronize the confirmed result. No local-only reversal is allowed.';
  return '';
}
export function stornoPeriodError(date: string, originalDate: string, today: string, policy: StornoPeriodPolicy): string {
  if (!validAccountingDate(date)) return 'Select a valid reversal date.';
  if (date < originalDate) return 'The reversal date cannot be earlier than the original posting date.';
  if (date > today) return 'The reversal date cannot be in the future.';
  if (policy.closedThrough && date <= policy.closedThrough) return `The accounting period is locked through ${policy.closedThrough}. Select an open period.`;
  if (policy.enabled) {
    const current = new Date(`${today}T12:00:00Z`);
    const firstOpen = new Date(Date.UTC(current.getUTCFullYear(), current.getUTCMonth() - (current.getUTCDate() <= policy.cutoffDay ? 1 : 0), 1)).toISOString().slice(0, 10);
    if (date < firstOpen) return `This period is closed by the company monthly cutoff. Select ${firstOpen} or later.`;
  }
  return '';
}
export function reversePostedLines(posting: PostedDocumentOperation, id: string): PostedDocumentLine[] {
  return posting.lines.map((line, index) => ({ ...line, id: `${id}:${index + 1}`, originalLineId: line.id,
    debitMinor: line.creditMinor, creditMinor: line.debitMinor,
    baseDebitMinor: line.baseCreditMinor, baseCreditMinor: line.baseDebitMinor }));
}
export function savedDocumentStornoError(document: Pick<StornoDocument, 'id' | 'company_id' | 'accounting_posting' | 'accounting_storno'>): string {
  const reversal = document.accounting_storno;
  if (!reversal) return '';
  const posting = document.accounting_posting;
  const error = 'The saved Storno does not match the original posting. Its integrity must be checked before continuing.';
  if (!posting || postedOperationError(posting, document) || postedOperationError(reversal, document)
    || reversal.originalOperationId !== posting.id || reversal.originalOperationNumber !== posting.number
    || reversal.baseCurrency !== posting.baseCurrency || reversal.date < posting.date || !nonEmptyText(reversal.reason)
    || !Array.isArray(reversal.history) || !reversal.history.length
    || reversal.history.some(event => !event || !nonEmptyText(event.id) || !nonEmptyText(event.actor) || !nonEmptyText(event.action) || !nonEmptyText(event.details) || !Number.isFinite(Date.parse(event.at)))
    || reversal.lines.length !== posting.lines.length) return error;
  const expected = reversePostedLines(posting, reversal.id);
  return expected.some((line, index) => Object.entries(line).some(([key, value]) => (reversal.lines[index] as unknown as Record<string, unknown>)[key] !== value)) ? error : '';
}

/** Signed document amounts are a presentation of the reversal, never an edit
 * to the original document totals or to the immutable D/C posting. */
export function oppositeDocumentAmount(value: unknown): { original: string; reversed: string } | null {
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  const text = String(value).trim().replace(/\s/g, '').replace(',', '.');
  if (!/^-?\d+(?:\.\d{1,2})?$/.test(text)) return null;
  const minor = Math.round(Number(text) * 100);
  if (!Number.isSafeInteger(minor)) return null;
  return { original: (minor / 100).toFixed(2), reversed: (minor === 0 ? 0 : -minor / 100).toFixed(2) };
}

/** Only document metadata is checked: test Storno has no dependency on GL data. */
export function testStornoDocumentSnapshot(document: StornoDocument) {
  const keys = ['id', 'company_id', 'number', 'status', 'accounting_note_status', 'document_type', 'document_subtype', 'currency',
    'document_date', 'operation_date', 'total_amount', 'amount_without_vat', 'vat', 'inactive', 'active', 'is_active'];
  return JSON.stringify(Object.fromEntries(keys.map(key => [key, document[key] ?? null])));
}
export function testStornoOriginalDate(document: StornoDocument) {
  const date = [document.operation_date, document.document_date].find(value => typeof value === 'string' && validAccountingDate(value));
  return typeof date === 'string' ? date : '';
}
export function testDocumentStornoBlocker(document: StornoDocument, allowed: boolean): string {
  if (!allowed) return 'You need View, Edit and Create access to Documents and access to this company.';
  if (document.document_storno || document.accounting_storno || document.advance_employee_reversal) return 'This document has already been reversed.';
  const states = [document.status, document.accounting_note_status].map(value => String(value ?? '').trim().toLowerCase());
  if (document.inactive || document.active === false || document.is_active === false || states.includes('inactive')) return 'Inactive documents cannot be reversed.';
  if (states.includes('processing')) return 'Wait until document processing is complete.';
  // Use the current document status, not evidence of a past workflow stage or GL posting.
  const currentStatus = states[0] || states[1];
  if (!['approved', 'confirmed'].includes(currentStatus))
    return 'Only a confirmed document can be reversed.';
  if (!nonEmptyText(document.id) || !nonEmptyText(document.company_id)) return 'The document and company are required.';
  if (!/^[A-Z]{3}$/.test(String(document.currency ?? ''))) return 'A valid document currency is required.';
  const amount = oppositeDocumentAmount(document.total_amount);
  if (!amount || Number(amount.original) === 0) return 'A valid non-zero document amount is required.';
  return '';
}
export function savedTestDocumentStornoError(document: StornoDocument): string {
  const reversal = document.document_storno;
  if (!reversal) return '';
  if (reversal.mode !== 'test' || reversal.status !== 'Reversed' || reversal.documentId !== document.id || reversal.companyId !== document.company_id
    || reversal.sourceSnapshot !== testStornoDocumentSnapshot(document) || reversal.currency !== document.currency
    || !nonEmptyText(reversal.id) || !nonEmptyText(reversal.number) || !nonEmptyText(reversal.reason) || !validAccountingDate(reversal.date)
    || reversal.date < testStornoOriginalDate(document) || !Array.isArray(reversal.history) || !reversal.history.length
    || reversal.history.some(event => !event || !nonEmptyText(event.id) || !nonEmptyText(event.actor) || !nonEmptyText(event.action) || !nonEmptyText(event.details) || !Number.isFinite(Date.parse(event.at))))
    return 'The saved test Storno integrity could not be verified.';
  return '';
}
export function createTestDocumentStorno(document: StornoDocument, command: TestStornoCommand, context: StornoContext): StornoDocument {
  const blocker = testDocumentStornoBlocker(document, context.allowed);
  if (blocker) throw new Error(blocker);
  const snapshot = testStornoDocumentSnapshot(document);
  if (command.expectedDocument !== snapshot) throw new Error('The document has changed. Close and reopen Storno before continuing.');
  const periodError = stornoPeriodError(command.date, testStornoOriginalDate(document), context.today, context.period);
  if (periodError) throw new Error(periodError);
  const reason = command.reason.trim();
  if (!reason || reason.length > 2000) throw new Error('Enter a reversal reason (1–2,000 characters).');
  if (!nonEmptyText(context.actor) || !Number.isFinite(Date.parse(context.now))) throw new Error('The action author and timestamp are required.');
  const id = `test-storno:${document.id}`, number = `ST-${String(document.number || document.id)}`;
  return { ...document, document_storno: {
    mode: 'test', id, number, documentId: document.id, companyId: document.company_id!, status: 'Reversed', date: command.date,
    reason, currency: String(document.currency), sourceSnapshot: snapshot,
    history: [{ id: `${id}:created`, at: context.now, actor: context.actor, action: 'Document Storno saved (test)',
      details: `${number} reverses document ${String(document.number || document.id)} on ${command.date}. Reason: ${reason}. Test only: no GL entries created or changed and nothing sent to an accounting system.` }],
  } };
}

export function documentStornoPresentation(document: Pick<StornoDocument, 'id' | 'company_id' | 'accounting_posting' | 'accounting_storno' | 'document_storno'> & { total_amount?: unknown; amount_without_vat?: unknown; vat?: unknown }) {
  if (document.document_storno) {
    if (savedTestDocumentStornoError(document as StornoDocument)) return null;
    return { status: 'Reversed' as const, number: document.document_storno.number, date: document.document_storno.date,
      amounts: { totalAmount: oppositeDocumentAmount(document.total_amount), amountWithoutVat: oppositeDocumentAmount(document.amount_without_vat), vat: oppositeDocumentAmount(document.vat) } };
  }
  if (!document.accounting_storno || savedDocumentStornoError(document)) return null;
  return {
    status: 'Reversed' as const,
    number: document.accounting_storno.number,
    date: document.accounting_storno.date,
    amounts: {
      totalAmount: oppositeDocumentAmount(document.total_amount),
      amountWithoutVat: oppositeDocumentAmount(document.amount_without_vat),
      vat: oppositeDocumentAmount(document.vat),
    },
  };
}

export function createDocumentStorno(document: StornoDocument, command: StornoCommand, context: StornoContext): StornoDocument {
  const blocked = documentStornoBlocker(document, context.allowed);
  if (blocked) throw new Error(blocked);
  const posting = document.accounting_posting!;
  if (JSON.stringify(posting) !== command.expectedPosting) throw new Error('The original posting has changed. Close and reopen Storno before continuing.');
  const periodError = stornoPeriodError(command.date, posting.date, context.today, context.period);
  if (periodError) throw new Error(periodError);
  const reason = command.reason.trim();
  if (!reason || reason.length > 2000) throw new Error('Enter a reversal reason (1–2,000 characters).');
  if (!context.actor || !Number.isFinite(Date.parse(context.now))) throw new Error('The action author and timestamp are required.');
  const id = `storno:${posting.id}`;
  const number = `ST-${posting.number}`;
  const reversal: DocumentStorno = {
    id, number, companyId: posting.companyId, documentId: document.id, status: 'Posted', date: command.date,
    postedAt: context.now, postedBy: context.actor, baseCurrency: posting.baseCurrency,
    integration: { destination: 'Local', status: 'Not sent' },
    originalOperationId: posting.id, originalOperationNumber: posting.number, reason,
    lines: reversePostedLines(posting, id),
    history: [{ id: `${id}:created`, at: context.now, actor: context.actor, action: 'Storno posted',
      details: `${number} reverses ${posting.number} (${posting.id}) on ${command.date}. Reason: ${reason}. Original GL entries retained unchanged.` }],
  };
  return { ...document, accounting_storno: reversal };
}

/** Ordinary edits/imports cannot create, replace, erase or bypass posting history. */
export function guardPostedDocumentMutation(previous: Record<string, unknown>, patch: Record<string, unknown>, options: { documentContentEdit?: boolean } = {}) {
  if ('approval_cancellation_history' in patch && JSON.stringify(previous.approval_cancellation_history) !== JSON.stringify(patch.approval_cancellation_history))
    throw new Error('Approval history can only be changed through Cancel approval.');
  for (const field of ['status', 'accounting_note_status']) {
    if (['approved', 'confirmed'].includes(String(previous[field] ?? '').trim().toLowerCase()) && field in patch
      && !['approved', 'confirmed', 'transferred', 'exported', 'posted', 'paid'].includes(String(patch[field] ?? '').trim().toLowerCase()))
      throw new Error('Use Cancel approval to return a confirmed document for correction.');
  }
  for (const key of ['correction_of_document_id', 'correction_kind', 'correction_reason', 'correction_history']) {
    if (key in patch && JSON.stringify(patch[key]) !== JSON.stringify(previous[key]))
      throw new Error('Corrective document links and history can only be created through the correction workflow.');
  }
  for (const key of ['accounting_posting', 'accounting_storno', 'document_storno', 'advance_employee_reversal', 'advance_employee_history']) {
    if (key in patch && JSON.stringify(patch[key]) !== JSON.stringify(previous[key]))
      throw new Error('Confirmed accounting operations can only be changed through the posting / Storno workflow.');
  }
  if (!previous.accounting_posting && !previous.document_storno) return;
  if (['advance_employee_id', 'advance_employee'].some(key => key in patch && previous[key] !== patch[key])) throw new Error('Use Assign advance employee to retain the original GL operation and record a separate reversal.');
  // Explicit, validated document edits may correct the source document. Never
  // replace a posted snapshot, its company/identity, or external transfer state.
  if (options.documentContentEdit && !previous.document_storno) {
    if (Object.keys(patch).some(key => (['id', 'company_id', 'inactive', 'active', 'is_active'].includes(key)
      || /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key))
      && JSON.stringify(previous[key]) !== JSON.stringify(patch[key]))) throw new Error('Document identity and accounting transfer history cannot be changed by editing document fields.');
    return;
  }
  if ('accountable_responsible_id' in patch && previous.accountable_responsible_id !== patch.accountable_responsible_id) throw new Error('The confirmed accounting operation is immutable. Use Storno to reverse its effect.');
  const accountingFields = new Set(['id', 'company_id', 'status', 'accounting_note_status', 'number', 'series', 'type', 'document_type', 'document_subtype', 'currency', 'operation_date', 'document_date', 'invoice_contract_date', 'total_amount', 'amount_without_vat', 'vat', 'vat_percent', 'expense_account', 'vat_classifier', 'debit', 'credit', 'line_items', 'summary_line_items', 'counterparty_id', 'client_counterparty', 'department_code', 'object_project', 'accountable_responsible', 'cost_center', 'inactive', 'is_active', 'active']);
  if (Object.keys(patch).some(key => (accountingFields.has(key) || /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key)) && JSON.stringify(previous[key]) !== JSON.stringify(patch[key])))
    throw new Error('The confirmed accounting operation is immutable. Use Storno to reverse its effect; the original document and posting remain in history.');
}

/** Show original and reversal as independent, posted entries, including base amounts. */
export function documentPostingRows(document: StornoDocument, activeAccounts: Set<string>): GlJournalRow[] {
  const posting = document.accounting_posting;
  if (!posting || postedOperationError(posting, document)) return [];
  const operations: (PostedDocumentOperation | DocumentStorno)[] = [posting];
  if (document.accounting_storno && !savedDocumentStornoError(document)) operations.push(document.accounting_storno);
  if (document.advance_employee_reversal && !savedDocumentStornoError({ ...document, accounting_storno: document.advance_employee_reversal })) operations.push(document.advance_employee_reversal);
  return operations.flatMap(operation => operation.lines.map(line => ({
    id: line.id, sourceDocumentId: document.id, documentNumber: operation.number, internalNumber: operation.id, operationDate: operation.date,
    counterparty: line.counterparty || '—', account: line.account, accountName: line.accountName,
    description: line.description, documentType: 'Accounting note', documentSubtype: operation === document.advance_employee_reversal ? 'Advance employee reversal' : 'originalOperationId' in operation ? 'Storno' : 'Confirmed posting',
    costCenter: line.costCenter || '—', object: line.object, department: line.department, employee: line.employee, vehicle: line.vehicle,
    createdBy: operation.postedBy, createdAt: operation.postedAt, postingStatus: 'Posted', posted: true, balanced: true,
    debit: line.debitMinor / 100, credit: line.creditMinor / 100, total: Math.max(line.debitMinor, line.creditMinor) / 100,
    baseCurrency: operation.baseCurrency, baseDebit: line.baseDebitMinor / 100, baseCredit: line.baseCreditMinor / 100,
    accountActive: activeAccounts.has(line.account),
    document: { id: operation.id, number: operation.number, currency: line.currency, status: 'Approved', documentType: 'Accounting note',
      source: 'Confirmed document GL posting', documentDate: operation.date,
      note: 'originalOperationId' in operation ? `${operation === document.advance_employee_reversal ? 'Advance employee reversal' : 'Storno'} of ${operation.originalOperationNumber} (${operation.originalOperationId}). ${operation.reason}` : `Source document: ${String(document.number || document.id)}` },
  })));
}
