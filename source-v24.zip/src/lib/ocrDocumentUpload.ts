import { supabase } from './supabase';
import { getCurrentUserIdentity, getCurrentUserUploadSource } from './currentUser';
import { GLOBAL_OCR_ADDITIONAL_INFORMATION_SCOPE, ocrAdditionalInformationDocumentFields, readOcrAdditionalInformation, ocrAdditionalInformationKey } from './ocrAdditionalInformation';
import { readProfileOcrSettings } from './profileOcrSettings';

const extensions = new Set(['pdf', 'jpg', 'jpeg', 'png', 'tif', 'tiff']);
export function validateOcrUpload(files: readonly Pick<File, 'name' | 'size'>[]) {
  const unsupported = files.find(file => !extensions.has(file.name.split('.').pop()?.toLowerCase() || ''));
  if (unsupported) return `Unsupported file format: ${unsupported.name}. Use PDF, JPG, PNG or TIF.`;
  const oversized = files.find(file => file.size > 50 * 1024 * 1024);
  return oversized ? `${oversized.name} exceeds the 50 MB file size limit.` : '';
}

/** Shared intake for Dashboard and Uploaded documents. ADDINFO applies to the
 * next uploads; saving it never rewrites previously uploaded files. */
export async function uploadDocumentsForOcr(files: readonly File[], options: { companyId?: string; companyName?: string; documentCount?: number } = {}) {
  const error = validateOcrUpload(files);
  if (error) throw new Error(error);
  const scope = options.companyId || GLOBAL_OCR_ADDITIONAL_INFORMATION_SCOPE;
  const additional = readOcrAdditionalInformation(window.localStorage, scope);
  const profilePreferences = readProfileOcrSettings(window.localStorage, getCurrentUserIdentity().email).general;
  // Explicit ADDINFO selections take precedence over profile defaults.
  if (!window.localStorage.getItem(ocrAdditionalInformationKey(scope))) {
    additional.detailedSplitting = profilePreferences.digitization === 'detailed';
    additional.duplicatesAccepted = !profilePreferences.rejectDuplicates;
  }
  const ids: string[] = [];
  for (const [index, file] of files.entries()) {
    const id = `dashboard-ocr-${crypto.randomUUID()}`;
    const path = `dashboard/${id}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from('documents').upload(path, file);
    if (uploadError) throw new Error(uploadError.message);
    const imageUrl = supabase.storage.from('documents').getPublicUrl(path).data.publicUrl;
    const now = new Date(), date = now.toLocaleDateString('lt-LT');
    const { error: saveError } = await supabase.from('documents').upsert({
      id, company_id: options.companyId, receive_date: date,
      client_counterparty: options.companyName || 'Unassigned company', document_type: 'OCR intake',
      source: 'Manual', source_details: { ...getCurrentUserUploadSource(), location: file.webkitRelativePath || file.name },
      total_amount: '0.00 €', due_end_date: '', file_case: file.name, order_no: '',
      number: `OCR-${String((options.documentCount || 0) + index + 1).padStart(4, '0')}`,
      type: 'Expense', document_date: date, document_purpose: 'Submitted for OCR processing',
      invoice_contract_date: '', operation_date: date, currency: 'EUR', amount_without_vat: '0.00 €',
      vat: '0.00 €', vat_percent: '0%', valid_form: 'OCR queue', status: 'Processing',
      created_at: now.toISOString(), image_url: imageUrl || null, ocr_input_priority: 'user-confirmed',
      ocr_processing_settings: { ...profilePreferences },
      ...ocrAdditionalInformationDocumentFields(additional),
    }, { onConflict: 'id' });
    if (saveError) throw new Error(saveError.message);
    ids.push(id);
  }
  return ids;
}
