import type { DebtRow } from './companyRelatedObjectData';
import type { OrganizationEmailHistoryEntry } from './organizationEmail';
import type { ReconciliationState } from './reconciliation';
import { debtDirection } from './debtActions';

export type DebtPaymentDetail = {
  id: string;
  date: string;
  reference: string;
  matchedMinor: number;
  currency: string;
  paymentMinor: number;
  paymentCurrency: string;
  purpose: string;
  reconciliationId: string;
  reconciledAt: string;
  actor: string;
  kind: string;
};

export const debtMoney = (minor: number, currency: string) => `${(minor / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;
export const debtMinor = (amount: string) => Math.round(Number(amount.replace(/,/g, '')) * 100);
const normalize = (value: string) => value.trim().toLocaleLowerCase();

/** Companion records for the existing sample debts, never persisted as bank/GL operations. */
const SAMPLE_PAYMENTS: Record<string, { document: string; payments: Array<[string, string, number]> }> = {
  'debt-1': { document: 'INV-1025', payments: [['2026-11-06', 'BNK-00481', 60000], ['2026-11-10', 'BNK-00498', 30000]] },
  'debt-2': { document: 'PUR-2041', payments: [['2026-11-06', 'BNK-00512', 60000], ['2026-11-11', 'BNK-00528', 30000]] },
  'debt-5': { document: 'INV-1027', payments: [['2026-11-05', 'BNK-00540', 20000]] },
};

export function debtPayments(debt: DebtRow, companyId: string, state?: ReconciliationState | null): DebtPaymentDetail[] {
  if (!companyId || (state && state.organizationId !== companyId)) return [];
  const invoice = state?.items.filter(item => item.organizationId === companyId && item.kind === 'Invoice'
    && item.documentNumber === debt.documentReference && item.currency === debt.currency
    && item.side === (debtDirection(debt) === 'receivable' ? 'Receivable' : 'Payable')
    && normalize(item.counterpartyName) === normalize(debt.counterpartyName));
  // An existing invoice owns its history, even when all of its matches were reversed.
  if (invoice?.length) {
    if (invoice.length !== 1) return [];
    const invoiceId = invoice[0].id;
    return state!.batches.filter(batch => !batch.reversedAt).flatMap(batch => batch.allocations.flatMap((allocation, index) => {
      if (allocation.invoiceId !== invoiceId) return [];
      const funding = state!.items.find(item => item.id === allocation.fundingId && item.organizationId === companyId);
      if (!funding) return [];
      return [{ id: `${batch.id}:${index}`, date: funding.documentDate, reference: funding.documentNumber,
        matchedMinor: allocation.amountMinor, currency: debt.currency, paymentMinor: funding.originalMinor,
        paymentCurrency: funding.currency, purpose: funding.paymentPurpose || funding.reference,
        reconciliationId: batch.id, reconciledAt: batch.at, actor: batch.actor, kind: funding.kind }];
    })).sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
  }
  const sample = SAMPLE_PAYMENTS[debt.id];
  if (!sample || sample.document !== debt.documentReference || sample.payments.reduce((sum, row) => sum + row[2], 0) !== debtMinor(debt.paidAmount)) return [];
  return sample.payments.map(([date, reference, minor], index) => ({
    id: `${companyId}:${debt.id}:payment:${index}`, date, reference, matchedMinor: minor, currency: debt.currency,
    paymentMinor: minor, paymentCurrency: debt.currency, purpose: `Payment for invoice ${debt.documentReference}`,
    reconciliationId: `RC-${reference.replace('BNK-', '')}`, reconciledAt: date, actor: '', kind: 'Payment',
  }));
}

export function debtCommunicationHistory(history: OrganizationEmailHistoryEntry[], companyId: string, companyName: string, debt: DebtRow) {
  return history.filter(entry => {
    const sameOrganization = entry.organizationId ? entry.organizationId === companyId : normalize(entry.sender) === normalize(companyName);
    if (!companyId || !sameOrganization || normalize(entry.recipient) !== normalize(debt.counterpartyName)) return false;
    if (entry.relatedDebtIds) return entry.relatedDebtIds.includes(debt.id);
    return entry.documentReference.split(/[,;\n]/).map(value => value.trim()).includes(debt.documentReference);
  }).sort((a, b) => (Date.parse(b.sentAt) || 0) - (Date.parse(a.sentAt) || 0));
}

export function debtCommunicationType(entry: OrganizationEmailHistoryEntry) {
  if (entry.purpose === 'reminder') return 'Payment reminder';
  if (entry.purpose === 'balance-confirmation') return 'Balance confirmation';
  if (/remind|primin/i.test(entry.templateName)) return 'Payment reminder';
  if (entry.portalUrl || /reconcil|confirm|suderin/i.test(entry.templateName)) return 'Balance confirmation';
  return 'Message';
}

export function debtCommunicationStatus(entry: OrganizationEmailHistoryEntry) {
  if (entry.responseReceivedAt) return 'Reply received';
  // This frontend records messages locally; only explicit delivery evidence means Sent.
  return entry.deliveryStatus === 'sent' ? 'Sent' : 'Saved';
}
