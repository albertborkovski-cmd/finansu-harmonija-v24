import type { DbDocument } from './supabase';
import type { DocumentIssueOcrRequest } from './documentIssues';

export function detailedDigitizationError(document: DbDocument & { inactive?: boolean; active?: boolean; is_active?: boolean }, allowed: boolean): string {
  if (!allowed) return 'You need View and Edit access to Documents and access to this company.';
  if (document.document_deletion || document.inactive || document.active === false || document.is_active === false)
    return 'Restore this document before sending it to OCR.';
  if (document.entry_method === 'manual') return 'Only uploaded documents can be returned for detailed digitization.';
  if (document.digitization_issues?.some(issue => ['Open', 'In progress'].includes(issue.status)))
    return 'The Worker must finish correcting the reported issue before OCR reprocessing.';
  return '';
}

/** A new OCR cycle retains source files, posting snapshots and previous history.
 * This queues work; it does not pretend an OCR engine has already run. */
export function requestDetailedDigitization(document: DbDocument, context: { allowed: boolean; actor: string; at: string; requestId: string }): DbDocument {
  const error = detailedDigitizationError(document, context.allowed);
  if (error) throw new Error(error);
  if (document.ocr_rerun_request?.source === 'Detailed digitization' && document.ocr_rerun_request.status === 'Pending integration') return document;
  if (document.ocr_rerun_requests !== undefined && !Array.isArray(document.ocr_rerun_requests)) throw new Error('OCR request history is invalid. It was not overwritten.');
  const request: DocumentIssueOcrRequest = { id: context.requestId, requestedAt: context.at, requestedBy: context.actor,
    documentId: document.id, companyId: document.company_id || '', status: 'Pending integration', source: 'Detailed digitization',
    mode: 'Detailed', reason: 'Detailed document digitization requested from All Documents.' };
  const history = [...(document.ocr_rerun_requests || [])];
  if (document.ocr_rerun_request && !history.some(item => item.id === document.ocr_rerun_request?.id)) history.push(document.ocr_rerun_request);
  return { ...document, status: 'Processing', detailed_splitting: true, ocr_rerun_request: request,
    ocr_rerun_requests: [...history, request] };
}
