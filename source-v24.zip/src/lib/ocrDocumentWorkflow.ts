import { customOcrStatus, isAuxiliaryOcrStatus } from './ocrStatuses';

type DocumentState = {
  status?: string; source?: string; entry_method?: string; company_id?: string; document_deletion?: unknown;
  inactive?: boolean; active?: boolean; is_active?: boolean;
  ocr_rerun_request?: { status?: string; requestedAt?: string; completedAt?: string };
  digitization_issues?: { status?: string }[];
  ocr_approval_route?: { destination?: string; completedAt?: string };
};
type TaskState = {
  status?: string; trainingStatus?: string;
  ocrRunRequest?: { status?: string; requestedAt?: string };
  teamLeadReview?: { status?: string; requestedAt?: string };
};
export type OcrDocumentStage = { queue: 'processing' | 'approval'; status: string };
const normalize = (value?: string) => value?.trim().toLowerCase() || '';
const pending = (value?: string) => ['pending integration', 'pending', 'queued', 'processing', 'in progress'].includes(normalize(value));

/** A request is not an OCR result. Old task requests stop applying after completion. */
export function awaitingOcrProcessing(document: DocumentState, task?: TaskState): boolean {
  if (pending(document.ocr_rerun_request?.status)
    || document.digitization_issues?.some(issue => issue.status === 'Awaiting OCR')) return true;
  if (!pending(task?.ocrRunRequest?.status)) return false;
  const requestedAt = task?.ocrRunRequest?.requestedAt;
  const completedAt = document.ocr_rerun_request?.completedAt || document.ocr_approval_route?.completedAt;
  return !requestedAt || !completedAt || completedAt < requestedAt;
}

export function awaitingTeamLead(document: DocumentState, task?: TaskState) {
  const request = document.ocr_rerun_request;
  const route = document.ocr_approval_route;
  const newerThanRequest = (at?: string) => !request?.requestedAt || Boolean(at && at >= request.requestedAt);
  return (route?.destination === 'TeamLead' && newerThanRequest(route.completedAt))
    || (task?.teamLeadReview?.status === 'Pending' && newerThanRequest(task.teamLeadReview.requestedAt));
}

export function ocrNeedsAttention(document: DocumentState) {
  const state = normalize(document.status);
  return document.digitization_issues?.some(issue => ['Open', 'In progress'].includes(issue.status || ''))
    || customOcrStatus(document.status || '')?.group === 'Needs attention'
    || ['exception', 'exceptional', 'duplicate', 'dublicate', 'organization not identified', 'not document', 'not documented',
      'rejected', 'provide additional', 'provide additional data', 'needs info'].includes(state);
}

/** OCR work stages are separate from the invoice's accounting status.
 * An explicit rerun takes precedence over an older completed task. */
export function ocrDocumentStage(document: DocumentState, task?: TaskState): OcrDocumentStage | null {
  const state = normalize(document.status);
  if (document.document_deletion || document.inactive || document.active === false || document.is_active === false
    || ['deleted', 'inactive', 'cancelled', 'canceled', 'reversed', 'storno'].includes(state)) return null;
  if (document.digitization_issues?.some(issue => ['Open', 'In progress'].includes(issue.status || '')))
    return { queue: 'processing', status: 'Needs correction' };
  if (awaitingTeamLead(document, task)) return { queue: 'approval', status: 'Awaiting approval' };
  if (awaitingOcrProcessing(document, task))
    return { queue: 'processing', status: 'Awaiting OCR' };
  if (isAuxiliaryOcrStatus(document.status || '')) return null;
  if (['approved', 'confirmed', 'posted', 'transferred', 'exported', 'paid'].includes(state)) return null;
  if (normalize(document.entry_method) === 'manual' && !task) return null;
  if (document.ocr_approval_route?.destination === 'FH') return null;
  if (normalize(task?.status) === 'completed' || task?.trainingStatus === 'Confirmed') return null;
  const custom = customOcrStatus(document.status || '');
  if (custom) return custom.group === 'Processed' ? null
    : { queue: 'processing', status: custom.group === 'Needs attention' ? 'Needs correction' : custom.status };
  if (state === 'worker review') return { queue: 'processing', status: 'Worker review' };
  if (['processing', 'in progress'].includes(state)) return { queue: 'processing', status: 'Processing' };
  if (['queued', 'awaiting ocr', 'pending ocr'].includes(state)) return { queue: 'processing', status: state === 'queued' ? 'Queued' : 'Awaiting OCR' };
  if (['accepted', 'completed', 'processed'].includes(state)) return null;
  if (['need review', 'needs review', 'awaiting approval'].includes(state))
    return { queue: 'approval', status: 'Awaiting approval' };
  if (['in progress', 'processing'].includes(normalize(task?.status))) return { queue: 'processing', status: 'In progress' };
  if (state === 'submitted' || state === 'uploaded') return { queue: 'processing', status: 'Queued' };
  // A manual accounting document does not enter OCR merely because it is Draft.
  const source = normalize(document.entry_method || document.source);
  if (!source || source === 'manual') return null;
  if (['new', 'pending', 'draft', 'uploaded'].includes(state)) return { queue: 'processing', status: 'Queued' };
  if (['correcting', 'provide additional', 'provide additional data', 'exception', 'duplicate', 'rejected', 'not document', 'not documented'].includes(state))
    return { queue: 'processing', status: 'Needs correction' };
  return null;
}
