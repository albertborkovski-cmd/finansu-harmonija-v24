import type { LinkedDirectoryUser } from './linkedSettingsData';

export const ADVANCE_EMPLOYEE_INVOICE_TYPE = 'ADVANCE_INVOICE';
const text = (value: unknown) => typeof value === 'string' ? value.trim() : '';
export const advanceEmployeeName = (user: LinkedDirectoryUser) => user.fullName || user.username || user.email || user.id;

/** Explicit company assignments, including an empty list, override legacy names. */
export function assignedAdvanceEmployees(company: { id: string; name: string }, users: readonly LinkedDirectoryUser[], assignedIds: readonly string[] | null) {
  const ids = assignedIds === null ? null : new Set(assignedIds);
  return users.filter(user => {
    if (!['enabled', 'active'].includes(text(user.status || 'Enabled').toLowerCase()) || String(user.inactive) === 'true' || String(user.active) === 'false') return false;
    if (ids) return ids.has(user.id);
    const organizations = text(user.organizations).split(',').map(value => value.trim().toLowerCase());
    return organizations.some(value => ['all organizations', company.id.toLowerCase(), company.name.toLowerCase()].includes(value));
  });
}

export function isPurchaseInvoice(document: Record<string, unknown>) {
  const purpose = text(document.document_purpose).toLowerCase();
  return (['purchase', 'sale'].includes(purpose) ? purpose : text(document.type).toLowerCase()) === 'purchase'
    && /^(invoices?|purchase[\s_-]*invoices?|vat[\s_-]*invoice)$/i.test(text(document.document_type));
}

/** OCR may supply an ID, email or exact name. Ambiguous names must be reviewed. */
export function resolveAdvanceEmployee(id: unknown, name: unknown, users: readonly LinkedDirectoryUser[]) {
  const key = text(id), label = text(name).toLowerCase();
  if (!key && !label) return undefined;
  const matches = users.filter(user => key ? user.id === key : [advanceEmployeeName(user), user.email].some(value => text(value).toLowerCase() === label));
  if (matches.length !== 1) throw new Error('Select an active External user assigned to this company as the Advance employee.');
  return matches[0];
}

export function normalizeAdvanceEmployeeDocument<T extends Record<string, unknown>>(document: T, users: readonly LinkedDirectoryUser[]): T {
  const hasEmployee = Boolean(text(document.advance_employee_id) || text(document.advance_employee));
  if (!isPurchaseInvoice(document)) return hasEmployee ? { ...document, advance_employee_id: '', advance_employee: '' } : document;
  const employee = resolveAdvanceEmployee(document.advance_employee_id, document.advance_employee, users);
  if (!employee) return document;
  if (document.correction_of_document_id || /credit|debit/i.test(text(document.document_subtype)))
    throw new Error('A corrective invoice cannot be assigned to an Advance employee.');
  return { ...document, advance_employee_id: employee.id, advance_employee: advanceEmployeeName(employee), document_subtype: ADVANCE_EMPLOYEE_INVOICE_TYPE };
}

export function selectInvoiceAdvanceEmployee<T extends { purpose: string; kind: string; advanceEmployeeId?: string; kindBeforeAdvanceEmployee?: string; creditSourceDocumentId?: string }>(draft: T, id: string): T {
  if (draft.purpose !== 'Purchase') return { ...draft, advanceEmployeeId: '', kindBeforeAdvanceEmployee: undefined };
  return { ...draft, advanceEmployeeId: id,
    kind: id ? ADVANCE_EMPLOYEE_INVOICE_TYPE : draft.kindBeforeAdvanceEmployee || (draft.advanceEmployeeId ? 'INVOICE' : draft.kind),
    kindBeforeAdvanceEmployee: id ? draft.kindBeforeAdvanceEmployee || (draft.kind === ADVANCE_EMPLOYEE_INVOICE_TYPE ? 'INVOICE' : draft.kind) : undefined,
    ...(id ? { creditSourceDocumentId: '' } : {}) };
}
