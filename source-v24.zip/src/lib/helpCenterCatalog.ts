import type { HelpText } from './exportHelpGuide';
import { INTEGRATION_ARTICLES } from './integrationHelp';
import { integrationTopics } from './integrationHelpTopics';
import { ORGANIZATION_HELP_SECTIONS, organizationHelpHref } from './organizationSettingsHelp';
import { OCR_USER_GUIDES, guideSearchText, type OcrUserGuide } from './ocrUserGuides';
import { SECURITY_USER_GUIDES } from './securityUserGuides';
import { PROFILE_GENERAL_HELP } from './profileGeneralHelp';

export type HelpEntry = {
  id: string;
  title: HelpText;
  description: HelpText;
  href: string;
  paragraphs?: HelpText[];
  searchText?: HelpText;
  guide?: OcrUserGuide;
  parentKey?: string;
  order?: number;
};
export type HelpCategory = {
  id: string;
  title: HelpText;
  description: HelpText;
  icon: 'system' | 'security' | 'browser' | 'api' | 'collection' | 'integration' | 'workflow' | 'communication';
  entries: HelpEntry[];
};
export const helpCenterHref = (category?: string, article?: string) => {
  const query = new URLSearchParams({ ...(category ? { category } : {}), ...(article ? { article } : {}) }).toString();
  return `./#help${query ? `?${query}` : ''}`;
};
const manual = (category: string, id: string, title: HelpText, description: HelpText, paragraphs: HelpText[]): HelpEntry => ({ id, title, description, paragraphs, href: helpCenterHref(category, id) });

const systemEntries: HelpEntry[] = [
  ...PROFILE_GENERAL_HELP.map(entry => manual('system', entry.id, entry.title, entry.description, entry.paragraphs)),
  manual('system', 'about', ['What does FH OCR do?', 'Kaip veikia FH OCR?'], ['From the received document to review and accounting export.', 'Nuo gauto dokumento iki patikrinimo ir perdavimo į apskaitą.'], [
    ['OCR extracts information from a document and checks it against field rules. The original remains available for comparison. OCR processing and approval in the accounting system are different stages.', 'OCR nuskaito dokumento informaciją ir tikrina ją pagal laukų taisykles. Originalas išlieka pasiekiamas palyginimui. OCR apdorojimas ir patvirtinimas apskaitos sistemoje yra skirtingi etapai.'],
    ['Uploaded documents is the received-file register. Documents is the accountant’s workspace for processed documents. Items already sent to accounting are reviewed in the archive.', 'Įkelti dokumentai yra gautų failų registras. Dokumentai yra buhalterio darbo vieta apdorotiems dokumentams. Jau perduoti į apskaitą įrašai peržiūrimi archyve.'],
    ['An unresolved reported issue can block further work. The Worker corrects the document, returns it through OCR review and the accountant sees the updated issue status.', 'Neišspręstas klaidos pranešimas gali blokuoti tolesnius veiksmus. Darbuotojas pataiso dokumentą, grąžina jį per OCR patikrą, o buhalteris mato atnaujintą klaidos būseną.'],
  ]),
  manual('system', 'workflow', ['Document processing step by step', 'Dokumento kelias nuo įkėlimo iki eksporto'], ['Upload → OCR review → accountant → accounting system.', 'Įkėlimas → OCR patikra → buhalteris → apskaitos sistema.'], [
    ['1. Upload through Dashboard or Uploaded documents. The received file appears in All Documents → Uploaded documents. Its source identifies the uploader or connected collection channel.', '1. Įkelkite per Apžvalgą arba Įkeltus dokumentus. Failas atsiranda Visi dokumentai → Įkelti dokumentai. Šaltinis nurodo įkėlusį asmenį arba prijungtą surinkimo kanalą.'],
    ['2. Review processing status. Missing organization, duplicate or unreadable content needs attention; open the status details to see the reason.', '2. Peržiūrėkite apdorojimo būseną. Neatpažinta organizacija, dublikatas ar nenuskaitomas turinys reikalauja dėmesio; priežastį atverkite paspaudę būseną.'],
    ['3. OCR → Workspace → My tasks contains available processing work. The Worker compares fields with the original and completes missing required values. If clarification is needed, they send a comment to TeamLead.', '3. OCR → Darbo sritis → Mano užduotys pateikiami apdorojimo darbai. Darbuotojas sutikrina laukus su originalu ir užpildo trūkstamas privalomas reikšmes. Jei reikia patikslinimo, su komentaru perduoda Komandos vadovui.'],
    ['4. Confirmed learning values are reviewed in Machine learning. Automatic use depends on the learning rule, evidence and confidence; a displayed learned value is not necessarily used automatically.', '4. Patvirtintos išmoktos reikšmės peržiūrimos Mašininiame mokymesi. Automatinis naudojimas priklauso nuo taisyklės, ją pagrindžiančių dokumentų ir pasitikėjimo; matoma išmokta reikšmė nebūtinai taikoma automatiškai.'],
    ['5. Processed documents reach All Documents → Documents. The accountant checks allocations, sends an export or reports an issue with a message. Reported issues are handled in OCR → Workspace → Document issues.', '5. Apdoroti dokumentai patenka į Visi dokumentai → Dokumentai. Buhalteris tikrina paskirstymą, eksportuoja arba praneša apie klaidą su žinute. Klaidos tvarkomos OCR → Darbo sritis → Dokumentų klaidos.'],
    ['6. The export result must be verified in the receiving system. A downloaded file, a manual Exported mark and a confirmed import are not equivalent. Current FH previews do not transmit to production accounting APIs.', '6. Eksporto rezultatą reikia patikrinti gavėjo sistemoje. Atsisiųstas failas, rankinė Eksportuota žyma ir patvirtintas importas nėra tas pats. Dabartinės FH peržiūros nesiunčia duomenų į produkcines apskaitos API.'],
  ]),
  manual('system', 'pricing', ['Plans, pricing and usage', 'Planai, kainodara ir naudojimas'], ['Where to see the current plan, usage and available alternatives.', 'Kur matomas dabartinis planas, naudojimas ir galimi pakeitimai.'], [
    ['In Profile settings → Update contract, review the company’s current plan, product and usage. The company comes from Company details, not the employee’s name.', 'Profilio nustatymai → Atnaujinti sutartį peržiūrėkite įmonės dabartinį planą, produktą ir naudojimą. Įmonė imama iš Įmonės duomenų, ne darbuotojo vardo.'],
    ['Select an available OCR, Finansų harmonija or combined plan and review its pricing details and limit behaviour. The client chooses offered plans; they do not edit prices.', 'Pasirinkite siūlomą OCR, Finansų harmonijos arba bendrą planą ir peržiūrėkite kainodarą bei veiksmą pasiekus limitą. Klientas renkasi pasiūlytą planą, bet nekoreguoja kainų.'],
    ['Administrators manage plans, prices and company assignments in SaaS. Saving a frontend selection is not a bank charge or electronic contract signature.', 'Administratoriai planus, kainas ir įmonių priskyrimus tvarko SaaS. Pasirinkimo išsaugojimas frontend nėra banko mokestis ar elektroninis sutarties pasirašymas.'],
  ]),
  manual('system', 'field-checks', ['Fields, confidence and required values', 'Laukai, pasitikėjimas ir privalomos reikšmės'], ['Understand warnings and why a document requires review.', 'Ką reiškia įspėjimai ir kodėl dokumentą reikia patikrinti.'], [
    ['The document type determines applicable fields and validation. Required organization columns are configured under the organization gear → Documents & digitization setup → Additional column settings.', 'Dokumento tipas nustato taikomus laukus ir tikrinimą. Privalomi organizacijos stulpeliai nustatomi per dantratį → Dokumentų ir skaitmeninimo nustatymai → Papildomų stulpelių nustatymai.'],
    ['A red exclamation in an empty required field indicates that a value is needed in that field. Read the status explanation and compare with the original instead of entering an arbitrary value just to dismiss the warning.', 'Raudonas šauktukas tuščiame privalomame lauke rodo, kad reikalinga būtent to lauko reikšmė. Perskaitykite būsenos paaiškinimą ir lyginkite su originalu, o ne įrašykite atsitiktinę reikšmę vien įspėjimui panaikinti.'],
    ['Confidence describes recognition reliability; a required value and a confidence threshold are different controls. Review the Machine learning evidence and competing values before relying on an automatic suggestion.', 'Pasitikėjimas apibūdina atpažinimo patikimumą; privaloma reikšmė ir pasitikėjimo riba yra skirtingi tikrinimai. Prieš pasitikėdami automatiniu pasiūlymu peržiūrėkite Mašininio mokymosi dokumentus ir konkuruojančias reikšmes.'],
  ]),
];

const organizationLabels: Record<string, string> = { overview: 'Organizacijos nustatymai', digitization: 'Dokumentų ir skaitmeninimo nustatymai', counterparties: 'Kontrahentai', departments: 'Padaliniai', objects: 'Objektai', series: 'Serijos', centers: 'Centrai', persons: 'Atskaitingi asmenys', groups: 'Prekių grupės', expenses: 'Išlaidos' };
const organizationEntries: HelpEntry[] = ORGANIZATION_HELP_SECTIONS.map(section => ({ id: `organization-${section.id}`, title: [section.label, organizationLabels[section.id]], description: section.intro, href: organizationHelpHref(section.id), searchText: [section.articles.map(article => `${article.label} ${article.body[0]}`).join(' '), section.articles.map(article => article.body[1]).join(' ')] }));

const securityEntries: HelpEntry[] = [
  ...SECURITY_USER_GUIDES.map(guide => ({ id: guide.id, title: guide.title, description: guide.description, href: helpCenterHref(guide.category, guide.id), guide, paragraphs: [], searchText: guideSearchText(guide) })),
  manual('security', 'access', ['Users and access rights', 'Naudotojai ir prieigos teisės'], ['User roles and access to organizations.', 'Naudotojų rolės ir prieiga prie organizacijų.'], [
    ['Administrators manage internal users and roles in Settings → Internal users. Organization assignment and action permissions are separate from the document’s processing status.', 'Administratoriai vidinius naudotojus bei roles tvarko Nustatymai → Vidiniai naudotojai. Organizacijos priskyrimas ir veiksmų teisės yra atskiri nuo dokumento apdorojimo būsenos.'],
    ['If an action is unavailable, check the assigned role, organization access and document restrictions. Do not use another employee’s credentials to bypass them.', 'Jei veiksmas neprieinamas, patikrinkite rolę, organizacijos prieigą ir dokumento ribojimus. Nenaudokite kito darbuotojo prisijungimų ribojimams apeiti.'],
    ['The intended invitation / recovery workflow lets users create their own password. Email delivery and activation are not yet connected in V25. The administrator should not ask for or record a user password.', 'Numatyta kvietimo / atkūrimo eiga leidžia naudotojams patiems kurti slaptažodį. V25 laiškų pristatymas ir aktyvavimas dar neprijungti. Administratorius neturi prašyti arba užsirašyti naudotojo slaptažodžio.'],
  ]),
  manual('security', 'secrets', ['API keys and safe support requests', 'API raktai ir saugus kreipimasis į pagalbą'], ['Which information to share and which to keep private.', 'Ką pateikti pagalbai ir ko neatskleisti.'], [
    ['Provide the integration name, error text, time and the relevant document identifier. Hide API keys, passwords, tokens and unnecessary personal details in screenshots.', 'Pateikite integracijos pavadinimą, klaidos tekstą, laiką ir susijusio dokumento identifikatorių. Ekrano nuotraukose paslėpkite API raktus, slaptažodžius, prieigos žetonus ir nereikalingus asmens duomenis.'],
    ['Production credentials belong in a secure connected backend. The current export-settings frontend does not save or send entered secrets; it is not a production credential vault.', 'Produkcijos prisijungimai turi būti saugomi saugiame prijungtame serveryje. Dabartinis eksporto nustatymų frontend įvestų paslapčių nesaugo ir nesiunčia; tai nėra produkcinė raktų saugykla.'],
  ]),
];

const browserEntries = [
  manual('browsers', 'version', ['The browser shows an older version', 'Naršyklė rodo senesnę versiją'], ['What to do if a page or its functions do not update.', 'Ką daryti, jei puslapio vaizdas ar funkcijos neatsinaujina.'], [
    ['After a system update, the browser may temporarily display previously saved page elements. If the layout looks outdated or a button does not respond, follow these steps.', 'Po sistemos atnaujinimo naršyklė gali laikinai rodyti anksčiau išsaugotus puslapio elementus. Jei matote seną išdėstymą arba mygtukas nereaguoja, atlikite šiuos veiksmus.'],
    ['1. Save your changes, then refresh the page using the browser’s Reload button. If necessary, close the system tab and open Finansų harmonija again using your usual sign-in address.', '1. Išsaugokite pakeitimus ir atnaujinkite puslapį naršyklės mygtuku Atnaujinti. Jei reikia, uždarykite sistemos skirtuką ir iš naujo atverkite Finansų harmoniją įprastu prisijungimo adresu.'],
    ['2. If a menu or action is missing, check the selected organization and work mode: OCR, Finansų harmonija or both. Available functions also depend on your assigned role and access rights.', '2. Jei nematote meniu punkto ar veiksmo, patikrinkite pasirinktą organizaciją ir darbo režimą: OCR, Finansų harmonija arba abu. Funkcijų prieinamumas taip pat priklauso nuo jūsų rolės ir suteiktų teisių.'],
    ['3. If the problem remains, save your work, sign out and sign in again. You can also try an up-to-date browser or a private window and sign in with the same account. This helps identify whether the problem is specific to your usual browser session.', '3. Jei problema išlieka, išsaugokite darbą, atsijunkite ir prisijunkite iš naujo. Taip pat galite išbandyti atnaujintą naršyklę arba privatų langą ir prisijungti ta pačia paskyra. Tai padeda nustatyti, ar problema susijusi su įprasta naršyklės sesija.'],
    ['4. Do not clear all site data as the first step: this can sign you out and remove unsaved information or browser preferences. If refreshing and signing in again do not help, contact support with the page name, the action you tried, the time and a screenshot. Do not include passwords, API keys or unnecessary personal information.', '4. Nevalykite visų svetainės duomenų kaip pirmo veiksmo: galite būti atjungti ir prarasti neišsaugotą informaciją ar naršyklėje išsaugotas nuostatas. Jei atnaujinimas ir pakartotinis prisijungimas nepadeda, kreipkitės į pagalbą: nurodykite puslapį, bandytą veiksmą, laiką ir pridėkite ekrano nuotrauką. Neįtraukite slaptažodžių, API raktų ar nereikalingų asmens duomenų.'],
  ]),
  manual('browsers', 'files', ['Downloaded files and ZIP archives', 'Atsisiųsti failai ir ZIP archyvai'], ['Find the export and open the correct file for import.', 'Kur rasti eksportą ir kurį failą rinktis importui.'], [
    ['Use the browser’s Downloads list to find the file created by Export. A downloaded file has not been sent to accounting merely because it is on your computer.', 'Naršyklės Atsisiuntimų sąraše raskite Eksportuoti veiksmu sukurtą failą. Vien atsisiuntimas į kompiuterį nereiškia perdavimo į apskaitą.'],
    ['If the receiving system needs XML files packed inside ZIP, extract the archive first. Windows: right-click → Extract all. macOS: double-click the ZIP. Select the extracted file matching purchases or sales.', 'Jei gavėjas priima ZIP viduje esančius XML, pirmiausia išskleiskite archyvą. Windows: dešinysis pelės mygtukas → Išskleisti viską. macOS: dukart spustelėkite ZIP. Rinkitės išskleistą pirkimų arba pardavimų failą.'],
    ['Renaming a file extension does not convert its data structure. Use the receiving system’s documented file format and import command.', 'Failo plėtinio pervadinimas nekeičia duomenų struktūros. Naudokite gavėjo sistemos aprašytą formatą ir importo komandą.'],
  ]),
];

const integrationHref = (id: string, topic: string) => `./#help/integrations?${new URLSearchParams({ integration: id, topic })}`;
const integrationEntries = (ids: string[]): HelpEntry[] => ids.flatMap(id => {
  const integration = INTEGRATION_ARTICLES.find(item => item.id === id)!;
  return integrationTopics(id).map(topic => ({ id: `${id}/${topic.id}`, title: ids.length > 1 ? [`${integration.name[0]} · ${topic.title[0]}`, `${integration.name[1]} · ${topic.title[1]}`] as HelpText : topic.title, description: topic.description, href: integrationHref(id, topic.id), searchText: [topic.sections.flatMap(section => [section.title[0], ...(section.steps || []).map(step => step[0]), ...(section.paragraphs || []).map(p => p[0])]).join(' '), topic.sections.flatMap(section => [section.title[1], ...(section.steps || []).map(step => step[1]), ...(section.paragraphs || []).map(p => p[1])]).join(' ')] as HelpText }));
});
const families: Array<[string, string, string[]]> = [
  ['moneo', 'MONEO', ['MONEO Excel', 'MONEO API']],
  ['jumis', 'Jumis', ['Jumis Excel', 'Jumis XML', 'Jumis API']],
  ['horizon', 'Horizon', ['Horizon Peppol XML', 'Horizon API']],
  ['zalktis', 'Zalktis', ['Zalktis XML', 'Zalktis Accounting XML']],
  ['agnum', 'Agnum', ['Agnum']], ['apskaita5', 'Apskaita5', ['Apskaita5']], ['bss', 'BSS', ['BSS', 'BSS Api']], ['business-central', 'Business Central', ['Business Central']], ['centas', 'Centas', ['Centas']], ['debetas', 'Debetas', ['Debetas', 'Debetas Excel']], ['dineta', 'Dineta', ['Dineta']], ['finvalda', 'Finvalda', ['Finvalda', 'Finvalda Excel']], ['monet', 'Monet', ['Monet']], ['optimum', 'Optimum', ['Optimum']], ['paulita', 'Paulita', ['Paulita']], ['pragma', 'Pragma', ['Pragma3', 'Pragma4', 'Pragma4 V2']], ['rivile', 'Rivilė', ['Rivilė', 'Rivilė API']], ['rivile-erp', 'Rivilė ERP', ['Rivilė ERP']], ['saikas', 'Saikas', ['Saikas']], ['site-pro', 'Site.pro', ['Site.pro']], ['syrve', 'Syrve', ['Syrve']],
];
const grouped = new Set(families.flatMap(family => family[2]));
const otherIds = INTEGRATION_ARTICLES.filter(item => item.group === 'accounting' && !grouped.has(item.id)).map(item => item.id);
const guideEntries: HelpEntry[] = OCR_USER_GUIDES.map(guide => ({ id: guide.id, title: guide.title, description: guide.description, href: helpCenterHref(guide.category, guide.id), guide, paragraphs: [], searchText: guideSearchText(guide) }));

export const HELP_CATEGORIES: HelpCategory[] = [
  { id: 'system', title: ['Using the system', 'Darbas su sistema'], description: ['Document workflow, field rules, organizations and code directories.', 'Dokumentų eiga, laukų taisyklės, organizacijos ir kodų sąrašai.'], icon: 'system', entries: [...systemEntries, ...organizationEntries] },
  { id: 'security', title: ['Security and privacy', 'Saugumas ir privatumas'], description: ['User access, API keys and safe information sharing.', 'Naudotojų prieiga, API raktai ir saugus informacijos pateikimas.'], icon: 'security', entries: securityEntries },
  { id: 'browsers', title: ['Browsers', 'Naršyklės'], description: ['Page refresh, downloads and ZIP files.', 'Puslapio atnaujinimas, atsisiuntimai ir ZIP failai.'], icon: 'browser', entries: browserEntries },
  { id: 'api', title: ['API and invoice export formats', 'API ir sąskaitų eksportavimo formatai'], description: ['Choose the receiving system and understand its configuration.', 'Pasirinkite gavėjo sistemą ir peržiūrėkite jos konfigūravimą.'], icon: 'api', entries: INTEGRATION_ARTICLES.filter(item => item.group === 'accounting').map(item => ({ id: item.id, title: item.name, description: item.summary, href: integrationHref(item.id, 'configuration') })) },
  { id: 'collection', title: ['Document collection', 'Dokumentų surinkimas'], description: ['Email, Google Drive, SharePoint, API and source information.', 'El. paštas, Google Drive, SharePoint, API ir šaltinių informacija.'], icon: 'collection', entries: integrationEntries(INTEGRATION_ARTICLES.filter(item => item.group === 'collection').map(item => item.id)) },
  { id: 'ocr-workflow', title: ['OCR workflow: a practical user guide', 'OCR darbo eiga: praktinė naudotojo instrukcija'], description: ['First login, upload, My tasks, TeamLead, issues, learning and accountant review — with screenshots.', 'Pirmas prisijungimas, įkėlimas, Mano užduotys, vadovas, klaidos, mokymasis ir buhalterio patikra – su nuotraukomis.'], icon: 'workflow', entries: guideEntries.filter(entry => entry.guide?.category === 'ocr-workflow') },
  { id: 'communication', title: ['Notifications, reminders and chats', 'Pranešimai, priminimai ir pokalbiai'], description: ['Bell priorities, active alerts and document-linked conversations between accountants and workers.', 'Varpelio prioritetai, aktyvūs signalai ir su dokumentu susietas buhalterio bei darbuotojo susirašinėjimas.'], icon: 'communication', entries: guideEntries.filter(entry => entry.guide?.category === 'communication') },
  ...families.map(([id, name, ids]): HelpCategory => ({ id, title: [name, name], description: [`${name}: setup, invoice import, codes and error explanations.`, `${name}: nustatymai, sąskaitų importas, kodai ir klaidų paaiškinimai.`], icon: 'integration', entries: integrationEntries(ids) })),
  { id: 'other-integrations', title: ['Other systems and file formats', 'Kitos sistemos ir failų formatai'], description: ['Būtent, CSV, Excel, iSAF, Odoo, XML and other supported settings.', 'Būtent, CSV, Excel, iSAF, Odoo, XML ir kiti nustatymų variantai.'], icon: 'integration', entries: integrationEntries(otherIds) },
];

export const HELP_FEATURED = ['first-session', 'worker-tasks', 'issues', 'notifications'].map(id => guideEntries.find(entry => entry.id === id)!);
const normalize = (value: string) => value.toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const createSearchIndex = (categories: HelpCategory[]) => Array.from(new Map(categories.flatMap(category => category.entries.map(entry => [entry.href, { category, entry, texts: [0, 1].map(lang => normalize(`${category.title[lang]} ${entry.title[lang]} ${entry.description[lang]} ${entry.searchText?.[lang] || ''} ${entry.paragraphs?.map(p => p[lang]).join(' ') || ''}`)) }] as const))).values());
const searchIndex = createSearchIndex(HELP_CATEGORIES);
export function searchHelp(query: string, lang: 0 | 1, categories?: HelpCategory[]) {
  const words = normalize(query).trim().split(/\s+/).filter(Boolean);
  if (!words.length) return [];
  return (categories ? createSearchIndex(categories) : searchIndex).filter(item => words.every(word => item.texts[lang].includes(word)))
    .sort((a, b) => Number(normalize(b.entry.title[lang]).includes(normalize(query.trim()))) - Number(normalize(a.entry.title[lang]).includes(normalize(query.trim()))));
}
