export const SYSTEM_TOOLTIP_ID = 'fh-system-tooltip';
export const SYSTEM_TOOLTIP_FADE_MS = 75;
export const TOOLTIP_TARGETS = '[data-tooltip], [data-system-tooltip-native], [data-system-tooltip-target], button, [role="button"], a[href], [title], svg[aria-label]';

/** Capture legacy titles once and keep them out of the native browser tooltip system.
 * React may write title again during a refresh; the shared observer normalizes it again. */
export function suppressNativeTooltipTitles(root: Element) {
  for (const element of [root, ...root.querySelectorAll('[title]')]) {
    if (!element.hasAttribute('title')) continue;
    element.setAttribute('data-system-tooltip-native', element.getAttribute('title') || '');
    element.removeAttribute('title');
  }
}

const plainText = (value: string) => value.replace(/\s+/g, ' ').trim();
const comparableText = (value: string) => plainText(value).toLocaleLowerCase().replace(/[\s:·.!]+$/g, '');

/** Read rendered labels, excluding icon titles, screen-reader labels and input values. */
function visibleTooltipText(element: Element): string {
  const read = (node: Node): string => {
    if (node.nodeType === 3) return node.textContent || '';
    if (node.nodeType !== 1) return '';
    const item = node as Element;
    if (item.matches('svg, [hidden], [aria-hidden="true"], .sr-only, input, textarea, select')) return '';
    const style = item.ownerDocument.defaultView?.getComputedStyle(item);
    if (style?.display === 'none' || style?.visibility === 'hidden') return '';
    return Array.from(item.childNodes).map(read).join('');
  };
  return plainText(read(element));
}

/** Only actual clipped text needs a full-value tooltip, not every titled table cell. */
export function hasTruncatedTooltipText(element: Element): boolean {
  const candidates = [element, ...element.querySelectorAll('span, p, div, a, button, label')];
  return candidates.some(item => {
    if (!item.getClientRects().length || !plainText(item.textContent || '')) return false;
    const style = item.ownerDocument.defaultView?.getComputedStyle(item);
    if (!style) return false;
    const clipsX = ['hidden', 'clip'].includes(style.overflowX) || style.textOverflow === 'ellipsis';
    const clipsY = ['hidden', 'clip'].includes(style.overflowY) || Number.parseInt(style.webkitLineClamp, 10) > 0;
    return (clipsX && item.clientWidth > 0 && item.scrollWidth > item.clientWidth + 1)
      || (clipsY && item.clientHeight > 0 && item.scrollHeight > item.clientHeight + 1);
  });
}

/** Icons explain actions; text controls only add meaningful help or reveal clipping. */
export function systemTooltipText(element: Element): string {
  const explicit = (element.getAttribute('data-tooltip') || element.getAttribute('title') || element.getAttribute('data-system-tooltip-native')
    || element.parentElement?.getAttribute('title') || element.parentElement?.getAttribute('data-system-tooltip-native') || '').trim();
  const text = visibleTooltipText(element);
  const icon = element.querySelector('svg');
  const hasVisibleLabel = Boolean(text && !/^[+×…⋮⋯−–-]+$/.test(text) && !(icon && /^\d+\+?$/.test(text)));
  if (hasVisibleLabel) {
    if (hasTruncatedTooltipText(element)) return text;
    // Keep explicit help (e.g. why an action is unavailable), not accessible row names.
    if (explicit && comparableText(explicit) !== comparableText(text)
      && (element.hasAttribute('data-tooltip') || element.matches('button, [role="button"], [aria-disabled="true"], [disabled]')
        || Boolean(element.querySelector(':disabled, [aria-disabled="true"]')))) return explicit;
    return '';
  }
  if (explicit && !/^[—–-]+$/.test(explicit)) return explicit;
  const label = element.getAttribute('aria-label');
  if (label?.trim()) return label.trim();
  const labelledBy = element.getAttribute('aria-labelledby')?.split(/\s+/).map(id => element.ownerDocument.getElementById(id)?.textContent || '').join(' ').trim();
  if (labelledBy) return labelledBy;
  if (element.matches('button, [role="button"], a[href]')) {
    const icons: Record<string, string> = {
      'lucide-plus': 'Add', 'lucide-x': 'Close', 'lucide-trash-2': 'Delete', 'lucide-pencil': 'Edit',
      'lucide-copy': 'Copy', 'lucide-eye': 'View', 'lucide-download': 'Export', 'lucide-upload': 'Import',
      'lucide-settings': 'Settings', 'lucide-refresh-cw': 'Refresh', 'lucide-info': 'Information',
      'lucide-chevron-down': 'Open options', 'lucide-chevron-up': 'Collapse',
      'lucide-chevron-left': 'Previous', 'lucide-chevron-right': 'Next',
      'lucide-arrow-left': 'Back', 'lucide-more-horizontal': 'More actions', 'lucide-ellipsis': 'More actions',
      'lucide-search': 'Search', 'lucide-filter': 'Add filters', 'lucide-save': 'Save',
    };
    for (const [className, name] of Object.entries(icons)) if (icon?.classList.contains(className)) return name;
  }
  return '';
}

export function systemTooltipPosition(anchor: { left: number; right: number; top: number; bottom: number }, size: { width: number; height: number }, viewport: { width: number; height: number }, side = 'bottom') {
  const gap = 8, edge = 8;
  const clamp = (value: number, max: number) => Math.max(edge, Math.min(value, Math.max(edge, max)));
  let left = (anchor.left + anchor.right - size.width) / 2;
  let top = anchor.bottom + gap;
  if (side === 'right' && anchor.right + gap + size.width <= viewport.width - edge) {
    left = anchor.right + gap; top = (anchor.top + anchor.bottom - size.height) / 2;
  } else if (top + size.height > viewport.height - edge) top = anchor.top - size.height - gap;
  return { left: clamp(left, viewport.width - size.width - edge), top: clamp(top, viewport.height - size.height - edge) };
}
