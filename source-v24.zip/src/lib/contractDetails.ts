import { validateContractPlan, type ContractPlan } from './contractPricing';
export type ContractDetails = { companyName: string; companyCode: string; vatCode: string; representative: string; address: string; country: string };
export type ContractPlanSelection = { planId: string; pricingRevision: number; planSnapshot: ContractPlan; tierId?: string };
export const contractStorageKey = (email: string) => `finansu-harmonija-v24:contract-details:${email.trim().toLowerCase()}`;
const countryCodes = 'AF AL DZ AS AD AO AI AQ AG AR AM AW AU AT AZ BS BH BD BB BY BE BZ BJ BM BT BO BQ BA BW BV BR IO BN BG BF BI CV KH CM CA KY CF TD CL CN CX CC CO KM CG CD CK CR CI HR CU CW CY CZ DK DJ DM DO EC EG SV GQ ER EE SZ ET FK FO FJ FI FR GF PF TF GA GM GE DE GH GI GR GL GD GP GU GT GG GN GW GY HT HM VA HN HK HU IS IN ID IR IQ IE IM IL IT JM JP JE JO KZ KE KI KP KR KW KG LA LV LB LS LR LY LI LT LU MO MG MW MY MV ML MT MH MQ MR MU YT MX FM MD MC MN ME MS MA MZ MM NA NR NP NL NC NZ NI NE NG NU NF MK MP NO OM PK PW PS PA PG PY PE PH PN PL PT PR QA RE RO RU RW BL SH KN LC MF PM VC WS SM ST SA SN RS SC SL SG SX SK SI SB SO ZA GS SS ES LK SD SR SJ SE CH SY TW TJ TZ TH TL TG TK TO TT TN TR TM TC TV UG UA AE GB US UM UY UZ VU VE VN VG VI WF EH YE ZM ZW XK'.split(' ');
export function contractCountries(language: 'lt' | 'en') {
  const names = new Intl.DisplayNames([language], { type: 'region' });
  return countryCodes.map(value => ({ value, label: names.of(value) || value })).sort((a, b) => a.label.localeCompare(b.label, language));
}
export function validateContractDetails(details: ContractDetails) {
  const errors: Partial<Record<keyof ContractDetails, string>> = {};
  for (const key of ['companyName', 'companyCode', 'representative', 'address', 'country'] as const) {
    if (!details[key].trim()) errors[key] = 'This field is required.';
  }
  if (details.country && !countryCodes.includes(details.country)) errors.country = 'Select a country from the list.';
  return errors;
}
export function readContractDetails(storage: Pick<Storage, 'getItem'>, email: string, representative: string): ContractDetails {
  const empty: ContractDetails = { companyName: '', companyCode: '', vatCode: '', representative, address: '', country: '' };
  try {
    const saved = JSON.parse(storage.getItem(contractStorageKey(email)) || 'null')?.details;
    if (!saved || typeof saved !== 'object') return empty;
    for (const key of Object.keys(empty) as (keyof ContractDetails)[]) if (typeof saved[key] === 'string') empty[key] = saved[key];
  } catch { /* Keep an editable form if local data is unavailable. */ }
  return empty;
}
export function readContractPlanId(storage: Pick<Storage, 'getItem'>, email: string) {
  try {
    const selection = JSON.parse(storage.getItem(contractStorageKey(email)) || 'null')?.pricing;
    return typeof selection?.planId === 'string' ? selection.planId : 'documents-and-lines';
  } catch { return 'documents-and-lines'; }
}
export function readConfirmedContractPlan(storage: Pick<Storage, 'getItem'>, email: string): ContractPlan | undefined {
  try {
    const pricing = JSON.parse(storage.getItem(contractStorageKey(email)) || 'null')?.pricing;
    return pricing?.planSnapshot?.id === pricing?.planId && !validateContractPlan(pricing.planSnapshot)
      ? structuredClone(pricing.planSnapshot) : undefined;
  } catch { return undefined; }
}
export function readContractTierId(storage: Pick<Storage, 'getItem'>, email: string): string {
  try {
    const pricing = JSON.parse(storage.getItem(contractStorageKey(email)) || 'null')?.pricing;
    return typeof pricing?.tierId === 'string' && pricing.planSnapshot?.id === pricing.planId
      && Array.isArray(pricing.planSnapshot?.tiers) && pricing.planSnapshot.tiers.some((tier: { id?: unknown }) => tier?.id === pricing.tierId)
      ? pricing.tierId : '';
  } catch { return ''; }
}
export function confirmContractDetails(storage: Pick<Storage, 'setItem'>, email: string, details: ContractDetails, pricing?: ContractPlanSelection) {
  if (Object.keys(validateContractDetails(details)).length) throw new Error('Complete the required company details.');
  if (pricing?.tierId && !pricing.planSnapshot.tiers.some(tier => tier.id === pricing.tierId)) throw new Error('Select a document range from the table.');
  const normalized = Object.fromEntries(Object.entries(details).map(([key, value]) => [key, value.trim()]));
  const record = { details: normalized, ...(pricing ? { pricing: structuredClone(pricing) } : {}), confirmedAt: new Date().toISOString(), confirmedBy: email, status: 'details-confirmed' };
  storage.setItem(contractStorageKey(email), JSON.stringify(record));
  return record;
}
