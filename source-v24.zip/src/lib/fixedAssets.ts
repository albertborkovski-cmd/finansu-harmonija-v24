/** Company-scoped fixed assets. Monetary values are integer minor units. */
export const ASSET_SECTIONS = [
  { id: 'register', label: 'Asset register' }, { id: 'depreciation', label: 'Depreciation' },
  { id: 'groups', label: 'Asset groups' }, { id: 'inventory', label: 'Asset inventory' },
  { id: 'operations', label: 'Asset operations' },
] as const;
export type AssetSection = typeof ASSET_SECTIONS[number]['id'];
export const ASSET_METHODS = ['Straight-line', 'Double-declining balance', 'Units of production', 'Sum-of-years-digits'] as const;
export type AssetMethod = typeof ASSET_METHODS[number];
export type AssetKind = 'Commissioning' | 'Opening balance' | 'Depreciation' | 'Modernization' | 'Revaluation' | 'Write-off' | 'Withdrawal for sale' | 'Transfer between groups';
export interface AssetGroup { id: string; code: string; name: string; assetAccount: string; depreciationAccount: string; expenseAccount: string; lifeMonths: number; method: AssetMethod; inactive: boolean }
export interface AssetSource { id: string; documentId?: string; number: string; amount: number }
export interface FixedAsset {
  id: string; number: string; name: string; groupId: string; acquisitionDate: string;
  cost: number; residual: number; openingDepreciation: number; lifeMonths: number; method: AssetMethod;
  depreciable: boolean; totalUnits: number; quantity: number; location: string; department: string;
  responsible: string; note: string; sources: AssetSource[]; inactive: boolean;
}
export interface AssetPosting { account: string; debit: number; credit: number }
export interface AssetOperation {
  id: string; number: string; assetId: string; assetNumber: string; assetName: string;
  kind: AssetKind; date: string; costChange: number; depreciationChange: number;
  lifeExtension: number; units: number; reason: string; lines: AssetPosting[]; by: string; at: string;
}
export interface AssetInventory {
  id: string; number: string; date: string; locked: boolean;
  lines: { assetId: string; number: string; name: string; bookQuantity: number; actualQuantity: number; bookValue: number; note: string }[];
}
export interface AssetStore {
  version: 1; companyId: string; currency: string; revision: number; examplesVersion?: number;
  assets: FixedAsset[]; groups: AssetGroup[]; operations: AssetOperation[]; inventories: AssetInventory[];
  audit: { id: string; subjectId: string; action: string; by: string; at: string }[];
}
export type AssetCommand =
  | { type: 'save-asset'; asset: FixedAsset }
  | { type: 'save-group'; group: AssetGroup }
  | { type: 'remove'; collection: 'assets' | 'groups'; id: string; linked?: boolean }
  | { type: 'restore'; collection: 'assets' | 'groups'; id: string }
  | { type: 'post'; assetId: string; kind: Exclude<AssetKind, 'Depreciation'>; date: string; account: string; amount: number; lifeExtension: number; reason: string; targetGroupId?: string }
  | { type: 'depreciate'; month: string; assetIds: string[]; units: Record<string, number> }
  | { type: 'save-inventory'; inventory: AssetInventory };
export interface AssetContext { today: string; by: string; at: string; id: () => string; accounts: { code: string; parentCode?: string; inactive?: boolean }[]; periodError: (date: string) => string }
export const assetStorageKey = (companyId: string) => `finansu-harmonija:v23:fixed-assets:${companyId}`;
export const assetToday = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export const assetMoney = (value: number) => (value / 100).toFixed(2);
export const assetMinor = (value: string | number) => Math.round(Number(String(value).replace(',', '.')) * 100);
export const validAssetDate = (date: string) => /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(Date.parse(date)) && new Date(date + 'T12:00:00Z').toISOString().slice(0, 10) === date;
export function assetMonthEnd(month: string) { if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) return ''; const [y, m] = month.split('-').map(Number); return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10); }
export function nextAssetMonth(month: string) { const [y, m] = month.slice(0, 7).split('-').map(Number); return new Date(Date.UTC(y, m, 1)).toISOString().slice(0, 7); }
export const newAssetStore = (companyId: string, currency: string): AssetStore => ({ version: 1, companyId, currency, revision: 0, assets: [], groups: [], operations: [], inventories: [], audit: [] });
export function parseAssetStore(raw: string | null, companyId: string, currency: string): AssetStore {
  if (!raw) return newAssetStore(companyId, currency);
  let s: AssetStore; try { s = JSON.parse(raw); } catch { throw new Error('The asset register could not be read.'); }
  if (!s || s.version !== 1 || s.companyId !== companyId || s.currency !== currency || !Number.isInteger(s.revision) || s.revision < 0 || !['assets', 'groups', 'operations', 'inventories', 'audit'].every(k => Array.isArray(s[k as keyof AssetStore]))) throw new Error('The asset register does not match this company or currency.');
  for (const rows of [s.assets, s.groups, s.operations, s.inventories]) if (new Set(rows.map(r => r.id)).size !== rows.length) throw new Error('The asset register contains duplicate records.');
  for (const a of s.assets) if (!a.id || !a.name || !a.number || !validAssetDate(a.acquisitionDate) || !Array.isArray(a.sources) || !ASSET_METHODS.includes(a.method) || !Number.isInteger(a.lifeMonths) || a.lifeMonths < 1 || ![a.cost, a.residual, a.openingDepreciation].every(v => Number.isSafeInteger(v) && v >= 0) || !s.groups.some(g => g.id === a.groupId)) throw new Error('The asset register contains invalid records.');
  for (const op of s.operations) if (!s.assets.some(a => a.id === op.assetId) || !validAssetDate(op.date) || ![op.costChange, op.depreciationChange, op.lifeExtension].every(Number.isSafeInteger) || !Array.isArray(op.lines) || !op.lines.length || op.lines.some(l => !l.account || !Number.isSafeInteger(l.debit) || !Number.isSafeInteger(l.credit) || l.debit < 0 || l.credit < 0) || op.lines.reduce((n, l) => n + l.debit - l.credit, 0) !== 0) throw new Error('The asset register contains invalid postings.');
  if (s.inventories.some(i => !i.id || !validAssetDate(i.date) || !Array.isArray(i.lines) || i.lines.some(l => !s.assets.some(a => a.id === l.assetId) || !Number.isFinite(l.actualQuantity)))) throw new Error('The asset register contains invalid records.');
  return s;
}
export function blankAsset(id: string, group?: AssetGroup): FixedAsset {
  return { id, number: '', name: '', groupId: group?.id || '', acquisitionDate: assetToday(), cost: 0, residual: 0, openingDepreciation: 0, lifeMonths: group?.lifeMonths || 60, method: group?.method || 'Straight-line', depreciable: true, totalUnits: 0, quantity: 1, location: '', department: '', responsible: '', note: '', sources: [], inactive: false };
}
export function assetBalance(s: AssetStore, a: FixedAsset, date = '9999-12-31') {
  const ops = s.operations.filter(o => o.assetId === a.id && o.date <= date);
  const start = ops.find(o => o.kind === 'Commissioning' || o.kind === 'Opening balance');
  const disposed = ops.some(o => o.kind === 'Write-off' || o.kind === 'Withdrawal for sale');
  const cost = start ? ops.reduce((n, o) => n + o.costChange, 0) : a.cost;
  const depreciation = start ? ops.reduce((n, o) => n + o.depreciationChange, 0) : a.openingDepreciation;
  const months = ops.filter(o => o.kind === 'Depreciation').length;
  return { cost, depreciation, book: cost - depreciation, months, life: a.lifeMonths + ops.reduce((n, o) => n + o.lifeExtension, 0), start, disposed, status: a.inactive ? 'Inactive' : disposed ? 'Disposed' : start ? 'In use' : 'Draft' };
}
export function assetUsed(s: AssetStore, id: string) { return s.operations.some(o => o.assetId === id) || s.inventories.some(i => i.lines.some(l => l.assetId === id)) || !!s.assets.find(a => a.id === id)?.sources.length; }
export function depreciationPreview(s: AssetStore, a: FixedAsset, month: string, units = 0) {
  const date = assetMonthEnd(month), b = assetBalance(s, a);
  let reason = '';
  const dep = s.operations.filter(o => o.assetId === a.id && o.kind === 'Depreciation').sort((x, y) => x.date.localeCompare(y.date));
  const expected = b.start ? nextAssetMonth(dep.at(-1)?.date || b.start.date) : '';
  if (!date) reason = 'Select a valid month.';
  else if (a.inactive || !b.start || b.disposed) reason = 'The asset is not in use.';
  else if (!a.depreciable) reason = 'Depreciation is disabled for this asset.';
  else if (dep.some(o => o.date.slice(0, 7) === month)) reason = 'This month is already calculated.';
  else if (month !== expected) reason = month < expected ? 'Depreciation starts in the next month after commissioning.' : 'Calculate the preceding month first.';
  else if (s.operations.some(o => o.assetId === a.id && o.date > date)) reason = 'A later asset operation already exists.';
  else if (b.book <= a.residual) reason = 'The asset is fully depreciated.';
  else if (a.method === 'Units of production' && (!Number.isFinite(units) || units <= 0 || a.totalUnits <= 0)) reason = 'Enter production units for this month.';
  const remaining = Math.max(0, b.book - a.residual), remainingMonths = Math.max(1, b.life - b.months);
  let amount = remaining / remainingMonths;
  if (a.method === 'Double-declining balance') amount = remainingMonths === 1 ? remaining : Math.max(amount, b.book * 2 / b.life);
  if (a.method === 'Units of production') amount = (b.cost - a.openingDepreciation - a.residual) * units / a.totalUnits;
  if (a.method === 'Sum-of-years-digits') {
    // Year weights, including a possible final partial year; monthly allocation.
    const weights = Array.from({ length: remainingMonths }, (_, i) => Math.ceil((remainingMonths - i) / 12));
    amount = remaining * weights[0] / weights.reduce((n, w) => n + w, 0);
  }
  return { assetId: a.id, date, expected, amount: reason ? 0 : Math.min(remaining, Math.max(0, Math.round(amount))), reason };
}
function requireAccount(code: string, ctx: AssetContext) {
  if (!ctx.accounts.some(a => a.code === code && !a.inactive) || ctx.accounts.some(a => a.parentCode === code)) throw new Error('Choose an active posting GL account.');
}
function requireDate(date: string, ctx: AssetContext) {
  if (!validAssetDate(date) || date > ctx.today) throw new Error('Choose a valid date that is not in the future.');
  if (ctx.periodError(date)) throw new Error('The accounting period is locked.');
}
export function changeAssetStore(previous: AssetStore, command: AssetCommand, ctx: AssetContext): AssetStore {
  const s = structuredClone(previous);
  const audit = (id: string, action: string) => s.audit.push({ id: ctx.id(), subjectId: id, action, by: ctx.by, at: ctx.at });
  const post = (a: FixedAsset, kind: AssetKind, date: string, costChange: number, depreciationChange: number, lines: AssetPosting[], reason: string, lifeExtension = 0, units = 0) => {
    requireDate(date, ctx);
    if (date < a.acquisitionDate || s.operations.some(o => o.assetId === a.id && o.date > date)) throw new Error('The operation cannot precede acquisition or a later asset operation.');
    const nonzero = lines.filter(l => l.debit || l.credit);
    nonzero.forEach(l => requireAccount(l.account, ctx));
    if (!nonzero.length || nonzero.some(l => !Number.isSafeInteger(l.debit) || !Number.isSafeInteger(l.credit) || l.debit < 0 || l.credit < 0) || nonzero.reduce((n, l) => n + l.debit - l.credit, 0)) throw new Error('Debit and credit must balance.');
    s.operations.push({ id: ctx.id(), number: `FA-${String(s.operations.length + 1).padStart(6, '0')}`, assetId: a.id, assetNumber: a.number, assetName: a.name, kind, date, costChange, depreciationChange, lifeExtension, units, reason: reason.trim(), lines: nonzero, by: ctx.by, at: ctx.at });
    audit(a.id, kind);
  };
  if (command.type === 'save-group') {
    const g = structuredClone(command.group);
    if (!g.id || !g.name.trim() || !g.code.trim() || !ASSET_METHODS.includes(g.method) || !Number.isInteger(g.lifeMonths) || g.lifeMonths < 1 || g.lifeMonths > 1200) throw new Error('Complete the asset group and useful life.');
    if (s.groups.some(x => x.id !== g.id && x.code.toLocaleLowerCase() === g.code.trim().toLocaleLowerCase())) throw new Error('This code already exists.');
    [g.assetAccount, g.depreciationAccount, g.expenseAccount].forEach(c => requireAccount(c, ctx));
    if (new Set([g.assetAccount, g.depreciationAccount, g.expenseAccount]).size !== 3) throw new Error('Use different asset, depreciation and expense accounts.');
    const old = s.groups.find(x => x.id === g.id);
    if (old && s.assets.some(a => a.groupId === g.id && s.operations.some(o => o.assetId === a.id)) && ['assetAccount', 'depreciationAccount', 'expenseAccount'].some(k => old[k as keyof AssetGroup] !== g[k as keyof AssetGroup])) throw new Error('GL accounts of a posted asset group cannot be replaced. Create a new group.');
    const index = s.groups.findIndex(x => x.id === g.id); if (index < 0) s.groups.push(g); else s.groups[index] = g;
    audit(g.id, 'Asset group saved');
  } else if (command.type === 'save-asset') {
    const a = structuredClone(command.asset), old = s.assets.find(x => x.id === a.id);
    a.sources = a.sources.map(source => ({ ...source, documentId: source.id }));
    if (!a.id || !a.number.trim() || !a.name.trim() || !validAssetDate(a.acquisitionDate) || !s.groups.some(g => g.id === a.groupId && !g.inactive) || !ASSET_METHODS.includes(a.method)) throw new Error('Complete the asset number, name, group and acquisition date.');
    if (s.assets.some(x => x.id !== a.id && x.number.trim().toLocaleLowerCase() === a.number.trim().toLocaleLowerCase())) throw new Error('This inventory number already exists.');
    if (![a.cost, a.residual, a.openingDepreciation].every(n => Number.isSafeInteger(n) && n >= 0) || a.cost <= 0 || a.openingDepreciation + a.residual > a.cost || !Number.isInteger(a.lifeMonths) || a.lifeMonths < 1 || a.lifeMonths > 1200 || !Number.isFinite(a.quantity) || a.quantity <= 0 || !Number.isFinite(a.totalUnits) || (a.method === 'Units of production' && a.totalUnits <= 0)) throw new Error('Check the cost, residual value, accumulated depreciation and useful life.');
    if (new Set(a.sources.map(d => d.id)).size !== a.sources.length || a.sources.some(d => !d.id || !d.number || !Number.isSafeInteger(d.amount) || d.amount <= 0) || a.sources.reduce((n, d) => n + d.amount, 0) > a.cost) throw new Error('Check the acquisition document amounts.');
    const locked: (keyof FixedAsset)[] = ['number', 'groupId', 'acquisitionDate', 'cost', 'residual', 'openingDepreciation', 'lifeMonths', 'method', 'depreciable', 'totalUnits', 'quantity', 'sources'];
    if (old && s.operations.some(o => o.assetId === old.id) && locked.some(k => JSON.stringify(old[k]) !== JSON.stringify(a[k]))) throw new Error('Posted asset values can only be changed through asset operations.');
    if (old) s.assets[s.assets.indexOf(old)] = a; else s.assets.push(a);
    audit(a.id, 'Asset card saved');
  } else if (command.type === 'remove' || command.type === 'restore') {
    const list = s[command.collection], record = list.find(x => x.id === command.id);
    if (!record) throw new Error('The record no longer exists.');
    if (command.type === 'restore') { record.inactive = false; audit(record.id, 'Reactivated'); }
    else {
      const used = command.linked || (command.collection === 'assets' ? assetUsed(s, record.id) : s.assets.some(a => a.groupId === record.id));
      if (used) { record.inactive = true; audit(record.id, 'Deactivated'); }
      else { list.splice(list.indexOf(record as never), 1); audit(record.id, 'Deleted'); }
    }
  } else if (command.type === 'depreciate') {
    requireDate(assetMonthEnd(command.month), ctx);
    if (!command.assetIds.length || new Set(command.assetIds).size !== command.assetIds.length) throw new Error('Select assets to calculate.');
    for (const id of command.assetIds) {
      const a = s.assets.find(x => x.id === id); if (!a) throw new Error('The record no longer exists.');
      const p = depreciationPreview(s, a, command.month, command.units[id] || 0); if (p.reason || !p.amount) throw new Error(p.reason || 'The asset is fully depreciated.');
      const g = s.groups.find(x => x.id === a.groupId); if (!g || g.inactive) throw new Error('Choose an active asset group.');
      post(a, 'Depreciation', p.date, 0, p.amount, [{ account: g.expenseAccount, debit: p.amount, credit: 0 }, { account: g.depreciationAccount, debit: 0, credit: p.amount }], command.month, 0, command.units[id] || 0);
    }
  } else if (command.type === 'post') {
    const a = s.assets.find(x => x.id === command.assetId), g = s.groups.find(x => x.id === a?.groupId);
    if (!a || a.inactive || !g || g.inactive) throw new Error('Choose an active asset and group.');
    const b = assetBalance(s, a), c = command;
    requireDate(c.date, ctx);
    if (c.kind !== 'Transfer between groups') requireAccount(c.account, ctx);
    if (!c.reason.trim()) throw new Error('Enter the operation reason.');
    if (c.account === g.assetAccount || c.account === g.depreciationAccount) throw new Error('Choose a different correspondence account.');
    if (c.kind === 'Commissioning' || c.kind === 'Opening balance') {
      if (b.start) throw new Error('The asset is already commissioned.');
      if (c.kind === 'Commissioning' && a.openingDepreciation) throw new Error('Use Opening balance for existing accumulated depreciation.');
      const lines = [{ account: g.assetAccount, debit: a.cost, credit: 0 }, { account: c.account, debit: 0, credit: a.cost }];
      if (a.openingDepreciation) lines.push({ account: c.account, debit: a.openingDepreciation, credit: 0 }, { account: g.depreciationAccount, debit: 0, credit: a.openingDepreciation });
      post(a, c.kind, c.date, a.cost, a.openingDepreciation, lines, c.reason);
    } else {
      if (!b.start || b.disposed) throw new Error('The asset is not in use.');
      if (c.kind === 'Transfer between groups') {
        const target = s.groups.find(x => x.id === c.targetGroupId && !x.inactive && x.id !== g.id);
        if (!target) throw new Error('Choose a different active asset group.');
        post(a, c.kind, c.date, 0, 0, [
          { account: target.assetAccount, debit: b.cost, credit: 0 }, { account: g.assetAccount, debit: 0, credit: b.cost },
          { account: g.depreciationAccount, debit: b.depreciation, credit: 0 }, { account: target.depreciationAccount, debit: 0, credit: b.depreciation },
        ], c.reason);
        a.groupId = target.id;
      } else if (c.kind === 'Modernization' || c.kind === 'Revaluation') {
        if (!Number.isSafeInteger(c.amount) || !c.amount || (c.kind === 'Modernization' && c.amount < 0) || b.book + c.amount < a.residual || !Number.isInteger(c.lifeExtension) || c.lifeExtension < 0 || b.life + c.lifeExtension > 1200) throw new Error('Check the adjustment amount and useful life extension.');
        const value = Math.abs(c.amount), increase = c.amount > 0;
        post(a, c.kind, c.date, c.amount, 0, [{ account: g.assetAccount, debit: increase ? value : 0, credit: increase ? 0 : value }, { account: c.account, debit: increase ? 0 : value, credit: increase ? value : 0 }], c.reason, c.lifeExtension);
      } else if (c.kind === 'Write-off' || c.kind === 'Withdrawal for sale') {
        const lastMonth = new Date(Date.UTC(Number(c.date.slice(0, 4)), Number(c.date.slice(5, 7)) - 1, 0)).toISOString().slice(0, 7);
        const preview = depreciationPreview(s, a, lastMonth);
        if (a.depreciable && b.book > a.residual && preview.expected && preview.expected <= lastMonth) throw new Error('Calculate depreciation through the preceding month before disposal.');
        post(a, c.kind, c.date, -b.cost, -b.depreciation, [{ account: g.depreciationAccount, debit: b.depreciation, credit: 0 }, { account: c.account, debit: b.book, credit: 0 }, { account: g.assetAccount, debit: 0, credit: b.cost }], c.reason);
      } else throw new Error('Choose a valid asset operation.');
    }
  } else if (command.type === 'save-inventory') {
    const inventory = structuredClone(command.inventory), old = s.inventories.find(i => i.id === inventory.id);
    if (old?.locked) throw new Error('This inventory is locked.');
    if (!inventory.id || !inventory.number.trim() || !validAssetDate(inventory.date) || inventory.date > ctx.today || !inventory.lines.length || new Set(inventory.lines.map(l => l.assetId)).size !== inventory.lines.length || inventory.lines.some(l => !s.assets.some(a => a.id === l.assetId) || !Number.isFinite(l.actualQuantity) || l.actualQuantity < 0)) throw new Error('Complete the inventory date and quantities.');
    if (s.inventories.some(i => i.id !== inventory.id && i.number === inventory.number)) throw new Error('This code already exists.');
    // Book values are always recalculated from the journal, never trusted from the form.
    inventory.lines = inventory.lines.map(l => { const a = s.assets.find(x => x.id === l.assetId)!; const b = assetBalance(s, a, inventory.date); return { ...l, number: a.number, name: a.name, bookQuantity: b.start && !b.disposed ? a.quantity : 0, bookValue: b.start && !b.disposed ? b.book : 0 }; });
    if (old) s.inventories[s.inventories.indexOf(old)] = inventory; else s.inventories.push(inventory);
    audit(inventory.id, inventory.locked ? 'Inventory locked' : 'Inventory saved');
  }
  s.revision++;
  return s;
}
