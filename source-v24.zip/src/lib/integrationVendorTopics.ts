import type { HelpText } from './exportHelpGuide';
import type { IntegrationHelpTopic } from './integrationHelpTopics';

// Original, concise summaries of checked provider workflows. Numeric references
// support the research audit without shipping third-party links or media.
type FollowUp = 'codes' | 'settings' | 'review';
const followUps: Record<FollowUp, HelpText[]> = {
  codes: [
    ['In All Documents → Documents select the organization → gear → Additional columns → the relevant code list. For expenses choose Code, Service or Product, then Import from Excel.', 'Visi dokumentai → Dokumentai pasirinkite organizaciją → dantratis → Papildomi stulpeliai → atitinkamas kodų sąrašas. Išlaidoms pasirinkite Kodas, Paslauga arba Prekė, tada Įkelti iš Excel.'],
    ['Paste code and name as two TAB-separated columns, one record per line. Remove headings, preserve leading zeros and check the preview before importing. Existing document allocations are not changed by loading a directory.', 'Įklijuokite du TAB atskirtus stulpelius: kodą ir pavadinimą, po vieną įrašą eilutėje. Pašalinkite antraštes, išsaugokite pradinius nulius ir patikrinkite peržiūrą. Registro įkėlimas nekeičia esamų dokumentų paskirstymo.'],
    ['Return to the document and assign the saved code in the corresponding field. If the format has no separate directory for that dimension, use its Additional column settings default; this does not create a missing document-level picker.', 'Grįžę į dokumentą priskirkite išsaugotą kodą atitinkamame lauke. Jei dimensijai nėra atskiro registro, naudokite formato Papildomų stulpelių numatytąją reikšmę; tai nesukuria trūkstamo pasirinkimo dokumento eilutėje.'],
  ],
  settings: [
    ['Open All Documents → Documents → select organization → gear → Documents & digitization setup. Select this integration and change only the settings for that company.', 'Atverkite Visi dokumentai → Dokumentai → pasirinkite organizaciją → dantratis → Dokumentų ir skaitmeninimo nustatymai. Pasirinkite šią integraciją; pakeitimai skirti tik tai įmonei.'],
    ['Use the field descriptions on the integration overview. Save non-secret settings, review required additional columns and inspect one invoice before a batch. The frontend does not establish a live connection or save / send real credentials.', 'Laukų reikšmes rasite integracijos apžvalgoje. Išsaugokite ne slaptus nustatymus, patikrinkite privalomus papildomus stulpelius ir prieš paketą peržiūrėkite vieną sąskaitą. Frontend neužmezga tikro ryšio ir tikrų raktų nesaugo bei nesiunčia.'],
  ],
  review: [
    ['In FH open the affected document with Edit and compare the original invoice with the reported field. Correct the code or allocation, not the invoice facts merely to bypass an error.', 'FH atverkite dokumentą per Redaguoti ir sutikrinkite klaidoje minimą lauką su originalu. Taisykite kodą ar paskirstymą, o ne sąskaitos faktus vien tam, kad apeitumėte klaidą.'],
    ['If the correction belongs to OCR, use Report issue and explain the discrepancy to the Worker. Before any real retry, check the destination for an existing invoice; a timeout does not prove that nothing was imported.', 'Jei reikia OCR korekcijos, rinkitės Pranešti apie klaidą ir darbuotojui aprašykite neatitikimą. Prieš tikrą pakartotinį siuntimą patikrinkite, ar gavėjo sistemoje sąskaitos jau nėra: laukimo laiko pabaiga neįrodo, kad importas neįvyko.'],
  ],
};
const topic = (id: string, title: HelpText, system: string, sourceArticleIds: number[], steps: HelpText[], followUp: FollowUp = 'settings', note?: HelpText): IntegrationHelpTopic => ({
  id, title, sourceArticleIds,
  description: [steps[0][0], steps[0][1]],
  sections: [
    { title: [`${system}: procedure and checks`, `${system}: eiga ir patikrinimai`], system, steps },
    { title: ['Continue in Finansų harmonija', 'Veiksmai Finansų harmonijoje'], system: 'FH', steps: followUps[followUp] },
  ], note,
  ...(followUp === 'codes' ? { screenshot: { file: 'expense-import.jpg', caption: ['FH code-list import. Select the appropriate directory and type before pasting.', 'FH kodų sąrašo įkėlimas. Prieš įklijuodami pasirinkite tinkamą registrą ir tipą.'] as HelpText } } : {}),
});

const bss = [
  topic('invoice-import', ['Invoice import and templates', 'Sąskaitų importas ir šablonai'], 'BSS', [10673425], [
    ['Choose file import or API; they are separate routes.', 'Pasirinkite failo importą arba API – tai atskiri būdai.'],
    ['For files, extract the ZIP containing XLSX invoice data and the XML import template.', 'Failo būdu išskleiskite ZIP su XLSX sąskaitų duomenimis ir XML importo šablonu.'],
    ['If updating the template, import its XML first. Otherwise keep the existing matching template.', 'Jei atnaujinate šabloną, pirma įkelkite jo XML. Kitu atveju palikite esamą tinkamą šabloną.'],
    ['Choose the purchase or sales XLSX, select the matching import template, then continue with Toliau >.', 'Pasirinkite pirkimų arba pardavimų XLSX, atitinkantį importo šabloną ir tęskite mygtuku Toliau >.'],
    ['For API instead, obtain the BSS integration username, key, portfolio and server URL. Configure BSS Api, not the file template.', 'API būdui gaukite BSS integracijos naudotoją, raktą, portfelį ir serverio URL. Konfigūruokite BSS Api, ne failo šabloną.'],
  ]),
  topic('product-codes', ['Product, service and discount codes', 'Prekių, paslaugų ir nuolaidų kodai'], 'BSS', [11325175], [
    ['Use the BSS product register as the source of identifiers.', 'Identifikatorius imkite iš BSS produktų registro.'],
    ['Open Products, display all required records and use the table context menu to export to Excel. Remove the image column and keep product code plus name.', 'Atverkite Produktai, parodykite reikiamus įrašus ir lentelės kontekstiniame meniu eksportuokite į Excel. Pašalinkite paveikslėlio stulpelį, palikite produkto kodą ir pavadinimą.'],
    ['Keep the distinction between products, services and discount codes when choosing the FH code type.', 'Parinkdami FH kodo tipą išlaikykite skirtumą tarp prekių, paslaugų ir nuolaidų kodų.'],
  ], 'codes'),
  topic('departments', ['Department codes', 'Padalinių kodai'], 'BSS', [11325348], [
    ['Department identifiers must match the BSS directory.', 'Padalinių identifikatoriai turi sutapti su BSS registru.'],
    ['Open Departments, display all required rows and export the table to Excel from its context menu. Copy code and name, then use FH Additional columns → Departments.', 'Atverkite Padaliniai, parodykite reikiamas eilutes ir kontekstiniame meniu eksportuokite lentelę į Excel. Nukopijuokite kodą bei pavadinimą ir FH rinkitės Papildomi stulpeliai → Padaliniai.'],
  ], 'codes'),
  topic('tax-codes', ['Tax codes and VAT mapping', 'Mokesčių kodai ir PVM atitikmenys'], 'BSS', [11325534], [
    ['A BSS tax code is an identifier, not simply a VAT percentage.', 'BSS mokesčio kodas yra identifikatorius, ne vien PVM procentas.'],
    ['Open Taxes, show the required records and export the table to Excel. Use the Tax code value from that list when configuring the BSS tax field in FH.', 'Atverkite Mokesčiai, parodykite reikiamus įrašus ir eksportuokite lentelę į Excel. FH BSS mokesčio laukui naudokite šio sąrašo Mokesčio kodas reikšmę.'],
    ['Check the document VAT classifier separately; do not replace a code with a percentage such as 21.', 'Atskirai patikrinkite dokumento PVM klasifikatorių; kodo nekeiskite vien procentu, pavyzdžiui, 21.'],
  ]),
  topic('accountable-persons', ['Accountable persons: list and assignment', 'Atskaitingi asmenys: sąrašas ir priskyrimas'], 'BSS', [10913926, 11330409], [
    ['The assigned person must have an existing BSS code.', 'Priskiriamas asmuo turi turėti BSS egzistuojantį kodą.'],
    ['Open Accountable → Accountable persons. Show the Code column and export the table to Excel. Copy the person code and name.', 'Atverkite Atskaitingi → Atskaitingi asmenys. Įjunkite Kodas stulpelį ir eksportuokite lentelę į Excel. Nukopijuokite asmens kodą bei vardą ir pavardę.'],
    ['Import into the FH accountable-person code directory and check the code selected for the document. A name alone does not identify a BSS person.', 'Įkelkite į FH atskaitingų asmenų kodų registrą ir patikrinkite dokumentui pasirinktą kodą. Vien vardas ir pavardė BSS asmens neidentifikuoja.'],
  ], 'codes'),
  topic('api-v2', ['API v2 and expense synchronization', 'API v2 ir išlaidų sinchronizavimas'], 'BSS', [12394522], [
    ['API v2 uses its own server and environment identifiers.', 'API v2 naudoja savo serverio ir aplinkos identifikatorius.'],
    ['Ask BSS for the v2 URL, integration username and password, environment ID and company ID. All values must refer to the same installation and company.', 'Iš BSS gaukite v2 adresą, integracijos naudotoją bei slaptažodį, aplinkos ID ir įmonės ID. Visi duomenys turi priklausyti tam pačiam diegimui ir įmonei.'],
    ['FH exposes these configuration fields, but has no live BSS expense-sync service. Until it is connected, use the manual code import instead of expecting an automatic refresh.', 'FH turi šiuos konfigūravimo laukus, bet tikra BSS išlaidų sinchronizavimo tarnyba neprijungta. Iki jos prijungimo naudokite rankinį kodų įkėlimą, ne automatinį atnaujinimą.'],
  ]),
  topic('zero-price', ['Error: price cannot be zero', 'Klaida: kaina negali būti lygi nuliui'], 'BSS', [13543605], [
    ['A zero-priced line can be rejected by the BSS product-card rules.', 'Nulinės kainos eilutę gali atmesti BSS produkto kortelės taisyklės.'],
    ['If the item is genuinely supplied free of charge, review the product-card setting allowing free supply. Do not invent a nonzero invoice price merely to avoid the validation.', 'Jei prekė iš tikrųjų suteikiama nemokamai, peržiūrėkite produkto kortelės nustatymą „Galima suteikti nemokamai“. Nekeiskite faktinės sąskaitos kainos vien tam, kad apeitumėte tikrinimą.'],
  ], 'review'),
];

export const VENDOR_HELP_TOPICS: Record<string, IntegrationHelpTopic[]> = {
  Apskaita5: [topic('item-codes', ['Importing item and service codes', 'Prekių ir paslaugų kodų įkėlimas'], 'Apskaita5', [6758268], [
    ['Copy identifiers from the Apskaita5 item catalog.', 'Identifikatorius kopijuokite iš Apskaita5 prekių katalogo.'],
    ['Open Item catalog → Print preview and save the list as Excel. Arrange the identifier in the first column and its description in the second; copy only data rows.', 'Atverkite Prekių katalogas → Spausdinimo peržiūra ir išsaugokite sąrašą Excel formatu. Pirmame stulpelyje palikite kodą, antrame – aprašymą; kopijuokite tik duomenų eilutes.'],
  ], 'codes')],
  BSS: bss.filter(item => item.id !== 'api-v2'),
  'BSS Api': bss,
  'Business Central': [topic('oauth-connection', ['OAuth, company endpoint and invoice extension', 'OAuth, įmonės adresas ir sąskaitų plėtinys'], 'Business Central', [12050553], [
    ['The invoice endpoint must be supplied by the installed integration extension.', 'Sąskaitų adresą turi pateikti įdiegtas integracijos plėtinys.'],
    ['For the documented Softera eInvoice route, confirm that its required API package is installed. Obtain the tenant, environment and company IDs from the administrator; a generic Business Central endpoint is not equivalent.', 'Aprašytam Softera eInvoice būdui patikrinkite, ar įdiegtas reikiamas API paketas. Iš administratoriaus gaukite nuomininko, aplinkos bei įmonės ID; bendras Business Central adresas nėra lygiavertis.'],
    ['Use the tenant OAuth v2 token address, the application client ID and its secret. The company API URL must point to the same tenant and environment. Never copy example IDs into production.', 'Naudokite nuomininko OAuth v2 rakto gavimo adresą, programos kliento ID ir slaptą reikšmę. Įmonės API adresas turi priklausyti tam pačiam nuomininkui bei aplinkai. Pavyzdinių ID į produkciją nekopijuokite.'],
  ])],
  Centas: [
    topic('invoice-import', ['First import and item cards', 'Pirmas importas ir prekių kortelės'], 'Centas', [6324925], [
      ['Select the company: Parametrai → Įmonės.', 'Pasirinkite įmonę: Parametrai → Įmonės.'],
      ['Export codes: Žinynai → Prekės → Nustatymai → Eksportas → Prekių sąrašas XLS. Retain code and name.', 'Iškelkite kodus: Žinynai → Prekės → Nustatymai → Eksportas → Prekių sąrašas XLS. Palikite kodą ir pavadinimą.'],
      ['Unpack the compatible production export. New item cards use Žinynai → Prekės → Importas → Kortelių įkėlimas/atnaujinimas and CSV selection.', 'Išskleiskite suderinamą produkcinį eksportą. Naujos prekių kortelės: Žinynai → Prekės → Importas → Kortelių įkėlimas/atnaujinimas ir CSV pasirinkimas.'],
      ['For invoices open Darbas → Duomenų importas → Nuosavas formatas.', 'Sąskaitoms atverkite Darbas → Duomenų importas → Nuosavas formatas.'],
      ['Choose purchase / sales direction and XML, not the item-card CSV. Select the invoice file and import.', 'Pasirinkite pirkimų / pardavimų kryptį ir XML, ne prekių kortelių CSV. Pasirinkite sąskaitų failą ir importuokite.'],
    ]),
    topic('original-document', ['Viewing the original invoice', 'Sąskaitos originalo peržiūra'], 'Centas', [7177287], [
      ['An original-document link is separate from imported accounting values.', 'Originalo nuoroda yra atskira nuo importuotų apskaitos reikšmių.'],
      ['In Centas, right-click the document and choose View original document. The link must have been included by the import and remain accessible.', 'Centas paspauskite dokumentą dešiniuoju pelės mygtuku ir rinkitės Peržiūrėti dokumento originalą. Nuoroda turi būti perduota importu ir išlikti pasiekiama.'],
    ], 'review'),
    topic('duplicate-counterparties', ['Duplicate counterparties', 'Pasikartojantys kontrahentai'], 'Centas', [4006791], [
      ['Different accounting and company codes can produce two cards for one counterparty.', 'Skirtingi apskaitos ir įmonės kodai gali sukurti dvi to paties kontrahento korteles.'],
      ['Compare Code and Company code before another import. Have the Centas administrator review linked transactions and a backup before any merge or removal; never delete a card solely because its name matches.', 'Prieš kitą importą palyginkite Kodas ir Įmonės kodas. Prieš sujungimą ar šalinimą administratorius turi patikrinti susijusias operacijas bei atsarginę kopiją; vien sutampantis pavadinimas nėra pagrindas trinti kortelę.'],
      ['Where a correction requires balances to be rebuilt, the Centas reconciliation tool is under Additional → Info → Recalculate current counterparty debts.', 'Jei po korekcijos reikia perskaičiuoti likučius, Centas veiksmas yra Papildoma → Info → Perskaičiuoti aktualių kontrahentų įsiskolinimą.'],
    ], 'review'),
    topic('currencies', ['Currency and exchange rates', 'Valiuta ir valiutų kursai'], 'Centas', [9506728], [
      ['The invoice currency must exist in Centas.', 'Sąskaitos valiuta turi egzistuoti Centas.'],
      ['Open Work → Accounting → Exchange rates. Add the missing currency, confirm its code and rate, then update the rates. Verify the rate for the invoice date before retrying.', 'Atverkite Darbas → Buhalterija → Valiutų kursai. Pridėkite trūkstamą valiutą, patvirtinkite jos kodą bei kursą ir atnaujinkite kursus. Prieš kartodami tikrinkite sąskaitos datos kursą.'],
    ], 'review'),
  ],
  Debetas: [
    topic('invoice-import', ['Invoice file and allocations', 'Sąskaitų failas ir paskirstymas'], 'Debetas', [9545706], [
      ['Debetas uses destination-specific codes before its document import.', 'Debetas importui reikalingi gavėjo sistemos kodai.'],
      ['Check expense / income allocation, department, object, expense article and VAT classification. The documented non-Excel route imports a text file through the Debetas import module; Debetas Excel is a different variant.', 'Patikrinkite išlaidų ar pajamų paskirstymą, padalinį, objektą, išlaidų straipsnį bei PVM klasifikatorių. Aprašytas ne Excel būdas importuoja tekstinį failą per Debetas importo modulį; Debetas Excel yra atskiras variantas.'],
    ]),
    topic('expense-articles', ['Expense article codes', 'Išlaidų straipsnių kodai'], 'Debetas', [12352713], [
      ['Use the expense-article identifier supplied by the Debetas administrator.', 'Naudokite Debetas administratoriaus pateiktą išlaidų straipsnio identifikatorių.'],
      ['The reference for this topic contained only a video, so an unverified Debetas menu path is not reproduced here. In FH the Debetas export schema has an Expense article default under Additional column settings.', 'Šios temos šaltinyje buvo tik vaizdo įrašas, todėl nepatikrintas Debetas meniu kelias čia nepateikiamas. FH Debetas formato Papildomų stulpelių nustatymuose yra Išlaidų straipsnio numatytoji reikšmė.'],
    ]),
  ],
  Dineta: [topic('connection', ['Integration user, server and templates', 'Integracijos naudotojas, serveris ir šablonai'], 'Dineta', [11579553], [
    ['Dineta access requires an integration account supplied by the provider.', 'Dineta prieigai reikalinga tiekėjo suteikta integracijos paskyra.'],
    ['Ask Dineta for the username and password and confirm the server URL used by your installation. Do not substitute a browser login path for the agreed integration URL.', 'Iš Dineta gaukite naudotoją bei slaptažodį ir patvirtinkite jūsų diegimo serverio adresą. Vietoj suderinto integracijos adreso nenaudokite naršyklės prisijungimo kelio.'],
    ['In FH select the purchase and sales GL templates and warehouse codes for the same company. Rights and network access must be configured by the provider before a live connector can work.', 'FH parinkite tos pačios įmonės pirkimo ir pardavimo DK šablonus bei sandėlio kodus. Tiekėjas turi suteikti teises ir tinklo prieigą prieš naudojant tikrą jungtį.'],
  ])],
  Finvalda: [
    topic('invoice-import', ['Invoice import and accounting parameters', 'Sąskaitų importas ir apskaitos parametrai'], 'Finvalda', [5172154], [
      ['In Finvalda settings check debit, credit and VAT accounts.', 'Finvalda nustatymuose patikrinkite debeto, kredito ir PVM sąskaitas.'],
      ['For new items, check account links and VAT. In import parameters, VA controls department, employee and warehouse.', 'Naujoms prekėms patikrinkite sąskaitų ryšį bei PVM. Importo parametruose VA valdo padalinį, darbuotoją ir sandėlį.'],
      ['Assign the receiving expense / income codes to the invoices in FH.', 'FH sąskaitoms priskirkite gavėjo išlaidų / pajamų kodus.'],
      ['With a compatible production file, open Duomenų importas in Finvalda and select Iš failo.', 'Turėdami suderinamą produkcinį failą, Finvalda atverkite Duomenų importas ir pažymėkite Iš failo.'],
      ['Click Naršyti, choose the file, inspect the loaded records and confirm the result.', 'Spauskite Naršyti, pasirinkite failą, peržiūrėkite nuskaitytus įrašus ir patvirtinkite rezultatą.'],
    ]),
    topic('service-codes', ['Service code list', 'Paslaugų kodų sąrašas'], 'Finvalda', [7887844], [
      ['The service register supplies the exact codes used by Finvalda.', 'Tikslūs Finvalda kodai imami iš paslaugų registro.'],
      ['Open Descriptions → Services → List. Select the required rows (Ctrl+A for all) and copy (Ctrl+C). Arrange code and name into two columns before pasting into FH.', 'Atverkite Aprašymai → Paslaugos → Sąrašas. Pažymėkite eilutes (visas – Ctrl+A) ir kopijuokite Ctrl+C. Prieš įklijuodami FH išdėstykite kodą bei pavadinimą dviem stulpeliais.'],
    ], 'codes'),
  ],
  Monet: [topic('identification-code', ['Creating the identification code', 'Identifikacinio kodo sukūrimas'], 'Monet', [17757400], [
    ['Monet identifies this import through an ExternalInvoice integration code.', 'Monet šį importą atpažįsta pagal ExternalInvoice integracijos kodą.'],
    ['Open Settings → Other → Integration. Create an ExternalInvoice entry, give it a name and save. Open its parameters and obtain the identifying Code.', 'Atverkite Nustatymai → Kita → Integravimas. Sukurkite ExternalInvoice įrašą, nurodykite pavadinimą ir išsaugokite. Atverkite parametrus ir paimkite identifikacinį Code.'],
    ['Enter that value in the FH Identification code field. It is not a user password and does not make the current file-export preview a live API connection.', 'Reikšmę įrašykite FH lauke Identifikacinis kodas. Tai ne naudotojo slaptažodis ir jis nepaverčia dabartinės failo eksporto peržiūros tikru API ryšiu.'],
  ])],
  Optimum: [
    topic('api-and-import', ['API key and first transfer', 'API raktas ir pirmas perdavimas'], 'Optimum', [5161093, 9856893], [
      ['The API key is available in Optimum under Help → API key.', 'Optimum API raktas pasiekiamas per Pagalba → API raktas.'],
      ['Match product, service or GL codes and choose the corresponding type. The receiving invoice list is Operations → Invoices; check it after a real transfer.', 'Suderinkite prekių, paslaugų arba DK kodus ir parinkite atitinkamą tipą. Gavėjo sąskaitų sąrašas yra Operacijos → Sąskaitos-faktūros; po tikro perdavimo tikrinkite jį.'],
    ]),
    topic('missing-related-data', ['Error: related data is missing', 'Klaida: trūksta susijusių duomenų'], 'Optimum', [4184813], [
      ['A missing country record can trigger a related-data error, including fkCities.', 'Trūkstamas šalies įrašas gali sukelti susijusių duomenų klaidą, įskaitant fkCities.'],
      ['Check Organization → Data → Countries and the invoice country. The expected country identifier is an uppercase two-letter ISO code. Add the actual missing country, not an arbitrary replacement.', 'Patikrinkite Organizacija → Duomenys → Šalys ir sąskaitos šalį. Tikimasi dviejų didžiųjų raidžių ISO kodo. Įtraukite tikrą trūkstamą šalį, ne atsitiktinį pakaitalą.'],
    ], 'review'),
    topic('number-pattern', ['Error: document number does not match the pattern', 'Klaida: numeris neatitinka šablono'], 'Optimum', [4179768], [
      ['The operation type can restrict the accepted document-number pattern.', 'Operacijos tipas gali riboti priimamą dokumento numerio šabloną.'],
      ['Review General ledger → Data → Operation types → SF invoice → Document number pattern. Ask the administrator to adjust an inappropriate restriction; do not change the legal invoice number to fit it.', 'Peržiūrėkite Didžioji knyga → Duomenys → Operacijų tipai → SF Sąskaita-faktūra → Dokumentų Nr. šablonas. Netinkamą ribojimą turi pataisyti administratorius; nekeiskite tikro sąskaitos numerio, kad jis tiktų šablonui.'],
    ], 'review'),
    topic('missing-vat-account', ['Error: Account.AccountId is empty', 'Klaida: neužpildyta Account.AccountId'], 'Optimum', [4131237], [
      ['The input VAT account may be absent from the receiving chart of accounts.', 'Gautino PVM sąskaitos gali nebūti gavėjo sąskaitų plane.'],
      ['Compare the configured input VAT account with the company chart. The reference uses 2441 as an example, not a universal account. Enter the actual existing account in FH Optimum settings.', 'Sutikrinkite nustatytą gautino PVM sąskaitą su įmonės sąskaitų planu. Šaltinyje 2441 yra pavyzdys, ne universali sąskaita. FH Optimum nustatymuose įrašykite iš tikrųjų egzistuojančią sąskaitą.'],
    ], 'review'),
    topic('duplicate-record', ['Error: duplicate number, code or name', 'Klaida: kartojasi numeris, kodas ar pavadinimas'], 'Optimum', [12033483], [
      ['First distinguish an existing invoice from a conflicting directory code.', 'Pirmiausia atskirkite jau esamą sąskaitą nuo sutampančio registro kodo.'],
      ['Search by invoice number and counterparty before retrying. If the invoice is absent, inspect directory codes, including empty values and collisions with 00. Do not remove posted records automatically.', 'Prieš kartodami ieškokite pagal sąskaitos numerį ir kontrahentą. Jei sąskaitos nėra, patikrinkite registrų kodus, įskaitant tuščias reikšmes ir sutapimus su 00. Užregistruotų operacijų automatiškai nešalinkite.'],
    ], 'review'),
    topic('missing-employee', ['Error: employee code is not found', 'Klaida: darbuotojo kodas nerastas'], 'Optimum', [14617754], [
      ['The Optimum user and employee identities must have compatible codes.', 'Optimum naudotojo ir darbuotojo tapatybės turi būti susietos tinkamais kodais.'],
      ['Have the administrator check the employee directory against the user used for the integration. Correct the mapping or add the actual missing employee; avoid creating a second person for the same identity.', 'Administratorius turi sutikrinti darbuotojų registrą su integracijai naudojamu naudotoju. Taisykite atitikmenį arba pridėkite tikrą trūkstamą darbuotoją; nekurkite antro įrašo tam pačiam asmeniui.'],
    ], 'review'),
    topic('service-unit-cost', ['Error: unit cost supplied for a service', 'Klaida: nurodyta paslaugos vieneto savikaina'], 'Optimum', [16880874], [
      ['This error can indicate a mismatch between Service and Product.', 'Ši klaida gali reikšti neatitikimą tarp Paslaugos ir Prekės tipų.'],
      ['Review the Optimum item card: Gaminys = No represents a service; Yes represents a product. Match the FH type to the real card and invoice rather than changing amounts.', 'Patikrinkite Optimum kortelę: Gaminys = Ne reiškia paslaugą, Taip – prekę. FH tipą suderinkite su tikra kortele ir sąskaita, nekeisdami sumų.'],
    ], 'review'),
  ],
  Paulita: [topic('invoice-import', ['Invoice export and receiving import', 'Sąskaitų eksportas ir gavėjo importas'], 'Paulita', [6504614], [
    ['Allocate expense / income codes before a Paulita invoice import.', 'Prieš Paulita sąskaitų importą priskirkite išlaidų ar pajamų kodus.'],
    ['The described route uses XML. Select the intended company in Paulita and its compatible invoice-import function. The reference does not provide a reliable text menu path, so confirm the exact command for your installed version.', 'Aprašytas būdas naudoja XML. Paulita pasirinkite reikiamą įmonę ir jos suderinamą sąskaitų importo funkciją. Šaltinyje nėra patikimo tekstinio meniu kelio, todėl konkrečią komandą patikslinkite pagal savo diegimo versiją.'],
  ])],
  Pragma3: [
    topic('codes-and-nomenclature', ['Correspondence and nomenclature codes', 'Korespondencijos ir nomenklatūros kodai'], 'Pragma 3', [8407868], [
      ['Pragma 3 uses correspondence codes and product nomenclature identifiers.', 'Pragma 3 naudoja korespondencijos kodus ir prekių nomenklatūros identifikatorius.'],
      ['Copy the correspondence code with its full name. For products use the nomenclature number; configure the import to match by that number, not by an approximate item name.', 'Nukopijuokite korespondencijos kodą su pilnu pavadinimu. Prekėms naudokite nomenklatūros numerį; importo atitikimą nustatykite pagal jį, ne panašų prekės pavadinimą.'],
    ], 'codes'),
    topic('unknown-supplier', ['Error: supplier is not recognized', 'Klaida: neatpažintas tiekėjas'], 'Pragma', [11754278], [
      ['The import may omit the company records needed to identify the supplier.', 'Importe gali nebūti įmonių įrašų, reikalingų tiekėjui atpažinti.'],
      ['Check the Companies option in the Pragma import dialog, then verify that the supplier code matches the company card. Do not repeatedly import the invoice without fixing its supplier reference.', 'Pragma importo lange patikrinkite Įmonės parinktį, tada sutikrinkite tiekėjo kodą su kortele. Nekartokite sąskaitos importo nepataisę tiekėjo atitikmens.'],
    ], 'review'),
  ],
  Pragma4: [topic('new-customer', ['Creating a missing customer during import', 'Trūkstamo kliento sukūrimas importuojant'], 'Pragma 4', [16144743], [
    ['The import configuration determines whether missing client cards can be created.', 'Importo nustatymai lemia, ar galima sukurti trūkstamas klientų korteles.'],
    ['Check the company code and search existing cards first. If a genuinely new client is not created, ask the Pragma administrator to review the import settings and permissions.', 'Pirmiausia patikrinkite įmonės kodą ir paieškokite esamų kortelių. Jei tikrai naujas klientas nesukuriamas, paprašykite Pragma administratoriaus patikrinti importo nustatymus bei teises.'],
  ], 'review')],
  'Rivilė ERP': [
    topic('erp-api-key', ['ERP API key and access', 'ERP API raktas ir prieiga'], 'Rivilė ERP', [9684948, 9685697], [
      ['Rivilė ERP uses an ERP key, not a GAMA Gateway key.', 'Rivilė ERP naudoja ERP raktą, ne GAMA Gateway raktą.'],
      ['Open Settings → General → API keys. Create a key with an identifying name and suitable expiry, then store it securely; its full value may only be shown once.', 'Atverkite Nustatymai → Bendrieji → API raktai. Sukurkite raktą su atpažįstamu pavadinimu ir tinkamu galiojimu, saugiai jį išsaugokite; visa reikšmė gali būti parodyta tik vieną kartą.'],
      ['Match department, item / service and VAT codes for the intended organization before using a connected adapter.', 'Prieš naudodami prijungtą adapterį suderinkite reikiamos organizacijos padalinių, prekių ar paslaugų bei PVM kodus.'],
    ]),
    topic('erp-item-codes', ['Importing ERP product and service codes', 'ERP prekių ir paslaugų kodų įkėlimas'], 'Rivilė ERP', [9685569], [
      ['Copy the exact ERP identifiers, preserving letter case.', 'Kopijuokite tikslius ERP identifikatorius, nekeisdami raidžių dydžio.'],
      ['Open Settings → Inventory and logistics → Products, services. Filter by type and use More → CSV export. Keep code and name as the first two columns for FH import.', 'Atverkite Nustatymai → Atsargos ir logistika → Prekės, paslaugos. Filtruokite pagal tipą ir rinkitės Daugiau → Eksportas į CSV. FH įkėlimui pirmuose dviejuose stulpeliuose palikite kodą ir pavadinimą.'],
    ], 'codes'),
  ],
  Saikas: [topic('invoice-import', ['Purchase and sales file import', 'Pirkimų ir pardavimų failo importas'], 'Saikas', [8004223], [
    ['Check purchase, purchase VAT, sales and sales VAT account mappings separately.', 'Atskirai patikrinkite pirkimų, pirkimų PVM, pardavimų ir pardavimų PVM sąskaitų atitikmenis.'],
    ['Open Funkcijos → Duomenų importavimas in Saikas.', 'Saikas atverkite Funkcijos → Duomenų importavimas.'],
    ['Select the purchase or sales import template matching your file.', 'Pasirinkite failą atitinkantį pirkimų arba pardavimų importo šabloną.'],
    ['Use Failas to select the compatible production document file, then Nuskaityti failą and Jungtis.', 'Per Failas pasirinkite suderinamą produkcinį dokumentų failą, tada Nuskaityti failą ir Jungtis.'],
    ['Verify records in Programa → Atsargų apskaita → Pirkimai or Pardavimai.', 'Rezultatą patikrinkite Programa → Atsargų apskaita → Pirkimai arba Pardavimai.'],
  ])],
  'Site.pro': [
    topic('connection-and-key', ['Site.pro (formerly B1): API and first transfer', 'Site.pro (anksčiau B1): API ir pirmas perdavimas'], 'Site.pro', [17778730, 6560168, 6576084], [
      ['The former B1 integration is listed as Site.pro.', 'Ankstesnė B1 integracija sąraše vadinama Site.pro.'],
      ['In Site.pro use Parameters → Integrations → API #2. Enable the required service and obtain the key for the specific company; different companies require their own access.', 'Site.pro rinkitės Parametrai → Integracijos → API #2. Įjunkite reikiamą paslaugą ir gaukite konkrečios įmonės raktą; skirtingoms įmonėms reikia atskiros prieigos.'],
      ['Before transfer, check warehouse, operation, expense and VAT codes. The key alone does not supply these allocations.', 'Prieš perdavimą patikrinkite sandėlio, operacijos, išlaidų ir PVM kodus. Vien raktas šių paskirstymų neužpildo.'],
    ]),
    topic('item-codes', ['Item and expense codes', 'Prekių ir išlaidų kodai'], 'Site.pro', [6576680], [
      ['Import the item identifiers used by the receiving company.', 'Įkelkite gavėjo įmonėje naudojamus prekių identifikatorius.'],
      ['Open Directories → Item cards → Items and export to Excel with the cloud action. Copy the code and description columns; include every code needed by the invoice lines.', 'Atverkite Žinynai → Prekių kortelės → Prekės ir debesies veiksmu eksportuokite į Excel. Nukopijuokite kodą bei aprašymą; įtraukite visus sąskaitų eilutėms reikalingus kodus.'],
    ], 'codes'),
    topic('operation-codes', ['Operation types', 'Operacijų rūšys'], 'Site.pro', [6576201], [
      ['The operation code identifies how the invoice is handled in Site.pro.', 'Operacijos kodas nurodo, kaip sąskaita tvarkoma Site.pro.'],
      ['Open Directories → Warehouse → Operation types and export to Excel. Use the code, not only the name, in the FH Site.pro Operation default.', 'Atverkite Žinynai → Sandėlio → Operacijos rūšys ir eksportuokite į Excel. FH Site.pro Operacijos numatytajai reikšmei naudokite kodą, ne vien pavadinimą.'],
    ]),
    topic('warehouses', ['Warehouse allocation', 'Sandėlio priskyrimas'], 'Site.pro', [6576117], [
      ['Choose the warehouse belonging to the correct company.', 'Rinkitės reikiamai įmonei priklausantį sandėlį.'],
      ['Open Directories → Warehouse → Warehouses and export the list to Excel. Confirm with the receiving import whether its warehouse identifier or name is expected; do not assume the spreadsheet column position defines the identifier.', 'Atverkite Žinynai → Sandėlio → Sandėliai ir eksportuokite sąrašą į Excel. Patikrinkite, ar gavėjo importas tikisi sandėlio identifikatoriaus, ar pavadinimo; vien stulpelio vieta skaičiuoklėje to nenustato.'],
      ['FH exposes document and line warehouse defaults; it does not yet provide a separate Site.pro warehouse directory.', 'FH pateikia dokumento ir eilutės sandėlio numatytąsias reikšmes; atskiro Site.pro sandėlių registro dar nėra.'],
    ]),
    topic('item-date-conflict', ['Error: item date conflict', 'Klaida: datos konfliktas prekei'], 'Site.pro', [15700973], [
      ['A sale dated before the stock purchase can cause an item-date conflict.', 'Pardavimas, kurio data ankstesnė už atsargų įsigijimą, gali sukelti prekės datos konfliktą.'],
      ['Compare the sales date, purchase receipt date, product and warehouse in Site.pro. Correct a missing or wrongly dated receipt only when supported by the source documents.', 'Site.pro sutikrinkite pardavimo datą, pirkimo gavimo datą, prekę ir sandėlį. Trūkstamą ar klaidingai datuotą gavimą taisykite tik pagal pirminius dokumentus.'],
      ['Do not shift the invoice date merely to pass stock validation. Check the result in the receiving system before sending again.', 'Nekeiskite sąskaitos datos vien tam, kad apeitumėte atsargų tikrinimą. Prieš kartodami siuntimą patikrinkite rezultatą gavėjo sistemoje.'],
    ], 'review'),
  ],
  Syrve: [
    topic('connection', ['Server address and integration account', 'Serverio adresas ir integracijos paskyra'], 'Syrve', [10365202], [
      ['Use a dedicated Syrve integration user and the correct server.', 'Naudokite atskirą Syrve integracijos naudotoją ir tinkamą serverį.'],
      ['The server protocol, address and port are visible in System Sign-in → More. Confirm credentials and permissions with the Syrve administrator. Do not copy another company’s URL or credentials.', 'Serverio protokolas, adresas ir prievadas matomi System Sign-in → More. Prisijungimus bei teises suderinkite su Syrve administratoriumi. Nekopijuokite kitos įmonės adreso ar prisijungimų.'],
    ]),
    topic('item-codes', ['SKU codes and expenses', 'SKU kodai ir išlaidos'], 'Syrve', [12540236], [
      ['Syrve SKU maps to the code; the item name maps to its description.', 'Syrve SKU atitinka kodą, prekės pavadinimas – jo aprašymą.'],
      ['Copy the exact SKU and name into the FH expense / product directory. Automatic refresh requires a live connector; the current FH screen supports manual entry and Excel paste.', 'Tikslų SKU ir pavadinimą įkelkite į FH išlaidų ar prekių registrą. Automatiniam atnaujinimui reikia tikros jungties; dabartinis FH langas leidžia įvesti ranka arba įklijuoti iš Excel.'],
    ], 'codes'),
    topic('warehouses', ['Warehouse codes', 'Sandėlių kodai'], 'Syrve', [12545700], [
      ['A Syrve warehouse must be identified by its own code.', 'Syrve sandėlis turi būti atpažįstamas pagal jo kodą.'],
      ['Open Inventory Management → Storage → Storages and read the storage code and name. Use the corresponding warehouse default in FH, not the delivery address.', 'Atverkite Inventory Management → Storage → Storages ir raskite sandėlio kodą bei pavadinimą. FH naudokite atitinkamą sandėlio numatytąją reikšmę, ne pristatymo adresą.'],
    ]),
    topic('concepts', ['Concept codes', 'Koncepcijų kodai'], 'Syrve', [12545735], [
      ['A concept is a separate Syrve dimension, not a warehouse.', 'Koncepcija yra atskira Syrve dimensija, ne sandėlis.'],
      ['Open Retail Sales → Concepts and obtain the concept code and name. In FH use the Concept default in the Syrve additional-column settings.', 'Atverkite Retail Sales → Concepts ir paimkite koncepcijos kodą bei pavadinimą. FH naudokite Koncepcijos numatytąją reikšmę Syrve papildomų stulpelių nustatymuose.'],
    ]),
    topic('batch-warehouse', ['Warehouse for multiple invoice lines', 'Sandėlis kelioms sąskaitos eilutėms'], 'Syrve', [12645142], [
      ['A delivery address does not reliably determine a Syrve warehouse.', 'Pristatymo adresas neleidžia patikimai nustatyti Syrve sandėlio.'],
      ['Verify the intended warehouse before applying it to all lines. FH currently has the format default but not a dedicated Syrve bulk warehouse assignment action; do not assume a different bulk field changes it.', 'Prieš taikydami visoms eilutėms patikrinkite sandėlį. FH šiuo metu turi formato numatytąją reikšmę, bet neturi atskiro masinio Syrve sandėlio priskyrimo veiksmo; kito masinio lauko keitimas jo nepakeičia.'],
    ]),
    topic('quantity-conversion', ['Product quantity conversion', 'Prekių kiekių perskaičiavimas'], 'Syrve', [13557673], [
      ['Quantity conversion follows the unit relationship in the Syrve product card.', 'Kiekių perskaičiavimas remiasi vienetų santykiu Syrve prekės kortelėje.'],
      ['For example, ten packages at 0.9 kg each represent 9 kg. Check the source unit, target unit and coefficient; the invoice total must remain consistent.', 'Pavyzdžiui, dešimt pakuočių po 0,9 kg sudaro 9 kg. Patikrinkite pradinį bei tikslinį vienetą ir koeficientą; sąskaitos suma turi išlikti suderinta.'],
      ['FH exposes the quantity-recalculation option as a setting. Without a connected Syrve adapter it does not fetch the product card or perform a verified stock conversion.', 'FH pateikia kiekių perskaičiavimo parinktį kaip nustatymą. Be prijungto Syrve adapterio ji negauna prekės kortelės ir neatlieka patikrinto atsargų perskaičiavimo.'],
    ]),
    topic('product-not-found', ['Error: outer product was not found', 'Klaida: prekė nerasta Syrve'], 'Syrve', [15250845], [
      ['The external-raw-materials-only filter can hide an otherwise existing product.', 'Tik išorinių žaliavų filtras gali paslėpti net egzistuojančią prekę.'],
      ['Compare the exact SKU and product card, then review the External raw materials only option. Do not create another product until you have ruled out filtering and a wrong code.', 'Sutikrinkite tikslų SKU bei prekės kortelę ir peržiūrėkite Tik išorinės žaliavos parinktį. Nekurkite antros prekės, kol neatmetėte filtro ar netinkamo kodo priežasties.'],
    ], 'review'),
  ],
};

const rivile = [
  topic('file-import', ['EIP file import order', 'EIP failų importavimo tvarka'], 'Rivilė GAMA', [8630489], [
    ['The client and item records must be available before the invoices that reference them.', 'Klientų ir prekių įrašai turi būti įkelti prieš juos naudojančias sąskaitas.'],
    ['Unpack the compatible production archive before choosing files in Rivilė GAMA.', 'Prieš rinkdamiesi failus Rivilė GAMA, išskleiskite suderinamą produkcinį archyvą.'],
    ['Import Klientai.eip first, in the intended company database.', 'Reikiamoje įmonės bazėje pirmiausia importuokite Klientai.eip.'],
    ['If supplied and required, import Prekes.eip next.', 'Jei pateiktas ir reikalingas, toliau importuokite Prekes.eip.'],
    ['Finally import Pirkimai.eip or Pardavimai.eip for the corresponding direction. Check the resulting invoices before repeating a file.', 'Galiausiai atitinkama kryptimi importuokite Pirkimai.eip arba Pardavimai.eip. Prieš kartodami failą patikrinkite gautas sąskaitas.'],
    ['These are the receiving system’s production-file requirements. The current FH preview file is not an EIP adapter and must not be imported as a production file.', 'Tai gavėjo sistemos produkcinių failų reikalavimai. Dabartinis FH peržiūros failas nėra EIP adapteris ir neturi būti importuojamas kaip produkcinis failas.'],
  ]),
  topic('expense-allocation', ['Expense / income allocation', 'Išlaidų ir pajamų paskirstymas'], 'Rivilė GAMA', [3508472], [
    ['Expense allocation can use a Rivilė code rather than a supplier item identifier.', 'Išlaidų paskirstymui galima naudoti Rivilės kodą, o ne tiekėjo prekės identifikatorių.'],
    ['Check Cards → 05 Codes and use its exact code in FH. Names, spaces and letter case must not silently replace the actual identifier.', 'Patikrinkite Kortelės → 05 Kodai ir FH naudokite tikslų kodą. Pavadinimas, tarpai ar pakeistas raidžių dydis neturi pakeisti tikro identifikatoriaus.'],
  ], 'codes'),
  topic('gateway-api', ['GAMA API key and Gateway', 'GAMA API raktas ir Gateway'], 'Rivilė GAMA', [5166019], [
    ['Direct transfer requires API access for the intended GAMA database and a working Gateway.', 'Tiesioginiam perdavimui reikia reikiamos GAMA bazės API prieigos ir veikiančio Gateway.'],
    ['Arrange access with Rivilė or the implementer. Use a separate key for the correct database and have the administrator verify that Gateway reaches it. A key does not replace server configuration.', 'Prieigą suderinkite su Rivile arba diegėju. Naudokite reikiamai bazei skirtą raktą; administratorius turi patikrinti, ar Gateway ją pasiekia. Raktas nepakeičia serverio konfigūravimo.'],
  ]),
  topic('products-services', ['Product, service and code types', 'Prekės, paslaugos ir kodo tipai'], 'Rivilė GAMA', [6261192], [
    ['Choose the directory type that exists in the receiving Rivilė database.', 'Pasirinkite gavėjo Rivilės bazėje egzistuojantį registro tipą.'],
    ['A Code, Service and Product are not interchangeable. Import the corresponding list into FH and choose the matching type before assigning a line, especially for quantity-based documents.', 'Kodas, Paslauga ir Prekė nėra tarpusavyje pakeičiami. Įkelkite atitinkamą sąrašą į FH ir prieš priskirdami eilutę parinkite tipą, ypač kiekinėms sąskaitoms.'],
  ], 'codes'),
  topic('new-item-settings', ['New-item account link, type and group', 'Naujos prekės sąskaitų ryšys, tipas ir grupė'], 'Rivilė GAMA', [8255025, 8128349], [
    ['Account-link and type settings concern newly created item cards.', 'Sąskaitų ryšio ir tipo nustatymai skirti naujai kuriamoms prekių kortelėms.'],
    ['Use an existing account-link code. Rivilė item types distinguish ordinary, assembled, disassembled, generated, composite, mixed and packaging items; confirm the correct numeric type with the card settings.', 'Naudokite egzistuojantį sąskaitų ryšio kodą. Rivilės tipai skiria paprastas, komplektuojamas, išskaidomas, generuojamas, sudėtines, mišrias prekes bei tarą; skaitinį tipą sutikrinkite su kortelės nustatymais.'],
    ['FH has Item account link code, Item type and an additional Product group field. Saving them does not update existing cards or create new Rivilė items without a real adapter.', 'FH turi Prekės sąskaitų ryšio kodą, Prekės tipą ir papildomą Prekių grupės lauką. Jų išsaugojimas nekeičia esamų kortelių ir be tikro adapterio nesukuria Rivilės prekių.'],
  ]),
  topic('automatic-export', ['Automatic export after digitization', 'Automatinis eksportas po skaitmeninimo'], 'Rivilė GAMA', [9728118], [
    ['Automatic export and accounting posting are separate decisions.', 'Automatinis eksportas ir dokumento perkėlimas apskaitoje yra atskiri sprendimai.'],
    ['In FH Rivilė API settings, Export immediately after digitization expresses the trigger; Automatically post expresses the receiving posting step. Required codes and successful validation must still be checked.', 'FH Rivilė API nustatymuose Eksportuoti iš karto po skaitmeninimo nurodo paleidimą, o Automatiškai perkelti – gavėjo registravimo veiksmą. Privalomi kodai ir validacijos vis tiek turi būti tikrinami.'],
    ['The current frontend stores these preferences but has no background export worker. Enabling a checkbox does not send any invoice.', 'Dabartinis frontend išsaugo šias parinktis, bet neturi foninės eksporto tarnybos. Varnelės pažymėjimas sąskaitų neišsiunčia.'],
  ]),
  topic('payments-persons', ['Payment accounts and accountable persons', 'Apmokėjimo sąskaitos ir atskaitingi asmenys'], 'Rivilė GAMA', [11754272], [
    ['Paid-invoice handling needs both accounting accounts and a valid person code when applicable.', 'Apmokėtos sąskaitos perdavimui reikia apskaitos sąskaitų ir, kai taikoma, tinkamo asmens kodo.'],
    ['Export the people list from Cards → 30 Persons through Print → MS Excel, retaining code and name. Match the sales / purchase payment account codes to the receiving chart.', 'Asmenų sąrašą eksportuokite Kortelės → 30 Asmenys per Spausdinti → MS Excel, palikdami kodą bei vardą ir pavardę. Pardavimų ir pirkimų apmokėjimo sąskaitas sutikrinkite su gavėjo sąskaitų planu.'],
    ['FH exposes general payment-account settings and person codes. It does not yet implement a separate payment-account mapping for every person or live payment-document creation.', 'FH pateikia bendrus apmokėjimo sąskaitų nustatymus ir asmenų kodus. Atskiro kiekvieno asmens apmokėjimo sąskaitų susiejimo bei tikrų mokėjimo dokumentų kūrimo dar nėra.'],
  ], 'codes'),
  topic('series', ['Invoice series', 'Sąskaitos serija'], 'Rivilė GAMA', [5412181], [
    ['Series and invoice number are separate fields.', 'Serija ir sąskaitos numeris yra atskiri laukai.'],
    ['Assign Series in FH when the receiving Rivilė Series field is required. Check it separately from the full document number after import; do not duplicate the prefix in both fields without agreeing the mapping.', 'FH priskirkite Seriją, kai jos reikia gavėjo Rivilės Serija laukui. Po importo tikrinkite ją atskirai nuo pilno dokumento numerio; be suderintų atitikmenų nedubliuokite priešdėlio abiejuose laukuose.'],
  ]),
  topic('missing-person', ['Error: person code not found', 'Klaida: nerastas asmens kodas'], 'Rivilė GAMA', [11754227], [
    ['The assigned accountable-person code is missing in Rivilė.', 'Priskirto atskaitingo asmens kodo nėra Rivilėje.'],
    ['Check Cards → 30 Persons. Correct the document mapping or create the actual person with the intended code. The example 24450 is not a mandatory default code.', 'Patikrinkite Kortelės → 30 Asmenys. Taisykite dokumento atitikmenį arba sukurkite tikrą asmenį su reikiamu kodu. Pavyzdinis 24450 nėra privalomas numatytasis kodas.'],
  ], 'review'),
  topic('department-company-id', ['Error: department ID does not match company ID', 'Klaida: padalinio ID neatitinka įmonės ID'], 'Rivilė GAMA', [14468863], [
    ['This can require a database-identity correction by the Rivilė provider.', 'Šiai klaidai gali reikėti Rivilės tiekėjo atliekamos bazės identifikatoriaus korekcijos.'],
    ['Check that the correct company and database key were selected, then ask the provider to verify the database ID. Do not change invoice values to compensate for an infrastructure mismatch.', 'Patikrinkite pasirinktą įmonę bei bazės raktą ir paprašykite tiekėjo patikrinti duomenų bazės ID. Nekeiskite sąskaitos reikšmių, kad kompensuotumėte infrastruktūros neatitikimą.'],
  ], 'review'),
  topic('wrong-import-command', ['Error: skip the state / file problem', 'Klaida: praleiskite būklę / problema su failu'], 'Rivilė GAMA', [14525404], [
    ['The wrong import command can produce a file-state error.', 'Netinkama importo komanda gali sukelti failo būklės klaidą.'],
    ['For an actual EIP file use the Rivilė EIP import action (the two-arrow import icon), not another import mode. Verify that the selected file is EIP and not the FH preview XML.', 'Tikram EIP failui naudokite Rivilės EIP importo veiksmą (dviejų rodyklių importo ikoną), ne kitą importo būdą. Patikrinkite, ar pasirinktas EIP, o ne FH peržiūros XML.'],
  ], 'review'),
  topic('missing-department', ['Error: department 9999999 not found', 'Klaida: nerastas padalinys 9999999'], 'Rivilė GAMA', [3527787], [
    ['A missing or unsuitable department default can cause this error.', 'Šią klaidą gali sukelti trūkstama arba netinkama padalinio numatytoji reikšmė.'],
    ['Check Cards → Departments and Service → Administration → Parameters → SS_PADALINYS. Use a department that exists in this company; do not create the example code blindly.', 'Patikrinkite Kortelės → Padaliniai ir Servisas → Administravimas → Parametrai → SS_PADALINYS. Naudokite šioje įmonėje egzistuojantį padalinį; pavyzdinio kodo aklai nekurkite.'],
  ], 'review'),
  topic('invalid-quantity', ['Error: I07_KIEKIS_U / 6027 invalid quantity', 'Klaida: I07_KIEKIS_U / 6027 blogas kiekis'], 'Rivilė GAMA', [14655090], [
    ['Quantity precision must agree with the unit and item-card settings.', 'Kiekio tikslumas turi atitikti vieneto ir prekės kortelės nustatymus.'],
    ['Check the unit fraction: 1 allows whole units, 10 one decimal place. Compare the source quantity with the allowed precision and correct the unit setup when appropriate; do not round away a real invoice quantity arbitrarily.', 'Patikrinkite vieneto frakciją: 1 leidžia sveikus vienetus, 10 – vieną dešimtainį ženklą. Sutikrinkite sąskaitos kiekį su leistinu tikslumu ir prireikus taisykite vieneto nustatymą; savavališkai neapvalinkite tikro kiekio.'],
  ], 'review'),
  topic('gateway-unavailable', ['Error: GAMA database unavailable', 'Klaida: GAMA duomenų bazė nepasiekiama'], 'Rivilė GAMA', [16613110], [
    ['An unavailable Gateway or database is a connection failure, not an invoice-field error.', 'Nepasiekiamas Gateway ar duomenų bazė yra ryšio, ne sąskaitos lauko klaida.'],
    ['Ask the administrator to check the Gateway process and database access. A temporary restart may require several minutes before retrying; verify whether the invoice already exists first.', 'Paprašykite administratoriaus patikrinti Gateway procesą ir prieigą prie bazės. Po laikino perkrovimo iki pakartojimo gali tekti palaukti kelias minutes; pirmiausia patikrinkite, ar sąskaita jau nesukurta.'],
  ], 'review'),
  topic('buyer-supplier-type', ['Error: customer is not a buyer / supplier', 'Klaida: klientas nėra pirkėjas / tiekėjas'], 'Rivilė GAMA', [18329345], [
    ['The customer card may not allow the invoice direction being imported.', 'Kliento kortelė gali neleisti importuojamos sąskaitos krypties.'],
    ['Check Cards → 02 Customers and its Buyer / Supplier type, then verify the company and VAT codes. Select the correct existing card instead of creating another solely to change its role.', 'Patikrinkite Kortelės → 02 Klientai ir Pirkėjas / Tiekėjas tipą, tada įmonės bei PVM kodus. Rinkitės tinkamą esamą kortelę, nekurkite kitos vien jos vaidmeniui pakeisti.'],
  ], 'review'),
  topic('change-customer-code', ['Changing a customer code safely', 'Saugus kliento kodo keitimas'], 'Rivilė GAMA', [3507022], [
    ['An established customer code is changed through Rivilė code conversion, not by deleting the card.', 'Naudojamas kliento kodas keičiamas per Rivilės perkodavimą, ne trinant kortelę.'],
    ['Use Service → Statistics → S8 Code changes. Create an operation of type Customer, enter old and new codes, save and post the conversion. Have an authorized administrator verify linked operations and a backup first.', 'Rinkitės Servisas → Statistika → S8 Kodų keitimas. Sukurkite Klientas tipo operaciją, nurodykite seną bei naują kodą, išsaugokite ir perkelkite perkodavimą. Įgaliotas administratorius prieš tai turi patikrinti susijusias operacijas bei atsarginę kopiją.'],
  ], 'review'),
  topic('foreign-currency', ['Foreign-currency invoices', 'Valiutinės sąskaitos'], 'Rivilė GAMA', [3544888], [
    ['Currency conversion requires receiving-system parameters and available rates.', 'Valiutos perskaičiavimui reikalingi gavėjo parametrai ir kursai.'],
    ['Review Service → Administration → Parameters → SS_VAL_PER for receipts and payments, and enter the needed exchange rates. Check the currency and date on the imported invoice.', 'Patikrinkite Servisas → Administravimas → Parametrai → SS_VAL_PER įplaukoms bei išmokoms ir suveskite reikalingus valiutų kursus. Importuotoje sąskaitoje sutikrinkite valiutą ir datą.'],
  ], 'review'),
  topic('code-list', ['Copying the Rivilė code list', 'Rivilės kodų sąrašo perkėlimas'], 'Rivilė GAMA', [3565278], [
    ['Export the code list instead of retyping identifiers.', 'Kodų sąrašą eksportuokite, kad nereikėtų perrašinėti identifikatorių.'],
    ['Open Service → Cards → Codes, choose Print and MS Excel. Remove an empty intervening column if present, leaving code and description adjacent. Preserve letter case.', 'Atverkite Servisas → Kortelės → Kodai, rinkitės Spausdinti ir MS Excel. Jei tarp kodo bei aprašymo yra tuščias stulpelis, jį pašalinkite. Išsaugokite raidžių dydį.'],
  ], 'codes'),
  topic('customer-list', ['Importing the customer list', 'Klientų sąrašo įkėlimas'], 'Rivilė GAMA', [5085970], [
    ['The accounting code and company registration code are separate identifiers.', 'Apskaitos kodas ir įmonės registracijos kodas yra skirtingi identifikatoriai.'],
    ['Export Service → Cards → Customers through Print → MS Excel. Retain accounting code, company code, VAT code and company name in that order.', 'Servisas → Kortelės → Klientai eksportuokite per Spausdinti → MS Excel. Eilės tvarka palikite apskaitos kodą, įmonės kodą, PVM kodą ir įmonės pavadinimą.'],
    ['In FH use organization gear → Counterparties → Import from Excel. Its fifth optional column is IBAN; separate multiple IBANs with commas or semicolons. Check the preview before importing.', 'FH rinkitės organizacijos dantratį → Kontrahentai → Įkelti iš Excel. Penktas neprivalomas stulpelis yra IBAN; kelis IBAN skirkite kableliu arba kabliataškiu. Prieš įkeldami patikrinkite peržiūrą.'],
  ]),
  topic('departments-objects', ['Departments and objects', 'Padaliniai ir objektai'], 'Rivilė GAMA', [5086101], [
    ['Department and object lists are maintained separately.', 'Padalinių ir objektų sąrašai tvarkomi atskirai.'],
    ['Open Service → Cards → Departments or Objects. Print to MS Excel and copy the first two data columns. Import them into the matching FH Additional columns directory, not into Expenses.', 'Atverkite Servisas → Kortelės → Padaliniai arba Objektai. Spausdinkite į MS Excel ir nukopijuokite pirmus du duomenų stulpelius. Įkelkite į atitinkamą FH Papildomų stulpelių registrą, ne į Išlaidas.'],
  ], 'codes'),
  topic('code-synchronization', ['Code synchronization and barcodes', 'Kodų sinchronizavimas ir barkodai'], 'Rivilė GAMA', [8041111], [
    ['API code synchronization is different from invoice export.', 'Kodų sinchronizavimas per API yra atskiras veiksmas nuo sąskaitų eksporto.'],
    ['A connected service can retrieve new / changed codes and alternative barcodes. This requires read access to the corresponding Rivilė directories, not merely a saved export-format name.', 'Prijungta tarnyba gali gauti naujus ar pakeistus kodus ir alternatyvius barkodus. Tam reikia skaitymo prieigos prie atitinkamų Rivilės registrų, ne vien išsaugoto eksporto formato pavadinimo.'],
    ['The current FH gear has manual / Excel code import and per-code alternative values, but no live Refresh from Rivilė action. Use these available controls until that service is implemented.', 'Dabartiniame FH dantratyje yra rankinis bei Excel kodų įkėlimas ir atskiro kodo alternatyvios reikšmės, bet nėra tikro Atnaujinti iš Rivilės veiksmo. Iki tarnybos įgyvendinimo naudokite esamus valdiklius.'],
  ], 'codes'),
];
VENDOR_HELP_TOPICS['Rivilė'] = rivile;
VENDOR_HELP_TOPICS['Rivilė API'] = rivile;
VENDOR_HELP_TOPICS['Pragma4'] = [...VENDOR_HELP_TOPICS.Pragma4, VENDOR_HELP_TOPICS.Pragma3[1]];
VENDOR_HELP_TOPICS['Pragma4 V2'] = VENDOR_HELP_TOPICS.Pragma4;
VENDOR_HELP_TOPICS['Finvalda Excel'] = VENDOR_HELP_TOPICS.Finvalda.filter(item => item.id === 'service-codes');
VENDOR_HELP_TOPICS['Debetas Excel'] = [];

const fileContract: IntegrationHelpTopic = {
  id: 'file-contract',
  title: ['File structure and production compatibility', 'Failo struktūra ir produkcinis suderinamumas'],
  description: ['Distinguish the FH preview payload from a receiving system’s import specification.', 'FH peržiūros duomenų atskyrimas nuo gavėjo importo specifikacijos.'],
  sections: [{ title: ['Current FH export', 'Dabartinis FH eksportas'], system: 'FH', steps: [
    ['The current accounting export uses the schema finansu-harmonija.accounting-export-preview.v1 with importReady=false. Rivilė and Agnum preview profiles produce XML; other configured delivery destinations use JSON. Selecting a format in organization settings does not implement its production serializer.', 'Dabartinis apskaitos eksportas naudoja finansu-harmonija.accounting-export-preview.v1 schemą su importReady=false. Rivilė ir Agnum peržiūros profiliai pateikia XML, kiti nustatyti perdavimo gavėjai – JSON. Formato pasirinkimas organizacijos nustatymuose neįgyvendina jo produkcinio failo generatoriaus.'],
    ['The payload separates destination, company, generation time and documents. A document includes its number, dates, counterparty, currency, net / VAT / total amounts and allocation fields. Accounting allocations and recognized document lines are separate arrays.', 'Duomenyse atskirti gavėjas, įmonė, generavimo laikas ir dokumentai. Dokumentas apima numerį, datas, kontrahentą, valiutą, sumą be PVM, PVM, bendrą sumą bei paskirstymo laukus. Apskaitiniai paskirstymai ir atpažintos dokumento eilutės pateikiami atskirais masyvais.'],
    ['Before production use, agree the receiving schema and validate a sample with its administrator. For CSV / Excel this includes columns, delimiters, encoding, dates and decimal precision; for XML / JSON it includes required fields, nesting and schema version. Never substitute another provider’s API or file contract.', 'Prieš produkcinį naudojimą su gavėjo administratoriumi suderinkite schemą ir patikrinkite pavyzdį. CSV ar Excel atveju tai stulpeliai, skirtukai, koduotė, datos ir skaičių tikslumas; XML ar JSON – privalomi laukai, struktūra ir schemos versija. Nenaudokite kito tiekėjo API ar failo sutarties kaip FH specifikacijos.'],
    ['An iSAF format preference is not a tax submission. Production validation, a compliant file generator and the receiving authority’s acknowledgement are outside the current preview.', 'iSAF formato parinktis nėra deklaracijos pateikimas. Produkcinė validacija, reikalavimus atitinkantis failo generatorius ir gavėjo patvirtinimas nėra dabartinės peržiūros dalis.'],
  ] }],
};
for (const format of ['CSV', 'Excel', 'Json', 'XML', 'iSAF']) VENDOR_HELP_TOPICS[format] = [fileContract];
