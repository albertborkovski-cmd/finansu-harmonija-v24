import type { ColConfig } from '../components/ColumnSettingsPanel';

/** Approved All Documents → Documents layout, captured from Columns on 2026-11-17.
 * Keep hidden columns in their chosen positions so users can enable them later. */
export const GLOBAL_DOCUMENT_COLUMN_ORDER = [
  'organization', 'documentDate', 'number', 'clientCounterparty', 'counterpartyCode',
  'currency', 'amountWithoutVat', 'vat', 'vatPercent', 'status', 'source',
  'totalAmount', 'dueEndDate', 'orderNo', 'departmentCode', 'objectProject',
  'series', 'costCenter', 'expenseAccount', 'accountableResponsible', 'note',
  'vatClassifier', 'fileCase', 'issueStatus', 'receiveDate', 'documentType',
  'purposeCode', 'operationDate',
] as const;

export function globalDocumentDefaultColumns(columns: readonly ColConfig[]): ColConfig[] {
  const available = new Map(columns.map(column => [column.key, { ...column }]));
  const result: ColConfig[] = [];
  for (const key of GLOBAL_DOCUMENT_COLUMN_ORDER) {
    const column = available.get(key);
    if (!column) continue;
    result.push({ ...column, visible: !['organization', 'counterpartyCode', 'purposeCode'].includes(key) });
    available.delete(key);
  }
  return [...result, ...available.values()];
}

/** Only this register is personalized. Legacy/company table settings are untouched. */
export function globalDocumentColumnPersistence(email: string) {
  const scope = `v23:global-documents:user:${encodeURIComponent(email.trim().toLowerCase() || 'anonymous')}`;
  return { layout: scope, widths: scope };
}
