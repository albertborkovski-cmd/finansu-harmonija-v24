import type { Company, DbDocument } from './supabase';
import { buildOrganizationDirectory, matchesOrganizationDirectoryDocument, type DirectoryCounterparty } from './organizationDirectory';
import { NO_BUYER_FILTER } from './documentOrganizationAssignment';

export type SharingEntry = { id: string; name: string; code: string; documentIds: string[]; hasSettings: boolean };
export type SharingPreview = { entries: Array<{ id: string; name: string; documentCount: number; hasSettings: boolean }>; documentCount: number };

/** Call with permission-filtered organizations and counterparties only. The
 * preview contains counts, not copied document contents or credentials. */
export function buildProfileSharingEntries(companies: Company[], counterparties: DirectoryCounterparty[], documents: DbDocument[], includeUnassigned: boolean): SharingEntry[] {
  const allowed = new Set(companies.map(company => company.id));
  const docs = [...new Map(documents.filter(document => String(document.entry_method ?? '').trim().toLowerCase() !== 'manual'
    && (allowed.has(document.company_id || '') || (includeUnassigned && !document.company_id))).map(document => [document.id, document])).values()];
  const directory = buildOrganizationDirectory(companies, counterparties);
  const rows = directory.map(entry => ({ id: entry.id, name: entry.name, code: entry.company_code || '', hasSettings: true,
    documentIds: docs.filter(document => matchesOrganizationDirectoryDocument({ companyId: document.company_id || '', counterpartyId: document.counterparty_id || '', counterpartyCode: document.counterparty_code || '', clientCounterparty: document.client_counterparty || '' }, [entry.id], [entry])).map(document => document.id),
  }));
  if (includeUnassigned) rows.unshift({ id: NO_BUYER_FILTER, name: 'No buyer', code: '', hasSettings: false, documentIds: docs.filter(document => !document.company_id).map(document => document.id) });
  return rows;
}

export function createProfileSharingPreview(entries: SharingEntry[], selectedIds: ReadonlySet<string>, apiKey: string): SharingPreview {
  if (!apiKey.trim() || apiKey.trim().length > 4096) throw new Error('Enter the destination account API key.');
  if (!selectedIds.size) throw new Error('Select at least one counterparty.');
  const selected = entries.filter(entry => selectedIds.has(entry.id));
  if (selected.length !== selectedIds.size) throw new Error('The available counterparties have changed. Refresh the list and select them again.');
  return { entries: selected.map(entry => ({ id: entry.id, name: entry.name, documentCount: entry.documentIds.length, hasSettings: entry.hasSettings })),
    documentCount: new Set(selected.flatMap(entry => entry.documentIds)).size };
}
