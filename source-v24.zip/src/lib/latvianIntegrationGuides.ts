import type { HelpText } from './exportHelpGuide';
import type { IntegrationHelpSection, IntegrationHelpTopic } from './integrationHelpTopics';
import { LATVIAN_ACCOUNTING_SYSTEMS, LATVIAN_INTEGRATION_SOURCES } from './latvianAccountingSystems';

const capability: HelpText = ['FH provides these destination choices, settings and instructions. Its current export downloads are data previews, not validated vendor import files; API delivery requires a connected server adapter. Do not import a preview as an official template or treat a saved setting as a successful transfer.', 'FH pateikia šiuos gavėjo pasirinkimus, nustatymus ir instrukcijas. Dabartiniai eksporto failai yra duomenų peržiūros, ne patikrinti tiekėjo importo failai; siuntimui per API reikia prijungtos serverio jungties. Peržiūros neimportuokite kaip oficialaus šablono, o išsaugoto nustatymo nelaikykite sėkmingu perdavimu.'];
const section = (title: HelpText, system: string, steps: HelpText[]): IntegrationHelpSection => ({ title, system, steps });

const providerSections: Record<string, IntegrationHelpSection[]> = {
  'MONEO Excel': [
    section(['Purchase invoices: official workbook', 'Pirkimo sąskaitos: oficialus šablonas'], 'MONEO', [
      ['Download Pieg_Rekinu_Imp.xlsx from the official purchase-import article linked below. Enter the supplier identifier, invoice number/date, VAT, amounts and GL account in the template’s corresponding columns; complete its mandatory fields.', 'Iš žemiau pateikto oficialaus pirkimų importo straipsnio atsisiųskite Pieg_Rekinu_Imp.xlsx. Į atitinkamus šablono stulpelius įrašykite tiekėjo identifikatorių, numerį, datą, PVM, sumas ir DK sąskaitą; užpildykite privalomus laukus.'],
      ['Create supplier cards and the required GL accounts in MONEO beforehand. Supplier registration numbers must match. Check invoice numbers: repeated supplier-invoice numbers in one workbook can be combined.', 'MONEO iš anksto sukurkite tiekėjų korteles ir reikalingas DK sąskaitas. Tiekėjų registracijos numeriai turi sutapti. Patikrinkite numerius: viename faile pasikartojantys tiekėjo sąskaitų numeriai gali būti sujungti.'],
      ['Keep the original column order, column count and worksheets. Save as XLSX with no more than 200 rows per file; use separate files for a larger import.', 'Nekeiskite originalios stulpelių tvarkos, jų skaičiaus ir darbalapių. Išsaugokite XLSX, ne daugiau kaip 200 eilučių faile; didesnį importą padalykite į atskirus failus.'],
      ['Use the supplier-invoice import in the intended MONEO company and choose the completed workbook. Review the import result and open the created invoices before posting them.', 'Reikiamoje MONEO įmonėje rinkitės tiekėjų sąskaitų importą ir užpildytą failą. Patikrinkite rezultatą ir sukurtas sąskaitas prieš jas registruodami apskaitoje.'],
    ]),
    section(['Sales invoices: totals or lines', 'Pardavimo sąskaitos: sumos arba eilutės'], 'MONEO', [
      ['Download Rekinu_Imp_2024.xlsx from the official sales-import article. Use existing customer codes and, for detailed invoices, existing item codes. Enter each item on a separate row, or use the supported totals-only layout.', 'Iš oficialaus pardavimų importo straipsnio atsisiųskite Rekinu_Imp_2024.xlsx. Naudokite esamus klientų, o detalioms sąskaitoms – prekių kodus. Kiekvieną prekę įrašykite atskiroje eilutėje arba naudokite palaikomą suminį variantą.'],
      ['Preserve the workbook structure and the 200-row limit. Open Realizācija → Importi → Rēķinu imports, select the XLSX and confirm. Check the resulting records in Realizācija → Rēķini.', 'Išlaikykite šablono struktūrą ir 200 eilučių ribą. Atverkite Realizācija → Importi → Rēķinu imports, pasirinkite XLSX ir patvirtinkite. Rezultatą tikrinkite Realizācija → Rēķini.'],
    ]),
  ],
  'MONEO API': [
    section(['Enable access for the correct company', 'Prieiga konkrečiai įmonei'], 'MONEO', [
      ['Arrange an API integration licence and API user with MONEO. Confirm the allowed server IP addresses and the user’s access to the required company and tables.', 'Su MONEO suderinkite API integracijos licenciją ir API naudotoją. Patvirtinkite leidžiamus serverio IP adresus bei naudotojo teises reikiamai įmonei ir lentelėms.'],
      ['Find the API address and company ID in MONEO → Palīdzība → Servera informācija. In FH select MONEO API and enter the matching API URL and compuid. Keys belong in the server connection, not document notes.', 'API adresą ir įmonės ID raskite MONEO → Palīdzība → Servera informācija. FH pasirinkite MONEO API ir atitinkamus API URL bei compuid. Raktai skirti serverio jungčiai, ne dokumento pastaboms.'],
    ]),
    section(['Request and receipt', 'Užklausa ir rezultatas'], 'MONEO', [
      ['MONEO requests use the Authorization header and request.compuid. The workflow describes separate read/create operations: a POST request alone does not mean that an invoice is created. Use the exact record-creation operation and schema from the vendor documentation.', 'MONEO užklausose naudojama Authorization antraštė ir request.compuid. Darbo eigoje atskirtos skaitymo ir kūrimo operacijos: vien POST dar nereiškia sąskaitos sukūrimo. Naudokite dokumentacijoje nurodytą kūrimo operaciją ir struktūrą.'],
      ['Select the appropriate table; sales.invoices is the sales-invoice table. Obtain the purchase table and line schema from the official table reference. Check the returned record identifier and errors before marking delivery complete.', 'Parinkite tinkamą lentelę: sales.invoices skirta pardavimo sąskaitoms. Pirkimų lentelę ir eilučių struktūrą tikrinkite oficialiame lentelių apraše. Prieš užbaigdami perdavimą patikrinkite grąžintą įrašo ID ir klaidas.'],
    ]),
  ],
  'Jumis Excel': [
    section(['Select the correct Excel example', 'Tinkamo Excel pavyzdžio pasirinkimas'], 'Jumis', [
      ['Use the official XLSX example for financial or stock documents, not an arbitrary worksheet. Red-marked fields are mandatory; keep paired additional-information fields together. Use the exact destination codes.', 'Naudokite oficialų finansinių arba sandėlio dokumentų XLSX pavyzdį, ne laisvą lentelę. Raudonai pažymėti laukai privalomi; susijusius papildomos informacijos laukus pildykite kartu. Naudokite tikslius gavėjo kodus.'],
      ['Open Konfigurācija → Jumis datu imports. Set Datu veids to Excel and choose the completed file. Resolve mapping prompts against existing records, then check imported documents.', 'Atverkite Konfigurācija → Jumis datu imports. Lauke Datu veids pasirinkite Excel ir užpildytą failą. Susiekite prašomas reikšmes su esamais įrašais, tada patikrinkite importuotus dokumentus.'],
      ['For non-EUR financial documents, check currencies and exchange rates in both document and posting sheets. Do not treat an invoice PDF as an Excel import file.', 'Ne EUR finansiniams dokumentams tikrinkite valiutas ir kursus dokumento bei korespondencijų lapuose. Sąskaitos PDF nėra Excel importo failas.'],
    ]),
  ],
  'Jumis XML': [
    section(['XML import', 'XML failo importas'], 'Jumis', [
      ['Use a sample exported from the intended Jumis document type and its official XML specification. Financial and stock documents have different structures. A generic XML export is not automatically compatible.', 'Naudokite iš reikiamo Jumis dokumento tipo eksportuotą pavyzdį ir oficialią XML specifikaciją. Finansinių ir sandėlio dokumentų struktūros skiriasi. Bendras XML failas savaime netinka.'],
      ['Open Konfigurēšana → Tj datu imports, select the matching XML and follow the import checks. Verify the document and accounting result after import.', 'Atverkite Konfigurēšana → Tj datu imports, pasirinkite tinkamą XML ir atlikite importo patikrą. Po importo sutikrinkite dokumentą ir apskaitos rezultatą.'],
    ]),
  ],
  'Jumis API': [
    section(['Cloud API access', 'Debesijos API prieiga'], 'Jumis', [
      ['The documented REST service works with Jumis cloud databases. Obtain the cloud username, special SQL password, database name and API parameters through the administrator. The special password is not the FH password.', 'Aprašyta REST tarnyba veikia su Jumis debesijos bazėmis. Per administratorių gaukite debesijos naudotoją, specialų SQL slaptažodį, bazės pavadinimą ir API parametrus. Specialus slaptažodis nėra FH slaptažodis.'],
      ['The server sends HTTPS POST JSON to the documented import service with username, password, database, apikey and XMLrequest. XMLrequest contains the selected Jumis XML structure. Do not place these credentials in the browser URL.', 'Serveris į dokumentacijoje nurodytą importo tarnybą siunčia HTTPS POST JSON su username, password, database, apikey ir XMLrequest. XMLrequest talpina pasirinktą Jumis XML struktūrą. Prisijungimų nedėkite į naršyklės URL.'],
      ['Read the returned import result and any document errors; an HTTP connection by itself does not confirm successful import.', 'Perskaitykite grąžintą importo rezultatą bei dokumentų klaidas; vien HTTP ryšys nepatvirtina sėkmingo importo.'],
    ]),
  ],
  'Horizon Peppol XML': [
    section(['Purchase e-invoices in Metarēķini', 'Pirkimo e. sąskaitos skiltyje Metarēķini'], 'Horizon', [
      ['Use a valid Peppol BIS Billing 3.0 invoice XML. A PDF attachment or an arbitrary XML file is not a structured Peppol invoice. Confirm that the receiving company has the Metarēķini functionality and the required document type.', 'Naudokite taisyklingą Peppol BIS Billing 3.0 sąskaitos XML. PDF priedas ar bet koks XML nėra struktūrinė Peppol sąskaita. Patikrinkite gavėjo įmonės Metarēķini funkcionalumą ir dokumento tipą.'],
      ['Open Dokumenti → Metarēķini → Metarēķinu saraksts → Darbības → Imports - PEPPOL formāts, or Metarēķinu imports → Pievienot. Choose the XML and review the import result.', 'Atverkite Dokumenti → Metarēķini → Metarēķinu saraksts → Darbības → Imports - PEPPOL formāts arba Metarēķinu imports → Pievienot. Pasirinkite XML ir peržiūrėkite rezultatą.'],
      ['Review supplier, currency and lines in the intermediate record. A metarēķins is not yet a posted accounting document: complete recognition/approval and generate the final invoice. Agree GL accounts and analytical dimensions separately.', 'Tarpiniame įraše patikrinkite tiekėją, valiutą ir eilutes. Metarēķins dar nėra užregistruotas apskaitos dokumentas: užbaikite atpažinimą bei derinimą ir sukurkite galutinę sąskaitą. DK ir analitines dimensijas suderinkite atskirai.'],
    ]),
  ],
  'Horizon API': [
    section(['REST connection', 'REST jungtis'], 'Horizon', [
      ['Ask the Horizon administrator to confirm REST access, the integration server address, authentication and permissions for the intended company. Use the official REST documentation linked below.', 'Paprašykite Horizon administratoriaus patvirtinti REST prieigą, integracijų serverio adresą, autentifikavimą ir teises reikiamai įmonei. Remkitės žemiau pateikta oficialia REST dokumentacija.'],
      ['Agree the invoice resource and document-type template for that installation before enabling delivery. Do not use the release-notes API as an accounting endpoint or send Peppol XML to an arbitrary REST URL.', 'Prieš įjungdami perdavimą suderinkite to diegimo sąskaitos resursą ir dokumento tipo šabloną. Pakeitimų žurnalo API nėra apskaitos galinis taškas; Peppol XML nesiųskite į atsitiktinį REST adresą.'],
      ['Configure GL and dimension mappings with the implementer. Check the returned document identifier, import errors and posting state separately.', 'Su diegėju sukonfigūruokite DK bei dimensijų atitikmenis. Atskirai patikrinkite grąžintą dokumento ID, importo klaidas ir registravimo būseną.'],
    ]),
  ],
  'Zalktis XML': [
    section(['Purchase e-invoices', 'Pirkimo e. sąskaitos'], 'Zalktis', [
      ['Before the first import, configure incoming-invoice posting schemes in Pamatdati → Administratora rīki → Rēķinu un noliktavas dokumentu kontējumu shēmas.', 'Prieš pirmą importą nustatykite gaunamų sąskaitų korespondencijų schemas: Pamatdati → Administratora rīki → Rēķinu un noliktavas dokumentu kontējumu shēmas.'],
      ['Import the structured purchase e-invoice XML from the invoice list. Zalktis checks whether the recipient registration number belongs to your company.', 'Sąskaitų sąraše importuokite struktūrinį pirkimo e. sąskaitos XML. Zalktis tikrina, ar gavėjo registracijos numeris priklauso jūsų įmonei.'],
      ['The imported purchase invoice opens for review. Correct additional information or posting accounts if needed, then save. This route is different from Zalktis accounting-entry XML import.', 'Importuota pirkimo sąskaita atveriama patikrai. Jei reikia, papildykite informaciją ar korespondencijų sąskaitas ir išsaugokite. Šis būdas skiriasi nuo Zalktis apskaitos įrašų XML importo.'],
    ]),
  ],
  'Zalktis Accounting XML': [
    section(['Accounting-entry XML', 'Apskaitos įrašų XML'], 'Zalktis', [
      ['Use Pamatdati → Administratora rīki → Dažādu datu imports un eksports → Zalktis datu eksports/imports. The file must be UTF-8 and follow the official hierarchical structure.', 'Naudokite Pamatdati → Administratora rīki → Dažādu datu imports un eksports → Zalktis datu eksports/imports. Failas turi būti UTF-8 ir atitikti oficialią hierarchinę struktūrą.'],
      ['The structure starts with Root, contains FailaPase and one or more Dokuments records. Copying these element names alone is not sufficient: use the full provider specification for required fields and postings.', 'Struktūra prasideda Root, turi FailaPase ir vieną ar daugiau Dokuments įrašų. Vien šių žymų neužtenka: privalomus laukus ir korespondencijas formuokite pagal visą tiekėjo specifikaciją.'],
      ['Check document type, date, number, partner, currency and balanced debit/credit entries before importing. The published example is versioned; confirm compatibility with your installed Zalktis version.', 'Prieš importą patikrinkite tipą, datą, numerį, partnerį, valiutą ir debeto bei kredito balansą. Paskelbtas pavyzdys turi versiją; patvirtinkite jo suderinamumą su savo Zalktis diegimu.'],
    ]),
  ],
};

const jumisStructure: IntegrationHelpSection = {
  title: ['FinancialDoc or StoreDoc?', 'FinancialDoc ar StoreDoc?'], system: 'Jumis',
  paragraphs: [
    ['FinancialDoc describes cash, bank and other financial operations. Its header includes DocNo, DocDate, DocPartnerRegistrationNo, DocAmount and DocCurrency; posting fields include LineDebetAccountCode, LineCreditAccountCode and LineVatRate. These are field references, not a complete import payload.', 'FinancialDoc aprašo kasos, banko ir kitas finansines operacijas. Antraštėje yra DocNo, DocDate, DocPartnerRegistrationNo, DocAmount ir DocCurrency, korespondencijose – LineDebetAccountCode, LineCreditAccountCode ir LineVatRate. Tai laukų nuorodos, ne pilna importo užklausa.'],
    ['StoreDoc is the stock-document structure for goods/service trading documents. Select the structure according to the destination register, not merely because an OCR document is called an invoice. Follow each block’s version and required fields.', 'StoreDoc yra prekių bei paslaugų prekybos dokumentų sandėlio struktūra. Ją rinkitės pagal gavėjo registrą, ne vien todėl, kad OCR dokumentas pavadintas sąskaita. Laikykitės konkretaus bloko versijos ir privalomų laukų.'],
  ],
};

export const LATVIAN_ACCOUNTING_GUIDES = Object.fromEntries(LATVIAN_ACCOUNTING_SYSTEMS.map(item => [item.name, {
  summary: [`${item.name}: ${item.format}; official import instructions and checks.`, `${item.name}: ${item.format}; oficiali importo eiga ir patikrinimai.`] as HelpText,
  setup: [`In All Documents → Documents select the organization → gear → Documents & digitization setup → Export format → ${item.name}. Save this organization’s choice.`, `Visi dokumentai → Dokumentai pasirinkite organizaciją → dantratį → Dokumentų ir skaitmeninimo nustatymai → Eksporto formatas → ${item.name}. Išsaugokite šios organizacijos pasirinkimą.`] as HelpText,
  checks: ['Check the receiver, document direction, required codes, currency and totals. File import and API delivery are different methods.', 'Patikrinkite gavėją, dokumento kryptį, privalomus kodus, valiutą ir sumas. Failo importas ir API siuntimas yra skirtingi būdai.'] as HelpText,
}]));

export const LATVIAN_HELP_TOPICS: Record<string, IntegrationHelpTopic[]> = Object.fromEntries(LATVIAN_ACCOUNTING_SYSTEMS.map(item => {
  const guide = LATVIAN_ACCOUNTING_GUIDES[item.name];
  const topics: IntegrationHelpTopic[] = [
    { id: 'configuration', title: ['Configuration and method selection', 'Konfigūravimas ir būdo pasirinkimas'], description: guide.summary, fieldReference: true, note: capability,
      sections: [section(['Where to configure FH', 'Kur nustatyti FH'], 'FH', [guide.setup,
        ['Enter the required non-secret settings and use the help icons for field explanations. Save. API secrets are not retained by this form; a secure server connection must be configured separately.', 'Užpildykite reikalingus neslaptus nustatymus; laukų paaiškinimus atverkite klaustukais. Išsaugokite. Ši forma API paslapčių nesaugo; saugi serverio jungtis prijungiama atskirai.'],
        ['Select documents from one organization. Export selected documents lets you choose the destination for a download; Send to uses the organization’s primary destination. Neither selecting a format nor downloading a preview proves external import.', 'Pažymėkite vienos organizacijos dokumentus. Eksportuoti pažymėtus dokumentus leidžia pasirinkti atsisiuntimo gavėją, o Siųsti į naudoja organizacijos pagrindinį formatą. Nei formato pasirinkimas, nei peržiūros atsisiuntimas nepatvirtina išorinio importo.'],
      ])] },
    { id: item.method === 'api' ? 'api-transfer' : 'invoice-import', title: item.method === 'api' ? ['API connection and document delivery', 'API prijungimas ir dokumentų perdavimas'] : ['Invoice import: step by step', 'Sąskaitų importas žingsnis po žingsnio'], description: guide.summary, sections: [...providerSections[item.name], ...(item.family === 'jumis' ? [jumisStructure] : [])], note: capability },
    { id: 'workflow-and-checks', title: ['Result and errors', 'Rezultatas ir klaidos'], description: guide.checks,
      sections: [
        section(['Before import', 'Prieš importą'], 'FH', [guide.checks, ['Resolve missing required data and reported document issues. Compare the invoice with its original, then use the receiving system’s exact codes.', 'Užpildykite privalomus duomenis ir išspręskite dokumento klaidas. Sutikrinkite sąskaitą su originalu ir naudokite tikslius gavėjo sistemos kodus.']]),
        section(['After import', 'Po importo'], item.family.toUpperCase(), [['Open the created record and compare invoice number, partner, net amount, VAT and total. Check posting separately. If the result is uncertain, search for the document before retrying to avoid duplicates.', 'Atverkite sukurtą įrašą, palyginkite numerį, partnerį, sumą be PVM, PVM ir bendrą sumą. Registravimą tikrinkite atskirai. Jei rezultatas neaiškus, prieš kartodami ieškokite dokumento, kad nesukurtumėte dublikato.']]),
        section(['When you need help', 'Kai reikia pagalbos'], 'FH', [['For a rejected import, provide the destination, document number, time and error text. For incorrect OCR values use Report issue. Never include API keys or passwords in messages or screenshots.', 'Atmesto importo atveju pateikite gavėją, dokumento numerį, laiką ir klaidos tekstą. Klaidingoms OCR reikšmėms naudokite Pranešti apie klaidą. Žinutėse ir nuotraukose nerodykite API raktų ar slaptažodžių.']]),
      ], note: item.family === 'zalktis' ? ['The cited Zalktis documentation describes file imports, not a public invoice-upload API. No Zalktis API option is offered without a verified API specification.', 'Nurodyta Zalktis dokumentacija aprašo failų importą, ne viešą sąskaitų įkėlimo API. Be patvirtintos API specifikacijos Zalktis API pasirinkimas nepateikiamas.'] : capability },
  ];
  return [item.name, topics.map(topic => ({ ...topic,
    sections: topic.sections.map((value, index) => index ? value : { ...value, example: {
      title: ['Example', 'Pavyzdys'], paragraphs: topic.id === 'configuration'
        ? [[`For Alice Stone select ${item.name}; another organization keeps its own format. ${item.method === 'api' ? 'A saved API URL does not activate a connection.' : 'Use the official receiving template, not a renamed PDF or preview file.'}`, `Alice Stone įmonei pasirinkite ${item.name}; kitos organizacijos formatas nesikeičia. ${item.method === 'api' ? 'Išsaugotas API URL jungties neįjungia.' : 'Naudokite oficialų gavėjo šabloną, ne pervadintą PDF ar peržiūros failą.'}`]]
        : topic.id === 'workflow-and-checks'
          ? [['Invoice INV-104 totals 121.00 EUR. Before retrying a failed import, search for INV-104 and the same supplier in the receiving company. If the record exists, compare it instead of importing it a second time.', 'Sąskaitos INV-104 suma – 121,00 EUR. Prieš kartodami nesėkmingą importą gavėjo įmonėje ieškokite INV-104 ir to paties tiekėjo. Jei įrašas yra, jį sutikrinkite, neimportuokite antrą kartą.']]
          : [[`Example invoice INV-104: net 100.00 EUR, VAT 21.00 EUR, total 121.00 EUR. Map its real supplier and GL codes to the ${item.format} specification; after import, all three amounts must agree with the original invoice.`, `Pavyzdinė sąskaita INV-104: be PVM 100,00 EUR, PVM 21,00 EUR, iš viso 121,00 EUR. Tikrus tiekėjo ir DK kodus susiekite pagal ${item.format} specifikaciją; po importo visos trys sumos turi sutapti su originalu.`]],
    } }),
    related: topics.filter(other => other.id !== topic.id).map(other => ({ topic: other.id, label: other.title })) }))];
}));
export const latvianIntegrationLinks = (format: string) => {
  const item = LATVIAN_ACCOUNTING_SYSTEMS.find(value => value.name === format);
  return item ? LATVIAN_INTEGRATION_SOURCES[item.family] : [];
};
