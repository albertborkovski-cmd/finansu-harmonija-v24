import { getLanguage, translateUi, type Language } from './language';
import { newStatementStore, type StatementArticle } from '../lib/financialStatementArticles';

/** Presentation only. Stored report keys, mappings and custom names never change language. */
const labels: Readonly<Record<string, string>> = {
  'Financial statement items': 'Finansinės atskaitomybės straipsniai',
  'Financial statement item': 'Finansinės atskaitomybės straipsnis',
  'How financial statement items work': 'Kaip veikia finansinės atskaitomybės straipsniai',
  'New item': 'Naujas straipsnis',
  'linked accounts': 'priskirtos sąskaitos',
  'unassigned': 'nepriskirtos sąskaitos',
  'No company chart assigned': 'Įmonei nepriskirtas sąskaitų planas',
  'Financial report': 'Finansinė ataskaita',
  'Balance sheet': 'Balansas',
  'Profit and loss': 'Pelno (nuostolių) ataskaita',
  'Suggest mappings': 'Siūlyti priskyrimus',
  'Mapping history': 'Priskyrimų istorija',
  'Export mappings': 'Eksportuoti priskyrimus',
  'Financial statement item tree': 'Finansinės atskaitomybės straipsnių medis',
  'Statement items': 'Ataskaitos straipsniai',
  'Search statement items': 'Ieškoti ataskaitos straipsnių',
  'Select item {code} {name}': 'Pasirinkti straipsnį {code} {name}',
  'No matching items.': 'Atitinkančių straipsnių nėra.',
  'No matching records.': 'Atitinkančių įrašų nėra.',
  'GL account mappings': 'DK sąskaitų priskyrimai',
  'Selected item': 'Pasirinktas straipsnis',
  'Select an item from the tree': 'Pasirinkite straipsnį iš medžio',
  'Mapping operation': 'Priskyrimo operacija',
  'Edit selected statement item': 'Redaguoti pasirinktą ataskaitos straipsnį',
  'Edit item': 'Redaguoti straipsnį',
  'Mapping views': 'Priskyrimų rodiniai',
  'Unassigned accounts': 'Nepriskirtos sąskaitos',
  'All mappings': 'Visi priskyrimai',
  'Search GL account mappings': 'Ieškoti DK sąskaitų priskyrimų',
  'Link selected': 'Priskirti pažymėtas',
  'Unlink selected': 'Panaikinti pažymėtus priskyrimus',
  'selected · selection is retained when filters change': 'pažymėta · pakeitus filtrus pasirinkimas išlieka',
  'Financial statement GL accounts': 'Finansinių ataskaitų DK sąskaitos',
  'Financial statement account mappings': 'Finansinių ataskaitų sąskaitų priskyrimai',
  'Select all filtered accounts': 'Pažymėti visas atfiltruotas sąskaitas',
  'Select GL account {code}': 'Pažymėti DK sąskaitą {code}',
  'Link to selected item': 'Priskirti pasirinktam straipsniui',
  'Link {code} to selected item': 'Priskirti {code} pasirinktam straipsniui',
  'Edit mapping': 'Redaguoti priskyrimą',
  'Edit mapping {code}': 'Redaguoti sąskaitos {code} priskyrimą',
  'Unlink account': 'Panaikinti sąskaitos priskyrimą',
  'Unlink {code}': 'Panaikinti sąskaitos {code} priskyrimą',
  'Assign a chart in Manage company → Accounting setup first.': 'Pirmiausia priskirkite sąskaitų planą: Įmonės valdymas → Apskaitos nustatymai.',
  'No accounts linked to this item. Select accounts in Unassigned accounts.': 'Šiam straipsniui nepriskirta sąskaitų. Pasirinkite jas skiltyje „Nepriskirtos sąskaitos“.',
  'All available GL accounts are mapped in this report.': 'Visos galimos DK sąskaitos jau priskirtos šioje ataskaitoje.',
  'Account name': 'Sąskaitos pavadinimas',
  'Operation': 'Operacija',
  'Item code': 'Straipsnio kodas',
  'Group': 'Grupė',
  'Report': 'Ataskaita',
  'Unassigned': 'Nepriskirta',
  'Linked': 'Priskirta',
  'Account unavailable': 'Sąskaita nepasiekiama',
  'Item inactive': 'Straipsnis neaktyvus',
  'Edit financial statement item': 'Redaguoti finansinės atskaitomybės straipsnį',
  'New financial statement item': 'Naujas finansinės atskaitomybės straipsnis',
  'Delete {code}': 'Ištrinti {code}',
  'Financial statement item saved.': 'Finansinės atskaitomybės straipsnis išsaugotas.',
  'Item report': 'Straipsnio ataskaita',
  'Item name': 'Straipsnio pavadinimas',
  'Item group': 'Straipsnio grupė',
  'Default operation': 'Numatytoji operacija',
  'Item default operation': 'Straipsnio numatytoji operacija',
  'Item status': 'Straipsnio būsena',
  'Edit account mapping': 'Redaguoti sąskaitos priskyrimą',
  'Mapping updated.': 'Priskyrimas atnaujintas.',
  'Mapping item': 'Priskyrimo straipsnis',
  'Edit mapping operation': 'Keisti priskyrimo operaciją',
  'Unlink GL accounts': 'Panaikinti DK sąskaitų priskyrimus',
  'Remove financial statement item': 'Pašalinti finansinės atskaitomybės straipsnį',
  'Mappings removed. GL accounts and postings are unchanged.': 'Priskyrimai panaikinti. DK sąskaitos ir įrašai nepakeisti.',
  'Item updated. Used items are retained as inactive.': 'Straipsnis atnaujintas. Naudoti straipsniai išsaugomi kaip neaktyvūs.',
  '{count} mapping(s) will be removed. The accounts return to Unassigned accounts. GL entries are not changed and history is retained.': 'Bus panaikinta priskyrimų: {count}. Sąskaitos grįš į „Nepriskirtos sąskaitos“. DK įrašai nebus keičiami, istorija bus išsaugota.',
  'Used or linked items are deactivated and kept with their history. Only unused items can be deleted.': 'Naudoti arba susieti straipsniai išjungiami ir išsaugomi su istorija. Ištrinti galima tik nenaudotus straipsnius.',
  'Review suggested mappings': 'Peržiūrėti siūlomus priskyrimus',
  '{count} suggestions · {report}': 'Pasiūlymų: {count} · {report}',
  '{count} suggested mappings saved.': 'Išsaugota siūlomų priskyrimų: {count}.',
  '{count} GL accounts linked to {code}.': 'Straipsniui {code} priskirta DK sąskaitų: {count}.',
  'Apply selected ({count})': 'Pritaikyti pažymėtus ({count})',
  'Suggestions use account names. Review the item and Debit / Credit operation before applying. Existing mappings are never overwritten.': 'Pasiūlymai parengiami pagal sąskaitų pavadinimus. Prieš pritaikydami patikrinkite straipsnį ir debeto / kredito operaciją. Esami priskyrimai neperrašomi.',
  'Select all suggestions': 'Pažymėti visus pasiūlymus',
  'Suggested item': 'Siūlomas straipsnis',
  'Select suggestion {code}': 'Pažymėti pasiūlymą sąskaitai {code}',
  'Account name matches {name}. Review before applying.': 'Sąskaitos pavadinimas atitinka straipsnį „{name}“. Prieš pritaikydami patikrinkite.',
  'No unambiguous suggestions. Assign accounts manually from the Unassigned accounts list.': 'Vienareikšmių pasiūlymų nėra. Priskirkite sąskaitas rankiniu būdu iš „Nepriskirtos sąskaitos“ sąrašo.',
  'Item': 'Straipsnis',
  'Change': 'Pakeitimas',
  'Item updated': 'Straipsnis atnaujintas',
  'Item created': 'Straipsnis sukurtas',
  'Item deactivated': 'Straipsnis išjungtas',
  'Unused item deleted': 'Nenaudotas straipsnis ištrintas',
  'Account linked': 'Sąskaita priskirta',
  'Mapping changed': 'Priskyrimas pakeistas',
  'Account unlinked': 'Sąskaitos priskyrimas panaikintas',
  'Select a report and an item in the left-hand tree.': 'Pasirinkite ataskaitą ir straipsnį kairėje esančiame medyje.',
  'Select one or more company GL accounts and click Link selected. Only leaf accounts are offered, avoiding duplicate parent totals.': 'Pažymėkite vieną ar kelias įmonės DK sąskaitas ir spauskite „Priskirti pažymėtas“. Siūlomos tik sąskaitos be žemesnio lygio sąskaitų, kad sumos nebūtų dubliuojamos.',
  'Debit means debit minus credit; Credit means credit minus debit. Set the operation for each mapping.': '„Debetas“ reiškia debetas minus kreditas, o „Kreditas“ – kreditas minus debetas. Kiekvienam priskyrimui pasirinkite operaciją.',
  'Use Selected item or All mappings to change or unlink assignments. Each account may appear only once per report.': 'Priskyrimus keiskite arba panaikinkite skiltyse „Pasirinktas straipsnis“ ir „Visi priskyrimai“. Vienoje ataskaitoje kiekviena sąskaita gali būti priskirta tik vieną kartą.',
  'Suggest mappings prepares name-based proposals for review. Nothing is saved until you apply them.': '„Siūlyti priskyrimus“ parengia pasiūlymus pagal pavadinimus. Jie išsaugomi tik jums juos peržiūrėjus ir pritaikius.',
  'The starter items are editable reporting headings, not a statutory filing template. Links are saved only for this company and its assigned chart. This screen manages classification; it does not post entries or submit financial statements.': 'Pradiniai straipsniai yra redaguojami ataskaitų pavadinimai, o ne oficialus ataskaitų teikimo šablonas. Priskyrimai išsaugomi tik šiai įmonei ir jos sąskaitų planui. Čia tvarkomas grupavimas – DK įrašai nekuriami ir finansinės ataskaitos neteikiamos.',
  'Reporting mappings could not be loaded.': 'Nepavyko įkelti ataskaitų priskyrimų.',
  'Changes could not be saved.': 'Nepavyko išsaugoti pakeitimų.',
  'Reporting mappings could not be read. Existing data has not been overwritten.': 'Nepavyko perskaityti ataskaitų priskyrimų. Esami duomenys neperrašyti.',
  'Invalid or duplicate reporting mappings.': 'Ataskaitų priskyrimai netinkami arba dubliuojasi.',
  'A GL account is assigned more than once within the same report.': 'Toje pačioje ataskaitoje DK sąskaita priskirta daugiau nei vieną kartą.',
  'Select an active financial statement item.': 'Pasirinkite aktyvų finansinės atskaitomybės straipsnį.',
  'GL account {code} already has a mapping in {report}. Edit its existing mapping instead.': 'DK sąskaita {code} jau priskirta ataskaitoje „{report}“. Redaguokite esamą priskyrimą.',
  'Enter a code, name, report, group and operation.': 'Įveskite kodą, pavadinimą, ataskaitą, grupę ir operaciją.',
  'This item code already exists.': 'Straipsnis su šiuo kodu jau yra.',
  'The report of a used item cannot be changed. Create a new item instead.': 'Naudoto straipsnio ataskaitos keisti negalima. Sukurkite naują straipsnį.',
  'Select at least one GL account.': 'Pasirinkite bent vieną DK sąskaitą.',
  'GL account {code} is unavailable, inactive or a parent account. Refresh the company chart.': 'DK sąskaita {code} nepasiekiama, neaktyvi arba turi žemesnio lygio sąskaitų. Atnaujinkite įmonės sąskaitų planą.',
  'Select Debit or Credit.': 'Pasirinkite debetą arba kreditą.',
  'The mapping no longer exists. Refresh the list.': 'Priskyrimo nebėra. Atnaujinkite sąrašą.',
  'Select an available GL account and valid operation.': 'Pasirinkite pasiekiamą DK sąskaitą ir tinkamą operaciją.',
  'Select at least one mapping.': 'Pasirinkite bent vieną priskyrimą.',
  'A mapping has changed. Refresh the list.': 'Priskyrimas pasikeitė. Atnaujinkite sąrašą.',
  'You do not have access to this company’s financial statement items.': 'Neturite prieigos prie šios įmonės finansinės atskaitomybės straipsnių.',
  'The assigned chart is unavailable. Check Manage company → Accounting setup.': 'Priskirtas sąskaitų planas nepasiekiamas. Patikrinkite: Įmonės valdymas → Apskaitos nustatymai.',
  'You do not have permission to edit this company’s financial statement items.': 'Neturite teisės redaguoti šios įmonės finansinės atskaitomybės straipsnių.',
  'Company settings could not be verified.': 'Nepavyko patikrinti įmonės nustatymų.',
  'Company access is no longer available.': 'Prieiga prie įmonės nebepasiekiama.',
  'The company chart has changed. Reopen this page before editing mappings.': 'Įmonės sąskaitų planas pasikeitė. Prieš keisdami priskyrimus iš naujo atidarykite šį puslapį.',
  'Mappings changed in another window. Refresh and try again.': 'Priskyrimai pakeisti kitame lange. Atnaujinkite ir bandykite dar kartą.',
  'Non-current assets · Intangible assets': 'Ilgalaikis turtas · Nematerialusis turtas',
  'Non-current assets · Tangible assets': 'Ilgalaikis turtas · Materialusis turtas',
  'Non-current assets · Other': 'Ilgalaikis turtas · Kitas turtas',
  'Current assets': 'Trumpalaikis turtas',
  'Equity': 'Nuosavas kapitalas',
  'Grants and provisions': 'Dotacijos ir atidėjiniai',
  'Liabilities': 'Įsipareigojimai',
  'Operating result': 'Veiklos rezultatas',
  'Financial result and tax': 'Finansinės veiklos rezultatas ir mokesčiai',
  'Development costs': 'Plėtros darbai',
  'Goodwill': 'Prestižas',
  'Software': 'Programinė įranga',
  'Licences, patents and similar rights': 'Licencijos, patentai ir panašios teisės',
  'Other intangible assets': 'Kitas nematerialusis turtas',
  'Advances for intangible assets': 'Avansai už nematerialųjį turtą',
  'Land': 'Žemė',
  'Buildings and structures': 'Pastatai ir statiniai',
  'Machinery and equipment': 'Mašinos ir įranga',
  'Vehicles': 'Transporto priemonės',
  'Other tangible assets': 'Kitas materialusis turtas',
  'Construction in progress': 'Nebaigta statyba',
  'Financial assets': 'Finansinis turtas',
  'Other non-current assets': 'Kitas ilgalaikis turtas',
  'Inventories': 'Atsargos',
  'Advances paid': 'Sumokėti avansai',
  'Trade receivables': 'Pirkėjų skolos',
  'Other receivables': 'Kitos gautinos sumos',
  'Short-term investments': 'Trumpalaikės investicijos',
  'Cash and cash equivalents': 'Pinigai ir pinigų ekvivalentai',
  'Prepayments and accrued income': 'Ateinančių laikotarpių sąnaudos ir sukauptos pajamos',
  'Share capital': 'Įstatinis kapitalas',
  'Share premium': 'Akcijų priedai',
  'Revaluation reserve': 'Perkainojimo rezervas',
  'Reserves': 'Rezervai',
  'Retained earnings': 'Nepaskirstytasis pelnas (nuostoliai)',
  'Grants and subsidies': 'Dotacijos ir subsidijos',
  'Provisions': 'Atidėjiniai',
  'Non-current liabilities': 'Ilgalaikiai įsipareigojimai',
  'Trade payables': 'Skolos tiekėjams',
  'Advances received': 'Gauti avansai',
  'Tax liabilities': 'Mokėtini mokesčiai',
  'Payroll liabilities': 'Su darbo santykiais susiję įsipareigojimai',
  'Other current liabilities': 'Kiti trumpalaikiai įsipareigojimai',
  'Accrued expenses and deferred income': 'Sukauptos sąnaudos ir ateinančių laikotarpių pajamos',
  'Sales revenue': 'Pardavimo pajamos',
  'Other operating income': 'Kitos veiklos pajamos',
  'Cost of sales': 'Pardavimo savikaina',
  'Selling and administrative expenses': 'Pardavimo ir administracinės sąnaudos',
  'Other operating expenses': 'Kitos veiklos sąnaudos',
  'Financial income': 'Finansinės veiklos pajamos',
  'Financial expenses': 'Finansinės veiklos sąnaudos',
  'Income tax expense': 'Pelno mokesčio sąnaudos',
};

export function statementText(text: string, language: Language = getLanguage()): string {
  if (language === 'en') return text;
  const key = text.trim();
  const suffix = key.match(/^(.*?)(\s*[:*])$/);
  const translated = labels[key] ?? (suffix && labels[suffix[1]] ? labels[suffix[1]] + suffix[2] : undefined);
  return translated ? text.replace(key, translated) : translateUi(text, language);
}

export function statementMessage(template: string, values: Readonly<Record<string, string | number>>, language: Language = getLanguage()): string {
  return statementText(template, language).replace(/\{(\w+)\}/g, (placeholder, key: string) => Object.hasOwn(values, key) ? String(values[key]) : placeholder);
}

const starters = new Map(newStatementStore('', '').articles.map(article => [article.id, article]));
export function statementArticleText(article: StatementArticle, field: 'name' | 'group', language: Language = getLanguage()): string {
  return starters.get(article.id)?.[field] === article[field] ? statementText(article[field], language) : article[field];
}

export function statementErrorText(text: string, language: Language = getLanguage()): string {
  const duplicate = text.match(/^GL account (.+) already has a mapping in (Balance sheet|Profit and loss)\. Edit its existing mapping instead\.$/);
  if (duplicate) return statementMessage('GL account {code} already has a mapping in {report}. Edit its existing mapping instead.', { code: duplicate[1], report: statementText(duplicate[2], language) }, language);
  const unavailable = text.match(/^GL account (.+) is unavailable, inactive or a parent account\. Refresh the company chart\.$/);
  if (unavailable) return statementMessage('GL account {code} is unavailable, inactive or a parent account. Refresh the company chart.', { code: unavailable[1] }, language);
  return statementText(text, language);
}

export function statementAuditValueText(value?: string, language: Language = getLanguage()): string {
  if (!value) return '—';
  try {
    const article = JSON.parse(value) as StatementArticle;
    if (article && typeof article.id === 'string' && typeof article.name === 'string' && typeof article.group === 'string' && typeof article.report === 'string' && typeof article.operation === 'string') {
      return [article.code, statementArticleText(article, 'name', language), statementArticleText(article, 'group', language), statementText(article.report, language), statementText(article.operation, language), statementText(article.inactive ? 'Inactive' : 'Active', language)].join(' · ');
    }
  } catch { /* Older audit rows use plain operation values. */ }
  const operation = value.match(/^(.* \/ )(Debit|Credit)$/);
  return operation ? operation[1] + statementText(operation[2], language) : statementText(value, language);
}
