import { useSyncExternalStore } from 'react';
import { lithuanian } from './lt';
import { lithuanianInterface } from './lt-interface';
import { lithuanianCompany } from './lt-company';
import { lithuanianAssets } from './lt-assets';
import { lithuanianDocumentSettings } from './lt-document-settings';

export type Language = 'en' | 'lt';
export const LANGUAGE_STORAGE_KEY = 'finansu-harmonija:language';
const listeners = new Set<() => void>();
const catalogue: Readonly<Record<string, string>> = { ...lithuanian, ...lithuanianInterface, ...lithuanianCompany, ...lithuanianAssets, ...lithuanianDocumentSettings };
const caseInsensitiveCatalogue = new Map(Object.entries(catalogue).map(([key, value]) => [key.toLocaleLowerCase('en'), value]));
const validLanguage = (value: unknown): Language => value === 'lt' ? 'lt' : 'en';
function readLanguage(): Language {
  try { return validLanguage(window.localStorage.getItem(LANGUAGE_STORAGE_KEY)); } catch { return 'en'; }
}
let language: Language = typeof window === 'undefined' ? 'en' : readLanguage();
function notifyLanguage(next: Language) {
  if (typeof document !== 'undefined') document.documentElement.lang = next;
  if (next === language) return;
  language = next;
  listeners.forEach(listener => listener());
}
if (typeof window !== 'undefined') {
  document.documentElement.lang = language;
  window.addEventListener('storage', event => {
    if (event.key === LANGUAGE_STORAGE_KEY || event.key === null) notifyLanguage(readLanguage());
  });
}
export function setLanguage(next: Language) {
  if (next !== 'en' && next !== 'lt') return;
  try { window.localStorage.setItem(LANGUAGE_STORAGE_KEY, next); } catch { /* The current tab still switches. */ }
  notifyLanguage(next);
}
export const getLanguage = () => language;
const subscribeLanguage = (callback: () => void) => {
  listeners.add(callback);
  return () => { listeners.delete(callback); };
};
const getServerLanguage = () => 'en' as Language;
export function useLanguage() {
  return useSyncExternalStore(subscribeLanguage, getLanguage, getServerLanguage);
}

/** Presentation only: never use translated labels as record values, IDs or permission keys. */
export function translateUi<T>(text: T, selectedLanguage: Language = language): T {
  if (typeof text !== 'string' || selectedLanguage === 'en') return text;
  const key = text.trim();
  const translated = catalogue[key];
  if (translated) return text.replace(key, translated) as T;
  // Punctuation / required markers and numbered section headings share the same catalogue entry.
  const numbered = key.match(/^(\d+\.\s+)(.+)$/);
  if (numbered && catalogue[numbered[2]]) return text.replace(key, numbered[1] + catalogue[numbered[2]]) as T;
  const suffixed = key.match(/^(.+?)(\s*[:*])$/);
  if (suffixed && catalogue[suffixed[1]]) return text.replace(key, catalogue[suffixed[1]] + suffixed[2]) as T;
  const plain = key.replace(/^(?:\+|·|→)\s*/, '');
  if (plain !== key && catalogue[plain]) return text.replace(plain, catalogue[plain]) as T;
  const insensitive = caseInsensitiveCatalogue.get(key.toLocaleLowerCase('en'));
  if (insensitive) return text.replace(key, insensitive) as T;
  return text;
}

/** Translate the UI template first, preserving document names, numbers and other inserted data. */
export function translateMessage(template: string, values: Readonly<Record<string, string | number>>, selectedLanguage: Language = language): string {
  return translateUi(template, selectedLanguage).replace(/\{(\w+)\}/g, (placeholder, key: string) =>
    Object.hasOwn(values, key) ? String(values[key]) : placeholder);
}

const lithuanianStatuses: Readonly<Record<string, string>> = {
  'Open': 'Atvira', 'Closed': 'Uždaryta', 'New': 'Nauja', 'Draft': 'Juodraštis',
  'Pending': 'Laukiama', 'Approved': 'Patvirtinta', 'Accepted': 'Priimta', 'Rejected': 'Atmesta',
  'Invalid': 'Neteisinga', 'Corrected': 'Pataisyta', 'Correcting': 'Taisoma',
  'Active': 'Aktyvi', 'Inactive': 'Neaktyvi', 'Unactivated': 'Neaktyvuota', 'Blocked': 'Užblokuota',
  'Processing': 'Apdorojama', 'Processed': 'Apdorota', 'In progress': 'Vykdoma', 'In Progress': 'Vykdoma',
  'Completed': 'Užbaigta', 'Transferred': 'Perduota', 'Exported': 'Eksportuota', 'Uploaded': 'Įkelta',
  'Provide Additional': 'Reikia papildomų duomenų', 'Provide additional data': 'Reikia papildomų duomenų',
  'Exception': 'Išimtis', 'Duplicate': 'Dublikatas', 'Not Documented': 'Ne dokumentas', 'Not document': 'Ne dokumentas',
  'Needs attention': 'Reikia dėmesio', 'Need review': 'Reikia peržiūros', 'Needs review': 'Reikia peržiūros',
  'Resolved': 'Išspręsta', 'Fixed': 'Ištaisyta', 'Awaiting OCR': 'Laukiama OCR',
  'Paid': 'Apmokėta', 'Unpaid': 'Neapmokėta', 'Overdue': 'Pradelsta', 'Reversed': 'Stornuota',
  'Unmatched': 'Nesudengta', 'Partially matched': 'Iš dalies sudengta', 'Matched': 'Sudengta',
  'Cancelled': 'Atšaukta', 'Failed': 'Nepavyko', 'Running': 'Vykdoma', 'Stopped': 'Sustabdyta',
  'Posted': 'Užregistruota', 'Pending approval': 'Laukiama patvirtinimo', 'Not started': 'Nepradėta',
  'Submitted': 'Pateikta', 'Queued': 'Eilėje', 'Archived': 'Archyvuota', 'Enabled': 'Įjungta', 'Disabled': 'Išjungta',
  'Valid': 'Tinkama', 'Invalid data': 'Neteisingi duomenys', 'In review': 'Peržiūrima',
  'Connected': 'Prijungta', 'Not connected': 'Neprijungta', 'Connection error': 'Prijungimo klaida',
  'Reconciled': 'Sudengta', 'Not reconciled': 'Nesudengta', 'Partially reconciled': 'Iš dalies sudengta',
  'Suggested': 'Pasiūlyta', 'Applied': 'Pritaikyta',
};
export function translateStatus<T>(value: T, selectedLanguage: Language = language): T {
  if (typeof value !== 'string' || selectedLanguage === 'en') return value;
  return (lithuanianStatuses[value] ?? translateUi(value, selectedLanguage)) as T;
}

/** Grid/filter metadata uses stable field keys; free-text record values stay untouched. */
export function translateFieldValue<T>(field: string, value: T): T {
  if (/status/i.test(field)) return translateStatus(value);
  if (['documentPurpose', 'document_purpose', 'purpose', 'direction', 'reconciliation', 'agingGroup'].includes(field)) return translateUi(value);
  return value;
}
