import { getLanguage, translateStatus, translateUi } from './language';

const units: Readonly<Record<string, string>> = { pcs: 'vnt.', kg: 'kg', l: 'l', m: 'm', hour: 'val.', month: 'mėn.', pack: 'pak.' };

/** Localize system choices, never item names, codes, warehouses or other record text. */
export function warehouseValueText(field: string, value: string): string {
  if (field === 'status') return translateStatus(value);
  if (field === 'unit') return getLanguage() === 'lt' ? units[value] ?? value : value;
  if (['type', 'kind', 'frequency', 'method'].includes(field)) return translateUi(value);
  return value;
}
