# Authorized V24 export-settings update

The same request now includes contextual question-mark help throughout Organization settings, a bottom main-menu Help entry, original FH screenshots, external import tutorial videos and a practical Site.pro item-date-conflict article. V24.0.3 publishes this scoped help update; identical application changes are maintained in V25. Keep every existing release tag, production credentials and the frozen original source unchanged.

On 2026-11-19 the user additionally requested reproducing each export format's settings inspected in Safari in both V24 and V25. This isolated V24 release checkout is authorized for that update and publication to the existing V24 testing site. Preserve v24 and v24.0.1 tags and the original frozen workspace. Do not copy production values or credentials. The same implementation belongs in local V25; never publish V25 source over V24 artifacts.

## V24.0.1 authorized hotfix

The same request also removes Chart of accounts only from the global Documents organization-settings gear menu, preserving the company GL journal menu and additional expense codes.

On 2026-11-19 the user explicitly requested an Organization not found quick filter in All Documents / Uploaded documents, Digitizing and Rejected selected by default, and publication to V24 GitHub Pages. The same changes are authorized in local V25. This isolated release checkout contains only those hotfixes. Keep the original v24 tag and frozen source workspace unchanged. Do not include newer V25 work or publish to any other release.

# Frozen V24 release

The user explicitly approved public V24 publication and an independent V25 development split on 2026-11-18.
V24 is frozen at source tag `v24` for GitHub testing. Do not edit its application code or move that tag after publication.
Testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v24/.
The artifact repository contains the compiled site, exact `source-v24.zip`, source manifest and release checks. Never push source Git history over artifact history.
All further development belongs only in `/Users/albert/Desktop/Logibyte/MESO/Finansu Harmonija Frontend/V25` (http://127.0.0.1:5206/).
V25 has an independent Git repository; never add V24 or earlier repositories as its remotes.
Local `.env`, `.meso-shared-data.json`, dependencies and build output remain untracked and unpublished.
This freeze and V25-only rule overrides all historical active-version notes below.

## Historical V24 workspace

V24 was created on 2026-11-18 from frozen V23 source commit `c057a07fa44f753fc9ba5483d2d5e61f59c18e0a` (tag `v23.1.0`) at the user's explicit request.
The active application workspace is `/Users/albert/Desktop/Logibyte/MESO/Finansu Harmonija Frontend/V24`, running at http://127.0.0.1:5205/.
Continue all application improvements in V24 only. It has an independent Git repository with no remotes. No V24 publication has been requested.
V23 and all earlier versions are frozen. Do not edit them, add their remotes to V24, or publish V24 changes to them.
V23 testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v23/. The original `v23` tags and the update `v23.1.0` tags must remain unchanged.
Keep source and compiled-artifact histories separate. Local `.env`, `.meso-shared-data.json`, dependencies and build output must remain untracked and unpublished.
This active V24 rule overrides all historical active-version notes below.

## Frozen V23 release

The user explicitly requested the V23 GitHub update and independent V24 development split on 2026-11-18.
V23 is frozen at source tag `v23.1.0` after that publication. Do not modify its application code or republish without a new explicit request.
All further application development belongs only in `/Users/albert/Desktop/Logibyte/MESO/Finansu Harmonija Frontend/V24` (http://127.0.0.1:5205/).
V23 testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v23/.
The original source and artifact `v23` tags must remain unchanged. Source and compiled-artifact histories are separate; never push source history to the artifact repository.
This freeze and V24-only rule overrides all historical active-workspace notes below.

## Historical V23 workspace

V23 was created on 2026-11-13 from frozen V22 source commit c3c37941a0d0861c66c6cad91acd5b6646b6480e (tag v22).
The active application workspace is `/Users/albert/Desktop/Logibyte/MESO/Finansu Harmonija Frontend/V23` and runs at http://127.0.0.1:5204/.
Continue all application improvements in V23 only. V23 has its own Git repository and no remote repositories.
V22, V21 and all earlier releases are frozen. Never add their remote repositories to V23 or publish V23 changes to them.
V22 testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v22/.
V22 source archive SHA-256: f7b34f11415f4b9a73136dfe7d09e84f9a82cd0910fd589b65b8d4d55b179c51 (503 files).
The V22 source and GitHub artifact histories are separate; never overwrite the artifact repository with source history.
The older version notes below are historical; this V23-only rule takes precedence.

## Frozen V22 release

V22 is frozen for GitHub testing as of 2026-11-13 (source tag `v22`). Do not edit its application code after this release.
All further development belongs only in `/Users/albert/Desktop/Logibyte/MESO/Finansu Harmonija Frontend/V23` (http://127.0.0.1:5204/).
V22 testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v22/.
The V22 GitHub repository contains prebuilt artifacts and an exact `source-v22.zip`, not the local source Git history. Never push local source history over the artifact repository.
The older active-workspace notes below are historical and do not override the V23-only development rule.

V22 was created on 2026-11-12 from frozen V21 source commit ff262afb73511fb335b3d8915d6d8894de764919 (tag v21).
The user-authorized V21.0.1 hotfix (2026-11-12; source 86b744c149481b34d40a5d7149aff308cf88bf19) only removes the Demo label beside Bank accounts Connection status. The same change is included here. This exception does not authorize further V21 changes.
The user-authorized V21.0.2 hotfix (2026-11-12; source 22a7da16289b6b038b1fc8733431f16c83a75d11; artifact 038012854c8f4c37e8a29f86630996f98bc1404e) removes Companies Bulk actions and its unused local dialog. The same UI and regression test are included here. All further development remains V22-only.
V22 update (2026-11-13): the user explicitly requested restoring Companies Bulk actions. Keep Assign accountant, Replace accountant and Set substitution for selected companies in V22; the frozen V21 release is unchanged.
V21, V20 and earlier versions are frozen. Do not edit their application code or publish further development to their repositories.
V22 is the only active development version: `/Users/albert/Desktop/Logibyte/MESO/Finansu Harmonija Frontend/V22`.
V21 testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v21/.
V21 local URL: http://127.0.0.1:5202/. V22 local URL: http://127.0.0.1:5203/.
Never add V21 or earlier repositories as V22 remotes. V21 source and GitHub prebuilt artifact histories are separate.
The historical version notes below describe earlier releases; they do not change the active V22 rule above.
V19 is frozen at commit 3ad31c4b14409d9f99d0ecc9192a735af7abf4bb (tag v19). Never edit its application code.
The previous V20 workspace was `/Users/albert/Desktop/Logibyte/MESO/Finansu Harmonija Frontend/V20`.
Read this AGENTS.md before editing. V20 must not have V19 or older repositories as remotes.
V19 testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v19/.
V20 local URL: http://127.0.0.1:5201/.
V18 is frozen at hotfix commit 4cd893b (tag v18.0.1); original release 94d7068 (tag v18).
Never add frozen repositories as V20 remotes or publish V20 changes to them.
V19 local URL: http://127.0.0.1:5200/.
V18 testing URL: https://albertborkovski-cmd.github.io/finansu-harmonija-v18/.
Dropdown contract: selection must not change trigger height or shift surrounding content. Keep selected labels on one truncated line; menus overlay content. Close on outside pointer and Escape using useDropdownDismiss (or equivalent existing behavior), keeping multi-select menus open when toggling options inside.
Dropdown selection style: every value option reserves an 18px left checkbox with 6px corners; selected fill/border #007EA7, white check (12px, stroke 2.5), selected row #E5EDF9. Keep single-select fields single-select. Reuse SearchableSelect / MultiSelectField / GeneralLedgerAccountSelect / SystemAddFilters; use capture-phase useDropdownDismiss with an additional menu ref for portals. A full-width option row must use role=option or aria-pressed + data-static-selection, never role=checkbox (reserved for the small checkbox control).
V18 local URL: http://127.0.0.1:5199/.
V17 is frozen at commit 33258134b61c6b780851c080f12724774a1935b7 (tag v17).
Never modify V17 or earlier repositories or add them as V18 remotes.
V17 testing: https://albertborkovski-cmd.github.io/finansu-harmonija-v17/.
Table scrolling rule: data rows scroll inside a bounded viewport and column headers stay visible. Use the shared HorizontalTableScrollbar / useFrozenTableHeaders contract for system tables.
Table workspace expansion: HorizontalTableScrollbar supplies the shared Expand workspace / Exit full screen control through TableWorkspaceExpand. Keep list state mounted so filters and selected IDs survive expansion. Reconciliation owns its dedicated workspace; do not add a second expand control there. Retain sticky headers, toolbar actions and scrolling while expanded.
Fullscreen lists share useWorkspaceExpansion and WorkspaceExpandButton, including Reconciliation. Use 16px edge padding and 12px layout gaps, a compact page heading with retained actions, and hide breadcrumbs/overview cards only for that list (mark custom breadcrumbs with data-system-breadcrumb and summary cards with data-table-workspace-overview). Keep dialogs above the workspace and preserve their normal layouts. Escape dismisses open popups before leaving fullscreen; expanded record groups must not block it.
Table row actions: always the final non-resizable column after every visible data column. With spare width, align actions to the table viewport's right edge using the shared system-table-row-actions class; when columns overflow, actions follow the final column and scroll with the table (never sticky/fixed over data). Headers and rows must share the same layout. Grid tables use a flexible final action track with a fixed minimum width.
Table selection rule: select-all affects every eligible filtered record, not only loaded rows. Store explicit stable record IDs. Search, filtering and clearing filters must preserve selection. Deselect-all removes only filtered IDs; use src/lib/tableSelection.ts for this behavior.
V17 runs at http://127.0.0.1:5198/.
V17 was created from frozen V16 commit 1aef121a0c750afc28cf87735c808dafcbb64d21 (tag v16).
V16 and earlier versions are frozen. Never modify them or add their repositories as V17 remotes.
V16 testing: https://albertborkovski-cmd.github.io/finansu-harmonija-v16/.
V16 runs at http://127.0.0.1:5197/.
V16 was created from frozen V15 commit 0f2280d63a4c95c40e319905d4128ec5605dd903 (tag v15).
V15 is frozen. Do not make application changes in V15 or earlier versions.
V15 testing: https://albertborkovski-cmd.github.io/finansu-harmonija-v15/.
V14 is frozen at bb4385c, tag v14: https://albertborkovski-cmd.github.io/finansu-harmonija-v14/.
V13 is frozen at commit fa07b75, tag v13, and published at https://albertborkovski-cmd.github.io/finansu-harmonija-v13/.
Do not add V15 or earlier GitHub repositories as V16 remotes. Never push V16 changes to frozen repositories.
Local .env, .meso-shared-data.json, node_modules, and build output remain untracked.
Persisted-record lifecycle: never physically delete a referenced/assigned record. Use src/lib/recordLifecycle.ts and recheck at action time, including bulk actions. Linked records become inactive and retain all relationships/history; only unlinked records may be deleted. Render inactive list rows with data-record-inactive and use the shared DeleteButtons linked/inactive props (Power instead of Trash). Preserve inactive flags on edit, import, reload and default-data merging. Keep stricter protected system-role and accounting-history rules. Unsaved form rows and unlink-only actions are not record deletion.
