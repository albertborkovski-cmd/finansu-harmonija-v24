// Mechanical presentation-only migration. Business values and storage schemas remain English.
// Run with --apply after reviewing new catalogue entries; otherwise prints untranslated UI copy.
import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const root = process.cwd();
const apply = process.argv.includes('--apply');
const inventory = new Set();
const replacements = new Map();
const presentationProps = new Set(['placeholder', 'title', 'label', 'aria-label', 'ariaLabel', 'columnLabel', 'emptyMessage', 'searchPlaceholder', 'searchLabel', 'confirmLabel', 'cancelLabel']);
const dynamicLabel = expression => /^(?:label|title|heading|subtitle|emptyMessage|placeholder|ariaLabel|columnLabel)$/.test(expression)
  || /^(?:column|col|item|menu|sub|child|group|section|tab|field|option|entry|action|filter|config|category|link|button|metric|rule|stat|module)\.(?:label|title)$/.test(expression);
function cleanText(value) {
  const lines = value.replace(/\t/g, ' ').split(/\r?\n/);
  return lines.map((line, i) => {
    let text = line;
    if (i !== 0) text = text.replace(/^ +/, '');
    if (i !== lines.length - 1) text = text.replace(/ +$/, '');
    return text;
  }).filter(Boolean).join(' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;|&#39;/g, "'").replace(/&nbsp;/g, '\u00a0');
}
for (const relative of fs.readdirSync(path.join(root, 'src'), { recursive: true }).filter(file => file.endsWith('.tsx') && !file.endsWith('LanguageSwitcher.tsx'))) {
  const filename = path.join(root, 'src', relative);
  const text = fs.readFileSync(filename, 'utf8');
  if (text.includes('translateUi as uiText')) continue;
  const source = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const edits = [];
  const add = (node, replacement) => edits.push({ start: node.getStart(source), end: node.end, replacement });
  const translateExpression = node => {
    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
      if (!/[a-zA-Z]{2}/.test(node.text)) return;
      inventory.add(node.text.trim()); add(node, `uiText(${node.getText(source)})`);
    } else if (ts.isConditionalExpression(node)) { translateExpression(node.whenTrue); translateExpression(node.whenFalse); }
    else if (ts.isBinaryExpression(node) && [ts.SyntaxKind.BarBarToken, ts.SyntaxKind.QuestionQuestionToken].includes(node.operatorToken.kind)) translateExpression(node.right);
  };
  function visit(node) {
    if (ts.isJsxText(node)) {
      const value = cleanText(node.text);
      if (/[a-zA-Z]{2}/.test(value)) { inventory.add(value.trim()); edits.push({ start: node.pos, end: node.end, replacement: `{uiText(${JSON.stringify(value)})}` }); }
      return;
    }
    if (ts.isJsxAttribute(node) && presentationProps.has(node.name.getText(source)) && node.initializer) {
      if (ts.isStringLiteral(node.initializer)) {
        inventory.add(node.initializer.text.trim()); add(node.initializer, `{uiText(${JSON.stringify(node.initializer.text)})}`); return;
      }
      if (ts.isJsxExpression(node.initializer) && node.initializer.expression) {
        const expr = node.initializer.expression;
        if (dynamicLabel(expr.getText(source))) add(expr, `uiText(${expr.getText(source)})`);
        else translateExpression(expr);
        return;
      }
    }
    if (ts.isJsxExpression(node) && node.expression && !ts.isJsxAttribute(node.parent)) {
      const expr = node.expression;
      if (dynamicLabel(expr.getText(source))) { add(expr, `uiText(${expr.getText(source)})`); return; }
      translateExpression(expr);
    }
    if (ts.isPropertyAssignment(node) && /^(label|title)$/.test(node.name.getText(source)) && ts.isStringLiteral(node.initializer)) inventory.add(node.initializer.text.trim());
    ts.forEachChild(node, visit);
  }
  visit(source);
  if (!edits.length) continue;
  const sorted = edits.sort((a,b) => b.start-a.start);
  let last = text.length, updated = text;
  for (const edit of sorted) { if (edit.end > last) throw new Error(`Overlapping UI edit: ${relative}`); updated = updated.slice(0,edit.start)+edit.replacement+updated.slice(edit.end); last=edit.start; }
  const importPath = path.relative(path.dirname(filename), path.join(root, 'src/i18n/language')).replaceAll(path.sep, '/');
  updated = `import { translateUi as uiText } from '${importPath.startsWith('.') ? importPath : './'+importPath}';\n` + updated;
  replacements.set(filename, updated);
}
if (apply) for (const [file, content] of replacements) fs.writeFileSync(file, content);
console.log(JSON.stringify({ files: replacements.size, strings: [...inventory].sort() }, null, 2));
