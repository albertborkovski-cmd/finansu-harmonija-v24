import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const statuses = {};
new Function('exports', compile('../src/lib/bankProcessingStatus.ts'))(statuses);
const company = { id: 'alice', name: 'Alice Stone' };
const original = { id: 'bank-1', company_id: company.id, status: 'Approved', bank_processing_status: 'Approved',
  bank_transaction: { paymentPurpose: 'Payment for invoice ADV-004', referenceNo: 'BANK-REF-004', counterpartyId: 'supplier-a',
    counterpartyName: 'Supplier A', amount: '894.19', currency: 'EUR', originalStatement: 'Original imported statement' },
  accounting_posting: { id: 'posted-1' }, confirmedReconciliation: { invoiceId: 'confirmed-1', amount: 100 } };

function fixture() {
  const api = {}, store = new Map(), writes = [];
  let current = structuredClone(original), allowed = true, failStorage = false;
  const parties = [{ id: 'supplier-a', name: 'Supplier A' }, { id: 'supplier-b', name: 'Supplier B' }, { id: 'inactive', name: 'Inactive', inactive: true }];
  const require = name => {
    if (name === './bankTransaction') return { bankTransactionFromDocument: row => structuredClone(row.bank_transaction) };
    if (name === './bankProcessingStatus') return statuses;
    if (name === './invoiceCreation') return { loadInvoiceCounterparties: () => structuredClone(parties) };
    if (name === './companyBankEditing') return { loadCompanyBankDocument: async (documentId, companyId) => {
      if (!allowed) throw Error('You do not have permission.');
      assert.equal(documentId, original.id); assert.equal(companyId, company.id);
      return structuredClone(current);
    } };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', compile('../src/lib/bankMatchingDemo.ts'))(api, require, { localStorage: {
    getItem: key => store.get(key) ?? null,
    setItem: (key, value) => { if (failStorage) throw Error('Storage unavailable'); writes.push(key); store.set(key, value); },
  } });
  const draft = { matchingPurpose: 'Corrected purpose for INV-2026-123', documentNo: 'INV-2026-123', counterpartyId: 'supplier-b' };
  return { ...api, store, writes, draft, current: () => structuredClone(current), change: patch => { current = { ...current, ...patch }; },
    revoke: () => { allowed = false; }, storageFailure: () => { failStorage = true; } };
}

test('matching defaults use bank facts without changing the original purpose or reference', () => {
  const f = fixture(), before = structuredClone(original);
  const draft = f.bankMatchingDefaults(original, company);
  assert.deepEqual(draft, { matchingPurpose: 'Payment for invoice ADV-004', documentNo: 'BANK-REF-004', counterpartyId: 'supplier-a' });
  draft.matchingPurpose = 'Unsaved text';
  assert.deepEqual(original, before);
  assert.equal(f.readBankMatchingDemo(company.id, original.id), null);
  assert.equal(f.writes.length, 0);
});

test('save only updates isolated demo data; approved bank data, GL and confirmed matches are unchanged', async () => {
  const f = fixture(), before = f.current();
  f.store.set('confirmed-reconciliation', JSON.stringify(before.confirmedReconciliation));
  const saved = await f.saveBankMatchingDemo(original, company, f.draft, 0);
  assert.equal(saved.revision, 1);
  assert.deepEqual(saved.input, f.draft);
  assert.deepEqual(saved.suggestion, { documentNo: 'INV-2026-123', counterpartyName: 'Supplier B', amount: '894.19', currency: 'EUR' });
  assert.deepEqual(f.current(), before);
  assert.equal(f.store.get('confirmed-reconciliation'), JSON.stringify(before.confirmedReconciliation));
  assert.deepEqual(f.writes, [f.bankMatchingDemoKey(company.id, original.id)]);
  assert.deepEqual(f.readBankMatchingDemo(company.id, original.id), saved);
  assert.equal(f.readBankMatchingDemo('other-company', original.id), null);
  assert.equal(f.readBankMatchingDemo(company.id, 'other-document'), null);
});

test('rerun refreshes the preview and detects another saved revision without applying a match', async () => {
  const f = fixture();
  const first = await f.saveBankMatchingDemo(original, company, f.draft, 0);
  const changed = { ...f.draft, matchingPurpose: 'Second purpose', documentNo: 'SECOND', counterpartyId: 'supplier-a' };
  const second = await f.saveBankMatchingDemo(original, company, changed, first.revision);
  assert.equal(second.revision, 2); assert.equal(second.suggestion.documentNo, 'SECOND');
  assert.equal(second.counterpartyName, 'Supplier A');
  await assert.rejects(f.saveBankMatchingDemo(original, company, f.draft, 1), /another window/);
  assert.equal(f.writes.length, 2);
  assert.deepEqual(f.current(), original);
});

test('save rechecks access, company, inactive/deleted state, original data and valid company counterparty', async () => {
  for (const patch of [{ company_id: 'other' }, { inactive: true }, { active: false }, { is_active: false }, { document_deletion: {} }]) {
    const f = fixture(); f.change(patch);
    await assert.rejects(f.saveBankMatchingDemo(original, company, f.draft, 0));
    assert.equal(f.writes.length, 0);
  }
  const denied = fixture(); denied.revoke();
  await assert.rejects(denied.saveBankMatchingDemo(original, company, denied.draft, 0), /permission/);
  const stale = fixture(); stale.change({ bank_transaction: { ...original.bank_transaction, amount: '900.00' } });
  await assert.rejects(stale.saveBankMatchingDemo(original, company, stale.draft, 0), /entry changed/);
  for (const counterpartyId of ['foreign', 'inactive']) {
    const f = fixture();
    await assert.rejects(f.saveBankMatchingDemo(original, company, { ...f.draft, counterpartyId }, 0), /counterparty/);
    assert.equal(f.writes.length, 0);
  }
});

test('invalid input and failed storage cannot produce a successful preview', async () => {
  for (const patch of [{ matchingPurpose: null }, { matchingPurpose: 'x'.repeat(5001) }, { documentNo: 'x'.repeat(201) },
    { counterpartyId: 'x'.repeat(501) }, { amount: '0' }]) {
    const f = fixture();
    await assert.rejects(f.saveBankMatchingDemo(original, company, { ...f.draft, ...patch }, 0));
    assert.equal(f.writes.length, 0);
  }
  const f = fixture(); f.storageFailure();
  await assert.rejects(f.saveBankMatchingDemo(original, company, f.draft, 0), /Storage unavailable/);
  assert.equal(f.readBankMatchingDemo(company.id, original.id), null);
  f.store.set(f.bankMatchingDemoKey(company.id, original.id), '{');
  assert.equal(f.readBankMatchingDemo(company.id, original.id), null);
});

test('editor separates immutable bank facts from editable matching data with an explicit non-algorithm preview', () => {
  const editor = read('../src/components/BankTransactionEditor.tsx');
  const dialog = read('../src/components/BankMatchingDataDialog.tsx');
  const list = read('../src/components/CompanyBankView.tsx');
  assert.match(editor, /new Set\(\[1, 2\]\)/);
  for (const label of ['Transaction date', 'Bank account', 'Counterparty name', 'Counterparty IBAN', 'Purpose of payment',
    'Transaction amount', 'Transaction currency', 'Exchange rate date', 'Reference No.']) {
    assert.ok(editor.includes(`aria-label="${label}" readOnly`), label);
  }
  for (const label of ['Edit matching data', 'Suggested matches', 'No matching algorithm has run']) assert.ok(editor.includes(label));
  for (const label of ['Original payment purpose', 'Matching purpose', 'Document No.', 'Counterparty', 'Save &amp; rerun matching']) {
    assert.ok(dialog.includes(label.replace('&amp;', '&')), label);
  }
  assert.match(dialog, /aria-label="Original payment purpose" readOnly/);
  assert.match(dialog, /<CancelButton/);
  assert.match(dialog, /portalMenu menuClassName="!z-\[5500\]"/);
  assert.match(dialog, /event.preventDefault\(\); event.stopPropagation\(\)/);
  assert.match(dialog, /previousFocus\?\.focus\(\)/);
  assert.match(list, /role="group" aria-label=\{`Bank transaction/);
  assert.match(list, /event.target === event.currentTarget && \(event.key === 'Enter' \|\| event.key === ' '\)/);
});
