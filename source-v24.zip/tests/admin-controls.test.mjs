import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const load = (file, imports) => {
  const api = {};
  new Function('exports', 'require', ts.transpileModule(readFileSync(new URL('../src/lib/' + file, import.meta.url), 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText)(api, name => imports[name]);
  return api;
};
const mode = load('workspaceMode.ts', {});
const api = load('adminControls.ts', { './accessControl': { isSystemAdministratorRole: role => role === 'Administrator' }, './workspaceMode': mode });
const admin = { email: 'admin@example.test', roleNames: ['Administrator'] };
const user = { email: 'user@example.test', roleNames: ['Accountant'] };
const empty = () => ({ maintenance: null, revokedBefore: {}, blocks: {} });
test('legacy policies apply to every product; recovery administrators are preserved', () => {
  const policy = { ...empty(), history: [], blocks: { [user.email]: { until: 500, reason: 'Maintenance' } } };
  for (const scope of ['ocr', 'fh', 'combined']) {
    assert.match(api.loginRestriction(policy, user, 100, scope), /Maintenance/);
    assert.equal(api.loginRestriction(policy, admin, 100, scope), null);
  }
  assert.equal(api.isControlAdmin({ ...admin, roleNames: ['Administrator', 'Inactive'] }), false);
});
test('OCR restrictions and revocations do not affect FH-only mode', () => {
  const policy = { ...empty(), history: [], scopes: { ocr: { ...empty(), blocks: { [user.email]: { until: 500, reason: 'OCR' } }, revokedBefore: { '*': 200 } } } };
  assert.equal(api.loginRestriction(policy, user, 300, 'fh'), null);
  assert.match(api.loginRestriction(policy, user, 300, 'ocr'), /OCR/);
  assert.match(api.loginRestriction(policy, user, 300, 'combined'), /OCR/);
  assert.equal(api.sessionRevoked(policy, user, 100, 300, 'fh'), false);
  assert.equal(api.sessionRevoked(policy, user, 100, 300, 'ocr'), true);
});
test('saving scope policy preserves other policies and adds scoped audit history', () => {
  const previousWindow = globalThis.window, values = new Map();
  globalThis.window = { localStorage: { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) }, dispatchEvent() {} };
  try {
    api.updateAdminControls(admin, 'OCR block', policy => ({ ...policy, blocks: { [user.email]: { until: 500, reason: 'OCR only' } } }), 'ocr');
    const next = api.updateAdminControls(admin, 'FH sign-out', policy => ({ ...policy, revokedBefore: { '*': 300 } }), 'fh');
    assert.equal(next.scopes.ocr.blocks[user.email].reason, 'OCR only');
    assert.equal(next.scopes.fh.revokedBefore['*'], 300);
    assert.deepEqual(next.blocks, {});
    assert.equal(next.history[0].scope, 'fh');
    const shared = api.updateAdminControls(admin, 'Shared maintenance', policy => ({ ...policy, maintenance: { id: 'm', start: 1000, end: 2000, reminderMinutes: 5, message: 'Shared' } }));
    assert.deepEqual(shared.scopes, next.scopes);
    assert.throws(() => api.updateAdminControls(user, 'Not allowed', policy => policy, 'ocr'));
    values.set(mode.workspaceModeStorageKey(user.email), JSON.stringify('fh'));
    assert.equal(api.adminSessionWorkspace(user.email), 'fh');
    values.set(mode.workspaceModeStorageKey(user.email), 'invalid');
    assert.equal(api.adminSessionWorkspace(user.email), 'combined');
  } finally { previousWindow === undefined ? delete globalThis.window : globalThis.window = previousWindow; }
});
test('reminders choose only applicable pending maintenance', () => {
  const plan = { id: 'ocr', start: 600000, end: 1200000, reminderMinutes: 5, message: 'OCR' };
  const policy = { ...empty(), history: [], scopes: { ocr: { ...empty(), maintenance: plan } } };
  assert.equal(api.upcomingAdminMaintenance(policy, 400000, 'fh'), null);
  assert.equal(api.upcomingAdminMaintenance(policy, 400000, 'ocr').id, 'ocr');
  assert.equal(api.upcomingAdminMaintenance(policy, 600000, 'combined'), null);
});
