import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const read = path => readFileSync(new URL(`../src/${path}`, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(read(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {};
new Function('exports', compile('lib/companyCounterpartyImport.ts'))(core);
const initial = () => ({ id: 'supplier', name: 'Supplier', company_code: '123', accounting_system_code: '001', vat_code: 'LT123', counterparty_gl_accounts: 'preserve', counterparty_created_by: 'Creator',
  counterparty_bank_accounts: JSON.stringify([{ id: 'bank-1', iban: 'LT121000011101001000', bank: 'SEB', primary: true }]), counterparty_activity_log: JSON.stringify([{ action: 'Created' }]) });
const draft = () => ({ name: 'Updated supplier', companyCode: '123', accountingCode: '001', vatCode: 'LT123', ibans: 'LT121000011101001000' });
function fixture() {
  const values = new Map([['company:alice', JSON.stringify([initial()])], ['company:bob', '[]'], ['global', '[]']]), events = [];
  let allowed = true, linked = false, serial = 0, afterDocuments = () => {};
  const commands = {};
  new Function('exports', 'require', 'window', 'crypto', 'CustomEvent', compile('lib/companyCounterpartyActions.ts'))(commands, name => {
    if (name === './supabase') return { supabase: { from: table => ({ select: () => ({ eq: async (_, id) => { if (table === 'documents') afterDocuments(); return { data: [{ id, name: id }], error: null }; } }) }) } };
    if (name === './documentEditAccess') return { canEditCompanySettings: () => allowed };
    if (name === './recordLifecycle') return { isInactiveRecord: row => row.active === false, isRecordLinked: () => linked, deactivateRecord: row => ({ ...row, active: false, inactive: true }) };
    if (name === './organizationDirectory') return { companyCounterpartiesKey: id => `company:${id}` };
    if (name === './currentUser') return { getCurrentUserName: () => 'Accountant' };
    if (name === './companyCounterpartyImport') return core;
    throw Error(name);
  }, { localStorage: { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) }, dispatchEvent: event => events.push(event) }, { randomUUID: () => `new-${++serial}` }, class { constructor(type, options) { this.type = type; this.detail = options.detail; } });
  return { ...commands, values, events, rows: () => JSON.parse(values.get('company:alice')), revoke: () => { allowed = false; }, link: () => { linked = true; }, onDocuments: action => { afterDocuments = action; } };
}

test('edit saves organization-only fields and contacts while preserving metadata, bank identity and audit history', async () => {
  const f = fixture(), before = initial();
  await f.updateCompanyCounterparty('alice', before, draft(), { email: ' new@example.com ', phone: ' 123 ' });
  const saved = f.rows()[0];
  assert.equal(saved.name, 'Updated supplier'); assert.equal(saved.email, 'new@example.com'); assert.equal(saved.phone, '123');
  assert.equal(saved.counterparty_gl_accounts, 'preserve'); assert.equal(saved.counterparty_created_by, 'Creator');
  assert.equal(JSON.parse(saved.counterparty_bank_accounts)[0].id, 'bank-1');
  assert.equal(JSON.parse(saved.counterparty_activity_log).length, 2);
  assert.equal(JSON.parse(saved.counterparty_activity_log)[1].user, 'Accountant');
  assert.equal(f.values.get('company:bob'), '[]'); assert.equal(f.values.get('global'), '[]');
  assert.equal(f.events[0].detail.companyId, 'alice'); assert.deepEqual(before, initial());
});

test('editing supports legacy IBAN lists and never reactivates inactive entries', () => {
  const f = fixture();
  const saved = f.prepareCounterpartyEdit({ ...initial(), active: false, counterparty_bank_accounts: 'LT121000011101001000' }, draft(), [], { email: '', phone: '' }, 'User', '2026-11-18', () => 'id');
  assert.equal(saved.active, false); assert.equal(JSON.parse(saved.counterparty_bank_accounts)[0].iban, 'LT121000011101001000');
});

test('stale, unauthorized and duplicate edits cannot overwrite stored rows', async () => {
  const f = fixture(); f.values.set('company:alice', JSON.stringify([{ ...initial(), name: 'Changed elsewhere' }]));
  await assert.rejects(f.updateCompanyCounterparty('alice', initial(), draft(), { email: '', phone: '' }), /has changed/);
  assert.equal(f.rows()[0].name, 'Changed elsewhere');
  f.revoke(); await assert.rejects(f.updateCompanyCounterparty('alice', f.rows()[0], draft(), { email: '', phone: '' }), /permission/);
  assert.throws(() => f.prepareCounterpartyEdit(initial(), draft(), [{ company_code: '123' }], { email: '', phone: '' }, '', '', () => 'id'), /highlighted/);
});

test('unused rows delete while newly linked rows deactivate and remain visible with history', async () => {
  const unused = fixture(); assert.equal(await unused.deleteCompanyCounterparty('alice', initial()), 'deleted'); assert.equal(unused.rows().length, 0);
  const used = fixture(); used.onDocuments(() => used.link());
  assert.equal(await used.deleteCompanyCounterparty('alice', initial()), 'deactivated'); assert.equal(used.rows()[0].active, false);
  assert.equal(JSON.parse(used.rows()[0].counterparty_activity_log).at(-1).action, 'Counterparty deactivated');
  assert.equal(used.values.get('company:bob'), '[]');
});

test('delete rechecks revoked rights and corrupt history stays untouched', async () => {
  const revoked = fixture(); revoked.onDocuments(() => revoked.revoke());
  await assert.rejects(revoked.deleteCompanyCounterparty('alice', initial()), /permission/); assert.equal(revoked.rows().length, 1);
  const corrupt = fixture(), row = { ...initial(), counterparty_activity_log: '{broken' };
  corrupt.values.set('company:alice', JSON.stringify([row])); corrupt.link();
  await assert.rejects(corrupt.deleteCompanyCounterparty('alice', row)); assert.equal(corrupt.rows()[0].counterparty_activity_log, '{broken');
});

test('system table exposes per-row edit/delete, column settings, pagination and guarded confirmation', () => {
  const source = read('components/OrganizationReferenceLists.tsx');
  assert.match(source, /data-button-family="row-edit"/); assert.match(source, /<RowDeleteButton/);
  assert.match(source, /<ColumnSettingsPanel/); assert.match(source, /system-table-row-actions/);
  assert.match(source, /editingCompany=\{editingCompany\}/); assert.match(source, /deleteCompanyCounterparty\(companyId, deleting.row\)/);
  assert.match(source, /slice\(safePage \* 20/); assert.match(source, /data-record-inactive=\{isInactiveRecord\(row\)/);
});
