import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
function load(file, require = name => { throw Error(name); }) {
  const result = {};
  const code = ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', code)(result, require);
  return result;
}
const data = load('../src/lib/companyRelatedObjectData.ts').DEBT_ROWS;
const actions = load('../src/lib/debtActions.ts');
const details = load('../src/lib/debtDetails.ts', name => { assert.equal(name, './debtActions'); return actions; });
const debt = data[0];
const organizationId = 'alice';

test('sample payment history reconciles to each paid debt, with stable organization-scoped IDs', () => {
  for (const row of data) {
    const before = structuredClone(row);
    const payments = details.debtPayments(row, organizationId);
    assert.equal(payments.reduce((sum, payment) => sum + payment.matchedMinor, 0), details.debtMinor(row.paidAmount));
    assert.ok(payments.every(payment => payment.currency === row.currency && payment.id.startsWith('alice:')));
    assert.deepEqual(row, before);
  }
  assert.deepEqual(details.debtPayments(debt, organizationId).map(row => row.matchedMinor), [60000, 30000]);
  assert.deepEqual(details.debtPayments({ ...debt, documentReference: 'other' }, organizationId), []);
  assert.deepEqual(details.debtPayments({ ...debt, paidAmount: '100.00' }, organizationId), []);
  assert.deepEqual(details.debtPayments(debt, ''), []);
  assert.equal(details.debtMoney(90000, 'EUR'), '900.00 EUR');
});

function reconciliation() {
  const invoice = { id: 'invoice', organizationId, kind: 'Invoice', documentNumber: debt.documentReference, currency: 'EUR', side: 'Receivable', counterpartyName: debt.counterpartyName };
  const payment = { id: 'payment', organizationId, kind: 'Payment', documentNumber: 'REAL-1', documentDate: '2026-11-10', originalMinor: 35000, currency: 'USD', reference: debt.documentReference, paymentPurpose: 'Original bank text' };
  return { organizationId, items: [invoice, payment], batches: [{ id: 'batch-1', at: '2026-11-10T12:00:00Z', actor: 'Accountant', allocations: [{ fundingId: 'payment', invoiceId: 'invoice', amountMinor: 30000 }] }] };
}
test('actual reconciliation replaces fixtures, preserving payment and invoice currencies', () => {
  const state = reconciliation(), original = structuredClone(state);
  const [row] = details.debtPayments(debt, organizationId, state);
  assert.equal(row.reference, 'REAL-1'); assert.equal(row.matchedMinor, 30000);
  assert.equal(row.currency, 'EUR'); assert.equal(row.paymentCurrency, 'USD'); assert.equal(row.paymentMinor, 35000);
  assert.equal(row.purpose, 'Original bank text'); assert.equal(row.actor, 'Accountant');
  assert.deepEqual(state, original);
});
test('reversed, missing and cross-organization matches are never presented as active payments', () => {
  const state = reconciliation();
  state.batches[0].reversedAt = '2026-11-11T12:00:00Z';
  assert.deepEqual(details.debtPayments(debt, organizationId, state), []);
  delete state.batches[0].reversedAt; state.items[1].organizationId = 'other';
  assert.deepEqual(details.debtPayments(debt, organizationId, state), []);
  state.organizationId = 'other';
  assert.deepEqual(details.debtPayments(debt, organizationId, state), []);
});

const message = { id: 'message', organizationId, sender: 'Alice Stone', recipient: debt.counterpartyName, recipientEmail: 'accountant@example.invalid', documentReference: debt.documentReference, sentAt: '2026-11-10T12:00:00Z', templateName: 'Payment reminder', portalUrl: '' };
test('communication history is scoped by company, counterparty and exact document or debt ID', () => {
  const history = [message,
    { ...message, id: 'batch', documentReference: `OTHER, ${debt.documentReference}` },
    { ...message, id: 'metadata', documentReference: 'renamed', relatedDebtIds: [debt.id] },
    { ...message, id: 'legacy', organizationId: undefined },
    { ...message, id: 'other-org', organizationId: 'other' },
    { ...message, id: 'other-party', recipient: 'Another buyer' },
    { ...message, id: 'partial-number', documentReference: `${debt.documentReference}0` },
    { ...message, id: 'other-id', relatedDebtIds: ['debt-3'] },
  ];
  assert.deepEqual(details.debtCommunicationHistory(history, organizationId, 'Alice Stone', debt).map(row => row.id), ['message', 'batch', 'metadata', 'legacy']);
});
test('communication type and delivery status do not fabricate sending or replies', () => {
  assert.equal(details.debtCommunicationType(message), 'Payment reminder');
  assert.equal(details.debtCommunicationType({ ...message, purpose: 'balance-confirmation' }), 'Balance confirmation');
  assert.equal(details.debtCommunicationStatus(message), 'Saved');
  assert.equal(details.debtCommunicationStatus({ ...message, deliveryStatus: 'sent' }), 'Sent');
  assert.equal(details.debtCommunicationStatus({ ...message, responseReceivedAt: message.sentAt }), 'Reply received');
});
test('details is a full-width three-section screen with existing views and retained parent list state', () => {
  const view = read('../src/components/DebtDetailsView.tsx'), parent = read('../src/components/CompanyDebtsView.tsx');
  for (const title of ['Debt information', 'Payments & Reconciliation', 'Communication history']) assert.ok(view.includes(`title="${title}"`));
  for (const label of ['Back to debts', 'Open document', 'View bank transaction', 'View reconciliation']) assert.ok(view.includes(label));
  assert.match(view, /aria-expanded=\{open\}/); assert.match(view, /lazy\(\(\) => import\('\.\/DebtLinkedDocumentView'\)\)/);
  assert.match(view, /removeEventListener\('organization-email-history-updated', update\)/);
  assert.match(parent, /setDetailId\(row.id\)/); assert.match(parent, /<DebtDetailsView/);
  assert.doesNotMatch(parent.match(/const backToDebts = \(\) => \{([\s\S]*?)\n  \}/)?.[1] || '', /setActiveTab|setQuery|setSelectedRows|setFilterValues/);
  const source = read('../src/components/DebtLinkedDocumentView.tsx');
  assert.match(source, /\.eq\('company_id', company.id\)/); assert.match(source, /\.eq\('number', debt.documentReference\)/);
  assert.match(source, /<DocumentDetailPanel[^>]*readOnly/); assert.match(source, /document_deletion/);
  assert.doesNotMatch(view + source, /\.insert\(|\.update\(|\.delete\(|localStorage.setItem/);
});
