import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
function load(file, require = name => { throw Error(name); }) {
  const result = {};
  const code = ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', code)(result, require);
  return result;
}
const data = load('../src/lib/companyRelatedObjectData.ts').DEBT_ROWS;
const actions = load('../src/lib/debtActions.ts');
const rights = { send: true, payment: true };
const receivables = data.filter(row => actions.debtDirection(row) === 'receivable');
const payables = data.filter(row => actions.debtDirection(row) === 'payable');

test('tabs filter by actual debt direction and overdue days', () => {
  assert.equal(receivables.length, 3); assert.equal(payables.length, 3);
  assert.deepEqual(data.filter(row => actions.debtInTab(row, 'Receivables')), receivables);
  assert.deepEqual(data.filter(row => actions.debtInTab(row, 'Payables')), payables);
  assert.equal(data.filter(row => actions.debtInTab(row, 'All')).length, 6);
  assert.deepEqual(data.filter(row => actions.debtInTab(row, 'Overdue')).map(row => row.id), ['debt-1', 'debt-2', 'debt-5', 'debt-6']);
});

test('each direction has only its applicable primary action; no selection is disabled', () => {
  for (const tab of ['Receivables', 'Payables', 'All', 'Overdue']) {
    const state = actions.debtActionState(tab, [], rights);
    assert.equal(state.reminder.enabled, false); assert.equal(state.payment.enabled, false); assert.equal(state['balance-confirmation'].enabled, false);
    assert.equal(state.reminder.visible, tab !== 'Payables'); assert.equal(state.payment.visible, tab !== 'Receivables');
  }
  for (const tab of ['Receivables', 'All', 'Overdue']) {
    const state = actions.debtActionState(tab, receivables.slice(0, 1), rights);
    assert.ok(state.reminder.visible && state.reminder.enabled); assert.equal(state.payment.visible, false); assert.ok(state['balance-confirmation'].enabled);
  }
  for (const tab of ['Payables', 'All', 'Overdue']) {
    const state = actions.debtActionState(tab, payables.filter(row => actions.debtInTab(row, tab)), rights);
    assert.ok(state.payment.visible && state.payment.enabled); assert.equal(state.reminder.visible, false); assert.ok(state['balance-confirmation'].enabled);
  }
});

test('switching tabs retains selection but cannot act on debts outside the current tab', () => {
  for (const [tab, rows] of [['Receivables', payables], ['Payables', receivables], ['Overdue', data.filter(row => row.daysOverdue === 0)]]) {
    const before = structuredClone(rows);
    const state = actions.debtActionState(tab, rows, rights);
    assert.equal(state.outsideTab, true);
    for (const action of ['reminder', 'payment', 'balance-confirmation']) assert.equal(state[action].enabled, false);
    assert.deepEqual(rows, before);
    assert.equal(actions.debtActionState('All', rows, rights)['balance-confirmation'].enabled, true);
  }
});

test('All selects applicable actions for single and multiple debts, retaining the common system button design', () => {
  for (const rows of [receivables.slice(0, 1), receivables]) {
    const state = actions.debtActionState('All', rows, rights);
    assert.deepEqual(state.reminder, { visible: true, enabled: true });
    assert.deepEqual(state.payment, { visible: false, enabled: false });
  }
  for (const rows of [payables.slice(0, 1), payables]) {
    const state = actions.debtActionState('All', rows, rights);
    assert.deepEqual(state.reminder, { visible: false, enabled: false });
    assert.deepEqual(state.payment, { visible: true, enabled: true });
  }
  const view = read('../src/components/CompanyDebtsView.tsx');
  assert.doesNotMatch(view, /Send statement|actionButtonClass|sr-only/);
  for (const action of ['reminder', 'payment']) assert.ok(view.includes(`disabled={!actions.${action}.enabled}`));
  assert.match(view, /disabled=\{!actions\['balance-confirmation'\]\.enabled\}/);
  assert.ok(view.includes('[&>div:last-child]:flex-wrap'));
});

test('mixed selections never silently drop one direction; confirmation supports both', () => {
  for (const tab of ['All', 'Overdue']) {
    const state = actions.debtActionState(tab, [receivables[0], payables[0]], rights);
    assert.ok(state.mixed && state.reminder.visible && state.payment.visible);
    assert.equal(state.reminder.enabled, false); assert.equal(state.payment.enabled, false); assert.ok(state['balance-confirmation'].enabled);
  }
  assert.throws(() => actions.groupDebtActions(data, 'reminder'), /one direction/);
  assert.throws(() => actions.groupDebtActions(data, 'payment'), /one direction/);
});

test('single and multiple debts group by counterparty, currency and direction with exact cents', () => {
  const reminder = actions.groupDebtActions(receivables, 'reminder');
  assert.equal(reminder.length, 2); assert.equal(reminder[0].amount, 750.5); assert.equal(reminder[0].references, 'INV-1025, INV-1026');
  assert.equal(reminder[1].amount, 600); assert.equal(reminder[1].currency, 'USD');
  const payment = actions.groupDebtActions(payables, 'payment');
  assert.equal(payment[0].amount, 425.25); assert.equal(payment[0].rows.length, 2);
  const mixedSameParty = [receivables[0], { ...receivables[0], id: 'pay', direction: 'payable' }, { ...receivables[0], id: 'usd', currency: 'USD' }];
  assert.equal(actions.groupDebtActions(mixedSameParty, 'balance-confirmation').length, 3);
  assert.equal(actions.groupDebtActions([receivables[0], receivables[0]], 'reminder')[0].amount, 300);
});

test('invalid, settled and unauthorized selections fail closed', () => {
  for (const value of ['', '0', '-10', 'NaN', '1e3', '12,34', '1.999']) {
    assert.equal(actions.debtAmountInCents(value), null);
    const rows = [{ ...receivables[0], outstandingAmount: value }];
    assert.equal(actions.debtActionState('All', rows, rights).reminder.enabled, false);
    assert.throws(() => actions.groupDebtActions(rows, 'reminder'));
  }
  assert.equal(actions.debtAmountInCents('1,200.50'), 120050);
  assert.equal(actions.debtActionState('All', receivables, { send: false, payment: false })['balance-confirmation'].enabled, false);
  assert.equal(actions.debtActionState('Payables', payables, { send: true, payment: false }).payment.enabled, false);
});

test('existing payment form receives selected debt totals and references, without fake document IDs or bank submission', () => {
  const group = actions.groupDebtActions(payables, 'payment')[0];
  const draft = actions.debtPaymentDraft(group, '2026-11-18', 'LT121000011101001000');
  assert.equal(draft.amount, '425.25'); assert.equal(draft.counterparty, 'Baltic Services, UAB'); assert.equal(draft.currency, 'EUR');
  assert.equal(draft.purpose, 'Payment for invoices PUR-2041, PUR-2042'); assert.equal(draft.relatedDocumentId, '');
  assert.equal(draft.creditorAccount, 'LT121000011101001000'); assert.equal(draft.executionDate, '2026-11-18');
  assert.throws(() => actions.debtPaymentDraft(actions.groupDebtActions(receivables, 'reminder')[0], '2026-11-18'));
});

test('reminder and balance confirmation select correct existing/default templates in the UI language', () => {
  const email = load('../src/lib/organizationEmail.ts');
  for (const language of ['en', 'lt']) {
    const reminder = email.debtEmailTemplates([], 'reminder', language)[0];
    const confirmation = email.debtEmailTemplates([], 'balance-confirmation', language)[0];
    assert.equal(reminder.language.toLowerCase(), language); assert.match(reminder.id, /reminder/);
    assert.equal(confirmation.language.toLowerCase(), language); assert.match(confirmation.id, /reconciliation/);
    const rendered = email.renderOrganizationEmailTemplate(reminder.body, { sender: 'Alice Stone', recipient: 'UAB Alfa', reconciliationDate: '2026-11-18', debtBalance: '750.50 EUR', portalUrl: '', documentReference: 'INV-1025, INV-1026' });
    assert.ok(rendered.includes('750.50 EUR') && rendered.includes('INV-1025, INV-1026'));
  }
  const custom = { id: 'custom', name: 'Our reminder', purpose: 'reminder', active: true, language: 'EN', subject: 'Ours', body: 'Ours' };
  assert.deepEqual(email.debtEmailTemplates([custom], 'reminder', 'en'), [custom]);
  assert.equal(email.debtEmailTemplates([{ ...custom, id: 'debt-reminder-en', active: false }], 'reminder', 'en').some(row => row.id === 'debt-reminder-en'), false);
});

test('UI uses existing forms, preserves filtered selection and advances only completed groups', () => {
  const view = read('../src/components/CompanyDebtsView.tsx');
  assert.match(view, /<NewPaymentForm/); assert.match(view, /<SendInvoicePanel/); assert.doesNotMatch(view, /Send statement|Send reminder to selected/);
  assert.match(view, /debtInTab\(row, activeTab\)/); assert.match(view, /toggleFilteredSelection\(current, sortedRows.map/);
  assert.match(view, /DEBT_ROWS.filter\(row => selectedRows.has\(row.id\)\)/);
  assert.match(view, /previous\].filter\(id => !completedIds.has\(id\)\)/);
  assert.match(view, /onSaved=\{completeGroup\}/); assert.match(view, /onSent=\{completeGroup\}/);
  assert.match(view, /canSend=\{\(\) => debtActionRights\(company\).send\}/);
  assert.match(read('../src/components/NewPaymentForm.tsx'), /initialDraft \? \{ \.\.\.initialDraft \}/);
});
