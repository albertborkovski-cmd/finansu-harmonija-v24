import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import { createRequire } from 'node:module';
import ts from 'typescript';
const source = path => readFileSync(new URL(`../src/${path}`, import.meta.url), 'utf8');
test('Dashboard reuses mode-scoped records and shows notifications below the OCR status cards', () => {
  const shell = source('components/Dashboard.tsx'), view = source('components/DashboardView.tsx');
  assert.match(shell, /useVisibleNotificationRecords\(notificationRecords, session, workspaceMode\)/);
  assert.match(shell, /getDashboardAttentionNotifications\(visibleNotifications.records/);
  assert.match(shell, /attentionNotifications=\{canViewMenu\(session, "notifications"\)/);
  assert.match(shell, /if \(row.ocrTarget\) await openOcrNotification\(row\)/);
  assert.ok(view.indexOf('<DashboardAttention') > view.indexOf('Based on current documents'));
  assert.doesNotMatch(view, /workspaceMode !== 'ocr' && allCompanies && attentionNotifications/);
});
test('dashboard list uses exact source navigation, scoped count, meaningful severity and one shared tooltip', () => {
  const ui = source('components/DashboardAttention.tsx');
  assert.match(ui, /await onOpenRecord\(row\)/);
  assert.match(ui, /onOpen\('notifications'\)/);
  assert.match(ui, /rows.length/);
  assert.match(ui, /severity === 'Critical'/);
  assert.match(ui, /NotificationRelativeTime/);
  assert.match(ui, /max-h-\[320px\] overflow-y-auto/);
});

test('dashboard renders only five highest-priority notifications without truncating the total or View all', () => {
  const require = createRequire(import.meta.url);
  const dependencies = {
    react: { useState: initial => [initial, () => {}] },
    'react/jsx-runtime': require('react/jsx-runtime'),
    'lucide-react': { AlertCircle: 'alert-icon', Bell: 'bell-icon', Info: 'info-icon' },
    '../i18n/language': { translateUi: value => value },
    './NotificationRelativeTime': { default: 'relative-time' },
  };
  const compiled = ts.transpileModule(source('components/DashboardAttention.tsx'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX },
  }).outputText;
  const api = {};
  new Function('exports', 'require', compiled)(api, name => {
    assert.ok(name in dependencies, `Unexpected dependency: ${name}`);
    return dependencies[name];
  });
  const nodes = tree => !tree || typeof tree !== 'object' ? [] : Array.isArray(tree)
    ? tree.flatMap(nodes) : [tree, ...nodes(tree.props?.children)];
  const rows = Array.from({ length: 24 }, (_, index) => ({
    id: `row-${index}`, category: 'notifications', name: `Notification ${index}`, message: '',
    severity: index < 2 ? 'Critical' : index < 7 ? 'Warning' : 'Info',
    createdAt: new Date(Date.UTC(2026, 10, 18, index)).toISOString(),
  }));
  const before = structuredClone(rows);
  let opened;
  const tree = nodes(api.default({ rows, onOpen: tab => { opened = tab; } }));
  const items = tree.filter(node => node.type === 'li');
  assert.equal(items.length, 5);
  assert.deepEqual(items.map(node => node.key), ['notifications:row-1', 'notifications:row-0', 'notifications:row-6', 'notifications:row-5', 'notifications:row-4']);
  assert.ok(tree.some(node => node.props?.['aria-label'] === 'Active notifications: 24'));
  tree.find(node => node.type === 'button' && node.props.children === 'View all').props.onClick();
  assert.equal(opened, 'notifications');
  assert.deepEqual(rows, before);
  assert.equal(nodes(api.default({ rows: rows.slice(0, 2), onOpen() {} })).filter(node => node.type === 'li').length, 2);
});
