import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const inline = {}, core = {}, details = {}, statuses = {};
new Function('exports', compile('../src/lib/documentInlineEditing.ts'))(inline);
new Function('exports', compile('../src/lib/documentProcessingStatus.ts'))(statuses);
new Function('exports', 'require', compile('../src/lib/documentDetailEditing.ts'))(details, name => name === './documentInlineEditing' ? inline : statuses);
new Function('exports', 'require', compile('../src/lib/bankTransaction.ts'))(core, name => name === './documentInlineEditing' ? inline : details);
const company = { id: 'a', name: 'Alice Stone', base_currency: 'EUR', organization_bank_accounts: JSON.stringify([{ iban: 'LT111', bank: 'Test bank', primary: true }, { iban: 'LT222', inactive: true }]) };
const document = { id: 'bank-1', company_id: 'a', status: 'Draft', number: 'PAY-1', source: 'Bank import', client_counterparty: 'Supplier A', counterparty_id: 'cp-a', counterparty_code: '123',
  total_amount: '230.10', amount_without_vat: '230.10', vat: '0', currency: 'EUR', operation_date: '2026-10-31', document_date: '2026-10-31', notes: 'Original statement',
  line_items: [{ id: 'product-1', product: 'Original OCR item' }], summary_line_items: [
    { id: 'a1', product: 'Received payment (customer debt)', expense: '2411', total: '229.90' },
    { id: 'a2', product: 'Bank fee / commission', expense: '6118', total: '0.20' },
  ] };
const options = { allowed: true, accountIbans: ['LT111'], counterparties: [{ id: 'cp-a', name: 'Supplier A', company_code: '123' }], glAccounts: ['2411', '6118'], reconciled: false };
const draft = () => core.bankTransactionFromDocument(document, company);
const validate = (value, source = document, overrides = {}) => core.validateBankTransaction(source, company, value, core.bankTransactionSnapshot(source), { ...options, ...overrides });

test('bank form preserves statement text and independent allocations without changing invoice/OCR data', () => {
  const original = structuredClone(document), value = draft();
  assert.equal(value.bankAccount, 'LT111'); assert.equal(value.originalStatement, 'Original statement');
  assert.equal(value.allocations.length, 2); assert.equal(value.allocations[1].amount, '0.20');
  assert.deepEqual(core.bankAllocationTotals(value), { amount: 23010, allocated: 23010, remaining: 0, valid: true });
  assert.deepEqual(document, original); assert.deepEqual(validate(value), value);
  assert.deepEqual(core.companyBankAccounts(company).map(row => row.iban), ['LT111']);
  const saved = { ...document, bank_transaction: value };
  const reopened = core.bankTransactionFromDocument(saved, company); reopened.notes = 'Local change';
  assert.equal(saved.bank_transaction.notes, 'Original statement');
});
test('allocation totals use cents, accept signed outgoing amounts and reject invalid/unbalanced values', () => {
  const value = draft(); value.amount = '-230.10'; value.allocations.forEach(row => { row.amount = `-${row.amount}`; });
  assert.equal(validate(value, { ...document, bank_transaction: structuredClone(value) }).amount, '-230.10');
  for (const amount of ['230.11', '', '0', 'NaN', '1.111']) {
    const value = draft(); value.amount = amount; assert.throws(() => validate(value), /amount/i);
  }
  for (const change of [row => { row.amount = ''; }, row => { row.glAccount = ''; }, row => { row.description = ''; }, row => { row.glAccount = 'foreign-account'; }]) {
    const value = draft(); change(value.allocations[0]); assert.throws(() => validate(value));
  }
});
test('optional booking date and counterparty IBAN survive bank edits independently of existing dates', () => {
  const bank = { ...draft(), counterpartyIban: 'LT121000011101001000', bookingDate: '2026-11-02', exchangeRateDate: '2026-10-30' };
  const source = { ...document, bank_transaction: bank };
  const reopened = core.bankTransactionFromDocument(source, company);
  reopened.notes = 'Updated note';
  const saved = validate(reopened, source);
  assert.equal(saved.counterpartyIban, bank.counterpartyIban);
  assert.equal(saved.bookingDate, '2026-11-02');
  assert.equal(saved.date, '2026-10-31');
  assert.equal(saved.exchangeRateDate, '2026-10-30');
  assert.equal(draft().bookingDate, undefined);
});
test('demo payment purposes use invoice references without overwriting saved bank text or other documents', () => {
  const alice = { ...company, id: '00000000-0000-4000-8000-000000000002' };
  const examples = [
    ['10000000-0000-4000-8000-000000000004', 'Advance invoice', 'Payment for invoice ADV-004'],
    ['10000000-0000-4000-8000-000000000003', 'Receipt', 'Payment for invoice EXP-003'],
  ];
  for (const [id, original, expected] of examples) {
    assert.equal(core.bankPaymentPurpose(id, alice.id, original), expected);
    assert.equal(core.bankPaymentPurpose(id, 'other-company', original), original);
    assert.equal(core.bankPaymentPurpose(id, alice.id, 'Custom description'), 'Custom description');
    const source = { ...document, id, company_id: alice.id, notes: '', document_subtype: original };
    assert.equal(core.bankTransactionFromDocument(source, alice).paymentPurpose, expected);
    assert.equal(core.bankTransactionFromDocument({ ...source, document_subtype: '', document_type: original }, alice).paymentPurpose, expected);
    source.bank_transaction = { ...draft(), paymentPurpose: 'Custom saved payment' };
    assert.equal(core.bankTransactionFromDocument(source, alice).paymentPurpose, 'Custom saved payment');
  }
  assert.equal(core.bankPaymentPurpose('other-record', alice.id, 'Receipt'), 'Receipt');
  const view = read('../src/components/CompanyBankView.tsx');
  assert.match(view, /paymentPurpose: bankPaymentPurpose\(document.id, company.id,/);
  assert.match(view, /title=\{row\[column.key as BankColumnKey\]\} className="flex-shrink-0 truncate/);
});
test('bank save rechecks access, company, deletion, state, stale data and immutable source text', () => {
  assert.throws(() => validate(draft(), document, { allowed: false }), /permission/);
  for (const patch of [{ company_id: 'b' }, { document_deletion: {} }, { status: 'Approved' }, { status: 'Processing' }, { accounting_posting: {} }, { document_storno: {} }, { inactive: true }]) {
    assert.throws(() => validate(draft(), { ...document, ...patch }));
  }
  assert.throws(() => core.validateBankTransaction({ ...document, notes: 'Other change' }, company, draft(), core.bankTransactionSnapshot(document), options), /changed/);
  const value = draft(); value.originalStatement = 'Changed'; assert.throws(() => validate(value), /original bank statement/);
  value.originalStatement = draft().originalStatement; value.bankAccount = 'OTHER'; assert.throws(() => validate(value), /bank account/);
});
test('reconciliation is derived from actual IDs and active batches, never from the document itself or its status', () => {
  const state = { organizationId: 'a', items: [{ id: 'bank-1', organizationId: 'a', originalMinor: 23010, remainingMinor: 100 }, { id: 'invoice-1', documentNumber: 'INV-1' }], batches: [{ allocations: [{ fundingId: 'bank-1', invoiceId: 'invoice-1' }] }] };
  const actual = core.bankReconciliation('bank-1', 'a', JSON.stringify(state));
  assert.equal(actual.status, 'Partially matched'); assert.deepEqual(actual.documents, [{ id: 'invoice-1', number: 'INV-1' }]);
  assert.equal(core.bankReconciliation('unlinked', 'a', JSON.stringify(state)).status, 'Unmatched');
  assert.equal(core.bankReconciliation('bank-1', 'a', '{').status, 'Unavailable');
  state.batches[0].reversedAt = '2026-11-01'; state.items[0].remainingMinor = 23010;
  assert.equal(core.bankReconciliation('bank-1', 'a', JSON.stringify(state)).documents.length, 0);
  const changed = draft(); changed.amount = '230.20'; changed.allocations[0].amount = '230.00';
  assert.throws(() => validate(changed, document, { reconciled: true }), /reconciliation/);
});
test('bank reconciliation offers three states and displays scoped demo badges without creating a settlement', () => {
  assert.deepEqual(core.BANK_RECONCILIATION_STATUSES, ['Unmatched', 'Partially matched', 'Matched']);
  const companyId = '00000000-0000-4000-8000-000000000002';
  const incomingId = '10000000-0000-4000-8000-000000000004';
  const outgoingId = '10000000-0000-4000-8000-000000000003';
  assert.equal(core.bankReconciliationForDisplay(incomingId, companyId, null).status, 'Unmatched');
  const demo = core.bankReconciliationForDisplay(outgoingId, companyId, null);
  assert.equal(demo.status, 'Matched'); assert.equal(demo.demo, true);
  assert.equal(demo.matched, false); assert.deepEqual(demo.documents, []);
  assert.equal(core.bankReconciliation(outgoingId, companyId, null).status, 'Unmatched');
  assert.equal(core.bankReconciliationForDisplay(outgoingId, 'other-company', null).status, 'Unmatched');
  assert.equal(core.bankReconciliationForDisplay(outgoingId, companyId, '{').status, 'Unavailable');
  const state = { organizationId: companyId, items: [{ id: outgoingId, organizationId: companyId, originalMinor: 68486, remainingMinor: 100 }], batches: [] };
  const before = JSON.stringify(state);
  const partial = core.bankReconciliationForDisplay(outgoingId, companyId, before);
  assert.equal(partial.status, 'Partially matched'); assert.equal(partial.demo, false);
  assert.equal(JSON.stringify(state), before);
  state.items[0].remainingMinor = 0;
  assert.equal(core.bankReconciliationForDisplay(outgoingId, companyId, JSON.stringify(state)).status, 'Matched');
  state.items[0].remainingMinor = 68486;
  assert.equal(core.bankReconciliationForDisplay(outgoingId, companyId, JSON.stringify(state)).status, 'Unmatched');
});
test('invalid dates, foreign counterparties and executable attachments cannot be saved', () => {
  for (const change of [value => { value.date = '2026-02-31'; }, value => { value.counterpartyId = 'foreign'; }, value => { value.attachments = [{ name: 'x', size: 10, type: 'text/html', url: 'data:text/html;base64,AA==' }]; }]) {
    const value = draft(); change(value); assert.throws(() => validate(value));
  }
});
test('all original bank fields are immutable while historical account references and allocations are preserved', () => {
  for (const key of ['date', 'bankAccount', 'counterpartyId', 'counterpartyName', 'counterpartyCode', 'counterpartyIban',
    'paymentPurpose', 'amount', 'currency', 'exchangeRateDate', 'referenceNo', 'transferNo']) {
    const value = draft(); value[key] = key === 'date' || key === 'exchangeRateDate' ? '2026-10-30' : key === 'currency' ? 'USD' : 'Changed';
    assert.throws(() => validate(value), /Original bank data/, key);
  }
  const bank = { ...draft(), bankAccount: '', counterpartyName: '', bookingDate: '2026-11-01' };
  const source = { ...document, bank_transaction: structuredClone(bank) };
  bank.allocations[0].department = 'ADMIN';
  assert.equal(validate(bank, source).allocations[0].department, 'ADMIN');
  bank.bookingDate = '2026-11-02';
  assert.throws(() => validate(bank, source), /Original bank data/);
});

function fixture() {
  const store = new Map(); let allowed = true;
  const api = {}, issues = {}, storno = {};
  new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
  const require = name => {
    if (name === './bankTransaction') return core;
    if (name === './companyBankEditing') return { canEditCompanyBankEntries: () => allowed };
    if (name === './invoiceCreation') return { loadInvoiceCounterparties: () => options.counterparties };
    if (name === '../components/GeneralLedgerView') return { loadCompanyGeneralLedgerAccountHierarchy: () => options.glAccounts.map(code => ({ code })) };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Static test'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', [document, { ...document, id: 'other', company_id: 'b' }]); put('companies', [company]); put('document_history', []);
  return { ...api, get, put, revoke: () => { allowed = false; } };
}
test('save persists the bank overlay and audit atomically, retaining all source document fields and other companies', async () => {
  const f = fixture(), value = draft(); value.notes = 'Accounting note'; value.allocations[0].department = 'ADMIN';
  const saved = await f.saveBankTransaction(document.id, company.id, value, core.bankTransactionSnapshot(document));
  assert.equal(saved.bank_transaction.paymentPurpose, value.paymentPurpose);
  for (const [key, field] of Object.entries(document)) assert.deepEqual(saved[key], field, key);
  assert.equal(f.get('documents')[1].bank_transaction, undefined);
  assert.equal(saved.detail_edit_history[0].user_name, 'Test accountant');
  assert.equal(f.get('document_history')[0].action, 'Bank transaction updated');
  await assert.rejects(f.saveBankTransaction(document.id, company.id, value, core.bankTransactionSnapshot(document)), /changed/);
  f.revoke(); await assert.rejects(f.saveBankTransaction(document.id, company.id, value, core.bankTransactionSnapshot(saved)), /permission/);
});
test('dedicated editor has five system sections, protected statement text, signed totals and real save/cancel actions', () => {
  const source = read('../src/components/BankTransactionEditor.tsx');
  for (const section of ['Bank details', 'Accounting allocation', 'Reconciliation', 'Additional information', 'Attachments and notes']) assert.ok(source.includes(section));
  assert.match(source, /new Set\(\[1, 2\]\)/);
  assert.match(source, /saveBankTransaction\(record.id, company.id, draft, expected.current\)/);
  assert.match(source, /<SaveButton type="submit"/); assert.match(source, /<CancelButton/);
  assert.match(source, /portalMenu menuClassName="!z-\[5200\]"/);
  assert.match(source, /HorizontalTableScrollbar scrollRef=\{table\} fixed=\{false\} expandable=\{false\}/);
  assert.doesNotMatch(source, /update\('originalStatement'/);
});
