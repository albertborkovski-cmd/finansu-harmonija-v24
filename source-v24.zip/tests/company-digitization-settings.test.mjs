import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const source = path => readFileSync(new URL(`../src/${path}`, import.meta.url), 'utf8');
const core = {};
const additional = {};
const schemas = {};
new Function('exports', ts.transpileModule(source('lib/exportFormatSchemas.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(schemas);
new Function('exports', ts.transpileModule(source('lib/documentAdditionalColumns.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText)(additional);
new Function('exports', 'require', ts.transpileModule(source('lib/companyDigitizationSettings.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(core, name => { if (name === './documentAdditionalColumns') return additional; if (name === './exportFormatSchemas') return schemas; throw new Error(name); });

test('every requested export format is available once', () => {
  const names = 'Agnum|Apskaita5|BSS|BSS Api|Business Central|Būtent|Būtent kiekinis|Centas|CSV|Debetas|Debetas Excel|Dineta|Directo|Euroskaita|Excel|Finvalda|Finvalda Excel|iSAF|Json|Lobasoft|Monet|Odoo|Optimum|Paulita|Pragma3|Pragma4|Pragma4 V2|Rivilė|Rivilė API|Rivilė ERP|Roda|Saikas|Site.pro|StandardERP|Syrve|UCS StoreHouse v4|Uniconta|XML'.split('|');
  assert.deepEqual(core.COMPANY_EXPORT_FORMATS, names);
  assert.equal(new Set(core.COMPANY_EXPORT_FORMATS).size, names.length);
});
test('settings round-trip independently with safe defaults and never serialize API credentials', () => {
  const defaults = core.parseCompanyDigitizationSettings();
  assert.equal(defaults.database, ''); assert.equal(defaults.exportAfterDigitization, false);
  const saved = { ...defaults, database: 'EXAMPLE', updateProducts: true, primaryLineCode: 'code', apiKey: 'do-not-store', unknown: 'discard' };
  const parsed = JSON.parse(core.serializeCompanyDigitizationSettings(saved));
  assert.equal(parsed.database, 'EXAMPLE'); assert.equal(parsed.updateProducts, true);
  assert.equal(parsed.apiKey, undefined); assert.equal(parsed.unknown, undefined);
  assert.deepEqual(core.parseCompanyDigitizationSettings(), defaults);
  assert.equal(core.parseCompanyDigitizationSettings('{"updateCodes":"true"}').updateCodes, false);
});
test('invalid settings cannot overwrite the company configuration', () => {
  for (const value of ['[1]', 'null', '{bad']) assert.throws(() => core.parseCompanyDigitizationSettings(value));
  for (const change of [{ purchaseOperation: 'Reservation' }, { salesOperation: 'Other' }, { primaryLineCode: 'random' }, { individualBuyerCode: 'fixed', fixedBuyerCode: '' }, { database: 'x'.repeat(501) }]) assert.throws(() => core.serializeCompanyDigitizationSettings({ ...core.DEFAULT_DIGITIZATION_SETTINGS, ...change }));
});
test('gear panel uses shared form controls, checks fresh company access and updates only its settings', () => {
  const form = source('components/OrganizationDigitizationSetup.tsx');
  assert.match(form, /type="password"/); assert.match(form, /API keys are not saved/);
  assert.match(form, /const patch = \{ primary_export_format: format, document_export_settings:/);
  assert.match(form, /canEditCompanySettings\(current\)/);
  assert.match(form, /current.document_export_settings !== company.document_export_settings/);
  assert.match(form, /SearchableSelect/); assert.match(form, /portalMenu/);
  assert.doesNotMatch(form, /localStorage.setItem|fetch\(/);
});

test('all nine additional columns round-trip independently and legacy flags migrate only once', () => {
  const company = { department_codes: JSON.stringify({ enabled: true, items: [] }) };
  const migrated = core.parseCompanyDigitizationSettings(undefined, company);
  assert.equal(migrated.additionalColumns.departmentCode.required, true);
  assert.equal(Object.keys(migrated.additionalColumns).length, 9);
  migrated.additionalColumns.departmentCode.required = false;
  migrated.additionalColumns.note = { required: true, automatic: true, defaultValue: 'Invoice note', defaultLabel: '' };
  const saved = core.parseCompanyDigitizationSettings(core.serializeCompanyDigitizationSettings(migrated), company);
  assert.equal(saved.additionalColumns.departmentCode.required, false);
  assert.deepEqual(saved.additionalColumns.note, migrated.additionalColumns.note);
  assert.equal(core.parseCompanyDigitizationSettings().additionalColumns.note.required, false);
  const malformed = core.parseCompanyDigitizationSettings('{"additionalColumns":{"note":{"required":"true","automatic":1,"defaultValue":12,"apiKey":"secret"}}}');
  assert.deepEqual(malformed.additionalColumns.note, { required: false, automatic: false, defaultValue: '', defaultLabel: '' });
  assert.doesNotMatch(core.serializeCompanyDigitizationSettings(malformed), /secret/);
});

test('automatic defaults respect stage, keep manual values, fill each empty allocation and never change amounts', () => {
  const settings = core.parseCompanyDigitizationSettings();
  settings.additionalColumns.departmentCode = { required: true, automatic: true, defaultValue: 'ADMIN', defaultLabel: 'Administration' };
  settings.additionalColumns.note = { required: true, automatic: false, defaultValue: 'Do not assign', defaultLabel: '' };
  settings.additionalColumns.accountableResponsible = { required: false, automatic: true, defaultValue: 'user-1', defaultLabel: 'Test User' };
  const company = { document_export_settings: core.serializeCompanyDigitizationSettings(settings) };
  const doc = { id: 'doc', department_code: '', notes: '', total_amount: '121.00', summary_line_items: [{ department: '', subtotal: '100' }, { department: 'SALES' }], line_items: [{ department: '' }] };
  const before = structuredClone(doc);
  const filled = additional.applyAdditionalColumnDefaults(doc, company, 'digitization');
  assert.equal(filled.department_code, 'ADMIN');
  assert.deepEqual(filled.summary_line_items.map(row => row.department), ['ADMIN', 'SALES']);
  assert.equal(filled.notes, ''); assert.equal(filled.total_amount, '121.00');
  assert.equal(filled.accountable_responsible_id, 'user-1'); assert.equal(filled.accountable_responsible, 'Test User');
  assert.deepEqual(doc, before);
  assert.deepEqual(additional.applyAdditionalColumnDefaults(doc, company, 'export'), doc);
  assert.deepEqual(additional.applyAdditionalColumnDefaults({ ...doc, entry_method: 'manual' }, company, 'digitization'), { ...doc, entry_method: 'manual' });
  assert.equal(additional.applyAdditionalColumnDefaults({ ...doc, department_code: 'MANUAL' }, company, 'digitization').department_code, 'MANUAL');
});
