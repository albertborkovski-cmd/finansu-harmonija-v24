import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const api = {};
new Function('exports', ts.transpileModule(read('../src/lib/companyBankAccountDisplay.ts'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText)(api);
const label = api.companyBankAccountLabel;
const alice = '00000000-0000-4000-8000-000000000002';
const first = '10000000-0000-4000-8000-000000000004';
const second = '10000000-0000-4000-8000-000000000003';

test('original Alice Stone demo rows show SEB and Swedbank without adding real accounts', () => {
  assert.equal(label(first, alice, {}), 'SEB · •••• 1234');
  assert.equal(label(second, alice, {}), 'Swedbank · •••• 5678');
  assert.equal(label(first, 'other-company', {}), '—');
  assert.equal(label('other-record', alice, {}), '—');
});

test('stored organization accounts override examples and show only the last four IBAN characters', () => {
  const account = { bank: ' SEB ', iban: 'LT12 1000 0111 0100 5678 ' };
  const before = structuredClone(account);
  assert.equal(label(first, alice, account), 'SEB · •••• 5678');
  assert.deepEqual(account, before);
  assert.equal(label(second, alice, { iban: 'LT121000011101009876' }), '•••• 9876');
  assert.equal(label('other-record', 'other-company', { bank: 'Swedbank', iban: 'LT121000011101001234' }), 'Swedbank · •••• 1234');
});

test('Bank renders the account label and keeps the transaction account distinct from counterparty IBAN', () => {
  const view = read('../src/components/CompanyBankView.tsx');
  assert.match(view, /bankAccount: companyBankAccountLabel\(document.id, company.id, transactionAccount\)/);
  assert.match(view, /iban: bank.bankAccount/);
  assert.match(view, /counterpartyIban: bank\?\.counterpartyIban/);
  assert.doesNotMatch(view, /bankAccount: bank.bankAccount \|\|/);
});
