import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const inline = {}, details = {}, statuses = {}, bank = {};
new Function('exports', compile('../src/lib/documentInlineEditing.ts'))(inline);
new Function('exports', compile('../src/lib/documentProcessingStatus.ts'))(statuses);
new Function('exports', 'require', compile('../src/lib/documentDetailEditing.ts'))(details, name => name === './documentInlineEditing' ? inline : statuses);
new Function('exports', 'require', compile('../src/lib/bankTransaction.ts'))(bank, name => name === './documentInlineEditing' ? inline : details);
const company = { id: 'company-a', name: 'Alice Stone', base_currency: 'EUR', organization_bank_accounts: JSON.stringify([{ bank: 'SEB', iban: 'LT123', primary: true }]) };
const options = { allowed: true, accountIbans: ['LT123'], counterparties: [], glAccounts: ['4430'], reconciled: false };
function fixture() {
  const creation = {}, statement = {}, api = {}, store = new Map(); let allowed = true;
  const issues = {}, storno = {};
  new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
  const require = name => {
    if (name === './bankTransaction') return bank;
    if (name === './bankTransactionCreation') return creation;
    if (name === './bankStatementImport') return statement;
    if (name === './companyBankEditing') return { canEditCompanyBankEntries: () => allowed };
    if (name === './documentRowActionAccess') return { canCreateCompanyDocument: () => allowed };
    if (name === './recordLifecycle') return { isInactiveRecord: row => Boolean(row.inactive || row.active === false), removeOrDeactivateRecords: rows => rows };
    if (name === './invoiceCreation') return { loadInvoiceCounterparties: () => [] };
    if (name === '../components/GeneralLedgerView') return { loadCompanyGeneralLedgerAccountHierarchy: () => [{ code: '4430' }] };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    throw Error(name);
  };
  new Function('exports', 'require', compile('../src/lib/bankTransactionCreation.ts'))(creation, require);
  new Function('exports', 'require', compile('../src/lib/bankStatementImport.ts'))(statement, require);
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Static test'); }, class {});
  const put = (table, value) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(value));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('companies', [company]); put('documents', [{ id: 'other', company_id: 'other-company', number: 'UNCHANGED' }]); put('document_history', []);
  const draft = () => ({ ...creation.newBankTransactionDocument(company, 'bank-new', '2026-11-12').bank_transaction,
    bankAccount: 'LT123', currency: 'EUR',
    counterpartyName: 'Test supplier', paymentPurpose: 'Payment for invoice TEST-1', amount: '-120.00', referenceNo: 'TEST-1',
    allocations: [{ id: 'line-1', description: 'Supplier payment', glAccount: '4430', department: '', project: '', costCenter: '', amount: '-120.00' }] });
  return { ...creation, ...statement, ...api, draft, get, put, revoke: () => { allowed = false; } };
}

test('new form is unsaved, company-scoped and defaults to New / Draft without a posting', () => {
  const f = fixture(), before = f.get('documents');
  const record = f.newBankTransactionDocument(company, 'new-id');
  assert.equal(record.company_id, company.id);
  for (const field of ['date', 'bankAccount', 'counterpartyName', 'counterpartyIban', 'paymentPurpose', 'amount', 'currency', 'exchangeRateDate', 'referenceNo']) assert.equal(record.bank_transaction[field], '');
  assert.equal(record.status, 'Draft'); assert.equal(record.bank_processing_status, 'New');
  assert.equal(record.bank_transaction.amount, ''); assert.equal(record.accounting_posting, undefined);
  assert.deepEqual(f.get('documents'), before);
});
test('manual entry creation validates ownership, fields and balanced allocations', () => {
  const f = fixture();
  const actual = f.prepareNewBankTransaction(company, 'bank-new', f.draft(), options, '2026-11-12T12:00:00Z', 'Test accountant');
  assert.equal(actual.bank_transaction.amount, '-120.00'); assert.equal(actual.number, 'TEST-1');
  assert.equal(actual.source, 'Manual bank entry'); assert.equal(actual.bank_processing_status, 'New');
  assert.equal(actual.created_by, 'Test accountant'); assert.equal(actual.accounting_posting, undefined);
  for (const patch of [{ bankAccount: 'FOREIGN' }, { counterpartyName: '' }, { counterpartyId: 'FOREIGN' }, { paymentPurpose: '' },
    { amount: '-121' }, { currency: 'INVALID' }, { date: '2026-02-31' }, { originalStatement: 'Fake import' }, { extraField: true },
    { allocations: [{ ...f.draft().allocations[0], glAccount: 'FOREIGN' }] }])
    assert.throws(() => f.prepareNewBankTransaction(company, 'bank-new', { ...f.draft(), ...patch }, options, '2026-11-12', 'Tester'));
  assert.throws(() => f.prepareNewBankTransaction(company, 'bank-new', f.draft(), { ...options, allowed: false }, '2026-11-12', 'Tester'));
});
test('save creates one bank record with history and retains other records; duplicates and revoked access are rejected', async () => {
  const f = fixture(), other = f.get('documents')[0];
  const saved = await f.createBankTransaction(company.id, 'bank-new', f.draft());
  assert.equal(f.get('documents').length, 2); assert.deepEqual(f.get('documents')[0], other);
  assert.equal(saved.detail_edit_history[0].action, 'Bank transaction created');
  assert.equal(f.get('document_history')[0].document_id, saved.id);
  assert.equal(bank.bankReconciliation(saved.id, company.id, null).status, 'Unmatched');
  await assert.rejects(f.createBankTransaction(company.id, 'bank-new', f.draft()), /already been saved/);
  f.revoke(); await assert.rejects(f.createBankTransaction(company.id, 'another', f.draft()), /permission/);
  assert.equal(f.get('documents').length, 2);
});
test('Bank toolbar uses the system plus action and opens the existing editor in create mode', () => {
  const view = read('../src/components/CompanyBankView.tsx'), editor = read('../src/components/BankTransactionEditor.tsx');
  assert.match(view, /ml-auto flex flex-wrap items-center justify-end/);
  const pageActions = view.slice(view.indexOf('<PageHeader title="Bank transaction"'), view.indexOf('<CompanyBreadcrumb'));
  assert.match(view, /<CompanyBreadcrumb companyName=\{company.name\} items=\{\["Bank", "Bank transaction"\]\}/);
  assert.match(read('../src/components/CompanyDetail.tsx'), /\{ id: 'transactions', label: 'Bank transaction' \}/);
  assert.match(pageActions, /actions=\{<>/);
  assert.match(pageActions, />Import statement<\/PageActionButton>/);
  assert.match(pageActions, />New transaction<\/PageActionButton>/);
  const tableToolbar = view.slice(view.indexOf('<OcrSearchField'), view.indexOf('<div ref={tableScrollRef}'));
  assert.doesNotMatch(tableToolbar, /Import statement|New transaction/);
  assert.match(view, /PageActionButton icon=\{<Plus size=\{16\} \/>\} onClick=\{openNewTransaction\}/);
  assert.match(view, /mode="create" document=\{newTransaction\}/);
  assert.match(editor, /createBankTransaction\(company.id, record.id, draft\)/);
  assert.match(editor, /isCreate \? 'Save' : 'Save changes'/);
  assert.match(editor, /isCreate \? 'New bank transaction' : 'Bank transaction details'/);
  assert.match(editor, /useState\(new Set\(\[1, 2\]\)\)/);
  assert.match(editor, /number === 1 && !isCreate && <fieldset/);
});

test('statement CSV parses signed values and quoted descriptions, and rejects invalid rows', () => {
  const f = fixture();
  const csv = '\uFEFFDate;Counterparty name;Purpose of payment;Amount;Currency\r\n2026-11-12;Customer;"Payment; invoice \\"1\\"";+894,19;eur\r\n'.replaceAll('\\"', '""');
  const rows = f.parseBankStatementCsv(csv);
  assert.equal(rows[0].amount, '894.19'); assert.equal(rows[0].currency, 'EUR');
  assert.equal(rows[0].paymentPurpose, 'Payment; invoice "1"');
  for (const invalid of ['', 'Date;Amount\n2026-11-12;1', f.BANK_STATEMENT_TEMPLATE.replace('894.19', '1e4'),
    f.BANK_STATEMENT_TEMPLATE.replace('2026-11-01', '2026-02-30'), f.BANK_STATEMENT_TEMPLATE.replace('894.19', '0'),
    f.BANK_STATEMENT_TEMPLATE.replace('894.19', '12.345'), f.BANK_STATEMENT_TEMPLATE.replace('894.19', 'NaN')])
    assert.throws(() => f.parseBankStatementCsv(invalid));
});

test('statement imports are company-scoped, atomic, deduplicated and leave postings/matching unchanged', async () => {
  const f = fixture(), before = f.get('documents');
  await assert.rejects(f.importBankStatement(company.id, 'FOREIGN', f.BANK_STATEMENT_TEMPLATE, 'statement.csv'), /bank account/);
  assert.deepEqual(f.get('documents'), before);
  await assert.rejects(f.importBankStatement(company.id, 'LT123', f.BANK_STATEMENT_TEMPLATE.replace('-684.86', 'bad'), 'statement.csv'), /Row 3/);
  assert.deepEqual(f.get('documents'), before);
  assert.deepEqual(await f.importBankStatement(company.id, 'LT123', f.BANK_STATEMENT_TEMPLATE, 'statement.csv'), { imported: 2, duplicates: 0 });
  const added = f.get('documents').slice(1);
  assert.deepEqual(f.get('documents')[0], before[0]);
  for (const row of added) {
    assert.equal(row.company_id, company.id); assert.equal(row.source, 'Bank import');
    assert.equal(row.bank_processing_status, 'New'); assert.equal(row.status, 'Draft');
    assert.equal(row.accounting_posting, undefined); assert.equal(row.bank_transaction.allocations[0].glAccount, '');
    assert.equal(row.bank_transaction.originalStatement, row.bank_transaction.paymentPurpose);
    assert.equal(row.detail_edit_history[0].action, 'Bank statement imported');
    assert.equal(bank.bankReconciliation(row.id, company.id, null).status, 'Unmatched');
  }
  assert.deepEqual(await f.importBankStatement(company.id, 'LT123', f.BANK_STATEMENT_TEMPLATE, 'renamed.csv'), { imported: 0, duplicates: 2 });
  assert.equal(f.get('documents').length, 3);
  f.revoke(); await assert.rejects(f.importBankStatement(company.id, 'LT123', f.BANK_STATEMENT_TEMPLATE, 'statement.csv'), /permission/);
});

test('statement action uses system design and opens a reviewable import, not IMPORTDATA history', () => {
  const view = read('../src/components/CompanyBankView.tsx'), dialog = read('../src/components/BankStatementImportDialog.tsx');
  assert.match(view, /PageActionButton icon=\{<Upload size=\{16\} \/>\}/);
  assert.match(view, /<BankStatementImportDialog company=\{company\}/);
  assert.match(dialog, /role="dialog" aria-modal="true"/);
  assert.match(dialog, /aria-label="Statement preview"/);
  assert.match(dialog, /importBankStatement\(company.id, bankAccount, file.text, file.name\)/);
});
