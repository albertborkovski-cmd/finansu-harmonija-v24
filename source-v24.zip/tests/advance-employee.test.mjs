import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = name => readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');
const modules = {};
function load(name) {
  if (modules[name]) return modules[name];
  const exports = modules[name] = {};
  const compiled = ts.transpileModule(read(`lib/${name}.ts`), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', compiled)(exports, dependency => load(dependency.replace('./', '')));
  return exports;
}
const employee = load('invoiceAdvanceEmployee'), accounting = load('advanceEmployeeAccounting'), storno = load('documentStorno'), subtype = load('documentSubtypeOptions'), ocr = load('ocrRequiredFields');
const company = { id: 'c1', name: 'Alice Stone' };
const users = [
  { id: 'e1', fullName: 'Ieva Vaitkutė', email: 'ieva@example.test', organizations: 'Alice Stone', status: 'Active' },
  { id: 'e2', fullName: 'Tomas Petrauskas', organizations: 'c1', status: 'Enabled' },
  { id: 'e3', fullName: 'Other company', organizations: 'Other', status: 'Active' },
  { id: 'e4', fullName: 'Blocked', organizations: 'Alice Stone', status: 'Blocked' },
  { id: 'e5', fullName: 'Inactive', organizations: 'Alice Stone', status: 'Active', inactive: true },
];
const invoice = () => ({ id: 'd1', company_id: 'c1', number: 'INV-1', document_type: 'INVOICES', document_subtype: 'INVOICE', document_purpose: 'Purchase', type: 'Purchase', status: 'Approved', currency: 'USD', total_amount: '121.00',
  accounting_posting: { id: 'p1', number: 'GL-1', companyId: 'c1', documentId: 'd1', status: 'Posted', date: '2026-11-01', postedAt: '2026-11-01T10:00:00Z', postedBy: 'Accountant', baseCurrency: 'EUR', integration: { destination: 'Local', status: 'Not sent' },
    lines: [
      { id: 'l1', account: '6000', accountName: 'Purchases', currency: 'USD', debitMinor: 10000, creditMinor: 0, baseDebitMinor: 9000, baseCreditMinor: 0, costCenter: 'C1' },
      { id: 'l2', account: '2441', accountName: 'Input VAT', currency: 'USD', debitMinor: 2100, creditMinor: 0, baseDebitMinor: 1890, baseCreditMinor: 0 },
      { id: 'l3', account: '4430', accountName: 'Payables', currency: 'USD', debitMinor: 0, creditMinor: 12100, baseDebitMinor: 0, baseCreditMinor: 10890 },
    ] } });
const context = () => ({ allowed: true, actor: 'Accountant', now: '2026-11-16T10:00:00Z', today: '2026-11-16', period: { enabled: false, cutoffDay: 25 } });
const assign = document => employee.normalizeAdvanceEmployeeDocument({ ...document, advance_employee_id: 'e1' }, users);

test('only active company External contacts; explicit empty assignment overrides legacy names', () => {
  assert.deepEqual(employee.assignedAdvanceEmployees(company, users, null).map(row => row.id), ['e1', 'e2']);
  assert.deepEqual(employee.assignedAdvanceEmployees(company, users, []), []);
  assert.deepEqual(employee.assignedAdvanceEmployees(company, users, ['e2', 'e3', 'e4']).map(row => row.id), ['e2', 'e3']);
});
test('manual and OCR identity resolution forces Advance invoice only for purchases', () => {
  const input = invoice(), before = structuredClone(input), next = assign(input);
  assert.deepEqual(input, before); assert.equal(next.document_subtype, 'ADVANCE_INVOICE'); assert.equal(next.advance_employee, users[0].fullName);
  assert.equal(employee.normalizeAdvanceEmployeeDocument({ ...input, advance_employee: 'ieva@example.test' }, users).advance_employee_id, 'e1');
  assert.throws(() => employee.normalizeAdvanceEmployeeDocument({ ...input, advance_employee_id: 'foreign' }, users), /assigned/);
  assert.throws(() => employee.resolveAdvanceEmployee('', users[0].fullName, [users[0], { ...users[0], id: 'duplicate' }]), /assigned/);
  const sale = employee.normalizeAdvanceEmployeeDocument({ ...next, document_purpose: 'Sale' }, users);
  assert.equal(sale.advance_employee_id, ''); assert.equal(sale.advance_employee, '');
  assert.throws(() => assign({ ...input, document_subtype: 'CREDIT_INVOICE' }), /corrective/);
});
test('selection restores prior kind when cleared and never enables a Sale employee', () => {
  const original = { purpose: 'Purchase', kind: 'VAT_INVOICE' };
  const selected = employee.selectInvoiceAdvanceEmployee(original, 'e1');
  assert.equal(selected.kind, 'ADVANCE_INVOICE');
  assert.equal(employee.selectInvoiceAdvanceEmployee(selected, '').kind, 'VAT_INVOICE');
  assert.equal(employee.selectInvoiceAdvanceEmployee({ purpose: 'Sale', kind: 'INVOICE' }, 'e1').advanceEmployeeId, '');
});
test('employee assignment leaves original GL intact and defers transfers to reconciliation', () => {
  const original = invoice(), before = structuredClone(original);
  const next = accounting.prepareAdvanceEmployeeAccounting(original, assign(original), context());
  assert.deepEqual(original, before); assert.deepEqual(next.accounting_posting, original.accounting_posting);
  assert.equal(next.accounting_storno, undefined); assert.equal(next.document_storno, undefined);
  assert.equal(next.status, 'Approved'); assert.equal(next.advance_employee_reversal, undefined);
  assert.equal(storno.documentPostingRows(next, new Set()).length, 3);
  const repeat = accounting.prepareAdvanceEmployeeAccounting(next, structuredClone(next), context());
  assert.deepEqual(repeat.advance_employee_reversal, next.advance_employee_reversal);
  assert.equal(repeat.advance_employee_history.length, 1);
  assert.equal(accounting.prepareAdvanceEmployeeAccounting(next, { ...next, advance_employee_id: 'e2' }, context()).advance_employee_id, 'e2');
});
test('unposted documents keep assignment without inventing GL accounts or entries', () => {
  const original = { ...invoice(), status: 'Draft', accounting_posting: undefined };
  const next = accounting.prepareAdvanceEmployeeAccounting(original, assign(original), context());
  assert.equal(next.advance_employee_reversal, undefined); assert.equal(next.advance_employee_history.length, 1);
  assert.equal(next.advance_employee_id, 'e1'); assert.equal(storno.documentPostingRows(next, new Set()).length, 0);
});
test('assignment changes no posting in closed periods; unavailable document states remain blocked', () => {
  const original = invoice();
  assert.equal(accounting.prepareAdvanceEmployeeAccounting(original, assign(original), { ...context(), period: { enabled: true, cutoffDay: 25, closedThrough: '2026-11-16' } }).advance_employee_reversal, undefined);
  for (const patch of [{ status: 'Transferred' }, { inactive: true }, { document_storno: {} }, { accounting_storno: {} }])
    assert.throws(() => accounting.prepareAdvanceEmployeeAccounting(original, assign({ ...original, ...patch }), context()));
  assert.throws(() => storno.guardPostedDocumentMutation(original, { advance_employee_history: [] }));
  assert.throws(() => storno.guardPostedDocumentMutation(original, { advance_employee_reversal: {} }));
});
test('already saved employee reversal and its original source remain immutable legacy history', () => {
  const original = assign(invoice());
  const reversal = storno.createDocumentStorno(original, { date: context().today, reason: 'Existing saved operation', expectedPosting: JSON.stringify(original.accounting_posting) }, context()).accounting_storno;
  const previous = { ...original, advance_employee_reversal: reversal, advance_employee_history: reversal.history };
  const result = accounting.prepareAdvanceEmployeeAccounting(previous, structuredClone(previous), context());
  assert.deepEqual(result, previous);
  assert.throws(() => accounting.prepareAdvanceEmployeeAccounting(previous, { ...previous, advance_employee_id: 'e2' }, context()), /already/);
});
const catalog = [
  { code: 'INVOICES', fullName: 'Invoices', parentCode: '', status: 'Active' },
  { code: 'INVOICE', fullName: 'Invoice', parentCode: 'INVOICES', status: 'Active' },
  { code: 'ADVANCE_INVOICE', fullName: 'Advance invoice', parentCode: 'INVOICES', status: 'Active' },
  { code: 'OLD', fullName: 'Old', parentCode: 'INVOICES', status: 'Inactive' },
  { code: 'CONTRACTS', fullName: 'Contracts', parentCode: '', status: 'Active' },
  { code: 'SERVICE_CONTRACT', fullName: 'Service contract', parentCode: 'CONTRACTS', status: 'Active' },
];
test('Subtype dropdown uses active children of the selected OCR parent only', () => {
  assert.deepEqual(subtype.documentSubtypeOptions(catalog, 'INVOICES').map(row => row.value), ['INVOICE', 'ADVANCE_INVOICE']);
  assert.deepEqual(subtype.documentSubtypeOptions(catalog, 'CONTRACTS').map(row => row.value), ['SERVICE_CONTRACT']);
  assert.equal(subtype.documentSubtypeOptions(catalog, 'UNKNOWN').length, 0);
  assert.throws(() => subtype.validateDocumentSubtype(catalog, 'INVOICES', 'SERVICE_CONTRACT'), /subtype/);
  assert.throws(() => subtype.validateDocumentSubtype(catalog, 'INVOICES', 'OLD'), /subtype/);
  assert.doesNotThrow(() => subtype.validateDocumentSubtype(catalog, 'INVOICES', 'ADVANCE_INVOICE'));
});
test('OCR completion propagates employee while respecting current document category', () => {
  const task = { documentType: 'INVOICE', advanceEmployeeId: 'e1', fields: { invoiceNumber: 'INV-2', invoiceDate: '2026-11-16', companyName: 'Supplier', totalAmount: '121.00', taxRate: '21', dueDate: '' } };
  const patch = ocr.ocrCompletionPatch(task, catalog, invoice());
  assert.equal(patch.advance_employee_id, 'e1'); assert.equal(patch.document_subtype, 'ADVANCE_INVOICE');
  assert.equal(ocr.ocrCompletionPatch({ ...task, documentType: 'SERVICE_CONTRACT' }, catalog, invoice()).document_subtype, 'SERVICE_CONTRACT');
  assert.equal(ocr.ocrCompletionPatch(task, catalog, { ...invoice(), document_purpose: 'Sale' }).document_subtype, 'INVOICE');
});
test('imported editor has subtype selector, a functional note dialog and no duplicate note input', () => {
  const panel = read('components/DocumentDetailPanel.tsx');
  assert.match(panel, /documentSubtypeOptions\(documentTypes, header.documentType\)/);
  assert.match(panel, /setShowNoteDialog\(true\)/);
  assert.match(panel, /DocumentNoteDialog value=\{header.note\}/);
  assert.doesNotMatch(panel, /EditableValueField label=\{uiText\("Note"\)\}/);
  assert.doesNotMatch(panel, /EditableOptionField label=\{uiText\("Type"\)\}/);
});

test('Advance employee uses the same typography and control geometry as adjacent document fields', () => {
  const panel = read('components/DocumentDetailPanel.tsx');
  const systemField = panel.slice(panel.indexOf('function EditableOptionField'), panel.indexOf('function Cell('));
  const advanceField = panel.slice(panel.indexOf("<span className=\"font-montserrat text-[14px] font-semibold leading-5 text-[#10233A]\">{uiText('Advance employee')"), panel.indexOf('{isAccountingNote && (', panel.indexOf("{uiText('Advance employee')}")));
  const control = systemField.match(/className="(h-8[^"]+)"/)[1];
  assert.ok(advanceField.includes(`className="${control}"`));
  assert.match(advanceField, /font-montserrat text-\[14px\] font-semibold leading-5/);
  assert.match(read('components/AdvanceEmployeeSelect.tsx'), /className=\{className \|\|/);
});
