import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {};
new Function('exports', compile('../src/lib/bankProcessingStatus.ts'))(core);

test('four FH processing choices and demo statuses do not depend on invoice or reconciliation states', () => {
  assert.deepEqual(core.BANK_PROCESSING_STATUSES, ['New', 'Invalid', 'Corrected', 'Approved']);
  assert.equal(core.bankProcessingStatus({ id: '10000000-0000-4000-8000-000000000004', status: 'Draft' }), 'New');
  assert.equal(core.bankProcessingStatus({ id: '10000000-0000-4000-8000-000000000003', status: 'Transferred' }), 'Approved');
  assert.equal(core.bankProcessingStatus({ id: 'other', status: 'Approved', reconciliationStatus: 'Matched' }), 'New');
  for (const value of core.BANK_PROCESSING_STATUSES) assert.equal(core.bankProcessingStatus({ id: 'other', bank_processing_status: value }), value);
  assert.equal(core.bankProcessingStatus({ id: 'other', bank_processing_status: 'Paid' }), 'New');
});

test('status command validates options, permissions, ownership, availability and stale status', () => {
  const document = { id: 'entry', company_id: 'a', status: 'Transferred' };
  const patch = (value = 'Invalid', source = document, allowed = true, expected = 'New') => core.bankProcessingStatusPatch(source, 'a', value, expected, allowed);
  assert.deepEqual(patch(), { bank_processing_status: 'Invalid' });
  assert.throws(() => patch('Paid'), /Select New/);
  assert.throws(() => patch('Approved', document, false), /permission/);
  for (const change of [{ company_id: 'b' }, { document_deletion: {} }, { inactive: true }, { active: false }, { is_active: false }]) assert.throws(() => patch('Approved', { ...document, ...change }));
  assert.throws(() => patch('Approved', { ...document, bank_processing_status: 'Corrected' }), /changed/);
  assert.equal(document.status, 'Transferred');
});

function fixture() {
  const store = new Map(); let allowed = true;
  const api = {}, issues = {}, storno = {};
  new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
  const require = name => {
    if (name === './bankProcessingStatus') return core;
    if (name === './companyBankEditing') return { canEditCompanyBankEntries: () => allowed };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './documentTestingExamples') return { createDocumentTestingExamples: () => [] };
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage: { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) }, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Static test'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', [{ id: 'entry', company_id: 'a', status: 'Transferred', total_amount: '100', bank_transaction: { amount: '-100' }, accounting_posting: { id: 'posted' } }, { id: 'other', company_id: 'b', status: 'Draft' }]);
  put('companies', [{ id: 'a', name: 'Alice Stone' }]); put('document_history', []);
  return { ...api, get, put, revoke: () => { allowed = false; } };
}

test('status persists with audit, without changing invoice approval, bank amounts, posting or other companies', async () => {
  const f = fixture(), previous = structuredClone(f.get('documents'));
  const saved = await f.saveBankProcessingStatus('entry', 'a', 'Approved', 'New');
  assert.equal(saved.bank_processing_status, 'Approved');
  for (const [key, value] of Object.entries(previous[0])) assert.deepEqual(saved[key], value, key);
  assert.deepEqual(f.get('documents')[1], previous[1]);
  assert.equal(f.get('document_history')[0].action, 'Bank processing status changed');
  assert.equal(saved.detail_edit_history[0].user_name, 'Test accountant');
  assert.equal(core.bankProcessingStatus(f.get('documents')[0]), 'Approved');
  await f.saveBankProcessingStatus('entry', 'a', 'Approved', 'Approved');
  assert.equal(f.get('document_history').length, 1);
  await assert.rejects(f.saveBankProcessingStatus('entry', 'a', 'Invalid', 'New'), /changed/);
  await assert.rejects(f.saveBankProcessingStatus('entry', 'b', 'Invalid', 'Approved'), /no longer available/);
  f.revoke(); await assert.rejects(f.saveBankProcessingStatus('entry', 'a', 'Invalid', 'Approved'), /permission/);
});

test('Bank status uses the shared portalled dropdown and the editor shows the same independent status', () => {
  const view = read('../src/components/CompanyBankView.tsx');
  assert.match(view, /<DocumentInlineSelectCell/);
  assert.match(view, /options=\{BANK_STATUS_OPTIONS\}/);
  assert.match(view, /saveBankProcessingStatus\(row.documentId, company.id, value, row.status\)/);
  assert.doesNotMatch(view, /confirmed:|CONFIRMED_STATUSES/);
  assert.match(read('../src/components/BankTransactionEditor.tsx'), /\{bankProcessingStatus\(record\)\}/);
});
