import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(`../src/${file}`, import.meta.url), 'utf8');
const compile = source => ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const parser = {};
new Function('exports', compile(read('lib/companyExpenseImport.ts')))(parser);
const draft = (code, name = 'Office supplies', alternativeCodes = '') => ({ code, name, alternativeCodes });

test('Excel import takes exactly Code + Name and preserves leading zeroes and strings', () => {
  assert.deepEqual(parser.parseExpenseCodePaste('001\tAccounting services\r\n002\tOffice supplies\r\n'), [draft('001', 'Accounting services'), draft('002')]);
  assert.deepEqual(parser.parseExpenseCodePaste('\uFEFFKodas\tPavadinimas\n001\tPaslauga'), [draft('001', 'Paslauga')]);
  assert.deepEqual(parser.parseExpenseCodePaste('Code\tDescription\n00009\tTravel'), [draft('00009', 'Travel')]);
  assert.deepEqual(parser.parseExpenseCodePaste(' A-02 \t Name, with comma \n\n'), [draft('A-02', 'Name, with comma')]);
  assert.deepEqual(parser.parseExpenseCodePaste(''), []);
});

test('quoted Excel descriptions may contain tabs, line breaks and escaped quotes', () => {
  assert.deepEqual(parser.parseExpenseCodePaste('001\t"Travel\tand\n""transport"""'), [draft('001', 'Travel\tand\n"transport"')]);
  assert.throws(() => parser.parseExpenseCodePaste('001\t"Missing quote'), /quotation/);
  assert.throws(() => parser.parseExpenseCodePaste('001\t"Name"extra'), /quotation/);
});

test('bad shape and oversized clipboard contents are rejected, not silently truncated', () => {
  assert.throws(() => parser.parseExpenseCodePaste('001\tName\tCode'), /exactly two/);
  assert.throws(() => parser.parseExpenseCodePaste('001,Name'), /exactly two/);
  assert.throws(() => parser.parseExpenseCodePaste('x'.repeat(1_000_001)), /1,000/);
  assert.throws(() => parser.parseExpenseCodePaste(Array.from({ length: 1001 }, (_, i) => `${i}\tName`).join('\n')), /1,000/);
  assert.equal(parser.parseExpenseCodePaste('Code\tName\n' + Array.from({ length: 1000 }, (_, i) => `${i}\tName`).join('\n')).length, 1000);
});

test('blank required values and all duplicate occurrences are highlighted, including inactive existing codes', () => {
  const errors = parser.expenseCodeRowErrors([draft('AA'), draft(' aa '), draft('old'), draft('', '')], [{ code: 'OLD', active: false }]);
  assert.match(errors[0].join(), /repeated/); assert.match(errors[1].join(), /repeated/);
  assert.match(errors[2].join(), /already exists/);
  assert.deepEqual(errors[3], ['Code is required.', 'Name is required.']);
  assert.throws(() => parser.validateExpenseCodeImport([draft('001'), draft('', 'Name')], 'Code', []), /highlighted/);
  assert.throws(() => parser.validateExpenseCodeImport([], 'Code', []), /Enter a code/);
  assert.throws(() => parser.validateExpenseCodeImport([draft('001')], 'Unknown', []), /Select Code/);
});

test('one selected type is applied to every pasted row; alternative codes are optional and normalized', () => {
  const values = parser.validateExpenseCodeImport([draft('001', ' Service ', 'A; B, A\nC'), draft('002')], 'Service', []);
  assert.deepEqual(values[0], { code: '001', name: 'Service', expenseType: 'Service', alternativeCodes: ['A', 'B', 'C'] });
  assert.equal(values[1].expenseType, 'Service');
  assert.deepEqual(values[1].alternativeCodes, []);
});

const source = read('components/GeneralLedgerView.tsx');
const ast = ts.createSourceFile('ledger.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const names = ['applyCompanyLedgerCustomization', 'buildCompanyLedgerCustomization', 'importCompanyExpenseCodes', 'loadCompanyGeneralLedgerAccounts', 'loadCompanyGeneralLedgerAccountHierarchy'];
const functions = ast.statements.filter(node => ts.isFunctionDeclaration(node) && names.includes(node.name?.text)).map(node => node.getText(ast)).join('\n');
function harness({ allowed = true, inactive = false, ledger = 'Standard', initial, failWrite = false } = {}) {
  const templates = [{ id: 'standard', name: 'Standard', active: true, accounts: [{ id: 'base', code: '6000', name: 'Base', type: 'Expense', active: true }] }];
  const storage = new Map(initial || []), writes = [], events = [], calls = [];
  const module = { exports: {} };
  let sequence = 0;
  runInNewContext(compile(functions), {
    exports: module.exports, validateExpenseCodeImport: parser.validateExpenseCodeImport,
    loadGeneralLedgerTemplates: () => templates, canEditCompanySettings: () => allowed, isInactiveRecord: company => company.inactive,
    STORAGE_KEY: 'global-templates', crypto: { randomUUID: () => `uuid-${++sequence}` },
    supabase: { from: table => { calls.push(table); return { select: () => ({ eq: async (key, id) => {
      calls.push([key, id]); return { data: [{ id, name: id, general_ledger: ledger, inactive }], error: null };
    } }) }; } },
    CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options?.detail; } },
    window: { localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => {
      if (failWrite) throw new Error('Quota exceeded'); writes.push(key); storage.set(key, value);
    } }, dispatchEvent: event => events.push(event) },
  });
  return { api: module.exports, templates, storage, writes, events, calls };
}

test('atomic company import retains overrides, inactive records, deletions and other templates', async () => {
  const key = 'finansu-harmonija:v12:company-general-ledger:alice';
  const custom = { standard: { overrides: { base: { id: 'base', code: '6000', name: 'Alice override', type: 'Expense', active: false } },
    additions: [{ id: 'custom', code: 'A0', name: 'Existing', type: 'Detail', active: true }], deletedIds: [] },
    unused: { overrides: {}, additions: [], deletedIds: ['retain-me'] } };
  const env = harness({ initial: [[key, JSON.stringify(custom)], ['finansu-harmonija:v12:company-general-ledger:bob', 'unchanged']] });
  const before = JSON.stringify(env.templates);
  const result = await env.api.importCompanyExpenseCodes('alice', 'Standard', [draft('001'), draft('002')], 'Product');
  assert.equal(result.length, 2); assert.equal(result[0].type, 'Detail'); assert.equal(result[0].expenseType, 'Product');
  assert.deepEqual(env.writes, [key]);
  const saved = JSON.parse(env.storage.get(key));
  assert.deepEqual(saved.standard.overrides, custom.standard.overrides);
  assert.deepEqual(saved.unused, custom.unused);
  assert.equal(saved.standard.additions.length, 3);
  assert.equal(env.storage.get('finansu-harmonija:v12:company-general-ledger:bob'), 'unchanged');
  assert.equal(JSON.stringify(env.templates), before);
  assert.deepEqual(env.events.map(event => event.type), ['company-general-ledger-updated', 'organization-reference-updated']);
  assert.deepEqual(env.calls, ['companies', ['id', 'alice']]);
});

test('saved codes and alternative codes are available in the existing company GL / expense dropdown source', async () => {
  const env = harness();
  await env.api.importCompanyExpenseCodes('alice', 'Standard', [draft('001', 'Consulting', 'ALT-1')], 'Service');
  const options = env.api.loadCompanyGeneralLedgerAccountHierarchy('alice', 'Standard');
  assert.equal(options.find(option => option.code === '001').name, 'Consulting');
  assert.deepEqual(Array.from(options.find(option => option.code === '001').alternativeCodes), ['ALT-1']);
  assert.equal(env.api.loadCompanyGeneralLedgerAccountHierarchy('bob', 'Standard').some(option => option.code === '001'), false);
  assert.match(read('lib/supabase.ts'), /documentAssignmentOptions\(company, lookups, loadCompanyGeneralLedgerAccountHierarchy\(company.id, company.general_ledger\)/);
  assert.match(read('components/GeneralLedgerAccountSelect.tsx'), /account.alternativeCodes\?\.some/);
});

test('fresh permissions, company state and changed assignment are checked before writing', async () => {
  for (const config of [{ allowed: false }, { inactive: true }, { ledger: 'Changed' }]) {
    const env = harness(config);
    await assert.rejects(env.api.importCompanyExpenseCodes('alice', 'Standard', [draft('001')], 'Code'), /permission|has changed/);
    assert.equal(env.writes.length, 0); assert.equal(env.events.length, 0);
  }
});

test('duplicate or incomplete batches save nothing and never overwrite existing records', async () => {
  const env = harness();
  for (const rows of [[draft('001'), draft('6000')], [draft('001'), draft('001')], [draft('001'), draft('002', '')]]) {
    await assert.rejects(env.api.importCompanyExpenseCodes('alice', 'Standard', rows, 'Code'), /highlighted/);
    assert.equal(env.writes.length, 0);
  }
  await env.api.importCompanyExpenseCodes('alice', 'Standard', [draft('001')], 'Code');
  await assert.rejects(env.api.importCompanyExpenseCodes('alice', 'Standard', [draft('001')], 'Code'), /highlighted/);
  assert.equal(env.writes.length, 1);
});

test('malformed storage and write failures keep prior data intact and do not announce success', async () => {
  for (const initial of [
    [['finansu-harmonija:v12:company-general-ledger:alice', '{broken']],
    [['finansu-harmonija:v12:company-general-ledger:alice', 'null']],
    [['finansu-harmonija:v12:company-general-ledger:alice', '{"standard":{}}']],
    [['global-templates', '{bad']],
  ]) {
    const env = harness({ initial });
    await assert.rejects(env.api.importCompanyExpenseCodes('alice', 'Standard', [draft('001')], 'Code'), /Could not read/);
    assert.equal(env.writes.length, 0); assert.equal(env.events.length, 0);
    assert.deepEqual([...env.storage], initial);
  }
  const env = harness({ failWrite: true });
  await assert.rejects(env.api.importCompanyExpenseCodes('alice', 'Standard', [draft('001')], 'Code'), /Quota/);
  assert.equal(env.events.length, 0);
});

test('the editor uses shared controls, bounded previews and requires an explicit save after paste', () => {
  const editor = read('components/CompanyExpenseCodeEditor.tsx');
  assert.match(editor, /<SearchableSelect/); assert.match(editor, /portalMenu/);
  assert.match(editor, /<PageActionButton/); assert.match(editor, /sticky top-0/);
  assert.match(editor, /rows.slice\(page \* pageSize/);
  assert.match(editor, /setRows\(parseExpenseCodePaste\(value\)\)/);
  assert.match(editor, /importCompanyExpenseCodes\(companyId, initialTemplateName.current, rows, type\)/);
  assert.match(editor, /invalidCount > 0/);
  assert.doesNotMatch(editor, /\.setItem\(/);
  const list = read('components/OrganizationReferenceLists.tsx');
  assert.match(list, /canEditCompanySettings\(company\) && !isInactiveRecord\(company\)/);
  assert.match(list, /edit\('manual'\)/); assert.match(list, /edit\('excel'\)/);
});
