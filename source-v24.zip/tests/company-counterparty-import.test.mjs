import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const read = path => readFileSync(new URL(`../src/${path}`, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(read(path), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {};
new Function('exports', compile('lib/companyCounterpartyImport.ts'))(core);
const sample = '0007\t012345678\tLT012345678\tUAB Pavyzdys\tLT12 1000 0111 0100 1000; DE89370400440532013000';
const draft = () => core.parseCounterpartyPaste(sample)[0];

test('five-column Excel paste preserves zeroes and accepts multiple IBANs, blank optional cells and headers', () => {
  const rows = core.parseCounterpartyPaste(`Kodas apskaitos programoje\tĮmonės kodas\tPVM kodas\tPavadinimas\tIBAN\r\n${sample}\r\n\t\t\tSecond company\t\r\n`);
  assert.equal(rows.length, 2); assert.equal(rows[0].accountingCode, '0007'); assert.equal(rows[0].companyCode, '012345678');
  assert.deepEqual(core.splitCounterpartyIbans(rows[0].ibans), ['LT121000011101001000', 'DE89370400440532013000']);
  assert.equal(rows[1].name, 'Second company'); assert.equal(rows[1].ibans, '');
  assert.equal(core.parseCounterpartyPaste('1\t2\t3\t"UAB ""Quoted"""\t')[0].name, 'UAB "Quoted"');
});

test('paste rejects incorrect column counts, broken quotes and oversized imports', () => {
  assert.deepEqual(core.parseCounterpartyPaste(' \r\n'), []);
  assert.throws(() => core.parseCounterpartyPaste('one\ttwo'), /five TAB/);
  assert.throws(() => core.parseCounterpartyPaste('1\t2\t3\t"Unclosed\t'), /quotation/);
  assert.throws(() => core.parseCounterpartyPaste(Array(1001).fill(sample).join('\n')), /1,000/);
});

test('duplicate codes are blocked within a batch and this organization, not merged or overwritten', () => {
  const row = draft();
  assert.deepEqual(core.counterpartyDraftErrors([row], []), [[]]);
  assert.match(core.counterpartyDraftErrors([row, row], []).flat().join(' '), /repeated/);
  for (const existing of [{ accounting_system_code: '0007' }, { company_code: '012345678' }, { vat_code: 'lt012345678' }])
    assert.match(core.counterpartyDraftErrors([row], [existing]).flat().join(' '), /already exists/);
  assert.match(core.counterpartyDraftErrors([{ ...row, name: '' }], []).flat().join(' '), /Name is required/);
  assert.match(core.counterpartyDraftErrors([{ ...row, ibans: 'not-iban' }], []).flat().join(' '), /IBAN format/);
});

test('saved companies include compatible bank records and audit and leave original records intact', () => {
  const existing = [{ id: 'previous', name: 'Prior', company_code: '999', inactive: true }], before = structuredClone(existing);
  let id = 0;
  const [saved] = core.prepareCompanyCounterparties([draft()], existing, 'Accountant', '2026-11-18T10:00:00Z', () => `id-${++id}`);
  assert.deepEqual(existing, before); assert.equal(saved.accounting_system_code, '0007');
  assert.deepEqual(core.counterpartyIbans(saved), ['LT121000011101001000', 'DE89370400440532013000']);
  assert.equal(JSON.parse(saved.counterparty_bank_accounts)[0].primary, true);
  assert.equal(JSON.parse(saved.counterparty_activity_log)[0].user, 'Accountant');
  assert.equal(saved.counterparty_created_at, '2026-11-18T10:00:00Z');
});

function commandFixture() {
  const values = new Map([['company:alice', JSON.stringify([{ id: 'prior', name: 'Prior', company_code: '999' }])], ['company:bob', '[]'], ['global', '[]']]);
  let allowed = true, inactive = false, serial = 0;
  const command = {}, events = [];
  new Function('exports', 'require', 'window', 'crypto', 'CustomEvent', compile('lib/saveCompanyCounterparties.ts'))(command, name => {
    if (name === './supabase') return { supabase: { from: () => ({ select: () => ({ eq: async (_, id) => ({ data: [{ id, name: id }], error: null }) }) }) } };
    if (name === './documentEditAccess') return { canEditCompanySettings: () => allowed };
    if (name === './recordLifecycle') return { isInactiveRecord: () => inactive };
    if (name === './organizationDirectory') return { companyCounterpartiesKey: id => `company:${id}` };
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './companyCounterpartyImport') return core;
    throw Error(name);
  }, { localStorage: { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) }, dispatchEvent: event => events.push(event) },
  { randomUUID: () => `test-${++serial}` }, class { constructor(name, options) { this.type = name; this.detail = options.detail; } });
  return { ...command, values, events, revoke: () => { allowed = false; }, deactivate: () => { inactive = true; } };
}

test('save rechecks access, appends only to selected company, detects duplicates and notifies readers', async () => {
  const f = commandFixture();
  assert.equal(await f.saveCompanyCounterparties('alice', [draft()]), 1);
  assert.equal(JSON.parse(f.values.get('company:alice')).length, 2);
  assert.equal(f.values.get('company:bob'), '[]'); assert.equal(f.values.get('global'), '[]');
  assert.equal(f.events[0].type, 'counterparties-updated'); assert.equal(f.events[0].detail.companyId, 'alice');
  await assert.rejects(f.saveCompanyCounterparties('alice', [draft()]), /highlighted/);
  for (const method of ['revoke', 'deactivate']) { const denied = commandFixture(); denied[method](); await assert.rejects(denied.saveCompanyCounterparties('alice', [draft()]), /permission/); }
});

test('corrupt storage is never overwritten and concurrent imports cannot duplicate codes', async () => {
  const f = commandFixture(); f.values.set('company:alice', '{broken');
  await assert.rejects(f.saveCompanyCounterparties('alice', [draft()]), /No companies/); assert.equal(f.values.get('company:alice'), '{broken');
  const concurrent = commandFixture(); const results = await Promise.allSettled([concurrent.saveCompanyCounterparties('alice', [draft()]), concurrent.saveCompanyCounterparties('alice', [draft()])]);
  assert.deepEqual(results.map(row => row.status), ['fulfilled', 'rejected']);
});

test('shared system controls expose manual create, preview/import and string-preserving Excel export', () => {
  const list = read('components/OrganizationReferenceLists.tsx'), editor = read('components/CompanyCounterpartyEditor.tsx');
  assert.match(list, /<CompanyCounterpartyEditor/); assert.match(list, /<PageActionButton[^\n]+Add company/);
  assert.match(list, /XLSX.utils.aoa_to_sheet/); assert.match(list, /counterpartyIbans\(row\).join\('; '\)/);
  assert.match(editor, /Import preview/); assert.match(editor, /pending.current/);
  const documents = read('components/Documents.tsx');
  assert.match(documents, /headerActions=\{<button[^\n]+Document archive/);
  assert.match(documents, /aria-pressed=\{archiveOpen\}/);
  assert.match(read('components/OcrDocumentsWorkspace.tsx'), /<Star[\s\S]+\{headerActions\}/);
  assert.doesNotMatch(documents, /icon=\{archiveOpen \?/);
});
