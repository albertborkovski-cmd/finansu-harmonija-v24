import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
function load(file, require = name => { throw Error(name); }) {
  const result = {};
  const code = ts.transpileModule(read(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', code)(result, require);
  return result;
}
const actions = load('../src/lib/debtActions.ts');
const { allDebtColumns, DEBT_AGING_GROUPS, debtAgingGroup, debtColumnSortValue, debtColumnValue, restoreDebtColumns } = load('../src/lib/debtTableColumns.ts', name => {
  assert.equal(name, './debtActions'); return actions;
});
const data = load('../src/lib/companyRelatedObjectData.ts').DEBT_ROWS;
const view = read('../src/components/CompanyDebtsView.tsx');
const standard = new Function(`return ${view.match(/const DEFAULT_COLUMNS: ColConfig\[\] = (\[[\s\S]*?\n\]);/)[1]}`)();

test('Aging group offers all five ranges and classifies inclusive boundaries without gaps', () => {
  assert.deepEqual(DEBT_AGING_GROUPS, ['Not overdue', '1–30 days', '31–60 days', '61–90 days', 'Over 90 days']);
  for (const [days, expected] of [[-10, 0], [0, 0], [1, 1], [30, 1], [31, 2], [60, 2], [61, 3], [90, 3], [91, 4], [365, 4]]) {
    assert.equal(debtAgingGroup(days), DEBT_AGING_GROUPS[expected]);
    assert.equal(debtColumnValue({ ...data[0], daysOverdue: days }, 'agingGroup'), DEBT_AGING_GROUPS[expected]);
  }
  for (const days of [NaN, Infinity, -Infinity]) assert.equal(debtAgingGroup(days), '');
  assert.match(view, /\.\.\.defaultColumns\.filter\(column => column.key !== 'actions'\)\.map/);
  assert.match(view, /key: 'agingGroup', label: 'Aging group', options: \[\.\.\.DEBT_AGING_GROUPS\]/);
});

test('Aging group combines with existing tab and multi-value filters without changing selection', () => {
  const rows = [0, 1, 30, 31, 60, 61, 90, 91].flatMap((daysOverdue, index) => ['Buyer', 'Supplier'].map(counterpartyType => ({ ...data[0], id: `${index}-${counterpartyType}`, counterpartyType, daysOverdue })));
  const selectedValues = ['31–60 days', 'Over 90 days'];
  for (const tab of ['Receivables', 'Payables', 'All', 'Overdue']) {
    const filtered = rows.filter(row => actions.debtInTab(row, tab) && selectedValues.includes(String(debtColumnValue(row, 'agingGroup'))));
    assert.deepEqual([...new Set(filtered.map(row => row.daysOverdue))], [31, 60, 91]);
    assert.equal(filtered.length, tab === 'Receivables' || tab === 'Payables' ? 3 : 6);
  }
  assert.match(view, /toggleFilteredSelection\(current, sortedRows.map\(row => row.id\)\)/);
});

test('standard debt tabs default to the requested nine columns and keep all others optional', () => {
  assert.deepEqual(standard.filter(column => column.visible && column.key !== 'actions').map(column => column.label), [
    'Counterparty name', 'Document reference', 'Due date', 'Total amount', 'Paid amount', 'Outstanding amount', 'Currency', 'Days overdue', 'Debt status',
  ]);
  for (const key of ['debtDirection', 'counterpartyCode', 'counterpartyType', 'documentType', 'issueDate', 'reminderStage', 'lastReminderDate', 'nextReminderDate', 'paymentPriority', 'department', 'notes']) {
    assert.equal(standard.find(column => column.key === key).visible, false);
  }
  assert.equal(standard.at(-1).key, 'actions');
  assert.match(view, /company-debts-standard-columns/);
});

test('All adds visible direction after the counterparty; optional reminder date exists in every layout', () => {
  const before = structuredClone(standard);
  const all = allDebtColumns(standard);
  assert.deepEqual(all.filter(column => column.visible && column.key !== 'actions').map(column => column.label), [
    'Counterparty name', 'Debt direction', 'Document reference', 'Due date', 'Total amount', 'Paid amount', 'Outstanding amount', 'Currency', 'Days overdue', 'Debt status',
  ]);
  for (const columns of [standard, all]) {
    assert.equal(columns.find(column => column.key === 'nextReminderDate').visible, false);
    assert.equal(columns.at(-1).key, 'actions');
  }
  all[0].width = 999;
  assert.deepEqual(standard, before);
  assert.equal(debtColumnValue({ ...data[0], nextReminderDate: '20.11.2026' }, 'nextReminderDate'), '20.11.2026');
  assert.equal(debtColumnValue(data[0], 'nextReminderDate'), '');
});

test('new optional columns merge into personal settings without losing order, size or visibility', () => {
  const saved = [{ key: 'totalAmount', visible: true, width: 210 }, { key: 'counterpartyName', visible: false, width: 250 }, { key: 'obsolete', visible: true, width: 100 }, { key: 'actions', visible: false, width: 100 }];
  const columns = restoreDebtColumns(standard, saved);
  assert.equal(columns[0].key, 'totalAmount'); assert.equal(columns[0].width, 210); assert.ok(columns[0].visible);
  assert.equal(columns[1].key, 'counterpartyName'); assert.equal(columns[1].visible, false);
  assert.equal(columns.find(column => column.key === 'nextReminderDate').visible, false);
  assert.equal(columns.at(-1).key, 'actions'); assert.ok(columns.at(-1).visible);
  assert.equal(columns.some(column => column.key === 'obsolete'), false);
  assert.deepEqual(restoreDebtColumns(standard, null), standard);
});

test('Receivables, Payables and Overdue share the nine-column defaults; only All adds direction', () => {
  assert.match(view, /const defaultColumns = activeTab === 'All' \? ALL_COLUMNS : DEFAULT_COLUMNS;/);
  assert.match(view, /const savedColumns = activeTab === 'All' \? allColumns : standardColumns;/);
  assert.doesNotMatch(view, /OVERDUE_COLUMNS|overdueDebtColumns|company-debts-overdue-columns/);
  assert.equal(standard.at(-1).key, 'actions');
  assert.ok(standard.at(-1).visible);
});

test('all previous columns remain selectable and creating All layout does not mutate shared defaults', () => {
  const before = structuredClone(standard);
  const columns = allDebtColumns(standard);
  for (const column of standard) assert.ok(columns.some(item => item.key === column.key));
  for (const key of ['totalAmount', 'paidAmount']) assert.equal(columns.find(column => column.key === key).visible, true);
  assert.equal(new Set(columns.map(column => column.key)).size, columns.length);
  columns[0].width = 999;
  columns.find(column => column.key === 'totalAmount').visible = false;
  assert.deepEqual(standard, before);
});

test('direction values agree with action eligibility and support existing filters and sorting', () => {
  for (const row of data) {
    assert.equal(debtColumnValue(row, 'debtDirection'), actions.debtDirection(row) === 'receivable' ? 'Receivable' : 'Payable');
    assert.equal(debtColumnValue(row, 'documentReference'), row.documentReference);
    assert.equal(debtColumnValue(row, 'outstandingAmount'), row.outstandingAmount);
  }
  assert.equal(debtColumnValue({ ...data[0], direction: undefined, counterpartyType: 'Unknown' }, 'debtDirection'), '—');
  assert.equal(debtColumnValue({ ...data[0], daysOverdue: 0 }, 'daysOverdue'), 0);
});

test('money and dates sort numerically and chronologically instead of as formatted labels', () => {
  const amounts = ['1,200.00', '900.00', '125.25', '0.00', '12,345.67'];
  const rows = amounts.map((totalAmount, index) => ({ ...data[0], id: `sort-${index}`, totalAmount }));
  assert.deepEqual([...rows].sort((a, b) => debtColumnSortValue(a, 'totalAmount') - debtColumnSortValue(b, 'totalAmount')).map(row => row.totalAmount), ['0.00', '125.25', '900.00', '1,200.00', '12,345.67']);
  const dates = ['01.12.2026', '30.11.2026', '2025-12-31', '02.01.2026'];
  const dated = dates.map(dueDate => ({ ...data[0], dueDate }));
  assert.deepEqual(dated.sort((a, b) => debtColumnSortValue(a, 'dueDate') - debtColumnSortValue(b, 'dueDate')).map(row => row.dueDate), ['2025-12-31', '02.01.2026', '30.11.2026', '01.12.2026']);
  assert.equal(debtColumnSortValue({ ...data[0], dueDate: '31.02.2026' }, 'dueDate'), '');
  assert.equal(debtColumnSortValue(data[0], 'nextReminderDate'), '');
});

test('headers and data rows use the shared system scale, equal insets and an unclipped final action column', () => {
  assert.match(view, /system-table-header-row/);
  assert.match(view, /system-table-row group flex min-h-10/);
  assert.match(view, /style=\{\{ minWidth: tableMinWidth \}\}/);
  assert.match(view, /data-debt-cell=\{column.key\}/);
  assert.match(view, /pl-3 pr-\[30px\] text-right tabular-nums/);
  assert.match(view, /flex w-full items-center justify-end gap-1/);
  assert.ok(standard.find(column => column.key === 'actions').width >= 200);
  assert.doesNotMatch(view, /text-\[11px\]/);
  assert.match(view, /useMultiColumnSort\(\s*filteredRows,\s*debtColumnSortValue/);
});

test('shared defaults remain customizable and existing search, filters, selection and details remain', () => {
  assert.match(view, /company-debts-standard-columns/);
  assert.match(view, /company-debts-all-columns/);
  assert.match(view, /layout: `company-debts-\$\{columnGroup\}-v24`, widths: `company-debts-\$\{columnGroup\}-v24`/);
  assert.match(view, /activeTab === 'All' \? allColumns : standardColumns/);
  assert.match(view, /activeTab === 'All' \? setAllColumns : setStandardColumns/);
  assert.match(view, /defaultColumns=\{defaultColumns.filter/);
  assert.match(view, /key === 'daysOverdue' && row.daysOverdue > 0/);
  assert.match(view, /if \(key === 'outstandingAmount'\)/);
  assert.match(view, /font-semibold tabular-nums/);
  for (const control of ['OcrSearchField', 'SystemAddFilters', 'View details', 'HorizontalTableScrollbar', 'toggleFilteredSelection']) assert.ok(view.includes(control));
  assert.match(view, /selectedValues.includes\(String\(debtColumnValue\(row, key\)\)\)/);
});

test('payment badges are separate from overdue days and cover buyer and supplier examples', () => {
  for (const tab of ['Receivables', 'Payables']) {
    const rows = data.filter(row => actions.debtInTab(row, tab));
    assert.deepEqual(new Set(rows.map(row => row.debtStatus)), new Set(['Unpaid', 'Partially paid']));
    assert.ok(rows.some(row => row.daysOverdue > 0));
    assert.ok(rows.some(row => row.daysOverdue === 0));
    for (const row of rows) {
      assert.equal(row.counterpartyType, tab === 'Receivables' ? 'Buyer' : 'Supplier');
      assert.equal(row.documentType, tab === 'Receivables' ? 'Sales invoice' : 'Purchase invoice');
      const total = debtColumnSortValue(row, 'totalAmount');
      const paid = debtColumnSortValue(row, 'paidAmount');
      const outstanding = debtColumnSortValue(row, 'outstandingAmount');
      assert.equal(Math.round((total - paid) * 100), Math.round(outstanding * 100));
      assert.equal(row.debtStatus, paid > 0 ? 'Partially paid' : 'Unpaid');
      const demoDate = Date.UTC(2026, 10, 18);
      assert.equal(row.daysOverdue, Math.max(0, Math.round((demoDate - debtColumnSortValue(row, 'dueDate')) / 86400000)));
    }
  }
  assert.match(view, /title=\{uiText\(row.debtStatus\)\}/);
  assert.match(view, /inline-flex max-w-full items-center gap-1.5 rounded px-2 py-1/);
  assert.doesNotMatch(view, /debtStatus[^\n]*Overdue/);
});
