import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import React from 'react';
import ts from 'typescript';

const read = file => readFileSync(new URL('../src/' + file, import.meta.url), 'utf8');
function parse(file) {
  const source = read(file);
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const nodes = [];
  const visit = node => { nodes.push(node); ts.forEachChild(node, visit); };
  visit(ast);
  return { source, ast, nodes };
}
function evaluate(source, context = {}) {
  const js = ts.transpileModule(`const result = (${source});`, { compilerOptions: { target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.React } }).outputText;
  return new Function('React', ...Object.keys(context), `${js};return result;`)(React, ...Object.values(context));
}

test('both Manage company entry points embed the existing company-scoped counterparties register', () => {
  for (const file of ['components/ManageCompanyView.tsx', 'components/CompanyClientInformation.tsx']) {
    const { ast, nodes } = parse(file);
    const register = nodes.find(node => ts.isJsxSelfClosingElement(node) && node.tagName.getText(ast) === 'Companies' && node.getText(ast).includes('embedded'));
    assert.ok(register);
    const Companies = () => null;
    for (const id of ['alice', 'grace']) {
      const tree = evaluate(register.getText(ast), { Companies, company: { id } });
      assert.equal(tree.type, Companies);
      assert.equal(tree.props.counterpartyCompanyId, id);
      assert.equal(tree.props.dataSource, 'counterparties');
      assert.equal(tree.props.entityLabel, 'counterparty');
      assert.equal(tree.props.embedded, true);
      assert.equal(tree.props.allowCreate, true);
    }
  }
  const manage = parse('components/ManageCompanyView.tsx');
  const sections = manage.nodes.find(node => ts.isVariableDeclaration(node) && node.name.getText(manage.ast) === 'SECTIONS');
  assert.deepEqual(evaluate(sections.initializer.getText(manage.ast)).slice(0, 2), ['General & status', 'Counterparties']);
  assert.match(read('components/Companies.tsx'), /company-counterparties:\$\{counterpartyCompanyId\}/);
  assert.match(read('components/CompanyDetail.tsx'), /dataSource="counterparties" counterpartyCompanyId=\{currentCompany.id\}/);
});

test('document types and Activity Log are Settings items with unchanged stored access keys', () => {
  const { ast, nodes, source } = parse('components/Sidebar.tsx');
  const array = name => {
    const node = nodes.find(node => ts.isVariableDeclaration(node) && node.name.getText(ast) === name);
    const code = node.initializer.getText(ast);
    const iconNames = [...code.matchAll(/icon: (\w+)/g)].map(match => match[1]);
    return evaluate(code, Object.fromEntries(iconNames.map(name => [name, () => null])));
  };
  const settings = array('organizationReferenceItems');
  assert.ok(settings.some(item => item.id === 'ocr-admin-document-type' && item.label === 'Document type'));
  assert.ok(settings.some(item => item.id === 'ocr-admin-activity' && item.label === 'Activity Log'));
  assert.deepEqual(settings.slice(-2).map(item => item.id), ['settings-organizations-document-status', 'ocr-admin-activity']);
  assert.equal(array('ocrSubMenuItems').some(item => item.id === 'ocr-admin'), false);
  const movedNode = nodes.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'isGeneralSettingsOcrMenu');
  const moved = evaluate(movedNode.getText(ast));
  for (const fn of ['isOcrSection', 'isSettingsActive']) {
    const node = nodes.find(node => ts.isFunctionDeclaration(node) && node.name?.text === fn);
    const check = evaluate(node.getText(ast), { isGeneralSettingsOcrMenu: moved });
    for (const menu of ['ocr-admin-document-type', 'ocr-admin-activity', 'ocr-admin-activity-ocr', 'ocr-admin-activity-fh']) assert.equal(check(menu), fn === 'isSettingsActive');
  }
  assert.match(source, /setSettingsExpanded\(true\); setOrganizationsExpanded\(true\)/);
  assert.match(read('components/AdministrationView.tsx'), /SystemBreadcrumb items=\{\['Settings', 'General settings', 'Activity Log', title\]\}/);
  const dashboard = read('components/Dashboard.tsx');
  assert.match(dashboard, /displayTitle=\{activeMenu === "settings-organizations-document-status" \? "Finansų harmonija"/);
  assert.match(dashboard, /\["Settings", "General settings", "Status"\]/);
  assert.match(dashboard, /["']ocr-admin-activity-ocr["']:\s*["']activity["']/);
  assert.match(dashboard, /["']ocr-admin-activity-fh["']:\s*["']activity-fh["']/);
  assert.doesNotMatch(dashboard, /breadcrumbParents=\{activeMenu === "ocr-admin-document-type" \? \["OCR", "Administration"\]/);
});
