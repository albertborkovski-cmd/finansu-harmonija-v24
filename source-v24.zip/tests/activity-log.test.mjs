import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const cache = new Map();
function load(name) {
  if (cache.has(name)) return cache.get(name);
  const api = {};
  cache.set(name, api);
  const source = readFileSync(new URL('../src/lib/' + name.replace('./', '') + '.ts', import.meta.url), 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', code)(api, load);
  return api;
}
const { activityLogScope, activityLogRows } = load('./activityLog');

test('OCR process history and financial operations are shown in separate logs', () => {
  for (const record of [{ module: 'OCR' }, { category: 'Machine learning' }, { action: 'Detailed digitization requested' }, { action: 'Issue resolved' }, { action: 'Sent to TeamLead' }])
    assert.equal(activityLogScope(record), 'ocr');
  for (const record of [{ category: 'Bank' }, { action: 'Updated' }, { action: 'Approved' }, { category: 'Accounting transfer test' }])
    assert.equal(activityLogScope(record), 'fh');
  const records = Object.freeze([
    Object.freeze({ id: 'old', document_id: 'doc', action: 'Updated', user_name: 'Accountant', details: 'Changed reference', created_at: '2026-11-10T10:00:00Z' }),
    Object.freeze({ id: 'ocr', document_id: 'doc', action: 'Issue resolved', created_at: '2026-11-12T10:00:00Z' }),
    Object.freeze({ id: 'new', organization_id: 'alice', action: 'Approved', created_at: '2026-11-13T10:00:00Z' }),
  ]);
  const documents = [{ id: 'doc', company_id: 'alice', number: 'INV-001' }];
  const allowed = new Set(['alice']);
  assert.deepEqual(activityLogRows(records, documents, allowed, 'fh').map(row => row.id), ['new', 'old']);
  const ocr = activityLogRows(records, documents, allowed, 'ocr');
  assert.equal(ocr.length, 1);
  assert.equal(ocr[0].name, 'INV-001');
  const old = activityLogRows(records, documents, allowed, 'fh')[1];
  assert.equal(old.user, 'Accountant');
  assert.equal(old.fields, 'Changed reference');
  assert.equal(records[0].id, 'old');
});

test('history excludes inaccessible companies and orphan document records', () => {
  const rows = activityLogRows([
    { id: 'allowed', document_id: 'a' },
    { id: 'restricted', document_id: 'b' },
    { id: 'explicit-restricted', document_id: 'a', organization_id: 'grace' },
    { id: 'orphan', document_id: 'missing' },
    { id: 'deleted', document_id: 'deleted', organization_id: 'alice' },
  ], [{ id: 'a', company_id: 'alice' }, { id: 'b', company_id: 'grace' }], new Set(['alice']), 'fh');
  assert.deepEqual(rows.map(row => row.id), ['allowed', 'deleted']);
});

test('new activity child routes inherit existing parent permissions without granting access', () => {
  const { canViewMenu, canEditMenu, createFullAccess } = load('./accessControl');
  for (const [view, edit] of [[true, true], [true, false], [false, false]]) {
    const session = { roleNames: ['Accountant'], access: createFullAccess(), menuAccess: { 'ocr-admin-activity': { view, edit } } };
    for (const child of ['ocr-admin-activity-ocr', 'ocr-admin-activity-fh']) {
      assert.equal(canViewMenu(session, child), view);
      assert.equal(canEditMenu(session, child), edit);
      assert.equal(canViewMenu({ ...session, roleNames: ['Inactive'] }, child), false);
      assert.equal(canEditMenu({ ...session, roleNames: ['Inactive'] }, child), false);
    }
  }
});
