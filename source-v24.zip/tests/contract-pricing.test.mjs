import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = name => readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');
function fixture() {
  let admin = true;
  const values = new Map(), storage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) };
  const api = {};
  const saas = {};
  new Function('exports', ts.transpileModule(source('lib/companySaas.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(saas);
  const output = ts.transpileModule(source('lib/contractPricing.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', output)(api, name => name === './accessControl' ? {
    parseSession: () => ({ email: 'admin@example.test', roleNames: [admin ? 'Administrator' : 'Accountant'] }),
    isSystemAdministratorRole: role => role === 'Administrator',
  } : name === './companySaas' ? saas : { AUTH_SESSION_KEY: 'auth' });
  return { api, storage, values, revoke: () => { admin = false; } };
}
test('nine progressive tiers reproduce supplied rates and the 1300-document example', () => {
  const { api } = fixture(), plan = api.defaultContractPricing().plans[0];
  assert.equal(plan.tiers.length, 9);
  assert.deepEqual(plan.tiers.map(api.discountedDocumentPrice), [30, 28.5, 27, 25.5, 24, 22.5, 21, 19.5, 18]);
  assert.equal(api.contractDocumentCostCents(plan, 0), 0);
  assert.equal(api.contractDocumentCostCents(plan, 251), 7528.5);
  assert.equal(api.contractExample(plan).total, 358.75);
  assert.equal(api.contractDocumentCostCents(plan, 10001) - api.contractDocumentCostCents(plan, 10000), 18);
  assert.throws(() => api.contractDocumentCostCents(plan, -1));
});
test('administrator changes one tier only, keeps audit and recalculates values', () => {
  const { api, storage } = fixture(), initial = api.readContractPricing(storage);
  const next = api.saveContractPricing(storage, 0, { kind: 'tier', planId: initial.plans[0].id, tierId: 'tier-2', basePriceCents: 40, discountPercent: 10 });
  assert.equal(api.discountedDocumentPrice(next.plans[0].tiers[1]), 36);
  assert.deepEqual(next.plans[0].tiers[0], initial.plans[0].tiers[0]);
  assert.equal(next.history[0].by, 'admin@example.test'); assert.equal(next.history[0].previous.basePriceCents, 30);
  assert.equal(next.revision, 1); assert.deepEqual(api.readContractPricing(storage), next);
  assert.ok(api.contractExample(next.plans[0]).total > 358.75);
});
test('new plans are independent copies and changing line billing affects only selected plan', () => {
  const { api, storage } = fixture(), original = api.defaultContractPricing().plans[0];
  let result = api.saveContractPricing(storage, 0, { kind: 'create', sourcePlanId: original.id, name: 'Custom SaaS' });
  const custom = result.plans[1];
  assert.notEqual(custom.id, original.id); assert.deepEqual(custom.tiers, original.tiers);
  result = api.saveContractPricing(storage, 1, { kind: 'lines', planId: custom.id, linePriceCents: 4, minimumLines: 10 });
  assert.deepEqual(result.plans[0], original);
  assert.equal(api.contractExample(result.plans[1]).lineCount, 100);
  assert.equal(api.contractExample(result.plans[1]).total, 361.75);
});
test('fresh permissions, stale revisions and invalid edits cannot modify saved pricing', () => {
  const f = fixture(), plan = f.api.defaultContractPricing().plans[0];
  const edit = { kind: 'tier', planId: plan.id, tierId: 'tier-1', basePriceCents: 30, discountPercent: 5 };
  f.api.saveContractPricing(f.storage, 0, edit);
  const original = f.storage.getItem(f.api.CONTRACT_PRICING_KEY);
  assert.throws(() => f.api.saveContractPricing(f.storage, 0, edit), /changed/);
  for (const patch of [{ basePriceCents: -1 }, { basePriceCents: NaN }, { discountPercent: 101 }, { discountPercent: -1 }]) assert.throws(() => f.api.saveContractPricing(f.storage, 1, { ...edit, ...patch }));
  assert.throws(() => f.api.saveContractPricing(f.storage, 1, { kind: 'create', sourcePlanId: plan.id, name: plan.name }));
  f.revoke(); assert.equal(f.api.canManageContractPricing(f.storage), false);
  assert.throws(() => f.api.saveContractPricing(f.storage, 1, edit), /administrator/);
  assert.equal(f.storage.getItem(f.api.CONTRACT_PRICING_KEY), original);
});
test('malformed catalogs are not silently reset; storage errors are surfaced', () => {
  const f = fixture(), plan = f.api.defaultContractPricing().plans[0];
  for (const value of ['broken', 'null', JSON.stringify({ revision: 1, plans: [null], history: [] })]) {
    f.values.set(f.api.CONTRACT_PRICING_KEY, value);
    assert.throws(() => f.api.readContractPricing(f.storage), /could not be loaded/);
    assert.equal(f.storage.getItem(f.api.CONTRACT_PRICING_KEY), value);
  }
  f.values.clear();
  assert.throws(() => f.api.saveContractPricing({ ...f.storage, setItem() { throw Error('Quota'); } }, 0, { kind: 'lines', planId: plan.id, linePriceCents: 2, minimumLines: 5 }), /Quota/);
});
test('profile selects published plans without exposing any pricing administration', () => {
  const view = source('components/ContractPricingPanel.tsx'), client = source('components/ClientPlanSelection.tsx');
  assert.match(view, /props.administration/); assert.match(view, /ClientPlanSelection/);
  assert.match(client, /SearchableSelect/); assert.match(client, /aria-pressed=\{checked\}/);
  assert.doesNotMatch(client, /saveContractPricing|New pricing plan|PencilLine|ContractPlanOptionsFields|SAAS_MODULES/);
  assert.match(client, /SAAS_PRODUCTS/); assert.match(client, /SAAS_PRICING/);
  assert.match(source('components/ContractSettings.tsx'), /selectedPlanId=\{currentPlanId\}/);
  assert.match(source('components/ContractSettings.tsx'), /planSnapshot: plan/);
});

test('legacy pricing keeps exact rates and defaults without rewriting the catalog', () => {
  const f = fixture(), legacy = f.api.defaultContractPricing();
  f.values.set(f.api.CONTRACT_PRICING_KEY, JSON.stringify(legacy));
  const plan = f.api.readContractPricing(f.storage).plans[0];
  assert.equal(f.api.contractDocumentPricing(plan), 'progressive');
  assert.equal(f.api.hasProgressiveDocumentPricing(plan), true);
  assert.equal(f.api.contractExample(plan).total, 358.75);
  const options = f.api.contractPlanSaas(plan); options.moduliai.push('dropbox');
  assert.deepEqual(f.api.contractPlanSaas(plan).moduliai, ['email', 'api']);
  assert.equal(f.values.get(f.api.CONTRACT_PRICING_KEY), JSON.stringify(legacy));
});

test('plan options persist independently, are audited and survive pricing model changes', () => {
  const f = fixture(), original = f.api.defaultContractPricing().plans[0];
  const saas = { ...f.api.contractPlanSaas(original), produktas: 'ocr', kainodara: 'users', kiekis: '8000', kaina: '19.95', periodas: 'year', virsijimas: 'block', moduliai: ['email', 'sharepoint', 'dropbox', 'google_drive', 'api', 'rivile_export'] };
  let next = f.api.saveContractPricing(f.storage, 0, { kind: 'create', sourcePlanId: original.id, name: 'OCR Pro', saas, documentPricing: 'flat' });
  const created = next.plans[1];
  assert.deepEqual(created.saas, saas); assert.deepEqual(next.plans[0], original);
  saas.moduliai.length = 0;
  assert.equal(created.saas.moduliai.length, 6);
  assert.equal(f.api.hasProgressiveDocumentPricing(created), false);
  next = f.api.saveContractPricing(f.storage, 1, { kind: 'configuration', planId: created.id, name: 'OCR Pro annual', saas: { ...created.saas, kainodara: 'fixed', kaina: '149' }, documentPricing: 'flat' });
  assert.equal(next.history[1].area, 'configuration');
  assert.equal(next.history[1].previous.saas.kainodara, 'users');
  assert.equal(next.history[1].next.saas.kaina, '149');
  assert.deepEqual(next.plans[1].tiers, original.tiers);
  assert.deepEqual(f.api.readContractPricing(f.storage), next);
  next = f.api.saveContractPricing(f.storage, 2, { kind: 'configuration', planId: created.id, name: created.name, saas: { ...created.saas, kainodara: 'docs' }, documentPricing: 'progressive' });
  assert.equal(f.api.hasProgressiveDocumentPricing(next.plans[1]), true);
  assert.equal(f.api.contractExample(next.plans[1]).total, 358.75);
  assert.deepEqual(next.plans[0], original);
});

test('flat document pricing uses the configured rate instead of progressive tiers', () => {
  const f = fixture(), plan = f.api.defaultContractPricing().plans[0];
  const next = f.api.saveContractPricing(f.storage, 0, { kind: 'configuration', planId: plan.id, name: plan.name, documentPricing: 'flat', saas: { ...f.api.contractPlanSaas(plan), kaina: '0.08' } });
  assert.equal(f.api.contractDocumentCostCents(next.plans[0], 1300), 10400);
  assert.equal(f.api.contractExample(next.plans[0]).total, 105);
  assert.deepEqual(next.plans[0].tiers, plan.tiers);
});

test('invalid SaaS options, stale saves and revoked rights cannot change configuration', () => {
  const f = fixture(), plan = f.api.defaultContractPricing().plans[0];
  const edit = { kind: 'configuration', planId: plan.id, name: plan.name, documentPricing: 'progressive', saas: f.api.contractPlanSaas(plan) };
  f.api.saveContractPricing(f.storage, 0, edit);
  const saved = f.storage.getItem(f.api.CONTRACT_PRICING_KEY);
  for (const patch of [{ produktas: 'missing' }, { kainodara: 'free' }, { periodas: 'week' }, { virsijimas: 'ignore' }, { kiekis: '0' }, { kiekis: '2.5' }, { kaina: '-1' }, { kaina: 'x' }, { moduliai: ['unknown'] }, { moduliai: null }]) {
    assert.throws(() => f.api.saveContractPricing(f.storage, 1, { ...edit, saas: { ...edit.saas, ...patch } }));
  }
  assert.throws(() => f.api.saveContractPricing(f.storage, 1, { ...edit, documentPricing: 'unknown' }));
  assert.throws(() => f.api.saveContractPricing(f.storage, 0, edit), /changed/);
  f.revoke(); assert.throws(() => f.api.saveContractPricing(f.storage, 1, edit), /administrator/);
  assert.equal(f.storage.getItem(f.api.CONTRACT_PRICING_KEY), saved);
});

test('plan editor shares every company SaaS option and changes the displayed pricing with the model', () => {
  const editor = source('components/ContractPlanOptions.tsx'), view = source('components/SaasPlansPricing.tsx');
  for (const registry of ['SAAS_PRODUCTS', 'SAAS_PRICING', 'SAAS_PERIODS', 'SAAS_OVERAGE', 'SAAS_MODULES']) assert.match(editor, new RegExp(registry));
  assert.match(editor, /MultiSelectField/); assert.match(editor, /portalMenu/);
  assert.match(view, /SAAS_PRODUCTS/); assert.match(view, /SAAS_PRICING/); assert.match(view, /contractDocumentPricing/);
  assert.match(source('components/SaasAdministration.tsx'), /plan \? contractPlanSaas\(plan\) : parseCompanySaasPlan/);
});
