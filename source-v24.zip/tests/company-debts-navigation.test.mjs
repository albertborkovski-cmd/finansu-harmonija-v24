import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const source = readFileSync(new URL('../src/components/CompanyDetail.tsx', import.meta.url), 'utf8');
test('Debts opens the existing list directly without any submenu', () => {
  assert.match(source, /id: 'reports',\s+label: 'Debts'/);
  const submenus = source.match(/const COMPANY_SUBMENU_IDS = \[([^\]]+)\]/)?.[1];
  assert.ok(submenus); assert.doesNotMatch(submenus, /reports/);
  assert.doesNotMatch(source, /company-reports-submenu|label: 'Debt list'/);
  assert.doesNotMatch(source, /activeDebtsMenu|setActiveDebtsMenu|import CompanyDebts from|<CompanyDebts\s/);
  assert.match(source, /activeMenu === 'reports' \? \(\s*<CompanyDebtsView/);
  assert.match(source, /initialRecordId=\{relatedObject\?\.type === 'Debt' \? relatedRecordId : undefined\}/);
  const list = readFileSync(new URL('../src/components/CompanyDebtsView.tsx', import.meta.url), 'utf8');
  assert.match(list, /items=\{\["Debts"\]\}/);
});

test('company information and Manage company remain available outside Debts', () => {
  assert.match(source, /activeCompanyInformationMenu/);
  assert.match(source, /label: 'Client information'|\s+'Client information',/);
  assert.match(source, /<CompanyClientInformation[^>]*activeTab="Client information"/);
});
