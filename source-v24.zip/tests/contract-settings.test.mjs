import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const read = file => readFileSync(new URL('../src/' + file, import.meta.url), 'utf8');
const api = {};
new Function('exports', 'require', ts.transpileModule(read('lib/contractDetails.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText)(api, () => ({ validateContractPlan: plan => plan?.id && Array.isArray(plan.tiers) ? '' : 'invalid' }));
const valid = { companyName: 'Example UAB', companyCode: '123456789', vatCode: '', representative: 'Test Person', address: 'Test address', country: 'LT' };
test('company fields required, VAT optional, country must come from searchable list', () => {
  assert.deepEqual(api.validateContractDetails(valid), {});
  for (const field of ['companyName', 'companyCode', 'representative', 'address', 'country']) assert.ok(api.validateContractDetails({ ...valid, [field]: ' ' })[field]);
  assert.ok(api.validateContractDetails({ ...valid, country: 'not-a-country' }).country);
  assert.ok(api.contractCountries('lt').some(country => country.value === 'LT' && country.label === 'Lietuva'));
  assert.ok(api.contractCountries('en').length > 240);
});
test('confirmation saves per-user details, never claims a signed contract, and does not overwrite on validation failure', () => {
  const values = new Map(), storage = { getItem: key => values.get(key) || null, setItem: (key, value) => values.set(key, value) };
  const result = api.confirmContractDetails(storage, 'test@example.com', valid);
  assert.equal(result.status, 'details-confirmed'); assert.equal(result.signedAt, undefined);
  assert.deepEqual(api.readContractDetails(storage, 'test@example.com', 'Fallback'), valid);
  assert.equal(api.readContractDetails(storage, 'other@example.com', 'Other').companyName, '');
  assert.throws(() => api.confirmContractDetails(storage, 'test@example.com', { ...valid, companyName: '' }));
  assert.deepEqual(api.readContractDetails(storage, 'test@example.com', 'Fallback'), valid);
  assert.throws(() => api.confirmContractDetails({ setItem() { throw Error('Quota'); } }, 'test@example.com', valid));
});
test('all nine supplied tiers and FH form components are present', () => {
  const view = read('components/ContractSettings.tsx'), profile = read('components/ProfileSettings.tsx');
  assert.match(profile, /id: 'contract', label: 'Update contract'/);
  assert.match(view, /SearchableSelect/); assert.match(view, /PageActionButton/);
  assert.match(view, /ContractPricingPanel/); assert.doesNotMatch(view, /Ivesk|Įvesk/);
  assert.match(read('i18n/lt-document-settings.ts'), /'This field is required.': 'Šį lauką būtina užpildyti.'/);
});
test('selected plan and a detached pricing snapshot are saved with company details', () => {
  const values = new Map(), storage = { getItem: key => values.get(key) || null, setItem: (key, value) => values.set(key, value) };
  const pricing = { planId: 'custom', pricingRevision: 2, planSnapshot: { id: 'custom', tiers: [{ basePriceCents: 30 }] } };
  const saved = api.confirmContractDetails(storage, 'test@example.com', valid, pricing);
  pricing.planSnapshot.tiers[0].basePriceCents = 99;
  assert.equal(api.readContractPlanId(storage, 'test@example.com'), 'custom');
  assert.equal(saved.pricing.planSnapshot.tiers[0].basePriceCents, 30);
  assert.equal(api.readContractPlanId(storage, 'other@example.com'), 'documents-and-lines');
  const snapshot = api.readConfirmedContractPlan(storage, 'test@example.com');
  assert.equal(snapshot.tiers[0].basePriceCents, 30);
  snapshot.tiers[0].basePriceCents = 77;
  assert.equal(api.readConfirmedContractPlan(storage, 'test@example.com').tiers[0].basePriceCents, 30);
});

test('selected document range persists with the plan without rewriting shared prices', () => {
  const values = new Map(), storage = { getItem: key => values.get(key) || null, setItem: (key, value) => values.set(key, value) };
  const pricing = { planId: 'custom', pricingRevision: 2, tierId: 'volume-2', planSnapshot: { id: 'custom', tiers: [{ id: 'volume-1', basePriceCents: 30 }, { id: 'volume-2', basePriceCents: 28.5 }] } };
  api.confirmContractDetails(storage, 'test@example.com', valid, pricing);
  assert.equal(api.readContractTierId(storage, 'test@example.com'), 'volume-2');
  assert.equal(api.readContractTierId(storage, 'other@example.com'), '');
  assert.deepEqual(api.readConfirmedContractPlan(storage, 'test@example.com').tiers, pricing.planSnapshot.tiers);
  const previous = values.get(api.contractStorageKey('test@example.com'));
  assert.throws(() => api.confirmContractDetails(storage, 'test@example.com', valid, { ...pricing, tierId: 'missing' }));
  assert.equal(values.get(api.contractStorageKey('test@example.com')), previous);
  assert.equal(values.size, 1);
});
